const { Document, Paragraph, TextRun, HeadingLevel, Table, TableRow, TableCell, 
  AlignmentType, TableOfContents, Header, Footer, ShadingType, PageBreak,
  WidthType, BorderStyle, Packer } = require("docx");
const fs = require("fs");
const path = require("path");

// Create document
const doc = new Document({
  title: "Advanced Analytics Platform - Technical Documentation",
  description: "Comprehensive documentation with code examples",
  styles: {
    paragraphStyles: [
      {
        id: "CodeBlock",
        name: "Code Block",
        basedOn: "Normal",
        next: "Normal",
        run: {
          font: "Courier New",
          size: 20,
          color: "333333",
        },
        paragraph: {
          spacing: {
            before: 240,
            after: 240,
          },
          indent: {
            left: 720,
          },
        },
      },
    ],
  },
});

// Add title page
doc.addSection({
  children: [
    new Paragraph({
      text: "Advanced Analytics Platform",
      heading: HeadingLevel.TITLE,
      alignment: AlignmentType.CENTER,
      spacing: {
        before: 3000,
        after: 400,
      },
    }),
    new Paragraph({
      text: "Technical Documentation",
      heading: HeadingLevel.HEADING_1,
      alignment: AlignmentType.CENTER,
      spacing: {
        after: 400,
      },
    }),
    new Paragraph({
      text: "Generated: May 10, 2025",
      alignment: AlignmentType.CENTER,
      spacing: {
        after: 4000,
      },
    }),
    new Paragraph({
      pageBreakBefore: true,
      text: "Table of Contents",
      heading: HeadingLevel.HEADING_1,
      spacing: {
        after: 400,
      },
    }),
    new TableOfContents("Table of Contents", {
      hyperlink: true,
      headingStyleRange: "1-3",
    }),
    new PageBreak(),
  ],
});

// Add Executive Summary section
doc.addSection({
  children: [
    new Paragraph({
      text: "1. Executive Summary",
      heading: HeadingLevel.HEADING_1,
    }),
    new Paragraph({
      text: "The Advanced Analytics Platform is a sophisticated web-based application designed to provide comprehensive analytics capabilities through multi-source data integration, real-time tracking, and AI-powered insights.",
    }),
    new Paragraph({
      text: "Key features include:",
      spacing: {
        before: 200,
      },
    }),
    new Paragraph({
      text: "• Multi-provider analytics integration (Google, Adobe, Mixpanel, etc.)",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "• Real-time user behavior tracking and monitoring",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "• AI-powered insights using OpenAI's GPT-4o model",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "• Predictive analytics capabilities",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "• Custom tracking script for authentic data collection",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      pageBreakBefore: true,
      text: "2. Project Architecture",
      heading: HeadingLevel.HEADING_1,
    }),
    new Paragraph({
      text: "2.1 Technology Stack",
      heading: HeadingLevel.HEADING_2,
    }),
  ],
});

// Create a technology stack table
const techStackTable = new Table({
  rows: [
    new TableRow({
      children: [
        new TableCell({
          width: {
            size: 3000,
            type: WidthType.DXA,
          },
          children: [new Paragraph({ text: "Component", bold: true })],
          shading: {
            fill: "EEEEEE",
          },
        }),
        new TableCell({
          width: {
            size: 6000,
            type: WidthType.DXA,
          },
          children: [new Paragraph({ text: "Technology", bold: true })],
          shading: {
            fill: "EEEEEE",
          },
        }),
      ],
    }),
    new TableRow({
      children: [
        new TableCell({
          children: [new Paragraph("Frontend")],
        }),
        new TableCell({
          children: [new Paragraph("React, TypeScript, TailwindCSS, Shadcn/UI")],
        }),
      ],
    }),
    new TableRow({
      children: [
        new TableCell({
          children: [new Paragraph("Backend")],
        }),
        new TableCell({
          children: [new Paragraph("Node.js, Express")],
        }),
      ],
    }),
    new TableRow({
      children: [
        new TableCell({
          children: [new Paragraph("Database")],
        }),
        new TableCell({
          children: [new Paragraph("PostgreSQL with Drizzle ORM")],
        }),
      ],
    }),
    new TableRow({
      children: [
        new TableCell({
          children: [new Paragraph("State Management")],
        }),
        new TableCell({
          children: [new Paragraph("TanStack Query")],
        }),
      ],
    }),
    new TableRow({
      children: [
        new TableCell({
          children: [new Paragraph("AI Integration")],
        }),
        new TableCell({
          children: [new Paragraph("OpenAI API (GPT-4o)")],
        }),
      ],
    }),
    new TableRow({
      children: [
        new TableCell({
          children: [new Paragraph("Real-time")],
        }),
        new TableCell({
          children: [new Paragraph("WebSockets (ws)")],
        }),
      ],
    }),
  ],
});

// Add the table to the document
doc.addSection({
  children: [
    techStackTable,
    new Paragraph({
      text: "2.2 System Architecture",
      heading: HeadingLevel.HEADING_2,
      spacing: {
        before: 400,
      },
    }),
    new Paragraph({
      text: "The architecture follows a modern client-server model with a clear separation between frontend and backend, RESTful API design principles, PostgreSQL database for persistent storage, and modular component structure for maintainability.",
    }),
    new Paragraph({
      text: "Schema Definition Example:",
      bold: true,
      spacing: {
        before: 200,
        after: 100,
      },
    }),
  ],
});

// Add code example for schema
doc.addSection({
  children: [
    new Paragraph({
      style: "CodeBlock",
      text: [
        "// shared/schema.ts",
        "import { pgTable, serial, text, timestamp, boolean, integer } from 'drizzle-orm/pg-core';",
        "import { createInsertSchema } from 'drizzle-zod';",
        "import { z } from 'zod';",
        "",
        "// User model",
        "export const users = pgTable('users', {",
        "  id: serial('id').primaryKey(),",
        "  username: text('username').notNull().unique(),",
        "  passwordHash: text('password_hash').notNull(),",
        "  email: text('email'),",
        "  createdAt: timestamp('created_at').defaultNow().notNull(),",
        "});",
        "",
        "// Website model for tracking analytics",
        "export const websites = pgTable('websites', {",
        "  id: serial('id').primaryKey(),",
        "  name: text('name').notNull(),",
        "  url: text('url').notNull(),",
        "  userId: integer('user_id').references(() => users.id),",
        "  createdAt: timestamp('created_at').defaultNow().notNull(),",
        "  isActive: boolean('is_active').default(true),",
        "});",
        "",
        "// Define TypeScript types",
        "export type User = typeof users.$inferSelect;",
        "export type Website = typeof websites.$inferSelect;",
      ].join("\n"),
      shading: {
        type: ShadingType.SOLID,
        color: "F5F5F5",
      },
    }),
    new Paragraph({
      pageBreakBefore: true,
      text: "3. Frontend Implementation",
      heading: HeadingLevel.HEADING_1,
    }),
    new Paragraph({
      text: "3.1 User Interface Components",
      heading: HeadingLevel.HEADING_2,
    }),
    new Paragraph({
      text: "The frontend is built with React and TypeScript, organized into a modular component structure. Key components include:",
    }),
    new Paragraph({
      text: "• MetricsOverview: Displays high-level analytics metrics",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "• RealTimeAnalytics: Shows real-time user activity",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "• DataSourceBadge: Visual indicator for data sources",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "• AIInsights: Displays AI-generated analysis",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "DataSourceBadge Component Example:",
      bold: true,
      spacing: {
        before: 200,
        after: 100,
      },
    }),
  ],
});

// Add code example for data source badge
doc.addSection({
  children: [
    new Paragraph({
      style: "CodeBlock",
      text: [
        "// client/src/components/ui/data-source-badge.tsx",
        "import { Info } from \"lucide-react\";",
        "import { Badge } from \"@/components/ui/badge\";",
        "import { cn } from \"@/lib/utils\";",
        "",
        "interface DataSourceBadgeProps {",
        "  sourceName: string;",
        "  providerName?: string;",
        "  className?: string;",
        "}",
        "",
        "export function DataSourceBadge({",
        "  sourceName,",
        "  providerName,",
        "  className",
        "}: DataSourceBadgeProps) {",
        "  return (",
        "    <div className={cn(",
        "      \"absolute top-0 right-0 text-white text-xs px-2 py-1 rounded-bl-md bg-gradient-to-r\",",
        "      className || \"from-blue-600 to-blue-700\"",
        "    )}>",
        "      Source: {providerName || sourceName}",
        "    </div>",
        "  );",
        "}",
        "",
        "interface DataSourceHeaderProps {",
        "  sourceName: string;",
        "  className?: string;",
        "}",
        "",
        "export function DataSourceHeader({",
        "  sourceName,",
        "  className",
        "}: DataSourceHeaderProps) {",
        "  return (",
        "    <div className={cn(",
        "      \"flex items-center bg-gradient-to-r from-primary-50 to-transparent p-3 rounded-md border border-primary-100\",",
        "      className",
        "    )}>",
        "      <Info className=\"h-5 w-5 text-primary-600 mr-2\" />",
        "      <span className=\"text-sm font-medium text-gray-700\">",
        "        Showing authentic analytics data from:",
        "      </span>",
        "      <Badge variant=\"outline\" className=\"ml-2 bg-primary-100 text-primary-700 border-primary-200 font-bold\">",
        "        {sourceName}",
        "      </Badge>",
        "    </div>",
        "  );",
        "}",
      ].join("\n"),
      shading: {
        type: ShadingType.SOLID,
        color: "F5F5F5",
      },
    }),
    new Paragraph({
      pageBreakBefore: true,
      text: "3.2 State Management",
      heading: HeadingLevel.HEADING_2,
    }),
    new Paragraph({
      text: "The application uses TanStack Query for efficient data fetching, caching, and state management. This provides automatic refetching of stale data, optimistic updates for mutations, and structured cache invalidation.",
    }),
    new Paragraph({
      text: "Query Client Configuration:",
      bold: true,
      spacing: {
        before: 200,
        after: 100,
      },
    }),
  ],
});

// Add code example for query client
doc.addSection({
  children: [
    new Paragraph({
      style: "CodeBlock",
      text: [
        "// client/src/lib/queryClient.ts",
        "import { QueryClient } from '@tanstack/react-query';",
        "",
        "// Create a custom fetch function for API requests",
        "export async function apiRequest(",
        "  url: string,",
        "  method: 'GET' | 'POST' | 'PATCH' | 'DELETE' = 'GET',",
        "  body?: any",
        ") {",
        "  const options: RequestInit = {",
        "    method,",
        "    headers: {",
        "      'Content-Type': 'application/json',",
        "    },",
        "    credentials: 'include',",
        "  };",
        "",
        "  if (body && method !== 'GET') {",
        "    options.body = JSON.stringify(body);",
        "  }",
        "",
        "  const response = await fetch(url, options);",
        "",
        "  if (!response.ok) {",
        "    const errorData = await response.json().catch(() => ({}));",
        "    throw new Error(",
        "      errorData.message || `API request failed with status ${response.status}`",
        "    );",
        "  }",
        "",
        "  if (response.status === 204) {",
        "    return null; // No content",
        "  }",
        "",
        "  return response.json();",
        "}",
        "",
        "// Configure and export the query client",
        "export const queryClient = new QueryClient({",
        "  defaultOptions: {",
        "    queries: {",
        "      staleTime: 1000 * 60 * 5, // 5 minutes",
        "      retry: 1,",
        "    },",
        "  },",
        "});",
      ].join("\n"),
      shading: {
        type: ShadingType.SOLID,
        color: "F5F5F5",
      },
    }),
    new Paragraph({
      pageBreakBefore: true,
      text: "4. Backend Implementation",
      heading: HeadingLevel.HEADING_1,
    }),
    new Paragraph({
      text: "4.1 API Design",
      heading: HeadingLevel.HEADING_2,
    }),
    new Paragraph({
      text: "The backend follows RESTful principles with endpoints for website management, analytics data retrieval, user event tracking, insights generation, and external website catalog.",
    }),
    new Paragraph({
      text: "API Routes Implementation:",
      bold: true,
      spacing: {
        before: 200,
        after: 100,
      },
    }),
  ],
});

// Add code example for API routes
doc.addSection({
  children: [
    new Paragraph({
      style: "CodeBlock",
      text: [
        "// server/routes.ts",
        "import { Express, Request, Response } from 'express';",
        "import { Server } from 'http';",
        "import { WebSocketServer } from 'ws';",
        "import { z } from 'zod';",
        "import { storage } from './storage';",
        "import { insertUserSchema, insertWebsiteSchema } from '@shared/schema';",
        "",
        "// WebSocket clients for real-time updates",
        "const clients = new Set<WebSocket>();",
        "",
        "export async function registerRoutes(app: Express): Promise<Server> {",
        "  // Create a HTTP server instance",
        "  const httpServer = require('http').createServer(app);",
        "  ",
        "  // Initialize WebSocket server",
        "  const wss = new WebSocketServer({ server: httpServer, path: '/api/ws' });",
        "  ",
        "  wss.on('connection', (ws: WebSocket) => {",
        "    clients.add(ws);",
        "    console.log('Client connected');",
        "    ",
        "    ws.on('close', () => {",
        "      clients.delete(ws);",
        "      console.log('Client disconnected');",
        "    });",
        "    ",
        "    ws.on('error', (error: Error) => {",
        "      console.error('WebSocket error:', error);",
        "      clients.delete(ws);",
        "    });",
        "  });",
        "  ",
        "  // Website Routes",
        "  app.get('/api/websites', async (req: Request, res: Response) => {",
        "    const userId = req.query.userId ? Number(req.query.userId) : undefined;",
        "    const websites = await storage.getWebsites(userId);",
        "    res.json(websites);",
        "  });",
        "  ",
        "  app.get('/api/websites/:id', async (req: Request, res: Response) => {",
        "    const id = Number(req.params.id);",
        "    const website = await storage.getWebsiteById(id);",
        "    ",
        "    if (!website) {",
        "      return res.status(404).json({ error: 'Website not found' });",
        "    }",
        "    ",
        "    res.json(website);",
        "  });",
        "  ",
        "  return httpServer;",
        "}",
      ].join("\n"),
      shading: {
        type: ShadingType.SOLID,
        color: "F5F5F5",
      },
    }),
    new Paragraph({
      pageBreakBefore: true,
      text: "5. Real-Time Analytics Implementation",
      heading: HeadingLevel.HEADING_1,
    }),
    new Paragraph({
      text: "5.1 Custom Tracking System",
      heading: HeadingLevel.HEADING_2,
    }),
    new Paragraph({
      text: "A custom tracking system is implemented to capture page views and user interactions, record device and browser information, track user sessions, and measure engagement metrics.",
    }),
    new Paragraph({
      text: "Tracking Implementation:",
      bold: true,
      spacing: {
        before: 200,
        after: 100,
      },
    }),
  ],
});

// Add code example for tracking
doc.addSection({
  children: [
    new Paragraph({
      style: "CodeBlock",
      text: [
        "// client/src/lib/tracking.ts",
        "import { v4 as uuidv4 } from 'uuid';",
        "",
        "// Define interfaces for tracking",
        "interface TrackingOptions {",
        "  appId?: string;",
        "  endpoint?: string;",
        "}",
        "",
        "interface TrackingEvent {",
        "  eventType: string;",
        "  page: string;",
        "  sessionId: string;",
        "  timestamp: string;",
        "  metadata?: Record<string, any>;",
        "}",
        "",
        "interface PageVisit {",
        "  page: string;",
        "  sessionId: string;",
        "  timestamp: string;",
        "  device: string;",
        "  browser: string;",
        "  referrer?: string;",
        "}",
        "",
        "// Tracker class implementation",
        "class Tracker {",
        "  private sessionId: string;",
        "  private endpoint: string;",
        "  private appId: string;",
        "  private isInitialized: boolean = false;",
        "  private wsConnection: WebSocket | null = null;",
        "  ",
        "  constructor(options: TrackingOptions = {}) {",
        "    // Generate a unique session ID or restore from storage",
        "    this.sessionId = sessionStorage.getItem('analytics_session_id') || uuidv4();",
        "    sessionStorage.setItem('analytics_session_id', this.sessionId);",
        "    ",
        "    // Set configuration",
        "    this.endpoint = options.endpoint || '/api';",
        "    this.appId = options.appId || 'default';",
        "    ",
        "    // Setup WebSocket connection for real-time updates",
        "    this.setupWebSocket();",
        "  }",
        "  ",
        "  // Initialize the tracker",
        "  public init(): void {",
        "    if (this.isInitialized) return;",
        "    ",
        "    // Record initial page visit",
        "    this.recordVisit();",
        "    ",
        "    // Add event listeners for user interactions",
        "    document.addEventListener('click', this.handleClick.bind(this));",
        "    document.addEventListener('submit', this.handleFormSubmit.bind(this));",
        "    ",
        "    this.isInitialized = true;",
        "    console.log('Tracking initialized successfully');",
        "  }",
        "  ",
        "  // Record a page visit",
        "  private async recordVisit(): Promise<void> {",
        "    const visit: PageVisit = {",
        "      page: window.location.pathname,",
        "      sessionId: this.sessionId,",
        "      timestamp: new Date().toISOString(),",
        "      device: this.getDeviceType(),",
        "      browser: this.getBrowserInfo(),",
        "      referrer: document.referrer || undefined",
        "    };",
        "    ",
        "    try {",
        "      const response = await fetch(`${this.endpoint}/visits`, {",
        "        method: 'POST',",
        "        headers: {",
        "          'Content-Type': 'application/json'",
        "        },",
        "        body: JSON.stringify(visit)",
        "      });",
        "      ",
        "      if (response.ok) {",
        "        console.log('Visit recorded successfully');",
        "      }",
        "    } catch (error) {",
        "      console.error('Failed to record visit:', error);",
        "    }",
        "  }",
        "  ",
        "  // Additional implementation details...",
        "}",
        "",
        "// Export singleton instance",
        "export const tracker = new Tracker();",
      ].join("\n"),
      shading: {
        type: ShadingType.SOLID,
        color: "F5F5F5",
      },
    }),
    new Paragraph({
      pageBreakBefore: true,
      text: "6. AI and Machine Learning Features",
      heading: HeadingLevel.HEADING_1,
    }),
    new Paragraph({
      text: "6.1 OpenAI Integration",
      heading: HeadingLevel.HEADING_2,
    }),
    new Paragraph({
      text: "The platform leverages OpenAI's GPT-4o model for natural language analysis of user behavior, contextual understanding of metrics, insight generation and explanation, and recommendation formulation.",
    }),
    new Paragraph({
      text: "OpenAI Integration Code:",
      bold: true,
      spacing: {
        before: 200,
        after: 100,
      },
    }),
  ],
});

// Add code example for OpenAI integration
doc.addSection({
  children: [
    new Paragraph({
      style: "CodeBlock",
      text: [
        "// client/src/lib/openai.ts",
        "import OpenAI from \"openai\";",
        "",
        "// the newest OpenAI model is \"gpt-4o\" which was released May 13, 2024",
        "const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });",
        "",
        "// Interface for insights responses",
        "export interface InsightResponse {",
        "  insight: string;",
        "  explanation: string;",
        "  confidence: number;",
        "  recommendedActions: string[];",
        "}",
        "",
        "// Generate insights from analytics data",
        "export async function generateInsightsFromData(",
        "  analyticsData: any, ",
        "  websiteName: string",
        "): Promise<InsightResponse> {",
        "  const prompt = `",
        "    Analyze the following analytics data for the website \"${websiteName}\":",
        "    ",
        "    ${JSON.stringify(analyticsData, null, 2)}",
        "    ",
        "    Please provide:",
        "    1. A key insight about user behavior or performance",
        "    2. A brief explanation of why this insight matters",
        "    3. A confidence score between 0 and 1",
        "    4. 2-3 recommended actions based on this insight",
        "  `;",
        "",
        "  try {",
        "    const response = await openai.chat.completions.create({",
        "      model: \"gpt-4o\",",
        "      messages: [",
        "        { role: \"system\", content: \"You are an expert analytics consultant.\" },",
        "        { role: \"user\", content: prompt }",
        "      ],",
        "      response_format: { type: \"json_object\" }",
        "    });",
        "",
        "    const content = response.choices[0].message.content;",
        "    return JSON.parse(content) as InsightResponse;",
        "  } catch (error) {",
        "    console.error(\"Error generating insights with OpenAI:\", error);",
        "    return {",
        "      insight: \"Unable to generate insights at this time\",",
        "      explanation: \"There was an error processing the analytics data\",",
        "      confidence: 0,",
        "      recommendedActions: [\"Try again later\"]",
        "    };",
        "  }",
        "}",
      ].join("\n"),
      shading: {
        type: ShadingType.SOLID,
        color: "F5F5F5",
      },
    }),
    new Paragraph({
      pageBreakBefore: true,
      text: "7. Conclusion",
      heading: HeadingLevel.HEADING_1,
    }),
    new Paragraph({
      text: "The Advanced Analytics Platform represents a sophisticated solution for analytics integration, real-time monitoring, and AI-powered insights. With its modular architecture, multi-provider integration capabilities, and focus on authentic data collection, the platform delivers valuable intelligence to help businesses optimize their digital presence and improve user experience.",
    }),
    new Paragraph({
      text: "The implementation leverages modern web technologies and follows best practices in software architecture to ensure maintainability, scalability, and extensibility. The code examples provided in this documentation illustrate the key components and design patterns used throughout the application.",
    }),
  ],
});

// Add footer
const footer = new Footer({
  default: new Paragraph({
    alignment: AlignmentType.CENTER,
    children: [
      new TextRun("Analytics Platform Documentation - Page "),
      new TextRun({
        children: ["PAGE"],
        style: "PageNumber",
      }),
      new TextRun(" of "),
      new TextRun({
        children: ["NUMPAGES"],
        style: "PageNumber",
      }),
    ],
  }),
});

// Generate document
Packer.toBuffer(doc).then((buffer) => {
  fs.writeFileSync("analytics-platform-documentation.docx", buffer);
  console.log("Word document created successfully at analytics-platform-documentation.docx");
});