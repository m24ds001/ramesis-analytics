-- Add indexes to optimize analytics queries

-- Add index for user_events by session_id and timestamp
CREATE INDEX IF NOT EXISTS idx_user_events_session_ts 
ON user_events (session_id, timestamp);

-- Add index for user_events by event_type for filtering
CREATE INDEX IF NOT EXISTS idx_user_events_type 
ON user_events (event_type);

-- Add index for website_visits by timestamp
CREATE INDEX IF NOT EXISTS idx_website_visits_timestamp 
ON website_visits (timestamp);

-- Add index for website_visits by session_id
CREATE INDEX IF NOT EXISTS idx_website_visits_session 
ON website_visits (session_id);

-- Add index for ai_insights by category for filtering
CREATE INDEX IF NOT EXISTS idx_ai_insights_category 
ON ai_insights (category);

-- Add index for recommendations by category for filtering
CREATE INDEX IF NOT EXISTS idx_recommendations_category 
ON recommendations (category);

-- Add index for unread insights
CREATE INDEX IF NOT EXISTS idx_ai_insights_unread 
ON ai_insights (is_read) WHERE is_read = false;

-- Add index for non-implemented recommendations
CREATE INDEX IF NOT EXISTS idx_recommendations_unimplemented 
ON recommendations (implemented) WHERE implemented = false;

-- Add GIN index for event_data jsonb field in user_events
CREATE INDEX IF NOT EXISTS idx_user_events_data 
ON user_events USING GIN (event_data jsonb_path_ops);

-- Add an index for time-based queries (without the predicate for compatibility)
CREATE INDEX IF NOT EXISTS idx_events_time_type 
ON user_events (timestamp, event_type, page);

-- Add index for website lookups by name
CREATE INDEX IF NOT EXISTS idx_websites_name 
ON websites (name);

-- Add index for website lookups by URL
CREATE INDEX IF NOT EXISTS idx_websites_url 
ON websites (url);

-- Create index on the external_website_catalog table
CREATE INDEX IF NOT EXISTS idx_external_website_catalog_domain
ON external_website_catalog (domain);

-- Create index on the external_website_analytics table for website ID and provider
CREATE INDEX IF NOT EXISTS idx_external_website_analytics_website
ON external_website_analytics (external_website_id, analytics_provider);

-- Add index for created_at on the external_website_analytics table
CREATE INDEX IF NOT EXISTS idx_external_website_analytics_created
ON external_website_analytics (created_at);

-- Create statistics for the query planner
ANALYZE user_events;
ANALYZE website_visits;
ANALYZE ai_insights;
ANALYZE recommendations;
ANALYZE websites;
ANALYZE external_website_catalog;
ANALYZE external_website_analytics;