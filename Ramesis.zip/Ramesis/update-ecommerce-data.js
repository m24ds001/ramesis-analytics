// We need to use ESM style imports with tsx
import { db } from './server/db.js';
import { aiInsights, recommendations, abTests } from './shared/schema.js';
import { eq } from 'drizzle-orm';

async function updateEcommerceData() {
  console.log('Updating sample data with e-commerce analytics...');

  // Clear existing data
  await db.delete(aiInsights);
  await db.delete(recommendations);
  await db.delete(abTests);

  // Add e-commerce insights
  await db.insert(aiInsights).values([
    {
      timestamp: new Date(),
      insight: "Product category 'Electronics' has shown a 32% increase in page views but only a 12% increase in conversions, indicating potential usability issues in the purchasing flow.",
      category: "warning",
      confidence: "high",
      isRead: false
    },
    {
      timestamp: new Date(),
      insight: "Customers who view the detailed product specifications are 2.7x more likely to add the item to cart compared to those who don't.",
      category: "success",
      confidence: "high",
      isRead: false
    },
    {
      timestamp: new Date(),
      insight: "Mobile users from iOS devices have a 24% higher average order value compared to Android users.",
      category: "insight",
      confidence: "medium",
      isRead: false
    },
    {
      timestamp: new Date(),
      insight: "Product reviews with images receive 43% more helpful votes and contribute to a 17% higher conversion rate.",
      category: "success",
      confidence: "high",
      isRead: false
    },
    {
      timestamp: new Date(),
      insight: "Cart abandonment rate has increased to 76% during checkout when shipping costs are displayed, compared to 58% site average.",
      category: "warning",
      confidence: "high",
      isRead: false
    }
  ]);

  // Add e-commerce recommendations
  await db.insert(recommendations).values([
    {
      timestamp: new Date(),
      title: "Implement Free Shipping Threshold",
      description: "Introduce free shipping for orders above $35 to decrease cart abandonment. Analysis shows this could increase conversion by 15-20% for orders between $25-40.",
      category: "conversion",
      implemented: false
    },
    {
      timestamp: new Date(),
      title: "Enhance Product Image Galleries",
      description: "Add 360-degree product views for top 50 products - this feature increased conversion by 22% in A/B tests for similar e-commerce sites.",
      category: "product",
      implemented: false
    },
    {
      timestamp: new Date(),
      title: "Simplify Mobile Checkout Process",
      description: "Reduce mobile checkout from 5 steps to 3 by combining shipping/billing and removing order review (making it expandable instead). Expected to reduce mobile cart abandonment by 23%.",
      category: "conversion",
      implemented: false
    },
    {
      timestamp: new Date(),
      title: "Implement 'Customers Also Bought' Section",
      description: "Add cross-selling recommendations to product pages based on purchase history analysis. Similar implementations have shown 18% increase in average order value.",
      category: "sales",
      implemented: true
    },
    {
      timestamp: new Date(),
      title: "Optimize Product Search Relevance",
      description: "Current search algorithm prioritizes exact matches - updating to semantic search could improve search conversion by 34% based on user behavior analysis.",
      category: "user_experience",
      implemented: false
    }
  ]);

  // Add e-commerce AB tests
  await db.insert(abTests).values([
    {
      name: "Product Page Layout Optimization",
      description: "Testing product details above the fold vs. requiring scroll",
      variantA: "Current: Images first, details below requiring scroll",
      variantB: "New: Split layout with images left, key details right",
      startDate: new Date(2025, 4, 1),
      endDate: new Date(2025, 4, 15),
      status: "active",
      variantAConversion: "4.7",
      variantBConversion: "6.2",
      confidence: "92.5"
    },
    {
      name: "Add to Cart Button",
      description: "Testing different CTA button styles and placements",
      variantA: "Current: Orange button below price",
      variantB: "New: Sticky green button that stays visible while scrolling",
      startDate: new Date(2025, 3, 15),
      endDate: new Date(2025, 4, 1),
      status: "completed",
      variantAConversion: "8.3",
      variantBConversion: "12.7",
      confidence: "97.8"
    },
    {
      name: "Product Recommendation Algorithm",
      description: "Testing different product recommendation approaches",
      variantA: "Current: Based on category popularity",
      variantB: "New: Based on individual browsing history and similar users",
      startDate: new Date(2025, 3, 1),
      endDate: new Date(2025, 3, 30),
      status: "completed",
      variantAConversion: "3.9",
      variantBConversion: "7.2",
      confidence: "99.1"
    }
  ]);

  console.log('E-commerce analytics data updated successfully');
}

updateEcommerceData().catch(console.error);