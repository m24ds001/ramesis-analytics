const fs = require('fs');
const path = require('path');
const pdf = require('html-pdf');

// Read the HTML file
const htmlFilePath = path.join(__dirname, 'project-report.html');
const htmlContent = fs.readFileSync(htmlFilePath, 'utf8');

// PDF options
const options = {
  format: 'A4',
  border: {
    top: '20mm',
    right: '15mm',
    bottom: '20mm',
    left: '15mm'
  },
  footer: {
    height: '10mm',
    contents: {
      default: '<span style="color: #444; text-align: center; font-size: 10px;">Analytics Platform Report - Page {{page}} of {{pages}}</span>',
    }
  }
};

console.log('Generating PDF report...');

// Generate PDF
pdf.create(htmlContent, options).toFile('./analytics-platform-report.pdf', (err, res) => {
  if (err) {
    console.error('Error generating PDF:', err);
    return;
  }
  console.log(`PDF successfully generated: ${res.filename}`);
});