import { pgTable, text, serial, timestamp, integer, jsonb, numeric, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { users } from './schema';

// Define a table for analytics data with proper constraints
export const analyticsData = pgTable('analytics_data', {
  id: serial('id').primaryKey(),
  websiteId: integer('website_id').notNull().references(() => websites.id, { 
    onDelete: 'cascade' // Add proper FK constraint with cascading delete
  }),
  date: timestamp('date').notNull().defaultNow(),
  // Add validation for numeric fields
  pageViews: integer('page_views').notNull().default(0),
  uniqueVisitors: integer('unique_visitors').notNull().default(0),
  bounceRate: numeric('bounce_rate', { precision: 5, scale: 2 }).notNull().default('0'),
  averageSessionDuration: numeric('avg_session_duration', { precision: 10, scale: 2 }).notNull().default('0'),
  conversionRate: numeric('conversion_rate', { precision: 5, scale: 2 }),
  source: text('source').notNull(), // Where the data came from (Google Analytics, etc.)
  rawData: jsonb('raw_data'), // Raw data from the source
  processed: boolean('processed').notNull().default(false),
});

export const insertAnalyticsDataSchema = createInsertSchema(analyticsData).omit({
  id: true,
});

// Add updated website credentials schema with improved security
export const secureWebsiteCredentials = pgTable("secure_website_credentials", {
  id: serial("id").primaryKey(),
  websiteId: integer("website_id").notNull().references(() => websites.id, {
    onDelete: 'cascade' // Proper cascading delete
  }),
  provider: text("provider").notNull(), // "google", "adobe", "mixpanel", etc.
  credentials: text("credentials").notNull(), // Encrypted credentials JSON
  accountId: text("account_id"), // Account ID in the provider system
  viewId: text("view_id"), // View/Property ID in the provider system
  lastVerified: timestamp("last_verified"),
  isValid: boolean("is_valid").default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertSecureWebsiteCredentialsSchema = createInsertSchema(secureWebsiteCredentials).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Define response validation schemas
export const analyticsResponseSchema = z.object({
  pageViews: z.number().int().min(0),
  uniqueVisitors: z.number().int().min(0),
  bounceRate: z.number().min(0).max(100),
  averageSessionDuration: z.number().min(0),
  conversionRate: z.number().min(0).max(100).optional(),
  topPages: z.array(z.object({
    url: z.string().url(),
    views: z.number().int().min(0),
    uniqueViews: z.number().int().min(0),
  })).optional(),
  sources: z.array(z.object({
    name: z.string(),
    visits: z.number().int().min(0),
  })).optional(),
});

export type AnalyticsResponse = z.infer<typeof analyticsResponseSchema>;