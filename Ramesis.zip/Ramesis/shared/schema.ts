import { pgTable, text, serial, integer, boolean, timestamp, jsonb, primaryKey, date } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const websites = pgTable("websites", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  url: text("url").notNull(),
  description: text("description"),
  type: text("type").notNull().default('generic'),  // 'ecommerce', 'blog', 'saas', etc.
  category: text("category"),  // More specific category
  userId: integer("user_id").notNull().references(() => users.id),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertWebsiteSchema = createInsertSchema(websites).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const websiteCredentials = pgTable("website_credentials", {
  id: serial("id").primaryKey(),
  websiteId: integer("website_id").notNull().references(() => websites.id),
  provider: text("provider").notNull(), // "google", "adobe", "mixpanel", etc.
  credentials: text("credentials").notNull(), // Encrypted credentials JSON
  accountId: text("account_id"), // Account ID in the provider system
  viewId: text("view_id"), // View/Property ID in the provider system
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertWebsiteCredentialsSchema = createInsertSchema(websiteCredentials).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Table for popular ecommerce/retail websites that users might want to analyze
export const externalWebsiteCatalog = pgTable("external_website_catalog", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  domain: text("domain").notNull().unique(),
  description: text("description"),
  logo: text("logo"), // URL to logo
  category: text("category").notNull(), // ecommerce, social, news, etc.
  apiEndpoints: jsonb("api_endpoints"), // JSON with potential API endpoints
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertExternalWebsiteCatalogSchema = createInsertSchema(externalWebsiteCatalog).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Table for tracking which analytics tools are used by which external websites
export const externalWebsiteAnalytics = pgTable("external_website_analytics", {
  id: serial("id").primaryKey(),
  externalWebsiteId: integer("external_website_id").notNull().references(() => externalWebsiteCatalog.id),
  analyticsProvider: text("analytics_provider").notNull(), // google, adobe, mixpanel, etc.
  detectionMethod: text("detection_method").notNull(), // how we detected this tool (api, headers, public data)
  verifiedStatus: text("verified_status").notNull().default('unverified'), // 'verified', 'unverified', 'disputed'
  additionalInfo: jsonb("additional_info"), // JSON with additional information
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertExternalWebsiteAnalyticsSchema = createInsertSchema(externalWebsiteAnalytics).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const websiteVisits = pgTable("website_visits", {
  id: serial("id").primaryKey(),
  sessionId: text("session_id").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  page: text("page").notNull(),
  device: text("device").notNull(),
  browser: text("browser").notNull(),
  duration: integer("duration"),
  referrer: text("referrer"),
  country: text("country"),
});

export const insertWebsiteVisitSchema = createInsertSchema(websiteVisits).omit({
  id: true,
});

export const userEvents = pgTable("user_events", {
  id: serial("id").primaryKey(),
  sessionId: text("session_id").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  eventType: text("event_type").notNull(),
  eventData: jsonb("event_data").notNull(),
  page: text("page").notNull(),
});

export const insertUserEventSchema = createInsertSchema(userEvents).omit({
  id: true,
});

export const aiInsights = pgTable("ai_insights", {
  id: serial("id").primaryKey(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  insight: text("insight").notNull(),
  category: text("category").notNull(),
  confidence: text("confidence").notNull(),
  isRead: boolean("is_read").notNull().default(false),
});

export const insertAiInsightSchema = createInsertSchema(aiInsights).omit({
  id: true,
});

export const recommendations = pgTable("recommendations", {
  id: serial("id").primaryKey(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(),
  implemented: boolean("implemented").notNull().default(false),
});

export const insertRecommendationSchema = createInsertSchema(recommendations).omit({
  id: true,
});

export const abTests = pgTable("ab_tests", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  variantA: text("variant_a").notNull(),
  variantB: text("variant_b").notNull(),
  startDate: timestamp("start_date").notNull().defaultNow(),
  endDate: timestamp("end_date"),
  status: text("status").notNull().default("active"),
  variantAConversion: text("variant_a_conversion").notNull().default("0"),
  variantBConversion: text("variant_b_conversion").notNull().default("0"),
  confidence: text("confidence").notNull().default("0"),
});

export const insertAbTestSchema = createInsertSchema(abTests).omit({
  id: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertWebsite = z.infer<typeof insertWebsiteSchema>;
export type Website = typeof websites.$inferSelect;

export type InsertWebsiteCredentials = z.infer<typeof insertWebsiteCredentialsSchema>;
export type WebsiteCredentials = typeof websiteCredentials.$inferSelect;

export type InsertExternalWebsiteCatalog = z.infer<typeof insertExternalWebsiteCatalogSchema>;
export type ExternalWebsiteCatalog = typeof externalWebsiteCatalog.$inferSelect;

export type InsertExternalWebsiteAnalytics = z.infer<typeof insertExternalWebsiteAnalyticsSchema>;
export type ExternalWebsiteAnalytics = typeof externalWebsiteAnalytics.$inferSelect;

export type InsertWebsiteVisit = z.infer<typeof insertWebsiteVisitSchema>;
export type WebsiteVisit = typeof websiteVisits.$inferSelect;

export type InsertUserEvent = z.infer<typeof insertUserEventSchema>;
export type UserEvent = typeof userEvents.$inferSelect;

export type InsertAiInsight = z.infer<typeof insertAiInsightSchema>;
export type AiInsight = typeof aiInsights.$inferSelect;

export type InsertRecommendation = z.infer<typeof insertRecommendationSchema>;
export type Recommendation = typeof recommendations.$inferSelect;

export type InsertAbTest = z.infer<typeof insertAbTestSchema>;
export type AbTest = typeof abTests.$inferSelect;

// Achievement system tables
export const achievements = pgTable("achievements", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  type: text("type").notNull(), // 'analytics', 'engagement', 'feature_usage', etc.
  criteria: jsonb("criteria").notNull(), // JSON with achievement criteria
  points: integer("points").notNull(),
  badgeIcon: text("badge_icon").notNull(), // Path or emoji for the badge
  level: integer("level").notNull().default(1), // Difficulty level
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertAchievementSchema = createInsertSchema(achievements).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const userAchievements = pgTable("user_achievements", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  achievementId: integer("achievement_id").notNull().references(() => achievements.id),
  progress: integer("progress").notNull().default(0), // Current progress (for incremental achievements)
  completed: boolean("completed").notNull().default(false), 
  completedAt: timestamp("completed_at"), // When the achievement was completed
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertUserAchievementSchema = createInsertSchema(userAchievements).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertAchievement = z.infer<typeof insertAchievementSchema>;
export type Achievement = typeof achievements.$inferSelect;

export type InsertUserAchievement = z.infer<typeof insertUserAchievementSchema>;
export type UserAchievement = typeof userAchievements.$inferSelect;

// Revenue tracking tables
export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  websiteId: integer("website_id").notNull().references(() => websites.id),
  sessionId: text("session_id").notNull(),
  userId: text("user_id"), // Customer's user ID
  amount: integer("amount").notNull(), // Amount in cents (e.g., 2550 = €25.50)
  currency: text("currency").notNull().default('EUR'),
  description: text("description"),
  productName: text("product_name"),
  productCategory: text("product_category"),
  transactionType: text("transaction_type").notNull().default('purchase'), // 'purchase', 'subscription', 'refund'
  paymentMethod: text("payment_method"), // 'card', 'paypal', 'bank_transfer'
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertTransactionSchema = createInsertSchema(transactions).omit({
  id: true,
  createdAt: true,
});

export const revenueGoals = pgTable("revenue_goals", {
  id: serial("id").primaryKey(),
  websiteId: integer("website_id").notNull().references(() => websites.id),
  name: text("name").notNull(),
  targetAmount: integer("target_amount").notNull(), // Target amount in cents
  currency: text("currency").notNull().default('EUR'),
  period: text("period").notNull().default('monthly'), // 'daily', 'weekly', 'monthly', 'yearly'
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertRevenueGoalSchema = createInsertSchema(revenueGoals).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type Transaction = typeof transactions.$inferSelect;

export type InsertRevenueGoal = z.infer<typeof insertRevenueGoalSchema>;
export type RevenueGoal = typeof revenueGoals.$inferSelect;
