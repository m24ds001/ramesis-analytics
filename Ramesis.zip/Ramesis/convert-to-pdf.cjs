const fs = require('fs');
const pdf = require('html-pdf');

// Read the HTML file
const htmlContent = fs.readFileSync('analytics-platform-documentation.html', 'utf8');

// PDF options
const options = {
  format: 'Letter',
  border: {
    top: '0.75in',
    right: '0.75in',
    bottom: '0.75in',
    left: '0.75in'
  },
  footer: {
    height: '0.5in',
    contents: {
      default: '<div style="text-align: center; font-size: 10px; color: #666;">Analytics Platform Documentation | Page {{page}} of {{pages}}</div>'
    }
  },
  type: 'pdf',
  renderDelay: 1000
};

console.log('Converting HTML to PDF...');

// Generate PDF
pdf.create(htmlContent, options).toFile('./analytics-platform-documentation.pdf', (err, res) => {
  if (err) {
    console.error('Error generating PDF:', err);
    return;
  }
  console.log(`PDF successfully generated: ${res.filename}`);
  console.log('You can download this file from your Replit files panel');
});