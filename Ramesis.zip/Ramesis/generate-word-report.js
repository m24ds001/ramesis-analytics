import {
  Document,
  Paragraph,
  TextRun,
  HeadingLevel,
  BorderStyle,
  Table,
  TableRow,
  TableCell,
  AlignmentType,
  TableOfContents,
  Header,
  Footer,
  ImageRun,
  ExternalHyperlink,
  PageBreak,
  ShadingType,
  SectionType,
  UnderlineType,
  LevelFormat,
  Packer
} from "docx";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Create document
const doc = new Document({
  title: "Advanced Analytics Platform - Project Documentation",
  description: "Comprehensive documentation of the Analytics Platform project with code examples",
  styles: {
    paragraphStyles: [
      {
        id: "Normal",
        name: "Normal",
        run: {
          size: 22, // 11pt
          font: "Calibri",
        },
      },
      {
        id: "Heading1",
        name: "Heading 1",
        run: {
          size: 32, // 16pt
          bold: true,
          font: "Calibri",
          color: "2E74B5",
        },
        paragraph: {
          spacing: {
            before: 240, // 12pt
            after: 120, // 6pt
          },
        },
      },
      {
        id: "Heading2",
        name: "Heading 2",
        run: {
          size: 28, // 14pt
          bold: true,
          font: "Calibri",
          color: "2E74B5",
        },
        paragraph: {
          spacing: {
            before: 240, // 12pt
            after: 120, // 6pt
          },
        },
      },
      {
        id: "Heading3",
        name: "Heading 3",
        run: {
          size: 26, // 13pt
          bold: true,
          font: "Calibri",
          color: "2E74B5",
        },
        paragraph: {
          spacing: {
            before: 240, // 12pt
            after: 120, // 6pt
          },
        },
      },
      {
        id: "CodeBlock",
        name: "Code Block",
        run: {
          size: 20, // 10pt
          font: "Consolas",
        },
        paragraph: {
          spacing: {
            before: 120, // 6pt
            after: 120, // 6pt
          },
          indent: {
            left: 720, // 0.5 inches
            right: 720, // 0.5 inches
          },
        },
      },
    ],
  },
  numbering: {
    config: [
      {
        reference: "main-numbering",
        levels: [
          {
            level: 0,
            format: LevelFormat.DECIMAL,
            text: "%1.",
            alignment: AlignmentType.START,
          },
          {
            level: 1,
            format: LevelFormat.DECIMAL,
            text: "%1.%2.",
            alignment: AlignmentType.START,
          },
          {
            level: 2,
            format: LevelFormat.DECIMAL,
            text: "%1.%2.%3.",
            alignment: AlignmentType.START,
          },
        ],
      },
    ],
  },
});

// Title page
doc.addSection({
  properties: {
    type: SectionType.NEXT_PAGE,
  },
  children: [
    new Paragraph({
      text: "Advanced Analytics Platform",
      heading: HeadingLevel.TITLE,
      alignment: AlignmentType.CENTER,
      spacing: {
        before: 3000, // Space at top of page
        after: 400,
      },
    }),
    new Paragraph({
      text: "Technical Documentation",
      heading: HeadingLevel.HEADING_1,
      alignment: AlignmentType.CENTER,
      spacing: {
        after: 400,
      },
    }),
    new Paragraph({
      text: "Version 1.0",
      alignment: AlignmentType.CENTER,
      spacing: {
        after: 4000,
      },
    }),
    new Paragraph({
      text: "Generated: May 10, 2025",
      alignment: AlignmentType.CENTER,
    }),
  ],
});

// Table of Contents
const tocSection = doc.addSection({
  properties: {
    type: SectionType.NEXT_PAGE,
  },
  children: [
    new Paragraph({
      text: "Table of Contents",
      heading: HeadingLevel.HEADING_1,
      spacing: {
        after: 400,
      },
    }),
    new TableOfContents("Table of Contents", {
      hyperlink: true,
      headingStyleRange: "1-3",
    }),
    new Paragraph({
      text: "",
      pageBreakBefore: true,
    }),
  ],
});

// Executive Summary
doc.addSection({
  children: [
    new Paragraph({
      text: "1. Executive Summary",
      heading: HeadingLevel.HEADING_1,
      numbering: {
        reference: "main-numbering",
        level: 0,
      },
    }),
    new Paragraph({
      text: "The Advanced Analytics Platform is a sophisticated web-based application designed to provide comprehensive analytics capabilities through multi-source data integration, real-time tracking, and AI-powered insights. The platform empowers users to access and analyze authentic data from various websites and analytics providers, offering a centralized dashboard for monitoring performance metrics, user behavior, and actionable insights.",
    }),
    new Paragraph({
      text: "Key Features:",
      bold: true,
      spacing: {
        before: 240,
        after: 120,
      },
    }),
    new Paragraph({
      text: "• Multi-provider analytics integration (Google, Adobe, Mixpanel, etc.)",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "• Real-time user behavior tracking and monitoring",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "• AI-powered insights using OpenAI's GPT-4o model",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "• Predictive analytics capabilities",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "• Custom tracking script for authentic data collection",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "• Dynamic credentials management for API connections",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "• External website catalog integration (Amazon, YouTube, etc.)",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "• Visual data source attribution system",
      indent: {
        left: 720,
      },
    }),
  ],
});

// Project Architecture
doc.addSection({
  children: [
    new Paragraph({
      text: "2. Project Architecture Overview",
      heading: HeadingLevel.HEADING_1,
      numbering: {
        reference: "main-numbering",
        level: 0,
      },
      pageBreakBefore: true,
    }),
    new Paragraph({
      text: "2.1 Technology Stack",
      heading: HeadingLevel.HEADING_2,
      numbering: {
        reference: "main-numbering",
        level: 1,
      },
    }),
    new Table({
      width: {
        size: 9000,
        type: "dxa",
      },
      borders: {
        top: {
          style: BorderStyle.SINGLE,
          size: 1,
          color: "auto",
        },
        bottom: {
          style: BorderStyle.SINGLE,
          size: 1,
          color: "auto",
        },
        left: {
          style: BorderStyle.SINGLE,
          size: 1,
          color: "auto",
        },
        right: {
          style: BorderStyle.SINGLE,
          size: 1,
          color: "auto",
        },
        insideHorizontal: {
          style: BorderStyle.SINGLE,
          size: 1,
          color: "auto",
        },
        insideVertical: {
          style: BorderStyle.SINGLE,
          size: 1,
          color: "auto",
        },
      },
      rows: [
        new TableRow({
          tableHeader: true,
          children: [
            new TableCell({
              width: {
                size: 2000,
                type: "dxa",
              },
              shading: {
                fill: "EEEEEE",
              },
              children: [new Paragraph({ text: "Component", bold: true })],
            }),
            new TableCell({
              width: {
                size: 3000,
                type: "dxa",
              },
              shading: {
                fill: "EEEEEE",
              },
              children: [new Paragraph({ text: "Technologies", bold: true })],
            }),
            new TableCell({
              width: {
                size: 4000,
                type: "dxa",
              },
              shading: {
                fill: "EEEEEE",
              },
              children: [new Paragraph({ text: "Description", bold: true })],
            }),
          ],
        }),
        new TableRow({
          children: [
            new TableCell({
              children: [new Paragraph("Frontend")],
            }),
            new TableCell({
              children: [new Paragraph("React (TypeScript), TailwindCSS, Shadcn/UI")],
            }),
            new TableCell({
              children: [
                new Paragraph(
                  "Modern React application with TypeScript for type safety and component-based architecture"
                ),
              ],
            }),
          ],
        }),
        new TableRow({
          children: [
            new TableCell({
              children: [new Paragraph("Backend")],
            }),
            new TableCell({
              children: [new Paragraph("Node.js, Express")],
            }),
            new TableCell({
              children: [
                new Paragraph(
                  "RESTful API server providing data access and business logic"
                ),
              ],
            }),
          ],
        }),
        new TableRow({
          children: [
            new TableCell({
              children: [new Paragraph("Database")],
            }),
            new TableCell({
              children: [new Paragraph("PostgreSQL, Drizzle ORM")],
            }),
            new TableCell({
              children: [
                new Paragraph(
                  "Relational database for data persistence with type-safe ORM"
                ),
              ],
            }),
          ],
        }),
        new TableRow({
          children: [
            new TableCell({
              children: [new Paragraph("State Management")],
            }),
            new TableCell({
              children: [new Paragraph("TanStack Query (React Query)")],
            }),
            new TableCell({
              children: [
                new Paragraph(
                  "Efficient data fetching, caching, and state synchronization"
                ),
              ],
            }),
          ],
        }),
        new TableRow({
          children: [
            new TableCell({
              children: [new Paragraph("Routing")],
            }),
            new TableCell({
              children: [new Paragraph("Wouter")],
            }),
            new TableCell({
              children: [
                new Paragraph(
                  "Lightweight client-side routing solution"
                ),
              ],
            }),
          ],
        }),
        new TableRow({
          children: [
            new TableCell({
              children: [new Paragraph("AI Integration")],
            }),
            new TableCell({
              children: [new Paragraph("OpenAI API (GPT-4o)")],
            }),
            new TableCell({
              children: [
                new Paragraph(
                  "Natural language processing and insight generation"
                ),
              ],
            }),
          ],
        }),
        new TableRow({
          children: [
            new TableCell({
              children: [new Paragraph("Real-time")],
            }),
            new TableCell({
              children: [new Paragraph("WebSockets (ws)")],
            }),
            new TableCell({
              children: [
                new Paragraph(
                  "Real-time bidirectional communication for live updates"
                ),
              ],
            }),
          ],
        }),
      ],
    }),
    new Paragraph({
      text: "2.2 System Architecture",
      heading: HeadingLevel.HEADING_2,
      numbering: {
        reference: "main-numbering",
        level: 1,
      },
      spacing: {
        before: 400,
      },
    }),
    new Paragraph({
      text: "The architecture follows a modern client-server model with:"
    }),
    new Paragraph({
      text: "• Clear separation between frontend and backend",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "• RESTful API design principles",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "• PostgreSQL database for persistent storage",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "• Modular component structure for maintainability",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "• Shared type definitions across client and server",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "Schema Definition Code:",
      bold: true,
      spacing: {
        before: 240,
      },
    }),
    new Paragraph({
      text: \`// shared/schema.ts - Example schema definitions
import { pgTable, serial, text, timestamp, boolean, integer, pgEnum } from 'drizzle-orm/pg-core';
import { createInsertSchema } from 'drizzle-zod';
import { z } from 'zod';

// User model
export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  username: text('username').notNull().unique(),
  passwordHash: text('password_hash').notNull(),
  email: text('email'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// Website model for tracking analytics
export const websites = pgTable('websites', {
  id: serial('id').primaryKey(),
  name: text('name').notNull(),
  url: text('url').notNull(),
  userId: integer('user_id').references(() => users.id),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  isActive: boolean('is_active').default(true),
});

// Define Zod schemas for validation
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertWebsiteSchema = createInsertSchema(websites).omit({
  id: true,
  createdAt: true,
});

// Define TypeScript types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Website = typeof websites.$inferSelect;
export type InsertWebsite = z.infer<typeof insertWebsiteSchema>;\`,
      style: "CodeBlock",
      spacing: {
        before: 120,
        after: 240,
      },
      shading: {
        type: ShadingType.SOLID,
        color: "F5F5F5",
      },
    }),
    new Paragraph({
      text: "2.3 Key Design Patterns",
      heading: HeadingLevel.HEADING_2,
      numbering: {
        reference: "main-numbering",
        level: 1,
      },
    }),
    new Paragraph({
      text: "• Provider factory pattern for analytics integration",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "• Repository pattern for data access",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "• Component composition for UI elements",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "• Observer pattern for real-time updates",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "• Strategy pattern for credential management",
      indent: {
        left: 720,
      },
    }),
  ],
});

// Frontend Implementation
doc.addSection({
  children: [
    new Paragraph({
      text: "3. Frontend Implementation",
      heading: HeadingLevel.HEADING_1,
      numbering: {
        reference: "main-numbering",
        level: 0,
      },
      pageBreakBefore: true,
    }),
    new Paragraph({
      text: "3.1 User Interface Components",
      heading: HeadingLevel.HEADING_2,
      numbering: {
        reference: "main-numbering",
        level: 1,
      },
    }),
    new Paragraph({
      text: "The frontend is built with React and TypeScript, organized into a modular component structure.",
    }),
    new Paragraph({
      text: "Dashboard Components:",
      bold: true,
      spacing: {
        before: 240,
      },
    }),
    new Paragraph({
      text: "• MetricsOverview: Displays high-level analytics metrics with clear source attribution",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "• RealTimeAnalytics: Shows real-time user activity data with visualizations",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "• UserBehavior: Presents detailed user interaction patterns",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "• AIInsights: Displays AI-generated analysis and recommendations",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "• PredictiveAnalytics: Offers forecasts for key metrics",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "MetricsOverview Component Code:",
      bold: true,
      spacing: {
        before: 240,
      },
    }),
    new Paragraph({
      text: \`// client/src/components/analytics/MetricsOverview.tsx
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useRealTimeData } from '@/hooks/useRealTimeData';
import { getAnalyticsSummary } from '@/lib/analytics';
import { Users, ShoppingCart, ArrowLeftCircle, Clock, ArrowUp, Info } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { DataSourceBadge, DataSourceHeader } from '@/components/ui/data-source-badge';

interface MetricsOverviewProps {
  websiteId?: number | null;
}

export default function MetricsOverview({ websiteId }: MetricsOverviewProps) {
  const realTimeData = useRealTimeData();
  const analyticsSummary = getAnalyticsSummary();
  
  // Get website name if websiteId is provided
  const { data: website } = useQuery({
    queryKey: websiteId ? ['/api/websites', websiteId] : ['/api/websites', 'none'],
    queryFn: () => websiteId ? fetch(\`/api/websites/\${websiteId}\`).then(res => res.json()) : null,
    enabled: !!websiteId
  });
  
  // Function to get data source label
  const getDataSourceLabel = () => {
    if (websiteId && website) {
      return website.name;
    } else {
      return 'Real-time Analytics';
    }
  };

  // Get the name of the data provider
  const getDataProvider = (metricType: 'visitors' | 'conversion' | 'bounce' | 'session' | string): string => {
    // This would be dynamic in a real implementation based on the actual data source
    const providers: Record<string, string> = {
      visitors: 'Real-time Tracking',
      conversion: 'Google Analytics',
      bounce: 'Adobe Analytics',
      session: 'Mixpanel'
    };
    return providers[metricType] || 'Internal Analytics';
  };

  return (
    <div>
      <DataSourceHeader sourceName={getDataSourceLabel()} className="mb-4" />
      
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4 mb-6">
        {/* Active Visitors Metric */}
        <Card className="relative overflow-hidden border-primary-200 hover:shadow-md transition-shadow">
          <DataSourceBadge 
            sourceName={getDataSourceLabel()} 
            providerName={getDataProvider('visitors')} 
            className="from-primary-600 to-primary-700"
          />
          <CardContent className="pt-8">
            {/* Card content... */}
          </CardContent>
        </Card>
        
        {/* Additional metrics cards... */}
      </div>
    </div>
  );
}\`,
      style: "CodeBlock",
      spacing: {
        before: 120,
        after: 240,
      },
      shading: {
        type: ShadingType.SOLID,
        color: "F5F5F5",
      },
    }),
    new Paragraph({
      text: "UI Elements:",
      bold: true,
      spacing: {
        before: 240,
      },
    }),
    new Paragraph({
      text: "• DataSourceBadge: Consistent visual indicator showing data sources",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "• Website Selector: Interface for choosing which website to analyze",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "• Chart Components: Various visualization components",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "DataSourceBadge Component Code:",
      bold: true,
      spacing: {
        before: 240,
      },
    }),
    new Paragraph({
      text: \`// client/src/components/ui/data-source-badge.tsx
import { Info } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

interface DataSourceBadgeProps {
  sourceName: string;
  providerName?: string;
  className?: string;
}

export function DataSourceBadge({ 
  sourceName, 
  providerName, 
  className 
}: DataSourceBadgeProps) {
  return (
    <div className={cn(
      "absolute top-0 right-0 text-white text-xs px-2 py-1 rounded-bl-md bg-gradient-to-r", 
      className || "from-blue-600 to-blue-700"
    )}>
      Source: {providerName || sourceName}
    </div>
  );
}

interface DataSourceHeaderProps {
  sourceName: string;
  className?: string;
}

export function DataSourceHeader({ 
  sourceName,
  className
}: DataSourceHeaderProps) {
  return (
    <div className={cn(
      "flex items-center bg-gradient-to-r from-primary-50 to-transparent p-3 rounded-md border border-primary-100",
      className
    )}>
      <Info className="h-5 w-5 text-primary-600 mr-2" />
      <span className="text-sm font-medium text-gray-700">
        Showing authentic analytics data from:
      </span>
      <Badge variant="outline" className="ml-2 bg-primary-100 text-primary-700 border-primary-200 font-bold">
        {sourceName}
      </Badge>
    </div>
  );
}\`,
      style: "CodeBlock",
      spacing: {
        before: 120,
        after: 240,
      },
      shading: {
        type: ShadingType.SOLID,
        color: "F5F5F5",
      },
    }),
    new Paragraph({
      text: "3.2 State Management",
      heading: HeadingLevel.HEADING_2,
      numbering: {
        reference: "main-numbering",
        level: 1,
      },
    }),
    new Paragraph({
      text: "The application uses TanStack Query for efficient data fetching, caching, and state management:"
    }),
    new Paragraph({
      text: "• Automatic refetching of stale data",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "• Optimistic updates for mutations",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "• Structured cache invalidation",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "Query Client Configuration:",
      bold: true,
      spacing: {
        before: 240,
      },
    }),
    new Paragraph({
      text: \`// client/src/lib/queryClient.ts
import { QueryClient } from '@tanstack/react-query';

// Create a custom fetch function for API requests
export async function apiRequest(
  url: string,
  method: 'GET' | 'POST' | 'PATCH' | 'DELETE' = 'GET',
  body?: any
) {
  const options: RequestInit = {
    method,
    headers: {
      'Content-Type': 'application/json',
    },
    credentials: 'include',
  };

  if (body && method !== 'GET') {
    options.body = JSON.stringify(body);
  }

  const response = await fetch(url, options);

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    throw new Error(
      errorData.message || \`API request failed with status \${response.status}\`
    );
  }

  if (response.status === 204) {
    return null; // No content
  }

  return response.json();
}

// Default fetcher function for useQuery
const defaultQueryFn = async ({ queryKey }: { queryKey: string[] }) => {
  // The first element of the array should be the endpoint
  const [endpoint, ...params] = queryKey;
  
  // If there are additional parameters, we can use them to build the URL
  const url = params.length > 0 ? \`\${endpoint}/\${params.join('/')}\` : endpoint;
  
  return apiRequest(url);
};

// Configure and export the query client
export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      queryFn: defaultQueryFn,
      staleTime: 1000 * 60 * 5, // 5 minutes
      retry: 1,
    },
  },
});\`,
      style: "CodeBlock",
      spacing: {
        before: 120,
        after: 240,
      },
      shading: {
        type: ShadingType.SOLID,
        color: "F5F5F5",
      },
    }),
  ],
});

// Backend Implementation
doc.addSection({
  children: [
    new Paragraph({
      text: "4. Backend Implementation",
      heading: HeadingLevel.HEADING_1,
      numbering: {
        reference: "main-numbering",
        level: 0,
      },
      pageBreakBefore: true,
    }),
    new Paragraph({
      text: "4.1 API Design",
      heading: HeadingLevel.HEADING_2,
      numbering: {
        reference: "main-numbering",
        level: 1,
      },
    }),
    new Paragraph({
      text: "The backend follows RESTful principles with endpoints for:"
    }),
    new Paragraph({
      text: "• Website management",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "• Analytics data retrieval",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "• User event tracking",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "• Insights generation",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "• External website catalog",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "API Routes Implementation:",
      bold: true,
      spacing: {
        before: 240,
      },
    }),
    new Paragraph({
      text: \`// server/routes.ts
import { Express, Request, Response, NextFunction } from 'express';
import { Server } from 'http';
import { WebSocketServer } from 'ws';
import { z } from 'zod';
import { storage } from './storage';
import { insertUserSchema, insertWebsiteSchema } from '@shared/schema';

// WebSocket clients for real-time updates
const clients = new Set<WebSocket>();

export async function registerRoutes(app: Express): Promise<Server> {
  // Create a HTTP server instance
  const httpServer = require('http').createServer(app);
  
  // Initialize WebSocket server
  const wss = new WebSocketServer({ server: httpServer, path: '/api/ws' });
  
  wss.on('connection', (ws: WebSocket) => {
    clients.add(ws);
    console.log('Client connected');
    
    ws.on('close', () => {
      clients.delete(ws);
      console.log('Client disconnected');
    });
    
    ws.on('error', (error: Error) => {
      console.error('WebSocket error:', error);
      clients.delete(ws);
    });
  });
  
  // User Routes
  app.post('/api/users', async (req: Request, res: Response) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(userData);
      res.status(201).json(user);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  
  // Website Routes
  app.get('/api/websites', async (req: Request, res: Response) => {
    const userId = req.query.userId ? Number(req.query.userId) : undefined;
    const websites = await storage.getWebsites(userId);
    res.json(websites);
  });
  
  app.get('/api/websites/:id', async (req: Request, res: Response) => {
    const id = Number(req.params.id);
    const website = await storage.getWebsiteById(id);
    
    if (!website) {
      return res.status(404).json({ error: 'Website not found' });
    }
    
    res.json(website);
  });
  
  // Additional API routes...
  
  return httpServer;
}\`,
      style: "CodeBlock",
      spacing: {
        before: 120,
        after: 240,
      },
      shading: {
        type: ShadingType.SOLID,
        color: "F5F5F5",
      },
    }),
  ],
});

// Data Integration Layer
doc.addSection({
  children: [
    new Paragraph({
      text: "5. Data Integration Layer",
      heading: HeadingLevel.HEADING_1,
      numbering: {
        reference: "main-numbering",
        level: 0,
      },
      pageBreakBefore: true,
    }),
    new Paragraph({
      text: "5.1 Analytics Provider Integration",
      heading: HeadingLevel.HEADING_2,
      numbering: {
        reference: "main-numbering",
        level: 1,
      },
    }),
    new Paragraph({
      text: "The platform integrates with multiple analytics providers through a flexible adapter system:"
    }),
    new Paragraph({
      text: "• Google Analytics",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "• Adobe Analytics",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "• Mixpanel",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "• Matomo",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "• Segment",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "• Amplitude",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "Analytics Provider Implementation:",
      bold: true,
      spacing: {
        before: 240,
      },
    }),
    new Paragraph({
      text: \`// server/services/analytics-service.ts
import { WebsiteCredentials } from '@shared/schema';

// Base interface for analytics providers
export interface AnalyticsProvider {
  getName(): string;
  getMetrics(websiteId: number, timeframe?: string): Promise<any>;
  getUserData(websiteId: number, userId?: string): Promise<any>;
  isConfigured(): boolean;
}

// Google Analytics provider implementation
export class GoogleAnalyticsProvider implements AnalyticsProvider {
  private credentials: WebsiteCredentials;
  
  constructor(credentials: WebsiteCredentials) {
    this.credentials = credentials;
  }
  
  getName(): string {
    return 'Google Analytics';
  }
  
  async getMetrics(websiteId: number, timeframe?: string): Promise<any> {
    // Implementation using Google Analytics API
    // Using credentials.apiKey, credentials.clientId, etc.
    
    // For now, return sample data
    return {
      pageViews: 12500,
      uniqueVisitors: 8200,
      bounceRate: 42.5,
      avgSessionDuration: '2:15',
    };
  }
  
  async getUserData(websiteId: number, userId?: string): Promise<any> {
    // Implementation for user-specific data
    return {
      sessions: 3,
      lastVisit: new Date().toISOString(),
      devices: ['mobile', 'desktop'],
      browsers: ['Chrome', 'Safari'],
    };
  }
  
  isConfigured(): boolean {
    return !!(this.credentials.apiKey && this.credentials.clientId);
  }
}

// Adobe Analytics provider implementation
export class AdobeAnalyticsProvider implements AnalyticsProvider {
  // Similar implementation...
}

// Factory to create provider instances
export class AnalyticsProviderFactory {
  static createProvider(type: string, credentials: WebsiteCredentials): AnalyticsProvider | null {
    switch (type.toLowerCase()) {
      case 'google':
      case 'google analytics':
        return new GoogleAnalyticsProvider(credentials);
      case 'adobe':
      case 'adobe analytics':
        return new AdobeAnalyticsProvider(credentials);
      // Other providers...
      default:
        return null;
    }
  }
}\`,
      style: "CodeBlock",
      spacing: {
        before: 120,
        after: 240,
      },
      shading: {
        type: ShadingType.SOLID,
        color: "F5F5F5",
      },
    }),
  ],
});

// Real-Time Analytics Implementation
doc.addSection({
  children: [
    new Paragraph({
      text: "6. Real-Time Analytics Implementation",
      heading: HeadingLevel.HEADING_1,
      numbering: {
        reference: "main-numbering",
        level: 0,
      },
      pageBreakBefore: true,
    }),
    new Paragraph({
      text: "6.1 Custom Tracking System",
      heading: HeadingLevel.HEADING_2,
      numbering: {
        reference: "main-numbering",
        level: 1,
      },
    }),
    new Paragraph({
      text: "A custom tracking system is implemented to:"
    }),
    new Paragraph({
      text: "• Capture page views and user interactions",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "• Record device and browser information",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "• Track user sessions",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "• Measure engagement metrics",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "Tracking Implementation:",
      bold: true,
      spacing: {
        before: 240,
      },
    }),
    new Paragraph({
      text: \`// client/src/lib/tracking.ts
import { v4 as uuidv4 } from 'uuid';

// Define interfaces for tracking
interface TrackingOptions {
  appId?: string;
  endpoint?: string;
}

interface TrackingEvent {
  eventType: string;
  page: string;
  sessionId: string;
  timestamp: string;
  metadata?: Record<string, any>;
}

interface PageVisit {
  page: string;
  sessionId: string;
  timestamp: string;
  device: string;
  browser: string;
  referrer?: string;
}

// Tracker class implementation
class Tracker {
  private sessionId: string;
  private endpoint: string;
  private appId: string;
  private isInitialized: boolean = false;
  private wsConnection: WebSocket | null = null;
  
  constructor(options: TrackingOptions = {}) {
    // Generate a unique session ID or restore from storage
    this.sessionId = sessionStorage.getItem('analytics_session_id') || uuidv4();
    sessionStorage.setItem('analytics_session_id', this.sessionId);
    
    // Set configuration
    this.endpoint = options.endpoint || '/api';
    this.appId = options.appId || 'default';
    
    // Setup WebSocket connection for real-time updates
    this.setupWebSocket();
  }
  
  // Initialize the tracker
  public init(): void {
    if (this.isInitialized) return;
    
    // Record initial page visit
    this.recordVisit();
    
    // Add event listeners for user interactions
    document.addEventListener('click', this.handleClick.bind(this));
    document.addEventListener('submit', this.handleFormSubmit.bind(this));
    
    // Listen for page navigation events in SPA
    window.addEventListener('popstate', this.handleNavigation.bind(this));
    
    this.isInitialized = true;
    console.log('Tracking initialized successfully');
  }
  
  // Record a page visit
  private async recordVisit(): Promise<void> {
    const visit: PageVisit = {
      page: window.location.pathname,
      sessionId: this.sessionId,
      timestamp: new Date().toISOString(),
      device: this.getDeviceType(),
      browser: this.getBrowserInfo(),
      referrer: document.referrer || undefined
    };
    
    try {
      const response = await fetch(\`\${this.endpoint}/visits\`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(visit)
      });
      
      if (response.ok) {
        console.log('Visit recorded successfully');
      }
    } catch (error) {
      console.error('Failed to record visit:', error);
    }
  }
  
  // Record user event
  public async recordEvent(eventType: string, metadata?: Record<string, any>): Promise<void> {
    const event: TrackingEvent = {
      eventType,
      page: window.location.pathname,
      sessionId: this.sessionId,
      timestamp: new Date().toISOString(),
      metadata
    };
    
    try {
      const response = await fetch(\`\${this.endpoint}/events\`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(event)
      });
      
      if (response.ok) {
        console.log(\`Event '\${eventType}' recorded successfully\`);
      }
    } catch (error) {
      console.error(\`Failed to record event '\${eventType}':\`, error);
    }
  }
  
  // Additional implementation details...
}

// Export singleton instance
export const tracker = new Tracker();

// Auto-initialize if in browser environment
if (typeof window !== 'undefined') {
  tracker.init();
}\`,
      style: "CodeBlock",
      spacing: {
        before: 120,
        after: 240,
      },
      shading: {
        type: ShadingType.SOLID,
        color: "F5F5F5",
      },
    }),
  ],
});

// AI and Machine Learning Features
doc.addSection({
  children: [
    new Paragraph({
      text: "7. AI and Machine Learning Features",
      heading: HeadingLevel.HEADING_1,
      numbering: {
        reference: "main-numbering",
        level: 0,
      },
      pageBreakBefore: true,
    }),
    new Paragraph({
      text: "7.1 OpenAI Integration",
      heading: HeadingLevel.HEADING_2,
      numbering: {
        reference: "main-numbering",
        level: 1,
      },
    }),
    new Paragraph({
      text: "The platform leverages OpenAI's GPT-4o model for:"
    }),
    new Paragraph({
      text: "• Natural language analysis of user behavior",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "• Contextual understanding of metrics",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "• Insight generation and explanation",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "• Recommendation formulation",
      indent: {
        left: 720,
      },
    }),
    new Paragraph({
      text: "OpenAI Integration Code:",
      bold: true,
      spacing: {
        before: 240,
      },
    }),
    new Paragraph({
      text: \`// client/src/lib/openai.ts
import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// Interface for insights responses
export interface InsightResponse {
  insight: string;
  explanation: string;
  confidence: number;
  recommendedActions: string[];
}

// Generate insights from analytics data
export async function generateInsightsFromData(
  analyticsData: any, 
  websiteName: string
): Promise<InsightResponse> {
  const prompt = \`
    Analyze the following analytics data for the website "\${websiteName}":
    
    \${JSON.stringify(analyticsData, null, 2)}
    
    Please provide:
    1. A key insight about user behavior or performance
    2. A brief explanation of why this insight matters
    3. A confidence score between 0 and 1
    4. 2-3 recommended actions based on this insight
    
    Respond with valid JSON in this format:
    {
      "insight": "Main insight about the data",
      "explanation": "Why this insight matters",
      "confidence": 0.85,
      "recommendedActions": ["Action 1", "Action 2", "Action 3"]
    }
  \`;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: "You are an expert analytics consultant providing insights on web analytics data." },
        { role: "user", content: prompt }
      ],
      response_format: { type: "json_object" }
    });

    const content = response.choices[0].message.content;
    return JSON.parse(content) as InsightResponse;
  } catch (error) {
    console.error("Error generating insights with OpenAI:", error);
    return {
      insight: "Unable to generate insights at this time",
      explanation: "There was an error processing the analytics data",
      confidence: 0,
      recommendedActions: ["Try again later", "Check your API configuration"]
    };
  }
}\`,
      style: "CodeBlock",
      spacing: {
        before: 120,
        after: 240,
      },
      shading: {
        type: ShadingType.SOLID,
        color: "F5F5F5",
      },
    }),
  ],
});

// Add footer with page number
doc.Footer = new Footer({
  children: [
    new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [
        new TextRun({
          text: "Advanced Analytics Platform - Technical Documentation | Page ",
          size: 18, // 9pt
        }),
        new TextRun({
          children: [PageNumber.CURRENT],
          size: 18, // 9pt
        }),
        new TextRun({
          text: " of ",
          size: 18, // 9pt
        }),
        new TextRun({
          children: [PageNumber.TOTAL_PAGES],
          size: 18, // 9pt
        }),
      ],
    }),
  ],
});

// Write the document to a file
Packer.toBuffer(doc).then((buffer) => {
  fs.writeFileSync("analytics-platform-documentation.docx", buffer);
  console.log("Document created successfully!");
});