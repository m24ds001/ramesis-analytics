#!/usr/bin/env node

/**
 * Real-time analytics testing script
 * 
 * This script tests various aspects of the real-time analytics system:
 * 1. Websocket connection and heartbeat
 * 2. Event tracking and message receipt
 * 3. Reconnection handling
 * 4. Load testing with simulated events
 * 5. Latency measurement
 */

const WebSocket = require('ws');
const fetch = require('node-fetch');
const readline = require('readline');

// Configuration
const config = {
  baseUrl: 'http://localhost:5000',
  wsUrl: 'ws://localhost:5000/api/ws',
  sessionId: `test-${Date.now()}`
};

// Create readline interface for interactive testing
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

// Track metrics
let messageCount = 0;
let lastLatency = 0;
let avgLatency = 0;
let minLatency = Number.MAX_SAFE_INTEGER;
let maxLatency = 0;

/**
 * Connect to the WebSocket server
 */
function connectWebSocket() {
  console.log(`Connecting to WebSocket at ${config.wsUrl}...`);
  const ws = new WebSocket(config.wsUrl);
  
  ws.on('open', () => {
    console.log('WebSocket connection established');
    console.log('Waiting for heartbeat...');
  });
  
  ws.on('message', (data) => {
    try {
      const message = JSON.parse(data);
      messageCount++;
      
      // Calculate latency for event messages
      if (message.type === 'ANALYTICS_UPDATE' && message.data?.eventType === 'NEW_EVENT') {
        const now = Date.now();
        const eventTime = new Date(message.data.data.timestamp).getTime();
        const latency = now - eventTime;
        
        lastLatency = latency;
        minLatency = Math.min(minLatency, latency);
        maxLatency = Math.max(maxLatency, latency);
        avgLatency = (avgLatency * (messageCount - 1) + latency) / messageCount;
        
        console.log(`Event received with ${latency}ms latency`);
      } else {
        console.log(`Message received: ${message.type}`);
      }
    } catch (error) {
      console.error('Error parsing message:', error);
    }
  });
  
  ws.on('close', () => {
    console.log('WebSocket connection closed');
    console.log('Attempting to reconnect in 5 seconds...');
    setTimeout(connectWebSocket, 5000);
  });
  
  ws.on('error', (error) => {
    console.error('WebSocket error:', error);
  });
  
  return ws;
}

/**
 * Track a single event and verify receipt
 */
async function trackEvent(eventType = 'button_click') {
  console.log(`Tracking event: ${eventType}...`);
  
  try {
    const response = await fetch(`${config.baseUrl}/api/track-event`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        sessionId: config.sessionId,
        eventType,
        page: '/test-page',
        eventData: {
          timestamp: Date.now(),
          testData: 'This is a test event'
        }
      })
    });
    
    const result = await response.json();
    console.log('Event tracked:', result.success);
    return result;
  } catch (error) {
    console.error('Error tracking event:', error);
    return null;
  }
}

/**
 * Run a load test with multiple events
 */
async function runLoadTest(count = 50) {
  console.log(`Starting load test with ${count} events...`);
  
  try {
    const startTime = Date.now();
    const response = await fetch(`${config.baseUrl}/api/test/simulate-events`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ count })
    });
    
    const result = await response.json();
    const duration = Date.now() - startTime;
    console.log(`Load test completed in ${duration}ms`);
    console.log(`Generated ${result.eventsGenerated} events`);
    return result;
  } catch (error) {
    console.error('Error running load test:', error);
    return null;
  }
}

/**
 * Display test metrics
 */
function showMetrics() {
  console.log('\n--- Test Metrics ---');
  console.log(`Messages received: ${messageCount}`);
  console.log(`Last event latency: ${lastLatency}ms`);
  console.log(`Min latency: ${minLatency === Number.MAX_SAFE_INTEGER ? 'N/A' : minLatency}ms`);
  console.log(`Max latency: ${maxLatency}ms`);
  console.log(`Average latency: ${avgLatency.toFixed(2)}ms`);
  console.log('-------------------\n');
}

/**
 * Display interactive menu
 */
function showMenu() {
  console.log('\nReal-time Analytics Testing Menu:');
  console.log('1. Connect to WebSocket');
  console.log('2. Track single event');
  console.log('3. Run load test (50 events)');
  console.log('4. Run load test (custom count)');
  console.log('5. Show metrics');
  console.log('6. Exit');
  
  rl.question('\nSelect an option: ', async (answer) => {
    switch (answer) {
      case '1':
        connectWebSocket();
        break;
      case '2':
        await trackEvent();
        break;
      case '3':
        await runLoadTest(50);
        break;
      case '4':
        rl.question('How many events? ', async (count) => {
          await runLoadTest(parseInt(count, 10) || 50);
          showMenu();
        });
        return;
      case '5':
        showMetrics();
        break;
      case '6':
        console.log('Exiting...');
        process.exit(0);
        break;
      default:
        console.log('Invalid option');
    }
    
    showMenu();
  });
}

// Start the test
console.log('Real-time Analytics Testing Tool');
console.log('===============================');
showMenu();