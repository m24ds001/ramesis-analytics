# Ramesis Analytics Platform - Technical Specifications

## System Architecture

### High-Level Overview
```
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│   Client App    │    │   Backend API    │    │  External APIs  │
│   (React/TS)    │◄──►│  (Node.js/Express)│◄──►│ GA4/Adobe/Mix   │
└─────────────────┘    └──────────────────┘    └─────────────────┘
         │                       │                       │
         ▼                       ▼                       ▼
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│  Real-time UI   │    │   PostgreSQL     │    │   AI Services   │
│   (WebSocket)   │    │   Database       │    │ OpenAI/Gemini   │
└─────────────────┘    └──────────────────┘    └─────────────────┘
```

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **State Management**: TanStack Query v5 for server state
- **Styling**: Tailwind CSS with Shadcn/ui components
- **Real-time**: WebSocket connections for live updates
- **Routing**: Wouter for client-side navigation
- **Charts**: Recharts for data visualization

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Database**: PostgreSQL with Drizzle ORM
- **Real-time**: WebSocket server for live data streaming
- **Authentication**: Session-based with secure cookies
- **Rate Limiting**: Express-rate-limit middleware
- **Validation**: Zod schemas for type-safe data validation

### Database Schema
```sql
-- Core Tables
- users (id, email, created_at, updated_at)
- websites (id, name, domain, category, user_id)
- website_credentials (id, website_id, provider, api_key)
- external_website_catalog (id, name, domain, category, traffic_multiplier)
- website_visits (id, page, timestamp, session_id, user_agent)
- user_events (id, event_type, session_id, data, timestamp)
- ai_insights (id, content, category, confidence, created_at)
- recommendations (id, title, description, priority, implemented)
```

## API Endpoints

### Analytics Data Endpoints
```
GET /api/ga4-data                 - Google Analytics 4 real-time data
GET /api/adobe-analytics-data     - Adobe Analytics metrics
GET /api/mixpanel-data            - Mixpanel event data
POST /api/unified-analytics       - Aggregated analytics from all sources
```

### External Website Monitoring
```
GET /api/external-websites        - List of monitored websites
GET /api/external-websites/search - Search websites by domain/name
GET /api/traffic-estimate/:domain - Traffic estimation for specific domain
POST /api/external-websites/:id/analytics/:metricType - Specific metrics
```

### Real-time Features
```
WebSocket /api/ws                 - Real-time data streaming
POST /api/track-event            - Event tracking endpoint
GET /api/real-tracking/stats     - Live tracking statistics
```

### AI & Insights
```
GET /api/insights                 - AI-generated insights
GET /api/recommendations         - Performance recommendations
POST /api/insights/generate      - Trigger new insight generation
```

## Data Integration

### Google Analytics 4 Integration
- **Service Account**: JSON key-based authentication
- **Measurement ID**: G-9V5W3D1G12 for client-side tracking
- **Property ID**: 487980909 for server-side API access
- **Real-time API**: Live visitor counts and engagement metrics
- **Reporting API**: Historical data and trend analysis

### Adobe Analytics Integration
- **Client ID**: 95b27a2a018b4cff8e353aac863a2328
- **API Access**: Reporting Suite APIs for metrics extraction
- **Real-time Data**: Live traffic and conversion tracking
- **Segments**: Custom audience analysis

### Mixpanel Integration
- **Project ID**: 3710164
- **API Key**: 047dff119d1bbfb0711f22fbe4c0d3cd
- **Event Tracking**: User behavior and funnel analysis
- **Cohort Analysis**: User retention metrics

### AI Service Integration
- **OpenAI GPT-4o**: Advanced insight generation and analysis
- **Google Gemini AI**: Recommendation engine and pattern recognition
- **Rate Limiting**: Intelligent usage optimization to stay within API limits

## Performance Specifications

### Real-time Capabilities
- **WebSocket Latency**: <100ms for live updates
- **Data Refresh Rate**: Every 1-5 seconds for critical metrics
- **Concurrent Users**: Supports 1000+ simultaneous connections
- **Update Frequency**: Real-time visitor counts updated every second

### Scalability Metrics
- **Page Views**: Currently handling 245,781/500,000 monthly
- **API Requests**: 1000+ requests per minute peak capacity
- **Database Performance**: Sub-100ms query response times
- **Memory Usage**: Optimized for low-memory operation

### Data Processing
- **External Websites**: 10+ major platforms monitored
- **Traffic Multipliers**: Website-specific scaling factors (Google: 2.3x, YouTube: 1.95x)
- **Category-based Analytics**: E-commerce, Media, Technology segments
- **Historical Data**: 30-day rolling window for trend analysis

## Security & Compliance

### Data Protection
- **Encryption**: TLS 1.3 for all data transmission
- **Secret Management**: Environment-based API key storage
- **Session Security**: HTTP-only cookies with secure flags
- **Input Validation**: Comprehensive Zod schema validation

### API Security
- **Rate Limiting**: 100 requests per minute per IP
- **CORS**: Configured for authorized domains only
- **Authentication**: Session-based with automatic expiration
- **Error Handling**: Secure error responses without data leakage

### Compliance Features
- **GDPR Ready**: Data anonymization and deletion capabilities
- **Privacy Controls**: User consent management
- **Audit Logging**: Comprehensive activity tracking
- **Data Retention**: Configurable retention policies

## Deployment & Infrastructure

### Environment Configuration
```env
# Analytics Integration
GOOGLE_ANALYTICS_PROPERTY_ID=[your_property_id]
VITE_GA_MEASUREMENT_ID=[your_measurement_id]
ADOBE_ANALYTICS_CLIENT_ID=[your_adobe_client_id]
MIXPANEL_API_KEY=[your_mixpanel_api_key]

# AI Services
OPENAI_API_KEY=[secure_key]
GOOGLE_AI_API_KEY=[secure_key]

# Database
DATABASE_URL=[postgresql_connection]
```

### Production Requirements
- **Node.js**: Version 18+ with TypeScript support
- **PostgreSQL**: Version 14+ with connection pooling
- **Memory**: Minimum 2GB RAM for optimal performance
- **Storage**: 10GB+ for database and logs
- **Network**: High-bandwidth connection for real-time data

### Monitoring & Observability
- **Health Checks**: Automated endpoint monitoring
- **Performance Metrics**: Response time and throughput tracking
- **Error Tracking**: Comprehensive error logging and alerting
- **Usage Analytics**: Platform usage and performance metrics

## Quality Assurance

### Testing Coverage
- **Unit Tests**: Core business logic validation
- **Integration Tests**: API endpoint functionality
- **Real-time Tests**: WebSocket connection stability
- **Performance Tests**: Load testing for concurrent users

### Data Validation
- **Real-time Verification**: Live data accuracy checks
- **Cross-platform Validation**: Multi-source data comparison
- **AI Insight Quality**: Confidence scoring for recommendations
- **Error Recovery**: Graceful fallback mechanisms

---

*Document Version: 1.0*
*Last Updated: May 26, 2025*
*Prepared for: Ramesis Analytics Platform Publication*