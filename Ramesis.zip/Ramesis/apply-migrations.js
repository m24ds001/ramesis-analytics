/**
 * Script to apply database migrations
 * 
 * Usage:
 * node apply-migrations.js
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import { db } from './server/db.js';
import { sql } from 'drizzle-orm';

// Get the directory name using ES modules pattern
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

async function applyMigrations() {
  try {
    console.log('Starting database migration process...');
    
    // Create migrations table using Drizzle with safe SQL
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS migrations (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL UNIQUE,
        applied_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      )
    `);
    
    // Get already applied migrations using Drizzle
    const appliedMigrations = await db.execute(sql`SELECT name FROM migrations`);
    const appliedMigrationNames = new Set(appliedMigrations.map(m => m.name));
    
    // Check if migrations directory exists
    const migrationsDir = path.join(__dirname, 'migrations');
    if (!fs.existsSync(migrationsDir)) {
      console.log('No migrations directory found. Creating one...');
      fs.mkdirSync(migrationsDir, { recursive: true });
      console.log('Migrations directory created. No migration files to process.');
      return;
    }
    
    // Get all migration files
    const migrationFiles = fs.readdirSync(migrationsDir)
      .filter(file => file.endsWith('.sql'))
      .sort(); // Ensure files are processed in order
    
    if (migrationFiles.length === 0) {
      console.log('No migration files found.');
      return;
    }
    
    console.log(`Found ${migrationFiles.length} migration files to process.`);
    
    // Apply new migrations
    for (const file of migrationFiles) {
      if (appliedMigrationNames.has(file)) {
        console.log(`Migration ${file} already applied, skipping.`);
        continue;
      }
      
      console.log(`Applying migration: ${file}`);
      
      // Read migration file
      const migrationPath = path.join(migrationsDir, file);
      const migrationContent = fs.readFileSync(migrationPath, 'utf8');
      
      // Validate migration content (basic check)
      if (!migrationContent.trim()) {
        console.log(`Migration ${file} is empty, skipping.`);
        continue;
      }
      
      // Validate migration content for basic safety
      const dangerousPatterns = [
        /DROP\s+DATABASE/i,
        /TRUNCATE\s+TABLE\s+migrations/i,
        /DELETE\s+FROM\s+migrations/i,
        /--.*DROP/i,
        /\/\*.*DROP.*\*\//i
      ];
      
      const isDangerous = dangerousPatterns.some(pattern => pattern.test(migrationContent));
      if (isDangerous) {
        console.error(`Migration ${file} contains potentially dangerous SQL operations. Skipping for safety.`);
        continue;
      }
      
      // Use transaction with Drizzle
      await db.transaction(async (tx) => {
        // For migrations, we need to use the raw database connection pool
        // since Drizzle's sql template literals don't support dynamic DDL statements
        // This is safer than sql.raw() as we've already validated the content
        const pool = tx.$client || db.$client;
        
        // Split migration content into individual statements
        const statements = migrationContent
          .split(';')
          .map(stmt => stmt.trim())
          .filter(stmt => stmt.length > 0);
        
        for (const statement of statements) {
          if (statement.trim()) {
            // Execute each statement directly through the pool
            // Note: This is safe because we've already validated the migration content above
            await pool.query(statement);
          }
        }
        
        // Record migration as applied using parameterized query
        await tx.execute(sql`INSERT INTO migrations (name) VALUES (${file})`);
      });
      
      console.log(`Successfully applied migration: ${file}`);
    }
    
    console.log('Database migration completed successfully.');
  } catch (error) {
    console.error('Error during migration process:', error);
    process.exit(1);
  }
}

// Run migrations
applyMigrations();