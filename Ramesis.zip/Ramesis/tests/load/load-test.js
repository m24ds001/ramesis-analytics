/**
 * Load testing script for the Analytics Platform API
 * 
 * Usage:
 * node tests/load/load-test.js
 * 
 * Or with custom settings:
 * CONNECTIONS=50 DURATION=30 URL=http://localhost:5000/api/events node tests/load/load-test.js
 */

import autocannon from 'autocannon';
import { promisify } from 'util';

// Default settings
const DEFAULT_URL = 'http://localhost:5000/api/events';
const DEFAULT_CONNECTIONS = 100;
const DEFAULT_DURATION = 60; // seconds

// Get settings from environment variables or use defaults
const URL = process.env.URL || DEFAULT_URL;
const CONNECTIONS = parseInt(process.env.CONNECTIONS || DEFAULT_CONNECTIONS, 10);
const DURATION = parseInt(process.env.DURATION || DEFAULT_DURATION, 10);

// Sample data for POST requests
const sampleEvent = {
  sessionId: 'load-test-session',
  timestamp: new Date().toISOString(),
  eventType: 'test',
  url: '/test-page',
  data: { testRun: true, loadTest: true }
};

// Create test configuration
const testConfig = {
  url: URL,
  connections: CONNECTIONS,
  duration: DURATION,
  title: `Load testing ${URL}`,
  headers: {
    'Content-Type': 'application/json'
  },
  requests: [
    {
      method: 'POST',
      path: '/',
      body: JSON.stringify(sampleEvent),
      headers: {
        'Content-Type': 'application/json'
      }
    },
    {
      method: 'GET',
      path: '/?limit=10',
    }
  ]
};

console.log(`Starting load test with ${CONNECTIONS} connections for ${DURATION} seconds on ${URL}`);

// Run the test
autocannon(testConfig, (err, results) => {
  if (err) {
    console.error('Error running load test:', err);
    process.exit(1);
  }
  
  // Print results
  console.log('===== LOAD TEST RESULTS =====');
  console.log(`Target: ${results.title}`);
  console.log(`Duration: ${results.duration}s`);
  console.log(`Connections: ${results.connections}`);
  console.log('\nSummary:');
  console.log(`Requests: ${results.requests.total}`);
  console.log(`Throughput: ${Math.floor(results.requests.average)} req/sec`);
  console.log(`Latency (avg): ${results.latency.average.toFixed(2)}ms`);
  console.log(`Latency (min): ${results.latency.min}ms`);
  console.log(`Latency (max): ${results.latency.max}ms`);
  console.log(`Latency (p99): ${results.latency.p99.toFixed(2)}ms`);
  console.log('\nErrors:');
  console.log(`Socket errors: ${results.errors}`);
  console.log(`HTTP errors: ${results.non2xx}`);
  console.log('\nStatus codes:');
  Object.entries(results.statusCodeStats).forEach(([code, count]) => {
    console.log(`  ${code}: ${count}`);
  });
  
  // Check if test was successful
  const successRate = (results.requests.total - results.non2xx) / results.requests.total;
  if (successRate < 0.95) {
    console.error('\nTest FAILED: Success rate below 95%');
    process.exit(1);
  } else {
    console.log('\nTest PASSED');
  }
});

// Handle CTRL+C
process.once('SIGINT', () => {
  console.log('Load test aborted');
  process.exit(0);
});