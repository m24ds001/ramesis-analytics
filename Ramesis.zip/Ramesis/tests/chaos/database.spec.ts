import { pool } from '../../server/db';
import fetch from 'node-fetch';
import { describe, test, expect, beforeAll, afterAll } from '@jest/globals';

// Base URL for the API
const API_BASE_URL = 'http://localhost:5000';

/**
 * Simulates a database failure by closing all connections
 */
async function simulateDatabaseFailure() {
  console.log('Simulating database failure...');
  await pool.end();
  
  // Wait for all connections to be closed properly
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  console.log('Database connections closed');
  return true;
}

/**
 * Restores database connectivity
 */
async function restoreDatabase() {
  console.log('Restoring database connectivity...');
  
  // Re-import the module to reinitialize the pool
  const { pool: newPool } = await import('../../server/db');
  
  // Make a test query to ensure connectivity
  await newPool.query('SELECT 1');
  
  console.log('Database connectivity restored');
  return true;
}

/**
 * Performs a health check request
 */
async function healthCheck() {
  return fetch(`${API_BASE_URL}/health`);
}

// Chaos testing scenarios for database resilience
describe('Database Resilience', () => {
  // Ensure the database is connected before and after tests
  beforeAll(async () => {
    try {
      await pool.query('SELECT 1');
    } catch (error) {
      console.error('Database is not available for testing:', error);
      throw error;
    }
  });
  
  afterAll(async () => {
    // Ensure database is restored
    try {
      await restoreDatabase();
    } catch (error) {
      console.error('Failed to restore database after tests:', error);
    }
  });
  
  test('System correctly reports health when database is down', async () => {
    // Check that system is healthy before test
    const initialResponse = await healthCheck();
    expect(initialResponse.status).toBe(200);
    
    // Simulate database failure
    await simulateDatabaseFailure();
    
    // System should report as unhealthy
    const unhealthyResponse = await healthCheck();
    expect(unhealthyResponse.status).toBe(503);
    
    const unhealthyBody = await unhealthyResponse.json();
    expect(unhealthyBody.status).toBe('unhealthy');
    expect(unhealthyBody.database.connected).toBe(false);
    
    // Restore database
    await restoreDatabase();
    
    // Wait for the system to recover
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    // System should report as healthy again
    const recoveryResponse = await healthCheck();
    expect(recoveryResponse.status).toBe(200);
    
    const recoveryBody = await recoveryResponse.json();
    expect(recoveryBody.status).toBe('healthy');
    expect(recoveryBody.database.connected).toBe(true);
  }, 30000);  // Allow extra time for this test due to recovery period
  
  test('API endpoints gracefully handle database outages', async () => {
    // Check that we can fetch events before the outage
    const initialEventsResponse = await fetch(`${API_BASE_URL}/api/events`);
    expect(initialEventsResponse.status).toBe(200);
    
    // Simulate database failure
    await simulateDatabaseFailure();
    
    // System should return 503 for API requests
    const unhealthyEventsResponse = await fetch(`${API_BASE_URL}/api/events`);
    expect(unhealthyEventsResponse.status).toBe(503);
    
    // Restore database
    await restoreDatabase();
    
    // Wait for the system to recover
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    // System should handle API requests again
    const recoveryEventsResponse = await fetch(`${API_BASE_URL}/api/events`);
    expect(recoveryEventsResponse.status).toBe(200);
  }, 30000);  // Allow extra time for this test due to recovery period
});