import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/Dashboard";
import UserBehavior from "@/pages/UserBehavior";
import AiInsights from "@/pages/AiInsights";
import ActionItems from "@/pages/ActionItems";
import PredictiveAnalytics from "@/pages/PredictiveAnalytics";
import Reports from "@/pages/Reports";
import Settings from "@/pages/Settings";
import WebsiteCatalog from "@/pages/WebsiteCatalog";
import ExternalAnalyticsView from "@/pages/ExternalAnalyticsView";
import WebsiteComparison from "@/pages/WebsiteComparison";

import Comparison from "@/pages/Comparison";
import SharedInsight from "@/pages/SharedInsight";
import AppShell from "@/components/layout/AppShell";
import { useEffect } from "react";
import { initGA } from "./lib/analytics";
import { useAnalytics } from "./hooks/use-analytics";

function Router() {
  // Track page views when routes change
  useAnalytics();
  
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/user-behavior" component={UserBehavior} />
      <Route path="/ai-insights" component={AiInsights} />
      <Route path="/action-items" component={ActionItems} />
      <Route path="/predictive-analytics" component={PredictiveAnalytics} />

      <Route path="/reports" component={Reports} />
      <Route path="/websites" component={WebsiteCatalog} />
      <Route path="/analytics/:websiteId/:provider" component={ExternalAnalyticsView} />
      <Route path="/website-comparison" component={WebsiteComparison} />
      <Route path="/comparison" component={Comparison} />

      <Route path="/settings" component={Settings} />
      <Route path="/shared-insight" component={SharedInsight} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  // Initialize Google Analytics when app loads
  useEffect(() => {
    // Verify required environment variable is present
    if (!import.meta.env.VITE_GA_MEASUREMENT_ID) {
      console.warn('Missing required Google Analytics key: VITE_GA_MEASUREMENT_ID');
    } else {
      console.log('Initializing Google Analytics with ID:', import.meta.env.VITE_GA_MEASUREMENT_ID);
      initGA();
    }
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <AppShell>
          <Router />
        </AppShell>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
