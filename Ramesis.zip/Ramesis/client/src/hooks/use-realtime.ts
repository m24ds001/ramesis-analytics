import { useState, useEffect } from 'react';

// Define real-time message types
export interface RealtimeMessage {
  type: string;
  data: any;
  count?: number;
  change?: number | null;
  timestamp?: number;
  channel?: string;
}

// Define metrics structure
export interface RealtimeMetrics {
  activeUsers: number;
  pageViews: number;
  conversionRate: number;
  averageSessionDuration: number;
  chartData: any[];
  error?: boolean;
  errorMessage?: string;
}

// Initial metrics for real-time dashboard
export const initialMetrics: RealtimeMetrics = {
  activeUsers: 0,
  pageViews: 0,
  conversionRate: 0,
  averageSessionDuration: 0,
  chartData: []
};

/**
 * Initialize WebSocket connection for real-time updates
 * @param onMessage Callback function to handle incoming messages
 * @returns Cleanup function to close connection
 */
export const initRealtime = (onMessage: (data: RealtimeMessage) => void) => {
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  const wsUrl = `${protocol}//${window.location.host}/api/ws`;
  
  console.log('Connecting WebSocket to:', wsUrl);
  const ws = new WebSocket(wsUrl);
  
  // Define maximum reconnect attempts
  const maxReconnectAttempts = 5;
  let connectionAttempts = 0;
  
  // Handle connection open
  ws.onopen = () => {
    console.log('WebSocket connection established');
    
    // Subscribe to analytics updates
    ws.send(JSON.stringify({
      type: 'subscribe',
      channel: 'analytics'
    }));
  };
  
  // Handle incoming messages
  ws.onmessage = (event) => {
    try {
      const message = JSON.parse(event.data);
      onMessage(message);
    } catch (error) {
      console.error('Error parsing real-time message:', error);
    }
  };
  
  // Handle connection close
  ws.onclose = (event) => {
    console.log('WebSocket connection closed', event.code, event.reason);
    
    // Attempt to reconnect unless we've reached max attempts
    if (connectionAttempts < maxReconnectAttempts) {
      connectionAttempts++;
      console.log(`Attempting to reconnect (${connectionAttempts}/${maxReconnectAttempts})...`);
      setTimeout(() => {
        initRealtime(onMessage);
      }, 3000); // Wait 3 seconds before reconnecting
    } else {
      console.log('Maximum reconnection attempts reached');
    }
  };
  
  // Handle errors
  ws.onerror = (error) => {
    console.error('WebSocket error:', error);
  };
  
  // Return cleanup function
  return () => {
    console.log('Cleaning up WebSocket connection');
    ws.close();
  };
};

/**
 * Hook to use real-time analytics data
 * @param websiteId Optional ID of the external website to get analytics for
 * @returns Current metrics and functions to update them
 */
export const useRealTimeAnalytics = (websiteId?: number | null) => {
  const [metrics, setMetrics] = useState<RealtimeMetrics>(initialMetrics);
  const [websiteName, setWebsiteName] = useState<string | null>(null);
  
  // Fetch the website name if we have an ID
  useEffect(() => {
    if (websiteId) {
      // Get website details to get the name
      fetch(`/api/external-websites/${websiteId}`)
        .then(res => res.json())
        .then(data => {
          if (data && data.name) {
            setWebsiteName(data.name);
            console.log(`Set website name to: ${data.name}`);
          }
        })
        .catch(error => console.error('Error fetching website name:', error));
    } else {
      setWebsiteName(null);
    }
  }, [websiteId]);
  
  // Set up polling for real-time GA4 data
  useEffect(() => {
    // Function to fetch real-time analytics data from our API endpoint
    const fetchRealTimeAnalytics = async () => {
      try {
        const measurementId = import.meta.env.VITE_GA_MEASUREMENT_ID;
        if (!measurementId) return;
        
        // Create body with optional website info
        const body: any = { measurementId };
        if (websiteName) {
          body.websiteName = websiteName;
        }
        
        // Make API call to our GA4 data endpoint
        const response = await fetch('/api/ga4-data', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(body),
        });
        
        // Handle response
        if (response.ok) {
          const data = await response.json();
          
          // Update metrics with real data
          setMetrics(prev => ({
            ...prev,
            activeUsers: data.activeUsers || 0,
            conversionRate: data.conversionRate || 0,
            pageViews: data.pageViews || 0,
            averageSessionDuration: data.averageSessionDuration || 0
          }));
        } else {
          console.error('Error fetching real-time analytics data:', response.statusText);
          setMetrics(prev => ({
            ...prev,
            error: true,
            errorMessage: `Failed to fetch real-time analytics: ${response.statusText}`
          }));
        }
      } catch (error) {
        console.error('Error fetching real-time analytics data:', error);
        setMetrics(prev => ({
          ...prev,
          error: true,
          errorMessage: `Unable to connect to analytics service: ${error.message || 'Unknown error'}`
        }));
      }
    };
    
    // Fetch data immediately and then every 10 seconds
    fetchRealTimeAnalytics();
    const interval = setInterval(fetchRealTimeAnalytics, 10000);
    
    // Cleanup on unmount
    return () => {
      clearInterval(interval);
    };
  }, [websiteName]);
  
  // Initialize WebSocket connection for real-time active user updates
  useEffect(() => {
    // Initialize real-time connection with retry mechanism
    let cleanup: (() => void) | null = null;
    let retryCount = 0;
    const maxRetries = 5;
    
    const connectWebSocket = () => {
      try {
        // Initialize real-time connection
        cleanup = initRealtime((message) => {
          if (message.type === 'ANALYTICS_UPDATE') {
            setMetrics(prev => ({
              ...prev,
              [message.data.metricType]: message.data.value
            }));
          } else if (message.type === 'activeVisitors') {
            console.log('Active visitors update:', message.count);
            
            // Only update active users if we're not looking at a specific website
            if (!websiteId) {
              setMetrics(prev => ({
                ...prev,
                activeUsers: message.count
              }));
            }
          }
        });
      } catch (error) {
        console.error('Error initializing WebSocket:', error);
        // Retry connection with backoff
        if (retryCount < maxRetries) {
          retryCount++;
          const timeout = Math.min(1000 * Math.pow(2, retryCount), 30000);
          console.log(`Retrying WebSocket connection in ${timeout/1000}s... (${retryCount}/${maxRetries})`);
          setTimeout(connectWebSocket, timeout);
        }
      }
    };
    
    // Start connection
    connectWebSocket();
    
    // Cleanup on unmount
    return () => {
      if (cleanup) cleanup();
    };
  }, [websiteId]);
  
  return metrics;
};

/**
 * Hook to get only active users count from real-time analytics
 * A simplified version of useRealTimeAnalytics that only tracks active users
 */
export const useActiveUsers = () => {
  const [activeUsers, setActiveUsers] = useState(0);
  
  // Initialize WebSocket connection for real-time active user updates
  useEffect(() => {
    // Initialize real-time connection with retry mechanism
    const cleanup = initRealtime((message) => {
      if (message.type === 'activeVisitors' && message.count !== undefined) {
        console.log('Active visitors update:', message.count);
        setActiveUsers(message.count);
      }
    });
    
    // Cleanup on unmount
    return cleanup;
  }, []);
  
  return { activeUsers };
};