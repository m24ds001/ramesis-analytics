import { useState, useEffect } from 'react';

type RealTimeData = {
  activeVisitors: number;
  change: number | null;
};

export function useRealTimeData(): RealTimeData {
  // Initialize with zero active visitors - no simulated data
  const [data, setData] = useState<RealTimeData>({
    activeVisitors: 0,
    change: null,
  });
  
  useEffect(() => {
    // Create WebSocket connection with fixed URL
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const host = window.location.hostname + (window.location.port ? `:${window.location.port}` : '');
    const wsUrl = `${protocol}//${host}/api/ws`;
    console.log('Connecting WebSocket to:', wsUrl);
    
    let socket: WebSocket;
    try {
      socket = new WebSocket(wsUrl);
    } catch (error) {
      console.error('WebSocket connection error:', error);
      // Create a dummy object to avoid crashes
      socket = {
        onopen: null,
        onmessage: null,
        onerror: null,
        onclose: null,
        close: () => {},
        send: () => {},
        readyState: 3 // CLOSED
      } as unknown as WebSocket;
      
      // Use zeros for data when WebSocket fails - no simulated data
      setData({
        activeVisitors: 0,
        change: null
      });
    }
    
    socket.onopen = () => {
      console.log('WebSocket connection established');
    };
    
    socket.onmessage = (event) => {
      try {
        const message = JSON.parse(event.data);
        console.log('WebSocket message received:', message);
        
        if (message.type === 'activeVisitors') {
          console.log('Active visitors update:', message.count);
          setData({
            activeVisitors: message.count || 0,
            change: message.change || null,
          });
        } else if (message.type === 'welcome') {
          console.log('Connection established, active connections:', message.activeConnections);
          if (message.activeConnections !== undefined) {
            setData({
              activeVisitors: message.activeConnections,
              change: null
            });
          }
        } else if (message.type === 'connection_update') {
          console.log('Connection update, active connections:', message.activeConnections);
          if (message.activeConnections !== undefined) {
            setData({
              activeVisitors: message.activeConnections,
              change: null
            });
          }
        }
      } catch (error) {
        console.error('Error processing WebSocket message:', error);
      }
    };
    
    socket.onerror = (error) => {
      console.error('WebSocket error:', error);
      // Use zeros for data when WebSocket has an error - no simulated data
      setData({
        activeVisitors: 0,
        change: null
      });
    };
    
    socket.onclose = () => {
      console.log('WebSocket connection closed');
    };
    
    // Clean up the WebSocket connection on unmount
    return () => {
      socket.close();
    };
  }, []);
  
  return data;
}
