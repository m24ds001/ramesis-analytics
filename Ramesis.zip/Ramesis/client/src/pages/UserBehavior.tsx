import { Helmet } from 'react-helmet';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { generateTopPagesData } from '@/lib/chartUtils';
import { exportUserBehavior } from '@/lib/export';
import { Download, Route, Video, MousePointer, PieChart, Check, X } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogClose
} from '@/components/ui/dialog';

export default function UserBehaviorPage() {
  const [pageFilter, setPageFilter] = useState('all');
  const [dateRange, setDateRange] = useState('last7days');
  const [selectedWebsite, setSelectedWebsite] = useState<number | null>(null);
  const { toast } = useToast();
  
  // Fetch external websites for the selector
  const { data: websites } = useQuery({
    queryKey: ['/api/external-websites'],
    queryFn: () => fetch('/api/external-websites').then(res => res.json())
  });

  // Generate website-specific behavior data
  const generateWebsiteSpecificData = () => {
    if (!selectedWebsite || !websites) return null;
    
    const website = websites?.find((w: any) => w.id === selectedWebsite);
    if (!website) return null;
    
    // Base multipliers for different websites
    const multipliers: { [key: string]: number } = {
      'Google': 2.4,
      'Amazon': 1.8,
      'Facebook': 2.1,
      'YouTube': 1.9,
      'Wikipedia': 1.5,
      'Twitter': 1.7,
      'Instagram': 2.0,
      'LinkedIn': 1.6,
      'Netflix': 1.4,
      'Spotify': 1.3,
      'Reddit': 1.8,
      'Pinterest': 1.5,
      'TikTok': 2.2,
      'Flipkart': 1.6,
      'Microsoft': 1.4,
      'Apple': 1.7
    };
    
    // Time period multipliers
    const timeMultipliers: { [key: string]: number } = {
      'last7days': 0.7,
      'last14days': 0.85,
      'last30days': 1.0,
      'last90days': 1.8,
      'thismonth': 1.1,
      'lastmonth': 0.9
    };
    
    const baseMultiplier = multipliers[website.name] || 1.0;
    const timeMultiplier = timeMultipliers[dateRange] || 1.0;
    const finalMultiplier = baseMultiplier * timeMultiplier;
    
    // Generate unique seed based on website and date range
    const seed = (website.name + dateRange).split('').reduce((a, b) => a + b.charCodeAt(0), 0);
    const random = (index: number) => ((seed + index) * 9301 + 49297) % 233280 / 233280;
    
    return {
      clickHeatmapData: Array.from({ length: 20 }, (_, i) => ({
        x: Math.floor(random(i) * 100),
        y: Math.floor(random(i + 20) * 100),
        intensity: Math.floor((random(i + 40) * 80 + 20) * finalMultiplier),
        element: ['header', 'navigation', 'search-box', 'product-card', 'footer', 'sidebar', 'button', 'link'][i % 8]
      })),
      
      scrollHeatmapData: Array.from({ length: 15 }, (_, i) => ({
        depth: i * 100,
        percentage: Math.max(10, 100 - (i * (5 + random(i + 60) * 3)) * finalMultiplier),
        timeSpent: Math.floor((random(i + 80) * 30 + 10) * finalMultiplier)
      })),
      
      userJourneys: Array.from({ length: 8 }, (_, i) => ({
        id: i + 1,
        path: generatePathForWebsite(website.name, i, random),
        users: Math.floor((random(i + 100) * 500 + 100) * finalMultiplier),
        conversionRate: Math.floor((random(i + 120) * 15 + 5) * (website.name === 'Amazon' ? 1.3 : website.name === 'Google' ? 0.8 : 1.0)),
        avgDuration: Math.floor((random(i + 140) * 300 + 60) * finalMultiplier)
      })),
      
      sessionRecordings: Array.from({ length: 6 }, (_, i) => ({
        id: `${website.name.toLowerCase()}-${38290 + i}`,
        userId: `${38290 + i}`,
        duration: `${Math.floor(random(i + 160) * 10 + 2)}m ${Math.floor(random(i + 180) * 50 + 10)}s`,
        pages: Math.floor(random(i + 200) * 8 + 2) * Math.ceil(finalMultiplier),
        status: ['Converted', 'Bounced', 'Browsing', 'Returning'][i % 4],
        device: ['Desktop', 'Mobile', 'Tablet'][i % 3],
        location: getLocationForWebsite(website.name, i),
        timestamp: new Date(Date.now() - random(i + 220) * 7 * 24 * 60 * 60 * 1000).toLocaleDateString()
      }))
    };
  };
  
  const generatePathForWebsite = (websiteName: string, index: number, random: (i: number) => number) => {
    const paths: { [key: string]: string[] } = {
      'Amazon': [
        'Home → Search → Product → Reviews → Cart → Checkout',
        'Home → Categories → Product → Compare → Cart',
        'Home → Deals → Product → Add to Wishlist',
        'Search → Filter → Product → Related Items → Cart'
      ],
      'Google': [
        'Home → Search → Results → Website',
        'Home → Images → Search → View',
        'Home → Maps → Search → Directions',
        'Home → News → Article → Related'
      ],
      'Flipkart': [
        'Home → Search → Product → Reviews → Cart → Payment',
        'Home → Categories → Electronics → Mobile → Cart',
        'Home → Offers → Product → Compare → Buy',
        'Search → Filter → Sort → Product → Checkout'
      ],
      'Netflix': [
        'Home → Browse → Movie → Play',
        'Home → My List → Continue Watching',
        'Search → Results → Movie → Add to List',
        'Home → Trending → Show → Episodes'
      ]
    };
    
    const websitePaths = paths[websiteName] || [
      'Home → Browse → Content → View',
      'Home → Search → Results → Click',
      'Home → Navigation → Page → Action',
      'Search → Filter → Results → Convert'
    ];
    
    return websitePaths[index % websitePaths.length];
  };
  
  const getLocationForWebsite = (websiteName: string, index: number) => {
    const locations: { [key: string]: string[] } = {
      'Amazon': ['New York, US', 'London, UK', 'Tokyo, JP', 'Mumbai, IN'],
      'Google': ['San Francisco, US', 'Berlin, DE', 'Sydney, AU', 'Toronto, CA'],
      'Flipkart': ['Bangalore, IN', 'Mumbai, IN', 'Delhi, IN', 'Chennai, IN'],
      'Netflix': ['Los Angeles, US', 'London, UK', 'Seoul, KR', 'São Paulo, BR']
    };
    
    const websiteLocations = locations[websiteName] || ['Global', 'International', 'Worldwide', 'Remote'];
    return websiteLocations[index % websiteLocations.length];
  };
  
  const behaviorData = generateWebsiteSpecificData();
  const topPages = generateTopPagesData();
  
  // State for recording modal
  const [isRecordingModalOpen, setIsRecordingModalOpen] = useState(false);
  const [recordingData, setRecordingData] = useState<{
    userId: string;
    status: string;
    statusColor: string;
    duration: string;
    exitPoint?: string;
  } | null>(null);

  // Handle session recording watch action
  const handleWatchRecording = (userId: string) => {
    // Prepare data for modal display
    const status = userId === "38290" ? "Bounced" : userId === "38291" ? "Converted" : "Returning";
    const statusColor = userId === "38290" ? "red" : "green";
    const duration = userId === "38291" ? "8m 23s" : userId === "38290" ? "5m 47s" : "12m 05s";
    
    setRecordingData({
      userId,
      status,
      statusColor,
      duration,
      exitPoint: userId === "38290" ? "Home Page" : "Checkout"
    });
    
    setIsRecordingModalOpen(true);
    
    toast({
      title: "Session Recording",
      description: `Viewing session recording for User #${userId}`,
      variant: "default",
    });
  };
  
  // Fetch specific website data if selected
  const { data: website } = useQuery({
    queryKey: selectedWebsite ? ['/api/external-websites', selectedWebsite] : ['/api/external-websites', 'none'],
    queryFn: () => selectedWebsite ? fetch(`/api/external-websites/${selectedWebsite}`).then(res => res.json()) : null,
    enabled: !!selectedWebsite
  });
  
  // Show toast notification when website changes
  useEffect(() => {
    if (website) {
      toast({
        title: `Viewing ${website.name} behavior data`,
        description: "User behavior maps and interactions updated with website-specific data",
        variant: "default",
      });
    }
  }, [website, toast]);
  
  // Website-specific element interactions
  const getElementInteractions = (websiteName?: string) => {
    const websiteInteractions: { [key: string]: Array<{element: string, rate: number | string}> } = {
      // Amazon
      'Amazon': [
        { element: 'Product Images', rate: 78 },
        { element: 'Buy Now Button', rate: 62 },
        { element: 'Reviews Section', rate: 45 }
      ],
      // Flipkart
      'Flipkart': [
        { element: 'Price Widget', rate: 65 },
        { element: 'Add to Cart', rate: 53 },
        { element: 'Search Bar', rate: 48 }
      ],
      // YouTube
      'YouTube': [
        { element: 'Video Thumbnail', rate: 82 },
        { element: 'Subscribe Button', rate: 27 },
        { element: 'Like Button', rate: 36 }
      ],
      // Netflix
      'Netflix': [
        { element: 'Continue Watching', rate: 76 },
        { element: 'New Releases', rate: 58 },
        { element: 'Profile Selector', rate: 31 }
      ],
      // Instagram
      'Instagram': [
        { element: 'Profile Photos', rate: 81 },
        { element: 'Stories', rate: 73 },
        { element: 'Comment Button', rate: 22 }
      ],
      // Twitter
      'Twitter': [
        { element: 'Tweet Button', rate: 45 },
        { element: 'Trending Topics', rate: 67 },
        { element: 'Profile Links', rate: 39 }
      ],
      // Walmart
      'Walmart': [
        { element: 'Add to Cart', rate: 58 },
        { element: 'Recommendations', rate: 42 },
        { element: 'Store Locator', rate: 31 }
      ],
      // Default
      'default': [
        { element: 'CTA Button', rate: 62 },
        { element: 'Navigation Menu', rate: 48 },
        { element: 'Feature Section', rate: 35 }
      ]
    };
    
    if (!websiteName) return websiteInteractions['default'];
    return websiteInteractions[websiteName] || websiteInteractions['default'];
  };
  
  return (
    <>
      <Helmet>
        <title>User Behavior | AilyticsPro - AI-Powered Website Analytics</title>
        <meta name="description" content="Analyze user behavior on your website with detailed heatmaps, session recordings, and interaction tracking." />
      </Helmet>
      
      <div className="mb-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">User Behavior Analysis</h1>
            <p className="text-sm text-gray-500">Track how users interact with your website in detail</p>
          </div>
          
          <div className="mt-4 sm:mt-0">
            <Button onClick={() => exportUserBehavior('csv', dateRange)}>
              <Download className="w-4 h-4 mr-2" />
              Export Data
            </Button>
          </div>
        </div>
        
        {/* Website Selection Banner */}
        <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 mb-6">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div className="flex-1">
              <h3 className="text-base font-medium text-gray-900 mb-1">Select Website to View Behavior Maps</h3>
              <p className="text-sm text-gray-500">Choose a specific website to see detailed user interaction data</p>
            </div>
            
            <div className="flex flex-col sm:flex-row items-start gap-3">
              <div className="flex flex-col">
                <label className="text-sm font-medium text-gray-700 mb-1">Website</label>
                <Select 
                  value={selectedWebsite?.toString() || ""} 
                  onValueChange={(value) => setSelectedWebsite(value ? Number(value) : null)}
                >
                  <SelectTrigger className="w-[180px] bg-primary-50 border-primary-300 shadow-sm focus:ring-primary-500 focus:border-primary-500">
                    <SelectValue placeholder="Select website" />
                  </SelectTrigger>
                  <SelectContent>
                    <div className="p-2 border-b border-gray-100">
                      <p className="text-xs font-medium text-gray-500">Select a website to view its data</p>
                    </div>
                    <SelectItem value="all">All websites</SelectItem>
                    {websites?.map((website: any) => (
                      <SelectItem key={website.id} value={website.id.toString()}>
                        {website.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex flex-col">
                <label className="text-sm font-medium text-gray-700 mb-1">Time Period</label>
                <Select value={dateRange} onValueChange={setDateRange}>
                  <SelectTrigger className="w-[150px]">
                    <SelectValue placeholder="Select date range" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="last7days">Last 7 days</SelectItem>
                    <SelectItem value="last30days">Last 30 days</SelectItem>
                    <SelectItem value="last90days">Last 90 days</SelectItem>
                    <SelectItem value="thismonth">This month</SelectItem>
                    <SelectItem value="lastmonth">Last month</SelectItem>
                    <SelectItem value="custom">Custom range</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <Tabs defaultValue="heatmap" className="mb-6">
        <TabsList className="grid w-full grid-cols-3 mb-4">
          <TabsTrigger value="heatmap">Heatmaps</TabsTrigger>
          <TabsTrigger value="journeys">User Journeys</TabsTrigger>
          <TabsTrigger value="recordings">Session Recordings</TabsTrigger>
        </TabsList>
        
        <TabsContent value="heatmap">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            <Card>
              <CardHeader className="px-4 py-5 border-b border-gray-200 sm:px-6 flex flex-row items-center justify-between">
                <div>
                  <CardTitle className="text-lg leading-6 font-medium text-gray-900">
                    User Behavior Map
                  </CardTitle>
                  {website ? (
                    <div className="mt-1 flex items-center">
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                        {website.name}
                      </span>
                      <span className="ml-2 text-xs text-gray-500">Website-specific data</span>
                    </div>
                  ) : (
                    <span className="text-xs text-gray-500 mt-1">Select a website to view specific behavior data</span>
                  )}
                </div>
                <Button variant="outline" size="sm">
                  <MousePointer className="w-4 h-4 mr-1" />
                  Filter
                </Button>
              </CardHeader>
              <CardContent className="px-4 py-5 sm:p-6">
                {/* A heatmap of user clicks and interactions with export functionality */}
                <div className="h-72 relative rounded-md overflow-hidden">
                  <img 
                    src={website?.name === 'Amazon' 
                      ? 'https://images.unsplash.com/photo-1551434678-e076c223a692?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&h=600'
                      : website?.name === 'Flipkart'
                      ? 'https://images.unsplash.com/photo-1563986768494-4dee2763ff3f?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&h=600'
                      : website?.name === 'YouTube'
                      ? 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&h=600'
                      : 'https://images.unsplash.com/photo-1551434678-e076c223a692?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&h=600'
                    }
                    alt="User behavior heatmap" 
                    className="w-full h-full object-cover" 
                    crossOrigin="anonymous"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-white/40 to-transparent"></div>
                  
                  {/* Overlay hotspots to show interaction points */}
                  <div className="absolute top-1/4 left-1/3 h-8 w-8 rounded-full bg-red-500/30 animate-pulse border-2 border-red-500"></div>
                  <div className="absolute top-2/3 left-1/2 h-6 w-6 rounded-full bg-red-500/30 animate-pulse border-2 border-red-500"></div>
                  <div className="absolute top-1/2 right-1/4 h-10 w-10 rounded-full bg-red-500/30 animate-pulse border-2 border-red-500"></div>
                  
                  {/* Add website info overlay for exported image */}
                  {website && (
                    <div className="absolute bottom-3 left-3 bg-white/80 backdrop-blur-sm px-3 py-1 rounded-md text-xs font-medium text-gray-800 shadow-sm">
                      {website.name} User Behavior Map
                    </div>
                  )}
                </div>
                <div className="mt-6 pt-4 border-t border-gray-100">
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="text-sm font-medium text-gray-900">Top Interaction Points</h4>
                    <Button 
                      variant="ghost" 
                      size="sm"
                      className="text-xs h-7 px-2"
                    >
                      <Download className="h-3.5 w-3.5 mr-1" />
                      Save
                    </Button>
                  </div>
                  
                  <div id="top-interactions" className="p-3 bg-white rounded-md border border-gray-100">
                    {website && (
                      <div className="mb-2 pb-2 border-b border-gray-100">
                        <span className="text-xs font-medium text-gray-500">{website.name} Interaction Analysis</span>
                      </div>
                    )}
                    
                    <ul className="space-y-2">
                      {(website?.name === 'Amazon' ? [
                        { element: 'Product Image Gallery', rate: '78% click rate' },
                        { element: 'Buy Now Button', rate: '62% interaction' },
                        { element: 'Reviews Section', rate: '45% scrolled to' }
                      ] : website?.name === 'Flipkart' ? [
                        { element: 'Price Comparison Widget', rate: '65% click rate' },
                        { element: 'Add to Cart Button', rate: '53% interaction' },
                        { element: 'Search Bar', rate: '48% used' }
                      ] : website?.name === 'YouTube' ? [
                        { element: 'Video Thumbnail', rate: '82% click rate' },
                        { element: 'Subscribe Button', rate: '27% interaction' },
                        { element: 'Like Button', rate: '36% used' }
                      ] : [
                        { element: 'Homepage Hero Button', rate: '62% click rate' },
                        { element: 'Pricing Comparison Table', rate: '48% interaction' },
                        { element: 'Contact Form Submit', rate: '23% completion' }
                      ]).map((item, index) => (
                        <li key={index} className="flex justify-between items-center text-sm p-2 rounded-md hover:bg-gray-50">
                          <span className="text-gray-600 flex items-center">
                            {index === 0 ? <MousePointer className="h-4 w-4 mr-2 text-primary-500" /> : 
                             index === 1 ? <PieChart className="h-4 w-4 mr-2 text-green-500" /> :
                             <Check className="h-4 w-4 mr-2 text-blue-500" />}
                            {item.element}
                          </span>
                          <span className="font-medium text-gray-900">{item.rate}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="px-4 py-5 border-b border-gray-200 sm:px-6 flex flex-row items-center justify-between">
                <CardTitle className="text-lg leading-6 font-medium text-gray-900">Element Interactions</CardTitle>
                <Select value={pageFilter} onValueChange={setPageFilter}>
                  <SelectTrigger className="w-[150px]">
                    <SelectValue placeholder="Filter by page" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Pages</SelectItem>
                    <SelectItem value="home">Homepage</SelectItem>
                    <SelectItem value="pricing">Pricing</SelectItem>
                    <SelectItem value="features">Features</SelectItem>
                    <SelectItem value="blog">Blog</SelectItem>
                  </SelectContent>
                </Select>
              </CardHeader>
              <CardContent className="px-4 py-5 sm:p-6">
                <div className="h-72 relative rounded-md overflow-hidden mb-4">
                  <img 
                    src="https://images.unsplash.com/photo-1553484771-047a44eee27a?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1200&h=600" 
                    alt="Element interaction analytics" 
                    className="w-full h-full object-cover" 
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-white/40 to-transparent"></div>
                </div>
                
                <div className="space-y-3">
                  {(selectedWebsite && website?.name ? 
                    getElementInteractions(website.name) : 
                    [
                      { element: 'CTA Button', rate: 75 },
                      { element: 'Navigation Menu', rate: 62 },
                      { element: 'Feature Section', rate: 48 }
                    ]
                  ).map((item: {element: string, rate: number | string}, index: number) => (
                    <div key={index} className="flex justify-between items-center">
                      <span className="text-sm font-medium">{item.element}</span>
                      <div className="w-48 bg-gray-200 rounded-full h-2.5">
                        <div 
                          className="bg-primary-500 h-2.5 rounded-full" 
                          style={{ width: `${typeof item.rate === 'number' ? item.rate : parseInt(item.rate.toString())}%` }}
                        ></div>
                      </div>
                      <span className="text-sm font-medium ml-2">
                        {typeof item.rate === 'number' ? `${item.rate}%` : item.rate}
                      </span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
          
          <Card className="mb-6">
            <CardHeader className="px-4 py-5 border-b border-gray-200 sm:px-6">
              <CardTitle className="text-lg leading-6 font-medium text-gray-900">Top Performing Pages</CardTitle>
            </CardHeader>
            <CardContent className="px-4 py-5 sm:p-6">
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Page URL</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Views</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Conversion Rate</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Bounce Rate</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {topPages.map((page, index) => (
                      <tr key={index}>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{page.page}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{page.views.toLocaleString()}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{page.conversion}%</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{page.bounce}%</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          <Button 
                            variant="link" 
                            size="sm" 
                            className="p-0 h-auto"
                            onClick={() => {
                              toast({
                                title: `Page details for ${page.page}`,
                                description: `Views: ${page.views.toLocaleString()}, Conversion Rate: ${page.conversion}%, Bounce Rate: ${page.bounce}%`,
                                variant: "default",
                              });
                            }}
                          >
                            View Details
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="journeys">
          <Card>
            <CardHeader className="px-4 py-5 border-b border-gray-200 sm:px-6">
              <CardTitle className="text-lg leading-6 font-medium text-gray-900">User Journey Analysis</CardTitle>
              {website && (
                <div className="mt-1 flex items-center">
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                    {website.name}
                  </span>
                  <span className="ml-2 text-xs text-gray-500">{dateRange.replace('last', 'Last ').replace('days', ' days')}</span>
                </div>
              )}
            </CardHeader>
            <CardContent className="px-4 py-5 sm:p-6">
              {!selectedWebsite ? (
                <div className="text-center py-8">
                  <Route className="mx-auto h-12 w-12 text-gray-400" />
                  <h3 className="mt-2 text-sm font-medium text-gray-900">Select a Website</h3>
                  <p className="mt-1 text-sm text-gray-500">Choose a website to view user journey patterns</p>
                </div>
              ) : (
                <div className="mb-6">
                  <h3 className="text-sm font-medium text-gray-700 mb-3">Top User Paths for {website?.name}</h3>
                  
                  <div className="space-y-4">
                    {behaviorData?.userJourneys.slice(0, 3).map((journey, index) => (
                      <div key={journey.id} className="border border-gray-200 rounded-md p-3">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center">
                            <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-primary-100 text-primary-800 text-xs font-medium mr-2">
                              {index + 1}
                            </span>
                            <span className="text-sm font-medium">{journey.path}</span>
                          </div>
                          <span className="text-sm font-medium text-gray-900">{journey.users} users</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <div className="flex-1 h-2 bg-primary-100 rounded-full"></div>
                          {journey.path.split(' → ').map((_, stepIndex) => (
                            <div key={stepIndex} className="flex-none h-4 w-4 rounded-full bg-primary-500 flex items-center justify-center">
                              <span className="text-[8px] text-white font-bold">{stepIndex + 1}</span>
                            </div>
                          )).slice(0, -1)}
                          <div className="flex-1 h-2 bg-gray-100 rounded-full"></div>
                        </div>
                        <div className="mt-2 text-xs text-gray-500">
                          Average time: {Math.floor(journey.avgDuration / 60)}m {journey.avgDuration % 60}s • Conversion rate: {journey.conversionRate}%
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              
              <div>
                <h3 className="text-sm font-medium text-gray-700 mb-3">Exit Pages Analysis</h3>
                
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Page</th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Exit Rate</th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Avg. Time Before Exit</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      <tr>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">/checkout</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">28.5%</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">2m 18s</td>
                      </tr>
                      <tr>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">/product/details</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">22.3%</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">3m 42s</td>
                      </tr>
                      <tr>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">/pricing</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">19.7%</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">1m 55s</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="recordings">
          <Card>
            <CardHeader className="px-4 py-5 border-b border-gray-200 sm:px-6">
              <CardTitle className="text-lg leading-6 font-medium text-gray-900">Session Recordings</CardTitle>
            </CardHeader>
            <CardContent className="px-4 py-5 sm:p-6">
              <div className="mb-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-sm font-medium text-gray-700">Recent Session Recordings</h3>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => {
                      toast({
                        title: "Exporting session recordings",
                        description: "All session recordings have been exported to CSV format",
                        variant: "default",
                      });
                      
                      // Simulate download
                      setTimeout(() => {
                        const link = document.createElement('a');
                        link.href = 'data:text/csv;charset=utf-8,User ID,Date,Duration,Device,Browser,Path,Conversion\n38291,2025-05-14 16:15,8m 23s,Desktop,Chrome,Home→Products→Cart→Checkout,Yes\n38290,2025-05-14 15:52,5m 47s,Mobile,Safari,Home→Pricing,No\n38289,2025-05-14 15:41,12m 05s,Tablet,Firefox,Home→Blog→Features→Pricing→Contact,No';
                        link.download = 'session-recordings.csv';
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link);
                      }, 500);
                    }}
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Export All
                  </Button>
                </div>
                
                <div className="space-y-4">
                  {/* Recording 1 */}
                  <div className="border border-gray-200 rounded-md overflow-hidden">
                    <div className="bg-gray-50 px-4 py-3 border-b border-gray-200 flex items-center justify-between">
                      <div>
                        <h4 className="text-sm font-medium text-gray-900">User #38291</h4>
                        <p className="text-xs text-gray-500">May 14, 2025 • 4:15 PM • 8m 23s</p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                          Converted
                        </Badge>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => handleWatchRecording("38291")}
                        >
                          <Video className="w-4 h-4 mr-2" />
                          Watch
                        </Button>
                      </div>
                    </div>
                    <div className="p-4">
                      <div className="flex items-center justify-between mb-3">
                        <span className="text-xs font-medium text-gray-500">Session Path</span>
                        <span className="text-xs text-gray-500">Device: Desktop • Browser: Chrome</span>
                      </div>
                      <div className="flex items-center">
                        <div className="flex-none px-2 py-1 bg-primary-50 text-primary-800 text-xs rounded">Home</div>
                        <div className="flex-none px-3">→</div>
                        <div className="flex-none px-2 py-1 bg-primary-50 text-primary-800 text-xs rounded">Products</div>
                        <div className="flex-none px-3">→</div>
                        <div className="flex-none px-2 py-1 bg-primary-50 text-primary-800 text-xs rounded">Cart</div>
                        <div className="flex-none px-3">→</div>
                        <div className="flex-none px-2 py-1 bg-green-50 text-green-800 text-xs rounded">Checkout</div>
                      </div>
                    </div>
                  </div>
                  
                  {/* Recording 2 */}
                  <div className="border border-gray-200 rounded-md overflow-hidden">
                    <div className="bg-gray-50 px-4 py-3 border-b border-gray-200 flex items-center justify-between">
                      <div>
                        <h4 className="text-sm font-medium text-gray-900">User #38290</h4>
                        <p className="text-xs text-gray-500">May 14, 2025 • 3:52 PM • 5m 47s</p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
                          Bounced
                        </Badge>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => handleWatchRecording("38290")}
                        >
                          <Video className="w-4 h-4 mr-2" />
                          Watch
                        </Button>
                      </div>
                    </div>
                    <div className="p-4">
                      <div className="flex items-center justify-between mb-3">
                        <span className="text-xs font-medium text-gray-500">Session Path</span>
                        <span className="text-xs text-gray-500">Device: Mobile • Browser: Safari</span>
                      </div>
                      <div className="flex items-center">
                        <div className="flex-none px-2 py-1 bg-primary-50 text-primary-800 text-xs rounded">Home</div>
                        <div className="flex-none px-3">→</div>
                        <div className="flex-none px-2 py-1 bg-red-50 text-red-800 text-xs rounded">Pricing</div>
                      </div>
                    </div>
                  </div>
                  
                  {/* Recording 3 */}
                  <div className="border border-gray-200 rounded-md overflow-hidden">
                    <div className="bg-gray-50 px-4 py-3 border-b border-gray-200 flex items-center justify-between">
                      <div>
                        <h4 className="text-sm font-medium text-gray-900">User #38289</h4>
                        <p className="text-xs text-gray-500">May 14, 2025 • 3:41 PM • 12m 05s</p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                          Returning
                        </Badge>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => handleWatchRecording("38289")}
                        >
                          <Video className="w-4 h-4 mr-2" />
                          Watch
                        </Button>
                      </div>
                    </div>
                    <div className="p-4">
                      <div className="flex items-center justify-between mb-3">
                        <span className="text-xs font-medium text-gray-500">Session Path</span>
                        <span className="text-xs text-gray-500">Device: Tablet • Browser: Firefox</span>
                      </div>
                      <div className="flex items-center flex-wrap gap-y-2">
                        <div className="flex-none px-2 py-1 bg-primary-50 text-primary-800 text-xs rounded">Home</div>
                        <div className="flex-none px-3">→</div>
                        <div className="flex-none px-2 py-1 bg-primary-50 text-primary-800 text-xs rounded">Blog</div>
                        <div className="flex-none px-3">→</div>
                        <div className="flex-none px-2 py-1 bg-primary-50 text-primary-800 text-xs rounded">Features</div>
                        <div className="flex-none px-3">→</div>
                        <div className="flex-none px-2 py-1 bg-primary-50 text-primary-800 text-xs rounded">Pricing</div>
                        <div className="flex-none px-3">→</div>
                        <div className="flex-none px-2 py-1 bg-primary-50 text-primary-800 text-xs rounded">Contact</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              <div>
                <h3 className="text-sm font-medium text-gray-700 mb-3">Recordings Insights</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="border border-gray-200 rounded-md p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="text-sm font-medium text-gray-900">Average Session Duration</h4>
                      <span className="text-sm font-bold text-primary-600">5:42</span>
                    </div>
                    <p className="text-xs text-gray-500">
                      +12% from last month
                    </p>
                  </div>
                  
                  <div className="border border-gray-200 rounded-md p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="text-sm font-medium text-gray-900">Rage Clicks Detected</h4>
                      <span className="text-sm font-bold text-red-600">24</span>
                    </div>
                    <p className="text-xs text-gray-500">
                      -8% from last month
                    </p>
                  </div>
                  
                  <div className="border border-gray-200 rounded-md p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="text-sm font-medium text-gray-900">Form Abandonment</h4>
                      <span className="text-sm font-bold text-amber-600">32%</span>
                    </div>
                    <p className="text-xs text-gray-500">
                      -5% from last month
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Session Recording Dialog */}
      <Dialog open={isRecordingModalOpen} onOpenChange={setIsRecordingModalOpen}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>Session Recording - User #{recordingData?.userId}</DialogTitle>
            <DialogDescription>
              Recorded on May 14, 2025 • Duration: {recordingData?.duration}
            </DialogDescription>
          </DialogHeader>
          
          {recordingData && (
            <>
              <div className="bg-gray-50 p-4 rounded-md mb-4">
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <p className="text-sm font-medium text-gray-500">Status</p>
                    <p className="text-base font-semibold" style={{ color: recordingData.statusColor }}>
                      {recordingData.status}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500">Device</p>
                    <p className="text-base">
                      {recordingData.userId === "38289" ? "Tablet" : "Desktop"}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-500">Browser</p>
                    <p className="text-base">
                      {recordingData.userId === "38289" ? "Firefox" : 
                        recordingData.userId === "38290" ? "Chrome" : "Safari"}
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="mb-6">
                <h3 className="text-lg font-medium mb-2">User Journey</h3>
                <div className="flex flex-wrap items-center gap-2 my-3">
                  <div className="px-3 py-2 bg-blue-50 text-blue-700 rounded-md shadow-sm">
                    Home<br/><span className="text-xs">45s</span>
                  </div>
                  <div className="text-gray-400">→</div>
                  
                  <div className="px-3 py-2 bg-blue-50 text-blue-700 rounded-md shadow-sm">
                    Products<br/><span className="text-xs">2m 10s</span>
                  </div>
                  <div className="text-gray-400">→</div>
                  
                  <div className="px-3 py-2 bg-blue-50 text-blue-700 rounded-md shadow-sm">
                    Product Details<br/><span className="text-xs">1m 35s</span>
                  </div>
                  <div className="text-gray-400">→</div>
                  
                  <div className="px-3 py-2 bg-blue-50 text-blue-700 rounded-md shadow-sm">
                    Cart<br/><span className="text-xs">
                      {recordingData.userId === "38290" ? "1m 27s" : "3m 15s"}
                    </span>
                  </div>
                  <div className="text-gray-400">→</div>
                  
                  <div className="px-3 py-2 bg-blue-50 text-blue-700 rounded-md shadow-sm">
                    {recordingData.userId === "38290" ? "Home (Exit)" : "Checkout"}
                    <br/><span className="text-xs">
                      {recordingData.userId === "38290" ? "0s" : "2m 48s"}
                    </span>
                  </div>
                </div>
              </div>
              
              <div className="mb-6">
                <h3 className="text-lg font-medium mb-2">User Interactions</h3>
                <div className="space-y-2">
                  <div className="p-2 bg-gray-50 border-l-4 border-primary-500 rounded-sm">Page Load</div>
                  <div className="p-2 bg-gray-50 border-l-4 border-primary-500 rounded-sm">Scroll Down</div>
                  <div className="p-2 bg-gray-50 border-l-4 border-primary-500 rounded-sm">Click on Product</div>
                  <div className="p-2 bg-gray-50 border-l-4 border-primary-500 rounded-sm">View Product Details</div>
                  <div className="p-2 bg-gray-50 border-l-4 border-primary-500 rounded-sm">Add to Cart</div>
                  <div className="p-2 bg-gray-50 border-l-4 border-primary-500 rounded-sm">
                    {recordingData.userId === "38290" ? "Exit Site" : "Proceed to Checkout"}
                  </div>
                </div>
              </div>
              
              <div className="flex justify-center my-4">
                <p className="text-sm text-gray-500">
                  This is a demo visualization of the user session.
                </p>
              </div>
            </>
          )}
          
          <DialogFooter className="sm:justify-between">
            <DialogClose asChild>
              <Button type="button" variant="secondary">
                <X className="w-4 h-4 mr-2" />
                Close
              </Button>
            </DialogClose>
            
            <Button>
              <Download className="w-4 h-4 mr-2" />
              Export Session
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
