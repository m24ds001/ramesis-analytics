import React from 'react';
import { Helmet } from 'react-helmet';
import WebsiteAbTestsSimple from '@/components/WebsiteAbTestsSimple';

const WebsiteABTestsPage = () => {
  return (
    <div className="container mx-auto p-4">
      <Helmet>
        <title>Website-Specific A/B Tests | Analytics Platform</title>
        <meta name="description" content="View and analyze A/B tests for specific websites including Google, Amazon, Facebook, YouTube and more." />
      </Helmet>

      <div className="mb-6">
        <h1 className="text-2xl font-bold mb-2">Website-Specific A/B Tests</h1>
        <p className="text-gray-500">Analyze A/B tests customized for major websites across the internet</p>
      </div>

      <div className="mt-6">
        <WebsiteAbTestsSimple />
      </div>
    </div>
  );
};

export default WebsiteABTestsPage;