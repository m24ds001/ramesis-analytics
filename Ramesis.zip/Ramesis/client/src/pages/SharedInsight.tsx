import { useEffect, useState } from 'react';
import { useLocation } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Share, Download } from 'lucide-react';
import { Helmet } from 'react-helmet';
import ShareableInsightCard, { InsightData } from '@/components/analytics/ShareableInsightCard';

export default function SharedInsight() {
  const [, setLocation] = useLocation();
  const [insightData, setInsightData] = useState<InsightData | null>(null);

  useEffect(() => {
    // Parse URL parameters to get insight data
    const params = new URLSearchParams(window.location.search);
    
    // Only proceed if we have the required parameters
    if (params.has('title') && params.has('description')) {
      const insight: InsightData = {
        title: params.get('title') || '',
        description: params.get('description') || '',
        metric: params.get('metric') || undefined,
        value: params.get('value') || undefined,
        change: params.get('change') || undefined,
        trend: params.get('trend') as 'up' | 'down' | 'neutral' || undefined,
        source: params.get('source') || undefined,
        websiteName: params.get('website') || undefined,
        timestamp: new Date().toISOString() // Use current time if not provided
      };
      
      setInsightData(insight);
    }
  }, []);

  // If no insight data is available, show a message
  if (!insightData) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-gray-50 px-4">
        <Helmet>
          <title>Invalid Insight | Ramesis Analytics</title>
          <meta name="description" content="This shared insight link appears to be invalid or incomplete." />
        </Helmet>
        <Card className="w-full max-w-md">
          <CardHeader className="bg-gray-100">
            <CardTitle>Invalid Insight</CardTitle>
          </CardHeader>
          <CardContent className="pt-6">
            <p className="text-center text-gray-600 mb-6">
              This shared insight link appears to be invalid or incomplete.
            </p>
            <Button 
              onClick={() => setLocation('/')} 
              className="w-full"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Return to Dashboard
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center min-h-screen bg-gray-50 px-4 py-12">
      <Helmet>
        <title>{insightData.title} | Ramesis Analytics</title>
        <meta name="description" content={insightData.description} />
        <meta property="og:title" content={insightData.title} />
        <meta property="og:description" content={insightData.description} />
        <meta property="og:type" content="website" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={insightData.title} />
        <meta name="twitter:description" content={insightData.description} />
      </Helmet>
      
      <div className="w-full max-w-3xl mb-8">
        <Button 
          variant="outline" 
          onClick={() => setLocation('/')}
          className="mb-4"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Dashboard
        </Button>
        
        <h1 className="text-2xl font-bold text-gray-900 mb-2">Shared Analytics Insight</h1>
        <p className="text-gray-600">
          View and share this analytics insight with your team
        </p>
      </div>
      
      <div className="w-full max-w-3xl">
        <ShareableInsightCard insight={insightData} />
        
        <div className="mt-8 text-center text-sm text-gray-500">
          <p>
            This insight was shared from Ramesis Analytics Platform.
            <br />
            View more insights by visiting our dashboard.
          </p>
        </div>
      </div>
    </div>
  );
}