import { Helmet } from 'react-helmet';
import Dashboard from '@/components/analytics/Dashboard';

export default function DashboardPage() {
  return (
    <>
      <Helmet>
        <title>Dashboard | Ramesis - AI-Powered Website Analytics</title>
        <meta name="description" content="Real-time website performance analytics and AI-powered insights to optimize your website's performance and increase conversions." />
      </Helmet>
      <Dashboard />
    </>
  );
}
