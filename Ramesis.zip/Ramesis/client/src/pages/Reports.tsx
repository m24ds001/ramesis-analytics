import { Helmet } from 'react-helmet';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { useState, useEffect } from 'react';
import { exportReport } from '@/lib/export';
import { Download, FileText, Calendar, Share2, RefreshCw } from 'lucide-react';

export default function ReportsPage() {
  const [dateRange, setDateRange] = useState('last7days');
  const [selectedWebsite, setSelectedWebsite] = useState('google.com');
  const [isGenerating, setIsGenerating] = useState(false);
  
  // Available websites for reports
  const websites = [
    { domain: 'google.com', name: 'Google' },
    { domain: 'amazon.com', name: 'Amazon' },
    { domain: 'facebook.com', name: 'Facebook' },
    { domain: 'youtube.com', name: 'YouTube' },
    { domain: 'twitter.com', name: 'Twitter' },
    { domain: 'instagram.com', name: 'Instagram' },
    { domain: 'linkedin.com', name: 'LinkedIn' },
    { domain: 'netflix.com', name: 'Netflix' }
  ];
  
  // Function to generate website-specific report
  const generateWebsiteReport = async () => {
    setIsGenerating(true);
    try {
      // Create a comprehensive report for the selected website
      const reportData = {
        website: selectedWebsite,
        websiteName: websites.find(w => w.domain === selectedWebsite)?.name || selectedWebsite,
        dateRange: dateRange,
        generatedAt: new Date().toISOString(),
        reportType: 'website-analysis'
      };
      
      // Use the export function to download the report
      await exportReport('website-analysis', 'pdf', dateRange, { 
        website: selectedWebsite,
        websiteName: reportData.websiteName
      });
      
    } catch (error) {
      console.error('Error generating report:', error);
    } finally {
      setIsGenerating(false);
    }
  };
  
  // Sample saved reports
  // Real-time generated reports based on actual website data
  const [recentReports, setRecentReports] = useState([]);
  
  const generateRecentReports = () => {
    const now = new Date();
    const reports = websites.slice(0, 3).map((website, index) => ({
      id: index + 1,
      title: `${website.name} Analytics`,
      description: `Real-time analytics for ${website.name}`,
      date: new Date(now.getTime() - (index * 24 * 60 * 60 * 1000)).toLocaleDateString(),
      website: website.domain,
      websiteName: website.name,
      format: 'JSON'
    }));
    setRecentReports(reports);
  };

  useEffect(() => {
    generateRecentReports();
  }, []);
  
  return (
    <>
      <Helmet>
        <title>Reports | Ramesis - AI-Powered Website Analytics</title>
        <meta name="description" content="Generate and view custom analytics reports with AI-powered insights." />
      </Helmet>
      
      <div className="mb-6 flex flex-col sm:flex-row justify-between items-start sm:items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Reports</h1>
          <p className="text-sm text-gray-500">Generate and schedule custom reports</p>
        </div>
        <div className="mt-4 sm:mt-0 flex items-center space-x-3">
          <Select value={selectedWebsite} onValueChange={setSelectedWebsite}>
            <SelectTrigger className="w-[160px]">
              <SelectValue placeholder="Select website" />
            </SelectTrigger>
            <SelectContent>
              {websites.map((website) => (
                <SelectItem key={website.domain} value={website.domain}>
                  {website.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={dateRange} onValueChange={setDateRange}>
            <SelectTrigger className="w-[140px]">
              <SelectValue placeholder="Date range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="last7days">Last 7 days</SelectItem>
              <SelectItem value="last30days">Last 30 days</SelectItem>
              <SelectItem value="last90days">Last 90 days</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={generateWebsiteReport} disabled={isGenerating}>
            {isGenerating ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Generating...
              </>
            ) : (
              <>
                <FileText className="w-4 h-4 mr-2" />
                Generate Report
              </>
            )}
          </Button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Quick Generate Card */}
        <Card>
          <CardHeader>
            <CardTitle>Quick Generate</CardTitle>
            <CardDescription>Create a new report instantly</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button 
              className="w-full" 
              onClick={() => exportReport('website-analysis', 'json', dateRange, { 
                website: selectedWebsite || 'google.com',
                websiteName: websites.find(w => w.domain === (selectedWebsite || 'google.com'))?.name || 'Google'
              })}
            >
              <Download className="w-4 h-4 mr-2" />
              Generate Report
            </Button>
          </CardContent>
        </Card>

        {/* Saved Reports */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Recent Reports</CardTitle>
            <CardDescription>Real-time generated analytics reports</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentReports.map((report) => (
                <div key={report.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center space-x-3">
                    <FileText className="h-8 w-8 text-blue-500" />
                    <div>
                      <h3 className="font-medium">{report.title}</h3>
                      <p className="text-sm text-gray-500">{report.description}</p>
                      <div className="flex items-center space-x-2 mt-1">
                        <Calendar className="h-4 w-4 text-gray-400" />
                        <span className="text-sm text-gray-500">{report.date}</span>
                        <Badge variant="outline">{report.format}</Badge>
                        <span className="text-sm text-gray-500">(Real-time)</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={() => exportReport('website-analysis', 'json', dateRange, { 
                        website: report.website,
                        websiteName: report.websiteName
                      })}
                    >
                      <Download className="w-4 h-4 mr-1" />
                      Download
                    </Button>
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={() => generateRecentReports()}
                    >
                      <RefreshCw className="w-4 h-4 mr-1" />
                      Refresh
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}