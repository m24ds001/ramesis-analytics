import { Helmet } from 'react-helmet';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { X, CheckCircle, AlertTriangle, TestTube, History, Loader, LayoutGrid, Tag, ShoppingCart, Headphones, RefreshCw } from 'lucide-react';
import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { getAbTests, createAbTest } from '@/lib/analytics';
import { AbTest } from '@shared/schema';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useToast } from '@/hooks/use-toast';
import { queryClient } from '@/lib/queryClient';

export default function ABTestingPage() {
  const { toast } = useToast();
  const [selectedTest, setSelectedTest] = useState<AbTest | null>(null);
  const [selectedWebsite, setSelectedWebsite] = useState<string>('all');
  
  // Fetch A/B tests from storage
  const { data: abTests, isLoading } = useQuery({
    queryKey: ['/api/abtests'],
    queryFn: getAbTests,
  });
  
  // Fetch website domains with A/B tests
  const { data: websiteSummary } = useQuery({
    queryKey: ['/api/website-abtests-summary'],
  });
  
  // Form schema for creating new test
  const formSchema = z.object({
    name: z.string().min(1, "Name is required"),
    description: z.string().min(1, "Description is required"),
    variantA: z.string().min(1, "Variant A is required"),
    variantB: z.string().min(1, "Variant B is required"),
    testType: z.string().min(1, "Test type is required"),
    targetAudience: z.string().min(1, "Target audience is required"),
    endDate: z.string().min(1, "End date is required"),
  });
  
  // Create test form
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      description: "",
      variantA: "",
      variantB: "",
      testType: "copy",
      targetAudience: "all",
      endDate: "",
    },
  });
  
  // Create test mutation
  const createTestMutation = useMutation({
    mutationFn: async (values: z.infer<typeof formSchema>) => {
      // Convert string date to actual Date object
      const endDate = new Date(values.endDate);
      
      return createAbTest({
        name: values.name,
        description: values.description,
        variantA: values.variantA,
        variantB: values.variantB,
        startDate: new Date(),
        endDate,
        status: "active",
        variantAConversion: "0",
        variantBConversion: "0",
        confidence: "0",
      });
    },
    onSuccess: () => {
      toast({
        title: "A/B Test Created",
        description: "Your new A/B test has been created successfully.",
      });
      form.reset();
      queryClient.invalidateQueries({ queryKey: ['/api/abtests'] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to create A/B test: " + (error as Error).message,
        variant: "destructive",
      });
    }
  });
  
  const onSubmit = (values: z.infer<typeof formSchema>) => {
    createTestMutation.mutate(values);
  };
  
  // Handle test selection for details view
  const handleTestSelect = (test: AbTest) => {
    setSelectedTest(test);
  };
  
  // Calculate test results
  const calculateTestResults = (test: AbTest) => {
    const variantAConv = parseFloat(test.variantAConversion);
    const variantBConv = parseFloat(test.variantBConversion);
    const confidence = parseFloat(test.confidence);
    
    let winner = null;
    let improvement = 0;
    
    if (variantBConv > variantAConv && confidence >= 95) {
      winner = 'B';
      improvement = ((variantBConv - variantAConv) / variantAConv) * 100;
    } else if (variantAConv > variantBConv && confidence >= 95) {
      winner = 'A';
      improvement = ((variantAConv - variantBConv) / variantBConv) * 100;
    }
    
    return { winner, improvement, confidence };
  };
  
  // Filter tests by selected website
  const getFilteredTests = (tests: AbTest[], status: string) => {
    if (!tests) return [];
    
    return tests.filter((test: AbTest) => {
      const statusMatch = test.status === status;
      const websiteMatch = selectedWebsite === 'all' || test.domain === selectedWebsite;
      
      return statusMatch && websiteMatch;
    });
  };
  
  // Format remaining days
  const getRemainingDays = (endDate: string) => {
    const end = new Date(endDate);
    const today = new Date();
    const remainingDays = Math.max(0, Math.ceil((end.getTime() - today.getTime()) / (1000 * 60 * 60 * 24)));
    return remainingDays;
  };
  
  return (
    <>
      <Helmet>
        <title>A/B Testing | AilyticsPro - AI-Powered Website Analytics</title>
        <meta name="description" content="Create and manage A/B tests for your website to optimize conversions and improve user experience with data-driven decisions." />
      </Helmet>
      
      <div className="mb-6 flex flex-col sm:flex-row justify-between items-start sm:items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">A/B Testing</h1>
          <p className="text-sm text-gray-500">Create, monitor, and analyze tests to optimize your website</p>
        </div>
        <div className="flex flex-col sm:flex-row items-end sm:items-center gap-4 mt-4 sm:mt-0">
          <div className="flex items-center gap-2">
            <span className="text-sm text-gray-500">Website:</span>
            <Select 
              value={selectedWebsite}
              onValueChange={setSelectedWebsite}
            >
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Select website" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Websites</SelectItem>
                {websiteSummary?.map((site: any) => (
                  <SelectItem key={site.domain} value={site.domain}>
                    {site.domain} ({site.testCount})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <Badge variant="outline" className="px-2 py-1 text-xs rounded-full bg-green-100 text-green-800 font-medium">
            Active: {abTests?.filter((test: AbTest) => test.status === 'active').length || 0} tests
          </Badge>
        </div>
      </div>
      
      <Tabs defaultValue="active" className="mb-6">
        <TabsList className="grid w-full grid-cols-4 mb-4">
          <TabsTrigger value="active">Active Tests</TabsTrigger>
          <TabsTrigger value="completed">Completed Tests</TabsTrigger>
          <TabsTrigger value="create">Create Test</TabsTrigger>
          <TabsTrigger value="ideas">Test Ideas</TabsTrigger>
        </TabsList>
        
        <TabsContent value="active">
          {isLoading ? (
            <Card className="h-64 flex items-center justify-center">
              <div className="text-center">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-500 mx-auto mb-4"></div>
                <p className="text-gray-500">Loading tests...</p>
              </div>
            </Card>
          ) : abTests && getFilteredTests(abTests, 'active').length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {getFilteredTests(abTests, 'active')
                .map((test: AbTest) => {
                  const remainingDays = getRemainingDays(test.endDate);
                  const variantAConv = parseFloat(test.variantAConversion);
                  const variantBConv = parseFloat(test.variantBConversion);
                  const isVariantBWinning = variantBConv > variantAConv;
                  
                  return (
                    <Card key={test.id} className="overflow-hidden">
                      <CardHeader className="px-6 py-4 bg-gray-50 border-b border-gray-200">
                        <div className="flex justify-between items-start">
                          <CardTitle className="text-md font-medium text-gray-900">{test.name}</CardTitle>
                          <Badge variant="outline" className="px-2 py-1 text-xs rounded-full bg-blue-100 text-blue-800">
                            {remainingDays} days left
                          </Badge>
                        </div>
                        <CardDescription className="line-clamp-2">{test.description}</CardDescription>
                      </CardHeader>
                      <CardContent className="px-6 py-4">
                        <div className="space-y-4">
                          <div>
                            <div className="flex justify-between items-center mb-1">
                              <div className="flex items-center">
                                <span className="text-xs font-medium text-gray-700 bg-white border border-gray-300 px-2 py-1 rounded mr-2">A</span>
                                <span className="text-sm text-gray-700 truncate max-w-[200px]">{test.variantA}</span>
                              </div>
                              <span className="text-sm font-medium text-gray-900">{test.variantAConversion}%</span>
                            </div>
                            <Progress value={parseFloat(test.variantAConversion) * 10} className="h-2" />
                          </div>
                          
                          <div>
                            <div className="flex justify-between items-center mb-1">
                              <div className="flex items-center">
                                <span className={`text-xs font-medium ${isVariantBWinning ? 'text-white bg-primary-500 border border-primary-500' : 'text-gray-700 bg-white border border-gray-300'} px-2 py-1 rounded mr-2`}>B</span>
                                <span className="text-sm text-gray-700 truncate max-w-[200px]">{test.variantB}</span>
                              </div>
                              <span className="text-sm font-medium text-gray-900">{test.variantBConversion}%</span>
                            </div>
                            <Progress value={parseFloat(test.variantBConversion) * 10} className="h-2" />
                          </div>
                          
                          <div className="pt-2 flex justify-between items-center">
                            <span className="text-xs text-gray-500">Confidence: {test.confidence}%</span>
                            <Button variant="outline" size="sm" onClick={() => handleTestSelect(test)}>
                              View Details
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
            </div>
          ) : (
            <Card>
              <CardContent className="px-6 py-10 text-center">
                <div className="mx-auto w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                  <TestTube className="h-6 w-6 text-gray-400" />
                </div>
                <h3 className="text-lg font-medium text-gray-900 mb-2">No active tests</h3>
                <p className="text-gray-500 mb-4">
                  You don't have any active A/B tests running. Create a new test to start optimizing your website.
                </p>
                <Button variant="outline" onClick={() => document.getElementById('create-tab')?.click()}>
                  Create Your First Test
                </Button>
              </CardContent>
            </Card>
          )}
          
          {selectedTest && (
            <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
              <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto">
                <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
                  <h2 className="text-xl font-semibold text-gray-900">{selectedTest.name}</h2>
                  <Button variant="ghost" size="sm" onClick={() => setSelectedTest(null)}>
                    <X className="h-5 w-5" />
                  </Button>
                </div>
                <div className="p-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <div>
                      <h3 className="text-sm font-medium text-gray-500 mb-2">Test Description</h3>
                      <p className="text-gray-900">{selectedTest.description}</p>
                      
                      <div className="mt-4 grid grid-cols-2 gap-4">
                        <div>
                          <h3 className="text-sm font-medium text-gray-500 mb-1">Start Date</h3>
                          <p className="text-gray-900">{new Date(selectedTest.startDate).toLocaleDateString()}</p>
                        </div>
                        <div>
                          <h3 className="text-sm font-medium text-gray-500 mb-1">End Date</h3>
                          <p className="text-gray-900">{new Date(selectedTest.endDate).toLocaleDateString()}</p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="bg-gray-50 rounded-lg p-4">
                      <h3 className="text-sm font-medium text-gray-900 mb-3">Test Results</h3>
                      
                      {parseFloat(selectedTest.confidence) >= 95 ? (
                        <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-4">
                          <div className="flex items-center">
                            <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                            <span className="font-medium text-green-800">
                              Variant {calculateTestResults(selectedTest).winner} is the winner with {selectedTest.confidence}% confidence
                            </span>
                          </div>
                          <p className="text-sm text-green-700 mt-1">
                            {calculateTestResults(selectedTest).improvement.toFixed(1)}% improvement over the other variant
                          </p>
                        </div>
                      ) : (
                        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-4">
                          <div className="flex items-center">
                            <AlertTriangle className="h-5 w-5 text-yellow-500 mr-2" />
                            <span className="font-medium text-yellow-800">
                              Test is not conclusive yet ({selectedTest.confidence}% confidence)
                            </span>
                          </div>
                          <p className="text-sm text-yellow-700 mt-1">
                            Continue running the test to reach at least 95% confidence for reliable results
                          </p>
                        </div>
                      )}
                      
                      <div className="space-y-4 mt-4">
                        <div>
                          <div className="flex justify-between mb-1">
                            <div className="flex items-center">
                              <span className="text-xs font-medium text-gray-700 bg-white border border-gray-300 px-2 py-1 rounded mr-2">A</span>
                              <span className="text-sm font-medium">Variant A</span>
                            </div>
                            <span className="text-sm font-medium">{selectedTest.variantAConversion}% conversion</span>
                          </div>
                          <Progress value={parseFloat(selectedTest.variantAConversion) * 10} className="h-2" />
                          <p className="text-xs text-gray-500 mt-1">{selectedTest.variantA}</p>
                        </div>
                        
                        <div>
                          <div className="flex justify-between mb-1">
                            <div className="flex items-center">
                              <span className="text-xs font-medium text-gray-700 bg-white border border-gray-300 px-2 py-1 rounded mr-2">B</span>
                              <span className="text-sm font-medium">Variant B</span>
                            </div>
                            <span className="text-sm font-medium">{selectedTest.variantBConversion}% conversion</span>
                          </div>
                          <Progress value={parseFloat(selectedTest.variantBConversion) * 10} className="h-2" />
                          <p className="text-xs text-gray-500 mt-1">{selectedTest.variantB}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="border-t border-gray-200 pt-6">
                    <h3 className="text-md font-medium text-gray-900 mb-4">Recommendations</h3>
                    
                    {parseFloat(selectedTest.confidence) >= 95 ? (
                      <div className="bg-white border border-gray-200 rounded-lg p-4">
                        <p className="text-gray-700 mb-4">
                          Based on the test results, we recommend implementing variant {calculateTestResults(selectedTest).winner} for all users.
                          This change is expected to improve your conversion rate by approximately {calculateTestResults(selectedTest).improvement.toFixed(1)}%.
                        </p>
                        <div className="flex justify-end">
                          <Button>
                            Implement Winner
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <div className="bg-white border border-gray-200 rounded-lg p-4">
                        <p className="text-gray-700 mb-4">
                          This test hasn't reached statistical significance yet. We recommend:
                        </p>
                        <ul className="list-disc pl-5 text-gray-700 space-y-1 mb-4">
                          <li>Continue running the test to collect more data</li>
                          <li>Consider sending more traffic to the test pages</li>
                          <li>Wait for at least 95% confidence before making a decision</li>
                        </ul>
                        <div className="flex justify-end">
                          <Button variant="outline">
                            Continue Test
                          </Button>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="completed">
          {isLoading ? (
            <Card className="h-64 flex items-center justify-center">
              <div className="text-center">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-500 mx-auto mb-4"></div>
                <p className="text-gray-500">Loading tests...</p>
              </div>
            </Card>
          ) : abTests && getFilteredTests(abTests, 'completed').length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {getFilteredTests(abTests, 'completed')
                .map((test: AbTest) => {
                  const variantAConv = parseFloat(test.variantAConversion);
                  const variantBConv = parseFloat(test.variantBConversion);
                  const winner = variantAConv > variantBConv ? 'A' : 'B';
                  
                  return (
                    <Card key={test.id} className="overflow-hidden">
                      <CardHeader className="px-6 py-4 bg-gray-50 border-b border-gray-200">
                        <div className="flex justify-between items-start">
                          <CardTitle className="text-md font-medium text-gray-900">{test.name}</CardTitle>
                          <Badge variant="outline" className="px-2 py-1 text-xs rounded-full bg-gray-100 text-gray-800">
                            Completed
                          </Badge>
                        </div>
                        <CardDescription className="line-clamp-2">{test.description}</CardDescription>
                      </CardHeader>
                      <CardContent className="px-6 py-4">
                        <div className="bg-green-50 border border-green-100 rounded-lg p-3 mb-4">
                          <div className="flex items-center">
                            <span className="text-xs font-medium text-white bg-green-500 px-2 py-1 rounded mr-2">{winner}</span>
                            <span className="text-sm font-medium text-green-800">
                              Winner with {test.confidence}% confidence
                            </span>
                          </div>
                        </div>
                        
                        <div className="space-y-4 mt-4">
                          <div>
                            <div className="flex justify-between mb-1">
                              <span className="text-sm">Variant A</span>
                              <span className="text-sm font-medium">{test.variantAConversion}%</span>
                            </div>
                            <Progress value={parseFloat(test.variantAConversion) * 10} className="h-2" />
                          </div>
                          
                          <div>
                            <div className="flex justify-between mb-1">
                              <span className="text-sm">Variant B</span>
                              <span className="text-sm font-medium">{test.variantBConversion}%</span>
                            </div>
                            <Progress value={parseFloat(test.variantBConversion) * 10} className="h-2" />
                          </div>
                        </div>
                        
                        <div className="mt-4 pt-4 border-t border-gray-200 flex justify-between items-center">
                          <span className="text-xs text-gray-500">
                            Ended: {new Date(test.endDate).toLocaleDateString()}
                          </span>
                          <Button variant="outline" size="sm" onClick={() => handleTestSelect(test)}>
                            View Details
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
            </div>
          ) : (
            <Card>
              <CardContent className="px-6 py-10 text-center">
                <div className="mx-auto w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                  <History className="h-6 w-6 text-gray-400" />
                </div>
                <h3 className="text-lg font-medium text-gray-900 mb-2">No completed tests</h3>
                <p className="text-gray-500 mb-4">
                  You don't have any completed A/B tests yet. Once your active tests finish, they'll appear here.
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
        
        <TabsContent value="create" id="create-tab">
          <Card>
            <CardHeader className="px-6 py-5 border-b border-gray-200">
              <CardTitle className="text-lg font-medium text-gray-900">Create New A/B Test</CardTitle>
              <CardDescription>
                Set up a new test to compare different versions of your website content or design
              </CardDescription>
            </CardHeader>
            <CardContent className="px-6 py-5">
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Test Name</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g. Homepage Hero Message" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="testType"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Test Type</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select test type" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="copy">Copy/Text Change</SelectItem>
                              <SelectItem value="design">Design/Layout</SelectItem>
                              <SelectItem value="function">Functionality</SelectItem>
                              <SelectItem value="offer">Offer/Pricing</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Description</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Describe what you're testing and why" 
                            className="min-h-[100px]"
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h3 className="text-sm font-medium text-gray-900 mb-4">Variant A (Control)</h3>
                      <FormField
                        control={form.control}
                        name="variantA"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Content</FormLabel>
                            <FormControl>
                              <Textarea 
                                placeholder="Current version" 
                                className="min-h-[100px]"
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div>
                      <h3 className="text-sm font-medium text-gray-900 mb-4">Variant B (Test)</h3>
                      <FormField
                        control={form.control}
                        name="variantB"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Content</FormLabel>
                            <FormControl>
                              <Textarea 
                                placeholder="New version to test" 
                                className="min-h-[100px]"
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="targetAudience"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Target Audience</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select audience" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="all">All Visitors</SelectItem>
                              <SelectItem value="new">New Visitors</SelectItem>
                              <SelectItem value="returning">Returning Visitors</SelectItem>
                              <SelectItem value="mobile">Mobile Users</SelectItem>
                              <SelectItem value="desktop">Desktop Users</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="endDate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>End Date</FormLabel>
                          <FormControl>
                            <Input type="date" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="pt-4 flex justify-end">
                    <Button type="submit" disabled={createTestMutation.isPending}>
                      {createTestMutation.isPending ? (
                        <>
                          <span className="animate-spin mr-2">
                            <Loader className="h-4 w-4" />
                          </span>
                          Creating...
                        </>
                      ) : 'Create Test'}
                    </Button>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="ideas">
          <Card>
            <CardHeader className="px-6 py-5 border-b border-gray-200">
              <CardTitle className="text-lg font-medium text-gray-900">AI-Generated Test Ideas</CardTitle>
              <CardDescription>
                Based on your website analytics, here are test ideas that could improve your conversion rate
              </CardDescription>
            </CardHeader>
            <CardContent className="px-6 py-5">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-white border border-gray-200 rounded-lg p-4">
                  <div className="flex items-start mb-3">
                    <div className="h-10 w-10 rounded-full bg-primary-100 flex items-center justify-center mr-3 flex-shrink-0">
                      <LayoutGrid className="h-5 w-5 text-primary-600" />
                    </div>
                    <div>
                      <h3 className="text-md font-medium text-gray-900">Hero Section Messaging</h3>
                      <p className="text-sm text-gray-600 mt-1">
                        Test benefit-focused vs. feature-focused headline on your homepage
                      </p>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-3 mb-4">
                    <div className="p-3 bg-gray-50 rounded-md">
                      <span className="block text-xs font-medium text-gray-700 mb-1">Variant A:</span>
                      <span className="text-sm">"Powerful analytics for your website"</span>
                    </div>
                    <div className="p-3 bg-green-50 rounded-md">
                      <span className="block text-xs font-medium text-gray-700 mb-1">Variant B:</span>
                      <span className="text-sm">"Boost conversions by 27% with AI insights"</span>
                    </div>
                  </div>
                  
                  <div className="text-sm text-gray-600 mb-4">
                    <p><strong>Expected impact:</strong> 15-25% increase in CTA clicks</p>
                  </div>
                  
                  <Button variant="outline" size="sm" className="w-full" onClick={() => {
                    document.getElementById('create-tab')?.click();
                    form.setValue('name', 'Homepage Hero Messaging');
                    form.setValue('description', 'Testing benefit-focused vs. feature-focused headline on the homepage');
                    form.setValue('variantA', 'Powerful analytics for your website');
                    form.setValue('variantB', 'Boost conversions by 27% with AI insights');
                    form.setValue('testType', 'copy');
                  }}>
                    Use This Idea
                  </Button>
                </div>
                
                <div className="bg-white border border-gray-200 rounded-lg p-4">
                  <div className="flex items-start mb-3">
                    <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center mr-3 flex-shrink-0">
                      <Tag className="h-5 w-5 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="text-md font-medium text-gray-900">Pricing Page Layout</h3>
                      <p className="text-sm text-gray-600 mt-1">
                        Test horizontal vs. card-based pricing display
                      </p>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-3 mb-4">
                    <div className="p-3 bg-gray-50 rounded-md">
                      <span className="block text-xs font-medium text-gray-700 mb-1">Variant A:</span>
                      <span className="text-sm">Horizontal pricing table</span>
                    </div>
                    <div className="p-3 bg-blue-50 rounded-md">
                      <span className="block text-xs font-medium text-gray-700 mb-1">Variant B:</span>
                      <span className="text-sm">Card-based pricing display</span>
                    </div>
                  </div>
                  
                  <div className="text-sm text-gray-600 mb-4">
                    <p><strong>Expected impact:</strong> 10-15% increase in plan selection</p>
                  </div>
                  
                  <Button variant="outline" size="sm" className="w-full" onClick={() => {
                    document.getElementById('create-tab')?.click();
                    form.setValue('name', 'Pricing Page Layout');
                    form.setValue('description', 'Testing horizontal pricing table vs. card-based pricing display');
                    form.setValue('variantA', 'Horizontal pricing table');
                    form.setValue('variantB', 'Card-based pricing display');
                    form.setValue('testType', 'design');
                  }}>
                    Use This Idea
                  </Button>
                </div>
                
                <div className="bg-white border border-gray-200 rounded-lg p-4">
                  <div className="flex items-start mb-3">
                    <div className="h-10 w-10 rounded-full bg-purple-100 flex items-center justify-center mr-3 flex-shrink-0">
                      <ShoppingCart className="h-5 w-5 text-purple-600" />
                    </div>
                    <div>
                      <h3 className="text-md font-medium text-gray-900">Checkout Form Length</h3>
                      <p className="text-sm text-gray-600 mt-1">
                        Test current form vs. simplified form with fewer fields
                      </p>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-3 mb-4">
                    <div className="p-3 bg-gray-50 rounded-md">
                      <span className="block text-xs font-medium text-gray-700 mb-1">Variant A:</span>
                      <span className="text-sm">12-field checkout form</span>
                    </div>
                    <div className="p-3 bg-purple-50 rounded-md">
                      <span className="block text-xs font-medium text-gray-700 mb-1">Variant B:</span>
                      <span className="text-sm">6-field simplified form</span>
                    </div>
                  </div>
                  
                  <div className="text-sm text-gray-600 mb-4">
                    <p><strong>Expected impact:</strong> 20-30% reduction in form abandonment</p>
                  </div>
                  
                  <Button variant="outline" size="sm" className="w-full" onClick={() => {
                    document.getElementById('create-tab')?.click();
                    form.setValue('name', 'Checkout Form Length');
                    form.setValue('description', 'Testing current checkout form vs. simplified form with fewer fields');
                    form.setValue('variantA', '12-field checkout form');
                    form.setValue('variantB', '6-field simplified form');
                    form.setValue('testType', 'function');
                  }}>
                    Use This Idea
                  </Button>
                </div>
                
                <div className="bg-white border border-gray-200 rounded-lg p-4">
                  <div className="flex items-start mb-3">
                    <div className="h-10 w-10 rounded-full bg-amber-100 flex items-center justify-center mr-3 flex-shrink-0">
                      <Headphones className="h-5 w-5 text-amber-600" />
                    </div>
                    <div>
                      <h3 className="text-md font-medium text-gray-900">Social Proof Display</h3>
                      <p className="text-sm text-gray-600 mt-1">
                        Test customer logos vs. testimonial carousel
                      </p>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-3 mb-4">
                    <div className="p-3 bg-gray-50 rounded-md">
                      <span className="block text-xs font-medium text-gray-700 mb-1">Variant A:</span>
                      <span className="text-sm">Customer logo grid</span>
                    </div>
                    <div className="p-3 bg-amber-50 rounded-md">
                      <span className="block text-xs font-medium text-gray-700 mb-1">Variant B:</span>
                      <span className="text-sm">Featured testimonial carousel</span>
                    </div>
                  </div>
                  
                  <div className="text-sm text-gray-600 mb-4">
                    <p><strong>Expected impact:</strong> 5-10% increase in demo requests</p>
                  </div>
                  
                  <Button variant="outline" size="sm" className="w-full" onClick={() => {
                    document.getElementById('create-tab')?.click();
                    form.setValue('name', 'Social Proof Display');
                    form.setValue('description', 'Testing customer logos vs. testimonial carousel');
                    form.setValue('variantA', 'Customer logo grid');
                    form.setValue('variantB', 'Featured testimonial carousel');
                    form.setValue('testType', 'design');
                  }}>
                    Use This Idea
                  </Button>
                </div>
              </div>
              
              <div className="mt-6 text-center">
                <Button>
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Generate More Ideas
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </>
  );
}
