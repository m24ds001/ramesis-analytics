import { useEffect, useState } from 'react';
import { useLocation, useParams } from 'wouter';
import ExternalAnalytics from '@/components/analytics/ExternalAnalytics';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';

// Function to parse query params
function useQueryParams() {
  if (typeof window === 'undefined') {
    return {};
  }
  
  return Object.fromEntries(
    new URLSearchParams(window.location.search).entries()
  );
}

export default function ExternalAnalyticsView() {
  const [, setLocation] = useLocation();
  const routeParams = useParams();
  const queryParams = useQueryParams();
  const [error, setError] = useState<string | null>(null);
  
  // Get websiteId and provider from route params
  const websiteId = parseInt(routeParams.websiteId || '0');
  const provider = routeParams.provider || '';
  
  // Get additional parameters from query params
  const websiteName = queryParams.name || '';
  const dateRange = queryParams.dateRange || '7days';
  
  useEffect(() => {
    if (!websiteId || !provider) {
      setError('Missing website ID or provider parameter');
    } else {
      setError(null);
      console.log(`Loading analytics for website ID ${websiteId} with provider ${provider}`);
    }
  }, [websiteId, provider]);
  
  const handleBack = () => {
    setLocation('/websites');
  };
  
  if (error) {
    return (
      <div className="container mx-auto p-6 text-center">
        <div className="mb-4">
          <Button 
            variant="outline" 
            className="flex items-center"
            onClick={handleBack}
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Website Catalog
          </Button>
        </div>
        <div className="bg-destructive/10 border border-destructive text-destructive p-6 rounded-lg">
          <h2 className="text-2xl font-bold">Error</h2>
          <p className="mt-2">{error}</p>
          <p className="mt-4">Please select a website and provider from the Website Catalog.</p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto">
      <div className="mb-4">
        <Button 
          variant="outline" 
          className="flex items-center"
          onClick={handleBack}
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Website Catalog
        </Button>
      </div>
      
      <ExternalAnalytics 
        websiteId={websiteId} 
        provider={provider} 
        websiteName={websiteName}
        dateRange={dateRange}
      />
    </div>
  );
}