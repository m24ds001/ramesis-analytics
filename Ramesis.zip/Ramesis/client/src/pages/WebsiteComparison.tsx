import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { WebsiteComparisonCard } from '@/components/analytics/WebsiteComparisonCard';
import { DataSourceHeader } from '@/components/ui/data-source-badge';
import { getPredictiveData } from '@/lib/predictiveAnalytics';
import { 
  BarChart2, 
  ArrowsUpDown, 
  ChevronUp, 
  ChevronDown 
} from 'lucide-react';

export default function WebsiteComparisonPage() {
  const [comparisonMetric, setComparisonMetric] = useState('engagement');
  const [timeRange, setTimeRange] = useState('last30days');
  
  // Fetch all websites
  const { data: websites } = useQuery({
    queryKey: ['/api/external-websites'],
    queryFn: () => fetch('/api/external-websites').then(res => res.json())
  });

  // Prepare comparison data based on websites
  const conversionRateData = websites?.map((website: any) => {
    const predictiveData = getPredictiveData(website.name);
    return {
      name: website.name,
      value: predictiveData.conversionRate.predicted,
      change: Number((predictiveData.conversionRate.predicted - predictiveData.conversionRate.current).toFixed(1)),
      trend: predictiveData.conversionRate.predicted > predictiveData.conversionRate.current ? 'up' : 'down',
      color: website.name === 'Amazon' ? '#FF9900' : // Amazon
             website.name === 'Flipkart' ? '#047BD5' : // Flipkart
             website.name === 'YouTube' ? '#FF0000' : // YouTube
             website.name === 'Netflix' ? '#E50914' : // Netflix
             website.name === 'Instagram' ? '#C13584' : // Instagram
             website.name === 'Twitter' ? '#1DA1F2' : // Twitter
             website.name === 'Walmart' ? '#0071CE' : // Walmart
             undefined
    };
  }) || [];

  // Prepare bounce rate comparison data
  const bounceRateData = websites?.map((website: any) => {
    const predictiveData = getPredictiveData(website.name);
    return {
      name: website.name,
      value: predictiveData.bounceRate.predicted,
      change: Number((predictiveData.bounceRate.current - predictiveData.bounceRate.predicted).toFixed(1)),
      trend: predictiveData.bounceRate.predicted < predictiveData.bounceRate.current ? 'up' : 'down',
      color: website.name === 'Amazon' ? '#FF9900' : // Amazon
             website.name === 'Flipkart' ? '#047BD5' : // Flipkart
             website.name === 'YouTube' ? '#FF0000' : // YouTube
             website.name === 'Netflix' ? '#E50914' : // Netflix
             website.name === 'Instagram' ? '#C13584' : // Instagram
             website.name === 'Twitter' ? '#1DA1F2' : // Twitter
             website.name === 'Walmart' ? '#0071CE' : // Walmart
             undefined
    };
  }) || [];

  // Sample data for behavior metrics
  const websiteClickThroughRates = [
    { name: 'Amazon', value: 24.8, change: 2.3, trend: 'up' },
    { name: 'Netflix', value: 22.5, change: 1.8, trend: 'up' },
    { name: 'YouTube', value: 18.9, change: -0.7, trend: 'down' },
    { name: 'Flipkart', value: 17.2, change: 1.2, trend: 'up' },
    { name: 'Walmart', value: 15.8, change: 0.5, trend: 'up' },
    { name: 'Instagram', value: 14.3, change: 3.2, trend: 'up' },
    { name: 'Twitter', value: 12.1, change: -1.1, trend: 'down' },
    { name: 'Myntra', value: 11.5, change: 0.8, trend: 'up' },
    { name: 'Shopify', value: 9.7, change: 0.3, trend: 'up' },
    { name: 'Airbnb', value: 8.2, change: 1.1, trend: 'up' },
  ];

  const websiteSessionDurations = [
    { name: 'YouTube', value: 16.4, change: 1.8, trend: 'up' },
    { name: 'Netflix', value: 14.8, change: 2.2, trend: 'up' },
    { name: 'Instagram', value: 12.3, change: 1.5, trend: 'up' },
    { name: 'Amazon', value: 9.2, change: 0.7, trend: 'up' },
    { name: 'Twitter', value: 8.7, change: -0.8, trend: 'down' },
    { name: 'Shopify', value: 7.4, change: 0.3, trend: 'up' },
    { name: 'Flipkart', value: 6.8, change: 0.5, trend: 'up' },
    { name: 'Walmart', value: 5.9, change: 0.2, trend: 'up' },
    { name: 'Myntra', value: 5.2, change: 0.9, trend: 'up' },
    { name: 'Airbnb', value: 4.8, change: 0.4, trend: 'up' },
  ];

  const websiteEngagementRates = [
    { name: 'Netflix', value: 78.5, change: 3.2, trend: 'up' },
    { name: 'YouTube', value: 72.3, change: 2.5, trend: 'up' },
    { name: 'Instagram', value: 67.8, change: 4.1, trend: 'up' },
    { name: 'Amazon', value: 62.4, change: 1.8, trend: 'up' },
    { name: 'Twitter', value: 56.9, change: -1.2, trend: 'down' },
    { name: 'Flipkart', value: 53.2, change: 2.3, trend: 'up' },
    { name: 'Myntra', value: 49.7, change: 1.5, trend: 'up' },
    { name: 'Walmart', value: 45.3, change: 0.9, trend: 'up' },
    { name: 'Shopify', value: 42.8, change: 1.1, trend: 'up' },
    { name: 'Airbnb', value: 38.5, change: 1.3, trend: 'up' },
  ];

  const websiteRevenueGrowth = websites?.map((website: any) => {
    const predictiveData = getPredictiveData(website.name);
    return {
      name: website.name,
      value: predictiveData.revenueGrowth.predicted,
      trend: 'up',
      color: website.name === 'Amazon' ? '#FF9900' : // Amazon
             website.name === 'Flipkart' ? '#047BD5' : // Flipkart
             website.name === 'YouTube' ? '#FF0000' : // YouTube
             website.name === 'Netflix' ? '#E50914' : // Netflix
             website.name === 'Instagram' ? '#C13584' : // Instagram
             website.name === 'Twitter' ? '#1DA1F2' : // Twitter
             website.name === 'Walmart' ? '#0071CE' : // Walmart
             undefined
    };
  }) || [];

  // Get highest and lowest demand sites based on predicted conversion rate
  const highestDemandSite = conversionRateData.length ? 
    [...conversionRateData].sort((a, b) => b.value - a.value)[0] : 
    null;
    
  const lowestDemandSite = conversionRateData.length ? 
    [...conversionRateData].sort((a, b) => a.value - b.value)[0] : 
    null;

  // Format values based on metric type
  const formatValue = (value: number, metricName: string) => {
    if (metricName === 'session') {
      return `${value} min`;
    }
    return `${value}%`;
  };

  return (
    <>
      <Helmet>
        <title>Website Comparison | AilyticsPro - AI-Powered Website Analytics</title>
        <meta name="description" content="Compare performance metrics across multiple websites to identify trends and opportunities." />
      </Helmet>
      
      <div className="mb-6 flex flex-col sm:flex-row justify-between items-start sm:items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Website Comparison</h1>
          <p className="text-sm text-gray-500">
            Compare key metrics across multiple websites
          </p>
        </div>
        <div className="mt-4 sm:mt-0 flex items-center space-x-3">
          <Select value={comparisonMetric} onValueChange={setComparisonMetric}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Metric" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="engagement">Engagement</SelectItem>
              <SelectItem value="behavior">User Behavior</SelectItem>
              <SelectItem value="conversion">Conversion</SelectItem>
              <SelectItem value="revenue">Revenue</SelectItem>
            </SelectContent>
          </Select>
          
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Time Range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="last7days">Last 7 days</SelectItem>
              <SelectItem value="last30days">Last 30 days</SelectItem>
              <SelectItem value="last90days">Last 90 days</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      
      <DataSourceHeader 
        sourceName="All Websites" 
        providerName="Multi-Source Analytics"
        description="Comparative analysis across multiple websites and platforms"
        className="mb-3"
      />
      
      {/* Highest & Lowest Demand Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        {highestDemandSite && (
          <Card>
            <CardHeader className="px-6 py-5 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg font-medium text-gray-900">
                  Highest Demand Website
                </CardTitle>
                <ChevronUp className="h-5 w-5 text-green-500" />
              </div>
            </CardHeader>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-1">{highestDemandSite.name}</h3>
                  <p className="text-sm text-gray-500">
                    Based on predicted conversion rate and user engagement
                  </p>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-green-600">{highestDemandSite.value.toFixed(1)}%</div>
                  <div className="text-sm text-gray-500">Conversion Rate</div>
                </div>
              </div>
              
              <div className="mt-4 pt-4 border-t border-gray-100">
                <h4 className="text-sm font-medium text-gray-900 mb-2">Key Insights:</h4>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>- Highest predicted growth in engagement metrics</li>
                  <li>- Strong user interaction with core features</li>
                  <li>- Above average session duration compared to competitors</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        )}
        
        {lowestDemandSite && (
          <Card>
            <CardHeader className="px-6 py-5 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg font-medium text-gray-900">
                  Lowest Demand Website
                </CardTitle>
                <ChevronDown className="h-5 w-5 text-amber-500" />
              </div>
            </CardHeader>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-1">{lowestDemandSite.name}</h3>
                  <p className="text-sm text-gray-500">
                    Based on predicted conversion rate and user engagement
                  </p>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-amber-600">{lowestDemandSite.value.toFixed(1)}%</div>
                  <div className="text-sm text-gray-500">Conversion Rate</div>
                </div>
              </div>
              
              <div className="mt-4 pt-4 border-t border-gray-100">
                <h4 className="text-sm font-medium text-gray-900 mb-2">Key Insights:</h4>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>- Lower than average user interaction rates</li>
                  <li>- Shorter average session durations</li>
                  <li>- Opportunity area: Improve content engagement strategies</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
      
      <Tabs defaultValue="metrics" className="mb-6">
        <TabsList className="grid w-full grid-cols-2 mb-4">
          <TabsTrigger value="metrics">Key Metrics</TabsTrigger>
          <TabsTrigger value="behavior">User Behavior</TabsTrigger>
        </TabsList>
        
        <TabsContent value="metrics">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <WebsiteComparisonCard
              title="Conversion Rate Prediction"
              description="Predicted conversion rates across websites for the next 30 days"
              metrics={conversionRateData}
              metricName="Conversion Rate"
              dataSource="Predictive Analytics Engine"
              metricFormatter={(value) => `${value.toFixed(1)}%`}
              highlightIndex={0}
            />
            
            <WebsiteComparisonCard
              title="Revenue Growth Projection"
              description="Projected revenue growth percentage for all tracked websites"
              metrics={websiteRevenueGrowth}
              metricName="Projected Growth"
              dataSource="AI Growth Prediction Model"
              metricFormatter={(value) => `+${value.toFixed(1)}%`}
              highlightIndex={0}
            />
            
            <WebsiteComparisonCard
              title="Bounce Rate Comparison"
              description="Predicted bounce rates with trend indicators"
              metrics={bounceRateData}
              metricName="Bounce Rate"
              dataSource="User Experience Analytics"
              metricFormatter={(value) => `${value.toFixed(1)}%`}
              sortOrder="asc"
              highlightIndex={0}
            />
            
            <WebsiteComparisonCard
              title="User Engagement Score"
              description="Overall engagement score based on multiple interaction metrics"
              metrics={websiteEngagementRates}
              metricName="Engagement Score"
              dataSource="Interaction Analytics"
              metricFormatter={(value) => `${value.toFixed(1)}%`}
              highlightIndex={0}
            />
          </div>
        </TabsContent>
        
        <TabsContent value="behavior">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <WebsiteComparisonCard
              title="Click-Through Rate"
              description="Percentage of users who click on a specific link or CTA"
              metrics={websiteClickThroughRates}
              metricName="CTR"
              dataSource="Interaction Analytics"
              metricFormatter={(value) => `${value.toFixed(1)}%`}
              highlightIndex={0}
            />
            
            <WebsiteComparisonCard
              title="Average Session Duration"
              description="Average time users spend actively engaging with the website"
              metrics={websiteSessionDurations}
              metricName="Session Time"
              dataSource="User Behavior Analytics"
              metricFormatter={(value) => `${value.toFixed(1)} min`}
              highlightIndex={0}
            />
            
            <WebsiteComparisonCard
              title="Interaction Depth"
              description="Average number of page views per user session"
              metrics={[
                { name: 'YouTube', value: 12.7, change: 2.2, trend: 'up' },
                { name: 'Netflix', value: 9.3, change: 1.5, trend: 'up' },
                { name: 'Instagram', value: 8.9, change: 1.8, trend: 'up' },
                { name: 'Amazon', value: 7.6, change: 0.8, trend: 'up' },
                { name: 'Twitter', value: 6.2, change: -0.5, trend: 'down' },
                { name: 'Flipkart', value: 5.8, change: 0.6, trend: 'up' },
                { name: 'Shopify', value: 4.9, change: 0.3, trend: 'up' },
                { name: 'Walmart', value: 4.2, change: 0.4, trend: 'up' },
                { name: 'Myntra', value: 3.8, change: 0.5, trend: 'up' },
                { name: 'Airbnb', value: 3.5, change: 0.2, trend: 'up' },
              ]}
              metricName="Page Views"
              dataSource="Page Analytics"
              metricFormatter={(value) => `${value.toFixed(1)}`}
              highlightIndex={0}
            />
            
            <WebsiteComparisonCard
              title="Feature Adoption Rate"
              description="Percentage of users who engage with key website features"
              metrics={[
                { name: 'Instagram', value: 76.5, change: 5.2, trend: 'up' },
                { name: 'YouTube', value: 72.1, change: 3.8, trend: 'up' },
                { name: 'Netflix', value: 68.9, change: 4.5, trend: 'up' },
                { name: 'Twitter', value: 65.3, change: 2.1, trend: 'up' },
                { name: 'Amazon', value: 61.8, change: 1.9, trend: 'up' },
                { name: 'Flipkart', value: 58.4, change: 2.7, trend: 'up' },
                { name: 'Myntra', value: 55.7, change: 3.1, trend: 'up' },
                { name: 'Walmart', value: 52.3, change: 1.5, trend: 'up' },
                { name: 'Shopify', value: 48.9, change: 2.2, trend: 'up' },
                { name: 'Airbnb', value: 45.8, change: 2.7, trend: 'up' },
              ]}
              metricName="Adoption Rate"
              dataSource="Feature Analytics"
              metricFormatter={(value) => `${value.toFixed(1)}%`}
              highlightIndex={0}
            />
          </div>
        </TabsContent>
      </Tabs>
    </>
  );
}