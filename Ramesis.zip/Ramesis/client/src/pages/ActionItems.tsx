import { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { 
  CheckCircle2, 
  ArrowUp, 
  AlertTriangle, 
  Lightbulb 
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';

// Types for our action items
interface ActionItem {
  id: string;
  timestamp: string;
  category: string;
  insight: string;
  website: string;
  actionPlan: string[];
  status: 'in-progress' | 'completed';
  progress: number;
}

export default function ActionItems() {
  const [actionItems, setActionItems] = useState<ActionItem[]>([]);
  
  // Load action items from localStorage on mount
  useEffect(() => {
    const savedItems = localStorage.getItem('ramesis-action-items');
    if (savedItems) {
      try {
        setActionItems(JSON.parse(savedItems));
      } catch (e) {
        console.error('Error parsing saved action items', e);
      }
    }
  }, []);

  // Get icon based on category
  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'success':
        return <ArrowUp className="h-5 w-5 text-green-500" />;
      case 'warning':
        return <AlertTriangle className="h-5 w-5 text-yellow-500" />;
      case 'suggestion':
      default:
        return <Lightbulb className="h-5 w-5 text-blue-500" />;
    }
  };

  // Get category display name
  const getCategoryDisplay = (category: string) => {
    switch (category) {
      case 'success':
        return 'Positive Trend';
      case 'warning':
        return 'Attention Needed';
      case 'suggestion':
      default:
        return 'Recommendation';
    }
  };

  // Update item progress
  const updateProgress = (id: string, newProgress: number) => {
    const updatedItems = actionItems.map(item => {
      if (item.id === id) {
        const status = newProgress >= 100 ? 'completed' : 'in-progress';
        return { ...item, progress: newProgress, status };
      }
      return item;
    });
    
    setActionItems(updatedItems);
    localStorage.setItem('ramesis-action-items', JSON.stringify(updatedItems));
  };

  // Mark item as complete
  const markAsComplete = (id: string) => {
    updateProgress(id, 100);
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  return (
    <>
      <Helmet>
        <title>Action Items - Ramesis Analytics</title>
        <meta name="description" content="Track and manage the actions you've taken based on AI insights from Ramesis Analytics." />
      </Helmet>
      
      <div className="py-6 px-6 flex flex-col gap-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Action Items</h1>
            <p className="text-muted-foreground">Track and manage your insights action plan</p>
          </div>
        </div>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle>Your Action Items</CardTitle>
            <CardDescription>
              These are the actions you've taken based on AI-generated insights
            </CardDescription>
          </CardHeader>
          <CardContent>
            {actionItems.length === 0 ? (
              <div className="text-center py-8">
                <CheckCircle2 className="mx-auto h-12 w-12 text-muted-foreground/50" />
                <h3 className="mt-4 text-lg font-semibold">No action items yet</h3>
                <p className="text-muted-foreground mt-2">
                  Visit the AI Insights page and take action on insights to see them here
                </p>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Insight</TableHead>
                    <TableHead>Website</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Progress</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {actionItems.map((item) => (
                    <TableRow key={item.id}>
                      <TableCell className="font-medium">
                        {formatDate(item.timestamp)}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-start space-x-2">
                          <span className="mt-0.5">
                            {getCategoryIcon(item.category)}
                          </span>
                          <div>
                            <div className="font-medium">
                              {getCategoryDisplay(item.category)}
                            </div>
                            <div className="text-sm text-muted-foreground">{item.insight}</div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>{item.website}</TableCell>
                      <TableCell>
                        <Badge
                          variant={item.status === 'completed' ? 'default' : 'outline'}
                          className={
                            item.status === 'completed'
                              ? 'bg-green-100 text-green-800 hover:bg-green-100'
                              : 'text-amber-800 bg-amber-100 hover:bg-amber-100'
                          }
                        >
                          {item.status === 'completed' ? 'Completed' : 'In Progress'}
                        </Badge>
                      </TableCell>
                      <TableCell className="w-[180px]">
                        <div className="flex flex-col gap-1">
                          <Progress value={item.progress} className="h-2" />
                          <span className="text-xs text-muted-foreground text-right">
                            {item.progress}%
                          </span>
                        </div>
                      </TableCell>
                      <TableCell className="text-right">
                        {item.status !== 'completed' && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => markAsComplete(item.id)}
                          >
                            Mark Complete
                          </Button>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        {actionItems.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Action Plans</CardTitle>
              <CardDescription>Detailed steps to implement your insights</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {actionItems.map((item) => (
                  <Card key={`plan-${item.id}`} className={item.status === 'completed' ? 'bg-green-50' : ''}>
                    <CardHeader className="pb-2">
                      <div className="flex justify-between items-center">
                        <CardTitle className="text-base">{item.insight}</CardTitle>
                        {item.status === 'completed' && (
                          <Badge variant="default" className="bg-green-100 text-green-800">
                            Completed
                          </Badge>
                        )}
                      </div>
                      <CardDescription>{item.website}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-1">
                        {item.actionPlan.map((step, index) => (
                          <li key={index} className="flex items-start gap-2">
                            <CheckCircle2 className={`h-4 w-4 mt-0.5 ${item.status === 'completed' ? 'text-green-500' : 'text-muted-foreground'}`} />
                            <span>{step}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </>
  );
}