import { Helmet } from 'react-helmet';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { getInsights } from '@/lib/analytics';
import { generateInsights, analyzePatterns } from '@/lib/openai';
import { queryClient } from '@/lib/queryClient';
import { 
  ArrowUp, AlertTriangle, Lightbulb, Route,
  LineChart, LogOut, RefreshCw, Download, 
  Loader, LayoutDashboard, LoaderCircle
} from 'lucide-react';

export default function AiInsightsPage() {
  const { toast } = useToast();
  const [analysisPrompt, setAnalysisPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  
  // Load acted insights from localStorage on component mount
  const [actedInsights, setActedInsights] = useState<Set<string>>(() => {
    const savedInsights = localStorage.getItem('ramesis-acted-insights');
    if (savedInsights) {
      try {
        return new Set(JSON.parse(savedInsights));
      } catch (e) {
        console.error('Error parsing saved insights', e);
        return new Set();
      }
    }
    return new Set();
  });
  
  // Fetch insights
  const { data: insights, isLoading } = useQuery({
    queryKey: ['/api/insights'],
    queryFn: getInsights,
  });
  
  // Generate insights mutation
  const generateInsightsMutation = useMutation({
    mutationFn: async (analyticsData: any) => {
      return generateInsights(analyticsData);
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/insights'] });
      
      // Check if we're using fallback data
      if (data && data.message && data.message.includes("API limitations")) {
        toast({
          title: "Analysis Complete",
          description: "New insights have been generated using local analysis (OpenAI API rate limit reached).",
          variant: "default",
        });
      } else {
        toast({
          title: "Analysis Complete",
          description: "New insights have been generated successfully.",
        });
      }
      
      setIsGenerating(false);
      setAnalysisPrompt('');
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to generate insights: " + (error as Error).message,
        variant: "destructive",
      });
      setIsGenerating(false);
    }
  });
  
  // Handle taking action on an insight
  const handleTakeAction = (insight: any) => {
    const insightKey = `${insight.id || insight.timestamp}-${insight.category}`;
    
    // Already acted on this insight
    if (actedInsights.has(insightKey)) {
      return;
    }
    
    // Get specific action steps based on insight type
    const getActionSteps = (category: string, description: string) => {
      if (description.includes('bounce rate')) {
        return [
          "Review your page loading speed",
          "Improve your headline and hero section",
          "Add clear value propositions",
          "Optimize for mobile users"
        ];
      } else if (description.includes('conversion rate')) {
        return [
          "Add testimonials and social proof",
          "Create clearer call-to-action buttons",
          "Simplify your checkout process",
          "A/B test different page layouts"
        ];
      } else if (description.includes('mobile')) {
        return [
          "Test mobile checkout flow",
          "Optimize mobile page speed",
          "Review mobile user experience",
          "Consider mobile-first design"
        ];
      } else {
        return [
          "Analyze the current situation",
          "Implement the suggested changes",
          "Monitor the results",
          "Adjust based on performance"
        ];
      }
    };
    
    const actionSteps = getActionSteps(insight.category, insight.insight);
    
    // Create a new action item for the Action Items page
    const actionItem = {
      id: insightKey,
      timestamp: new Date().toISOString(),
      category: insight.category,
      insight: insight.insight,
      website: insight.website || "All Websites",
      actionPlan: actionSteps,
      status: 'in-progress',
      progress: 25
    };
    
    // Save to localStorage for Action Items page
    const savedItems = localStorage.getItem('ramesis-action-items');
    let items = [];
    if (savedItems) {
      try {
        items = JSON.parse(savedItems);
      } catch (e) {
        console.error('Error parsing saved action items', e);
      }
    }
    
    // Add the new action item
    items.push(actionItem);
    localStorage.setItem('ramesis-action-items', JSON.stringify(items));
    
    // Mark insight as acted upon
    const newActedInsights = new Set([...actedInsights, insightKey]);
    setActedInsights(newActedInsights);
    
    // Save acted insights to localStorage for persistence
    localStorage.setItem('ramesis-acted-insights', JSON.stringify([...newActedInsights]));
    
    // Display toast with action steps
    toast({
      title: "Action Plan Created!",
      description: `Here's your next steps: ${actionSteps[0]}`,
      duration: 5000,
    });
    
    // Show detailed action plan
    setTimeout(() => {
      toast({
        title: "Complete Action Plan",
        description: actionSteps.join(" • "),
        duration: 8000,
      });
    }, 1000);
  };

  // Request custom analysis
  const handleCustomAnalysis = async () => {
    if (!analysisPrompt.trim()) {
      toast({
        title: "Input Required",
        description: "Please enter what you want to analyze.",
        variant: "destructive",
      });
      return;
    }
    
    setIsGenerating(true);
    
    // Sample analytics data - in a real app, this would be actual data
    const analyticsData = {
      customPrompt: analysisPrompt,
      pageViews: 14582,
      uniqueVisitors: 8147,
      bounceRate: 42.5,
      conversionRate: 3.2,
      avgTimeOnPage: 94, // seconds
      topPages: [
        { path: '/', views: 5204, bounceRate: 38.2 },
        { path: '/pricing', views: 2381, bounceRate: 45.7 },
        { path: '/features', views: 1945, bounceRate: 35.1 },
      ],
      trafficSources: [
        { source: 'Organic Search', percentage: 42.8 },
        { source: 'Direct', percentage: 25.1 },
        { source: 'Social Media', percentage: 15.7 },
      ],
    };
    
    try {
      await generateInsightsMutation.mutateAsync(analyticsData);
      setAnalysisPrompt('');
    } catch (error) {
      // Error is handled in the mutation
    }
  };
  
  // Get category icon and color
  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'success':
        return <ArrowUp className="h-5 w-5 text-green-500" />;
      case 'warning':
        return <AlertTriangle className="h-5 w-5 text-yellow-500" />;
      case 'suggestion':
      default:
        return <Lightbulb className="h-5 w-5 text-blue-500" />;
    }
  };
  
  // Get category background color
  const getCategoryBgColor = (category: string) => {
    switch (category) {
      case 'success':
        return 'bg-green-100';
      case 'warning':
        return 'bg-yellow-100';
      case 'suggestion':
      default:
        return 'bg-blue-100';
    }
  };
  
  // Get category style - used for card styling
  const getCategoryStyle = (category: string) => {
    switch (category) {
      case 'success':
        return {
          bgColor: 'bg-green-100',
          textColor: 'text-green-700',
          borderColor: 'border-green-200',
          iconColor: 'text-green-500'
        };
      case 'warning':
        return {
          bgColor: 'bg-yellow-100',
          textColor: 'text-yellow-700',
          borderColor: 'border-yellow-200',
          iconColor: 'text-yellow-500'
        };
      case 'suggestion':
      default:
        return {
          bgColor: 'bg-blue-100',
          textColor: 'text-blue-700',
          borderColor: 'border-blue-200',
          iconColor: 'text-blue-500'
        };
    }
  };
  
  return (
    <>
      <Helmet>
        <title>AI Insights | Ramesis - AI-Powered Website Analytics</title>
        <meta name="description" content="Get intelligent insights about your website performance using advanced AI analysis. Identify patterns and get actionable recommendations." />
      </Helmet>
      
      <div className="mb-6 flex flex-col sm:flex-row justify-between items-start sm:items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">AI Insights</h1>
          <p className="text-sm text-gray-500">Advanced analysis and recommendations powered by AI</p>
        </div>
        <div>
          <Badge variant="outline" className="px-2 py-1 text-xs rounded-full bg-primary-100 text-primary-800 font-medium">
            Powered by GPT-4
          </Badge>
        </div>
      </div>
      
      <Tabs defaultValue="insights" className="mb-6">
        <TabsList className="grid w-full grid-cols-3 mb-4">
          <TabsTrigger value="insights">AI Insights</TabsTrigger>
          <TabsTrigger value="patterns">Pattern Analysis</TabsTrigger>
          <TabsTrigger value="custom">Custom Analysis</TabsTrigger>
        </TabsList>
        
        <TabsContent value="insights">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {isLoading ? (
              <Card className="col-span-1 lg:col-span-2 h-64 flex items-center justify-center">
                <div className="text-center">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-500 mx-auto mb-4"></div>
                  <p className="text-gray-500">Loading insights...</p>
                </div>
              </Card>
            ) : insights && insights.length > 0 ? (
              insights.map((insight: any, index: number) => {
                const style = getCategoryStyle(insight.category);
                const insightKey = `${insight.id || insight.timestamp}-${insight.category}`;
                const isActedUpon = actedInsights.has(insightKey);
                
                return (
                  <Card key={insight.id || index} className={`overflow-hidden transition-all duration-300 ${isActedUpon ? 'bg-green-50 border-green-200' : ''}`}>
                    <CardHeader className={`px-6 py-4 border-b border-gray-200 ${isActedUpon ? 'bg-green-100' : 'bg-gray-50'}`}>
                      <div className="flex items-center">
                        <span className={`inline-flex items-center justify-center h-8 w-8 rounded-full ${getCategoryBgColor(insight.category)} mr-3`}>
                          {getCategoryIcon(insight.category)}
                        </span>
                        <CardTitle className="text-md font-medium text-gray-900">
                          {insight.category === 'success' ? 'Positive Trend' : 
                           insight.category === 'warning' ? 'Attention Needed' :
                           'Recommendation'}
                        </CardTitle>
                        <div className="ml-auto flex items-center gap-2">
                          {isActedUpon && (
                            <Badge variant="outline" className="px-2 py-1 text-xs rounded-full bg-green-100 text-green-700 border-green-300">
                              ✓ Action Taken
                            </Badge>
                          )}
                          <Badge variant="outline" className="px-2 py-1 text-xs rounded-full bg-gray-100 text-gray-800 font-medium">
                            {insight.confidence} confidence
                          </Badge>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="px-6 py-4">
                      <p className="text-gray-700">{insight.insight}</p>
                      <div className="mt-4 flex justify-between items-center">
                        <span className="text-xs text-gray-500">
                          {new Date(insight.timestamp).toLocaleDateString()}
                        </span>
                        <Button 
                          variant={isActedUpon ? "default" : "outline"}
                          size="sm"
                          onClick={() => handleTakeAction(insight)}
                          disabled={isActedUpon}
                          className={isActedUpon ? "bg-green-600 hover:bg-green-700" : ""}
                        >
                          {isActedUpon ? "✓ Action Taken" : "Take Action"}
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })
            ) : (
              <Card className="col-span-1 lg:col-span-2">
                <CardContent className="px-6 py-10 text-center">
                  <div className="mx-auto w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                    <LayoutDashboard className="h-8 w-8 text-gray-400" />
                  </div>
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No insights available yet</h3>
                  <p className="text-gray-500 mb-4">
                    Generate your first AI-powered insights to get recommendations for improving your website.
                  </p>
                  <Button 
                    onClick={() => {
                      setIsGenerating(true);
                      // Sample analytics data 
                      const analyticsData = {
                        pageViews: 14582,
                        uniqueVisitors: 8147,
                        bounceRate: 42.5,
                        conversionRate: 3.2,
                      };
                      generateInsightsMutation.mutate(analyticsData);
                    }}
                    disabled={isGenerating}
                  >
                    {isGenerating ? 
                      <>
                        <LoaderCircle className="h-4 w-4 mr-2 animate-spin" />
                        Generating...
                      </> : 
                      'Generate Insights'
                    }
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>
        
        <TabsContent value="patterns">
          <div className="grid grid-cols-1 gap-6">
            <Card>
              <CardHeader className="px-6 py-4 border-b border-gray-200">
                <CardTitle className="text-lg font-medium text-gray-900">User Behavior Patterns</CardTitle>
              </CardHeader>
              <CardContent className="px-6 py-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-white p-4 rounded-lg border border-gray-200 shadow-sm">
                    <div className="flex items-center mb-2">
                      <div className="h-10 w-10 rounded-full bg-primary-100 flex items-center justify-center">
                        <Route className="h-5 w-5 text-primary-600" />
                      </div>
                      <h3 className="ml-3 text-md font-medium text-gray-900">Page Sequence</h3>
                    </div>
                    <p className="text-sm text-gray-600 mb-2">Most common user journey</p>
                    <div className="p-3 rounded-md bg-gray-50 text-sm">
                      Home → Features → Pricing → Sign Up
                    </div>
                    <Badge variant="outline" className="mt-3 px-2 py-1 bg-green-50 text-green-700 border-green-200">
                      High confidence
                    </Badge>
                  </div>
                  
                  <div className="bg-white p-4 rounded-lg border border-gray-200 shadow-sm">
                    <div className="flex items-center mb-2">
                      <div className="h-10 w-10 rounded-full bg-green-100 flex items-center justify-center">
                        <LineChart className="h-5 w-5 text-green-600" />
                      </div>
                      <h3 className="ml-3 text-md font-medium text-gray-900">Conversion Point</h3>
                    </div>
                    <p className="text-sm text-gray-600 mb-2">Most effective conversion element</p>
                    <div className="p-3 rounded-md bg-gray-50 text-sm">
                      Testimonials section
                    </div>
                    <Badge variant="outline" className="mt-3 px-2 py-1 bg-yellow-50 text-yellow-700 border-yellow-200">
                      Medium confidence
                    </Badge>
                  </div>
                  
                  <div className="bg-white p-4 rounded-lg border border-gray-200 shadow-sm">
                    <div className="flex items-center mb-2">
                      <div className="h-10 w-10 rounded-full bg-red-100 flex items-center justify-center">
                        <LogOut className="h-5 w-5 text-red-600" />
                      </div>
                      <h3 className="ml-3 text-md font-medium text-gray-900">Drop-off Point</h3>
                    </div>
                    <p className="text-sm text-gray-600 mb-2">Common exit point</p>
                    <div className="p-3 rounded-md bg-gray-50 text-sm">
                      Payment information page
                    </div>
                    <Badge variant="outline" className="mt-3 px-2 py-1 bg-green-50 text-green-700 border-green-200">
                      High confidence
                    </Badge>
                  </div>
                </div>
                
                <div className="mt-6">
                  <h3 className="text-md font-medium text-gray-900 mb-3">AI Pattern Analysis</h3>
                  <p className="text-sm text-gray-700 mb-4">
                    Our AI has detected that users who view your product comparison page for more than 2 minutes have a 70% higher likelihood of conversion. 
                    Consider highlighting key product differentiators more clearly to accelerate decision-making.
                  </p>
                  <div className="flex justify-end">
                    <Button variant="outline" size="sm" className="mr-2">
                      <Download className="h-4 w-4 mr-1" />
                      Export Analysis
                    </Button>
                    <Button size="sm">
                      <RefreshCw className="h-4 w-4 mr-1" />
                      Update Analysis
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="custom">
          <Card>
            <CardHeader className="px-6 py-4 border-b border-gray-200">
              <CardTitle className="text-lg font-medium text-gray-900">Custom AI Analysis</CardTitle>
            </CardHeader>
            <CardContent className="px-6 py-4">
              <p className="text-sm text-gray-600 mb-4">
                Ask our AI to analyze specific aspects of your website performance or user behavior. 
                Get tailored insights about any metrics, pages, or segments that matter to you.
              </p>
              
              <div className="space-y-4">
                <Textarea
                  placeholder="What would you like to analyze? (e.g., 'Why is my bounce rate high on the pricing page?' or 'How can I improve conversion from mobile users?')"
                  className="min-h-[120px]"
                  value={analysisPrompt}
                  onChange={(e) => setAnalysisPrompt(e.target.value)}
                />
                
                <Button 
                  className="w-full"
                  onClick={handleCustomAnalysis}
                  disabled={isGenerating}
                >
                  {isGenerating ? 
                    <>
                      <LoaderCircle className="h-4 w-4 mr-2 animate-spin" />
                      Analyzing...
                    </> : 
                    'Request Custom Analysis'
                  }
                </Button>
              </div>
              
              <div className="mt-6 border-t border-gray-200 pt-4">
                <h3 className="text-md font-medium text-gray-900 mb-3">Example Questions</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <Button 
                    variant="outline" 
                    className="justify-start text-left h-auto py-2"
                    onClick={() => setAnalysisPrompt("Why do users drop off on my checkout page and how can I fix it?")}
                  >
                    Why do users drop off on my checkout page and how can I fix it?
                  </Button>
                  <Button 
                    variant="outline" 
                    className="justify-start text-left h-auto py-2"
                    onClick={() => setAnalysisPrompt("Which content drives the most engagement and why?")}
                  >
                    Which content drives the most engagement and why?
                  </Button>
                  <Button 
                    variant="outline" 
                    className="justify-start text-left h-auto py-2"
                    onClick={() => setAnalysisPrompt("How does my site performance compare to industry benchmarks?")}
                  >
                    How does my site performance compare to industry benchmarks?
                  </Button>
                  <Button 
                    variant="outline" 
                    className="justify-start text-left h-auto py-2"
                    onClick={() => setAnalysisPrompt("What user segments have the highest lifetime value and why?")}
                  >
                    What user segments have the highest lifetime value and why?
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </>
  );
}
