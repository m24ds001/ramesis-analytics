import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Helmet } from "react-helmet";

export default function ComparisonPage() {
  const comparisonData = [
    {
      area: "Multi-Provider Integration",
      existingSolutions: "Google Analytics, Adobe Analytics, Matomo",
      identifiedGaps: "Limited interoperability between platforms; siloed data; proprietary formats",
      ailyticsSolution: "Unified adapter system enabling cross-platform data integration; standardized data model across providers; centralized dashboard for multiple sources"
    },
    {
      area: "AI-Powered Analytics",
      existingSolutions: "Basic statistical analysis; rudimentary pattern recognition",
      identifiedGaps: "Limited contextual understanding; generic insights not specific to business context",
      ailyticsSolution: "GPT-4o implementation with domain-specific prompting; customizable AI analysis framework; confidence scoring for recommendations"
    },
    {
      area: "Real-Time Data Processing",
      existingSolutions: "Delayed batch processing; limited real-time capabilities",
      identifiedGaps: "High latency in insights generation; limited WebSocket implementation",
      ailyticsSolution: "WebSocket-based real-time updates; event-driven architecture; optimized for immediate data propagation and visualization"
    },
    {
      area: "User Behavior Analysis",
      existingSolutions: "Session tracking; funnel analysis",
      identifiedGaps: "Lacks predictive capabilities; limited understanding of user intent",
      ailyticsSolution: "AI-augmented behavior modeling; contextual understanding of user journeys; pattern recognition across sessions"
    }
  ];

  return (
    <div className="container mx-auto py-8">
      <Helmet>
        <title>AilyticsPro - Competitive Comparison</title>
        <meta 
          name="description" 
          content="See how AilyticsPro's advanced analytics platform compares to traditional solutions, addressing key gaps in multi-provider integration, AI-powered analytics, real-time processing, and user behavior analysis." 
        />
      </Helmet>
      
      <h1 className="text-3xl font-bold mb-6 text-center">AilyticsPro Competitive Comparison</h1>
      
      <Card className="mb-8">
        <CardContent className="p-6">
          <p className="text-lg mb-4">
            AilyticsPro delivers advanced analytics capabilities that address critical gaps in existing solutions.
            Our platform provides a unified approach to multi-source analytics with AI-powered insights and
            real-time data processing.
          </p>
        </CardContent>
      </Card>
      
      <div className="overflow-x-auto">
        <Table className="border-collapse w-full">
          <TableHeader className="bg-slate-800">
            <TableRow>
              <TableHead className="border px-4 py-3 text-left font-medium text-white">Research Area</TableHead>
              <TableHead className="border px-4 py-3 text-left font-medium text-white">Existing Solutions</TableHead>
              <TableHead className="border px-4 py-3 text-left font-medium text-white">Identified Gaps</TableHead>
              <TableHead className="border px-4 py-3 text-left font-medium text-white">How AilyticsPro Addresses the Gap</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {comparisonData.map((row, index) => (
              <TableRow key={index} className={index % 2 === 0 ? "bg-slate-50" : "bg-white"}>
                <TableCell className="border px-4 py-3 font-medium">{row.area}</TableCell>
                <TableCell className="border px-4 py-3">{row.existingSolutions}</TableCell>
                <TableCell className="border px-4 py-3">{row.identifiedGaps}</TableCell>
                <TableCell className="border px-4 py-3">{row.ailyticsSolution}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
      
      <Card className="mt-8">
        <CardContent className="p-6">
          <h2 className="text-xl font-bold mb-4">Why Choose AilyticsPro?</h2>
          <ul className="list-disc pl-5 space-y-2">
            <li>Seamless integration with multiple analytics providers</li>
            <li>Advanced AI-powered insights using OpenAI's GPT-4o technology</li>
            <li>Real-time data visualization and alerts through WebSocket technology</li>
            <li>Comprehensive user behavior analysis with predictive capabilities</li>
            <li>Centralized dashboard for all analytics sources</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}