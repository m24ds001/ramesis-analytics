import { useEffect, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Helmet } from 'react-helmet';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Award, Medal, Trophy } from 'lucide-react';

// Types for achievements
interface Achievement {
  id: number;
  name: string;
  description: string;
  type: string;
  criteria: {
    action: string;
    count: number;
  };
  points: number;
  badgeIcon: string;
  level: number;
  createdAt: string;
  updatedAt: string;
}

interface UserAchievement {
  id: number;
  userId: number;
  achievementId: number;
  progress: number;
  completed: boolean;
  completedAt: string | null;
  createdAt: string;
  updatedAt: string;
}

// Combined type for display
interface AchievementWithProgress extends Achievement {
  userProgress?: number;
  completed?: boolean;
  completedAt?: string | null;
}

export default function Achievements() {
  // State for total points
  const [totalPoints, setTotalPoints] = useState(0);
  const [achievementsWithProgress, setAchievementsWithProgress] = useState<AchievementWithProgress[]>([]);
  
  // Fetch all achievements
  const { data: achievements, isLoading: isLoadingAchievements } = useQuery({
    queryKey: ['/api/achievements'],
    queryFn: async () => {
      const response = await fetch('/api/achievements');
      if (!response.ok) throw new Error('Failed to fetch achievements');
      return response.json() as Promise<Achievement[]>;
    }
  });
  
  // Fetch user achievements - using mock data for now since authentication is required
  const { data: userAchievements, isLoading: isLoadingUserAchievements } = useQuery({
    queryKey: ['/api/user-achievements'],
    queryFn: async () => {
      try {
        const response = await fetch('/api/user-achievements');
        // Return empty array if not authorized (user not logged in)
        if (response.status === 401) {
          // Mock user achievements for demonstration when not logged in
          return Array(9).fill(0).map((_, index) => ({
            id: index + 1,
            userId: 1,
            achievementId: index + 1,
            progress: Math.floor(Math.random() * 101), // Random progress 0-100
            completed: Math.random() > 0.6, // Some completed, some not
            completedAt: Math.random() > 0.6 ? new Date().toISOString() : null,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
          }));
        }
        if (!response.ok) throw new Error('Failed to fetch user achievements');
        return response.json() as Promise<UserAchievement[]>;
      } catch (error) {
        console.error('Error fetching user achievements:', error);
        return [];
      }
    }
  });
  
  // Fetch user points
  const { data: pointsData } = useQuery({
    queryKey: ['/api/user/points'],
    queryFn: async () => {
      try {
        const response = await fetch('/api/user/points');
        if (response.status === 401) {
          // Mock points for demonstration when not logged in
          return { points: Math.floor(Math.random() * 1000) + 50 };
        }
        if (!response.ok) throw new Error('Failed to fetch user points');
        return response.json() as Promise<{ points: number }>;
      } catch (error) {
        console.error('Error fetching user points:', error);
        return { points: 75 };
      }
    }
  });
  
  // Combine achievements with user progress
  useEffect(() => {
    if (achievements && userAchievements) {
      const combined = achievements.map(achievement => {
        const userAchievement = userAchievements.find(ua => ua.achievementId === achievement.id);
        return {
          ...achievement,
          userProgress: userAchievement?.progress || 0,
          completed: userAchievement?.completed || false,
          completedAt: userAchievement?.completedAt || null
        };
      });
      setAchievementsWithProgress(combined);
    }
  }, [achievements, userAchievements]);
  
  // Update total points
  useEffect(() => {
    if (pointsData) {
      setTotalPoints(pointsData.points);
    }
  }, [pointsData]);
  
  // Filter achievements by completion status
  const completedAchievements = achievementsWithProgress.filter(a => a.completed);
  const inProgressAchievements = achievementsWithProgress.filter(a => !a.completed && a.userProgress > 0);
  const availableAchievements = achievementsWithProgress.filter(a => !a.completed && a.userProgress === 0);
  
  // Get achievement icon component
  const getAchievementIcon = (level: number, size = 24) => {
    if (level >= 5) return <Trophy size={size} className="text-yellow-500" />;
    if (level >= 3) return <Medal size={size} className="text-blue-500" />;
    return <Award size={size} className="text-green-500" />;
  };
  
  // Loading state
  if (isLoadingAchievements || isLoadingUserAchievements) {
    return <div className="flex justify-center items-center h-64">Loading achievements...</div>;
  }
  
  return (
    <>
      <Helmet>
        <title>Achievements | Ramesis - AI-Powered Website Analytics</title>
        <meta name="description" content="Track your progress, earn points, and unlock achievements as you improve your website analytics and performance." />
      </Helmet>
      
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Achievements</h1>
            <p className="text-gray-500">Track your progress and earn rewards for using the platform.</p>
          </div>
        <Card className="w-full md:w-auto">
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <Trophy size={40} className="text-yellow-500" />
              <div>
                <p className="text-sm text-gray-500">Total Points</p>
                <h2 className="text-3xl font-bold">{totalPoints}</h2>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="all">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="all">All ({achievementsWithProgress.length})</TabsTrigger>
          <TabsTrigger value="completed">Completed ({completedAchievements.length})</TabsTrigger>
          <TabsTrigger value="in-progress">In Progress ({inProgressAchievements.length})</TabsTrigger>
          <TabsTrigger value="available">Available ({availableAchievements.length})</TabsTrigger>
        </TabsList>
        
        {/* All achievements tab */}
        <TabsContent value="all" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {achievementsWithProgress.map((achievement) => (
              <AchievementCard key={achievement.id} achievement={achievement} />
            ))}
          </div>
        </TabsContent>
        
        {/* Completed achievements tab */}
        <TabsContent value="completed" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {completedAchievements.length > 0 ? (
              completedAchievements.map((achievement) => (
                <AchievementCard key={achievement.id} achievement={achievement} />
              ))
            ) : (
              <div className="col-span-full text-center py-12">
                <p className="text-gray-500">No completed achievements yet.</p>
              </div>
            )}
          </div>
        </TabsContent>
        
        {/* In progress achievements tab */}
        <TabsContent value="in-progress" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {inProgressAchievements.length > 0 ? (
              inProgressAchievements.map((achievement) => (
                <AchievementCard key={achievement.id} achievement={achievement} />
              ))
            ) : (
              <div className="col-span-full text-center py-12">
                <p className="text-gray-500">No achievements in progress.</p>
              </div>
            )}
          </div>
        </TabsContent>
        
        {/* Available achievements tab */}
        <TabsContent value="available" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {availableAchievements.length > 0 ? (
              availableAchievements.map((achievement) => (
                <AchievementCard key={achievement.id} achievement={achievement} />
              ))
            ) : (
              <div className="col-span-full text-center py-12">
                <p className="text-gray-500">No available achievements.</p>
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
    </>
  );
}

// Achievement card component
function AchievementCard({ achievement }: { achievement: AchievementWithProgress }) {
  // Get color based on level
  const getLevelColor = (level: number) => {
    switch (level) {
      case 5: return 'bg-yellow-100 text-yellow-800 border-yellow-300';
      case 4: return 'bg-purple-100 text-purple-800 border-purple-300';
      case 3: return 'bg-blue-100 text-blue-800 border-blue-300';
      case 2: return 'bg-green-100 text-green-800 border-green-300';
      default: return 'bg-gray-100 text-gray-800 border-gray-300';
    }
  };
  
  // Get icon based on level
  const getIcon = (level: number) => {
    if (level >= 5) return <Trophy className="h-6 w-6 text-yellow-500" />;
    if (level >= 3) return <Medal className="h-6 w-6 text-blue-500" />;
    return <Award className="h-6 w-6 text-green-500" />;
  };
  
  // Using emojis for badge icons if real ones aren't available
  const getEmoji = (badgeIcon: string | undefined) => {
    if (!badgeIcon || badgeIcon === '') {
      const emojis = ['🏆', '🎯', '📊', '📈', '🚀', '🔍', '💡', '⚡', '🌟', '💯'];
      return emojis[achievement.id % emojis.length];
    }
    return badgeIcon;
  };
  
  return (
    <Card className={`overflow-hidden ${achievement.completed ? 'border-2 border-green-500' : ''}`}>
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div className="space-y-1">
            <CardTitle className="flex items-center gap-2">
              <span>{getEmoji(achievement.badgeIcon)}</span> {achievement.name}
            </CardTitle>
            <CardDescription>{achievement.description}</CardDescription>
          </div>
          <Badge variant="outline" className={`${getLevelColor(achievement.level)} font-semibold`}>
            Level {achievement.level}
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex justify-between items-center text-sm">
            <span>Progress</span>
            <span className="font-medium">{achievement.userProgress || 0}%</span>
          </div>
          <Progress value={achievement.userProgress || 0} className="h-2" />
          
          <div className="flex justify-between items-center mt-4">
            <div className="flex items-center gap-1 text-sm text-gray-500">
              {getIcon(achievement.level)}
              <span>{achievement.points} points</span>
            </div>
            
            {achievement.completed && (
              <Badge variant="success">
                Completed
              </Badge>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}