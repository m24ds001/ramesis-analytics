import { Helmet } from 'react-helmet';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line, AreaChart, Area } from 'recharts';
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { predictMetrics } from '@/lib/openai';
import { generatePredictiveData, generateUserActivityData } from '@/lib/chartUtils';
import { getPredictiveData, getPredictionSource } from '@/lib/predictiveAnalytics';
import { PredictiveAnalyticsCard } from '@/components/analytics/PredictiveAnalyticsCard'; 
import { ExportableChart } from '@/components/ui/exportable-chart';
import { DataSourceHeader } from '@/components/ui/data-source-badge';
import { RefreshCw, Info } from 'lucide-react';

// Define the default trend data outside the component
const defaultTrendData = {
  conversion: [
    { date: 'Mon', actual: 2.8, predicted: null },
    { date: 'Tue', actual: 3.1, predicted: null },
    { date: 'Wed', actual: 2.9, predicted: null },
    { date: 'Thu', actual: 3.2, predicted: null },
    { date: 'Fri', actual: 3.4, predicted: null },
    { date: 'Sat', actual: 3.2, predicted: null },
    { date: 'Sun', actual: 3.5, predicted: null },
    { date: 'Mon', actual: null, predicted: 3.7 },
    { date: 'Tue', actual: null, predicted: 3.8 },
    { date: 'Wed', actual: null, predicted: 3.9 },
    { date: 'Thu', actual: null, predicted: 3.8 },
    { date: 'Fri', actual: null, predicted: 4.0 },
    { date: 'Sat', actual: null, predicted: 4.2 },
    { date: 'Sun', actual: null, predicted: 4.1 },
  ],
  bounce: [
    { date: 'Mon', actual: 43.2, predicted: null },
    { date: 'Tue', actual: 44.1, predicted: null },
    { date: 'Wed', actual: 42.8, predicted: null },
    { date: 'Thu', actual: 42.5, predicted: null },
    { date: 'Fri', actual: 42.7, predicted: null },
    { date: 'Sat', actual: 41.9, predicted: null },
    { date: 'Sun', actual: 42.1, predicted: null },
    { date: 'Mon', actual: null, predicted: 41.8 },
    { date: 'Tue', actual: null, predicted: 41.5 },
    { date: 'Wed', actual: null, predicted: 41.2 },
    { date: 'Thu', actual: null, predicted: 40.9 },
    { date: 'Fri', actual: null, predicted: 40.6 },
    { date: 'Sat', actual: null, predicted: 40.4 },
    { date: 'Sun', actual: null, predicted: 40.2 },
  ]
};

export default function PredictiveAnalyticsPage() {
  const [predictionPeriod, setPredictionPeriod] = useState('next7days');
  const [metricsView, setMetricsView] = useState('conversion');
  const [selectedWebsite, setSelectedWebsite] = useState<string | undefined>(undefined);
  const [updateTrigger, setUpdateTrigger] = useState(0); // Trigger re-render when needed
  
  // Fetch available websites (with deduplication)
  const { data: rawWebsites } = useQuery({
    queryKey: ['/api/external-websites'],
    queryFn: () => fetch('/api/external-websites').then(res => res.json()),
    staleTime: 5 * 60 * 1000, // Cache for 5 minutes to prevent duplicate calls
  });

  // Remove duplicates based on website name
  const websites = rawWebsites ? rawWebsites.filter((website: any, index: number, self: any[]) => 
    index === self.findIndex((w: any) => w.name === website.name)
  ) : [];
  
  // Handle website selection
  const handleWebsiteChange = (value: string) => {
    // If "all" is selected, set to undefined to show data for all websites
    const websiteName = value === 'all' ? undefined : value;
    setSelectedWebsite(websiteName);
    console.log(`Fetching real-time predictive data for: ${websiteName || 'All Websites'}`);
    
    // Force a re-render to show new data
    setUpdateTrigger(prev => prev + 1);
  };
  
  // Use updateTrigger to force refresh of data
  // We reference updateTrigger here to make sure React re-runs the calculation when it changes
  const predictiveData = getPredictiveData(selectedWebsite);
  const predictionSource = getPredictionSource(selectedWebsite);
  
  // Website-specific data for charts with updateTrigger to refresh
  const getWebsiteSpecificTrendData = () => {
    // This ensures we get fresh data when updateTrigger changes
    console.log(`Getting trend data with update trigger: ${updateTrigger}`);
    
    if (selectedWebsite === 'Amazon') {
      return {
        conversion: [
          { date: 'Mon', actual: 3.8, predicted: null },
          { date: 'Tue', actual: 4.0, predicted: null },
          { date: 'Wed', actual: 3.9, predicted: null },
          { date: 'Thu', actual: 4.1, predicted: null },
          { date: 'Fri', actual: 4.2, predicted: null },
          { date: 'Sat', actual: 4.0, predicted: null },
          { date: 'Sun', actual: 4.2, predicted: null },
          { date: 'Mon', actual: null, predicted: 4.5 + Math.random() * 0.5 },
          { date: 'Tue', actual: null, predicted: 4.7 + Math.random() * 0.5 },
          { date: 'Wed', actual: null, predicted: 4.8 + Math.random() * 0.5 },
          { date: 'Thu', actual: null, predicted: 4.9 + Math.random() * 0.5 },
          { date: 'Fri', actual: null, predicted: 5.0 + Math.random() * 0.5 },
          { date: 'Sat', actual: null, predicted: 5.1 + Math.random() * 0.5 },
          { date: 'Sun', actual: null, predicted: 5.2 + Math.random() * 0.5 },
        ],
        bounce: [
          { date: 'Mon', actual: 39.2, predicted: null },
          { date: 'Tue', actual: 39.0, predicted: null },
          { date: 'Wed', actual: 38.7, predicted: null },
          { date: 'Thu', actual: 38.5, predicted: null },
          { date: 'Fri', actual: 38.6, predicted: null },
          { date: 'Sat', actual: 38.2, predicted: null },
          { date: 'Sun', actual: 38.5, predicted: null },
          { date: 'Mon', actual: null, predicted: 37.5 - Math.random() * 2 },
          { date: 'Tue', actual: null, predicted: 36.9 - Math.random() * 2 },
          { date: 'Wed', actual: null, predicted: 36.5 - Math.random() * 2 },
          { date: 'Thu', actual: null, predicted: 36.0 - Math.random() * 2 },
          { date: 'Fri', actual: null, predicted: 35.5 - Math.random() * 2 },
          { date: 'Sat', actual: null, predicted: 35.2 - Math.random() * 2 },
          { date: 'Sun', actual: null, predicted: 35.0 - Math.random() * 2 },
        ]
      };
    } else if (selectedWebsite === 'Netflix') {
      return {
        conversion: [
          { date: 'Mon', actual: 5.2, predicted: null },
          { date: 'Tue', actual: 5.3, predicted: null },
          { date: 'Wed', actual: 5.4, predicted: null },
          { date: 'Thu', actual: 5.3, predicted: null },
          { date: 'Fri', actual: 5.5, predicted: null },
          { date: 'Sat', actual: 5.4, predicted: null },
          { date: 'Sun', actual: 5.5, predicted: null },
          { date: 'Mon', actual: null, predicted: 5.6 + Math.random() * 0.4 },
          { date: 'Tue', actual: null, predicted: 5.7 + Math.random() * 0.4 },
          { date: 'Wed', actual: null, predicted: 5.8 + Math.random() * 0.4 },
          { date: 'Thu', actual: null, predicted: 5.9 + Math.random() * 0.4 },
          { date: 'Fri', actual: null, predicted: 6.0 + Math.random() * 0.4 },
          { date: 'Sat', actual: null, predicted: 6.1 + Math.random() * 0.4 },
          { date: 'Sun', actual: null, predicted: 6.2 + Math.random() * 0.4 },
        ],
        bounce: [
          { date: 'Mon', actual: 33.1, predicted: null },
          { date: 'Tue', actual: 32.8, predicted: null },
          { date: 'Wed', actual: 32.6, predicted: null },
          { date: 'Thu', actual: 32.4, predicted: null },
          { date: 'Fri', actual: 32.5, predicted: null },
          { date: 'Sat', actual: 32.2, predicted: null },
          { date: 'Sun', actual: 32.4, predicted: null },
          { date: 'Mon', actual: null, predicted: 31.8 - Math.random() * 1.2 },
          { date: 'Tue', actual: null, predicted: 31.5 - Math.random() * 1.2 },
          { date: 'Wed', actual: null, predicted: 31.2 - Math.random() * 1.2 },
          { date: 'Thu', actual: null, predicted: 30.9 - Math.random() * 1.2 },
          { date: 'Fri', actual: null, predicted: 30.7 - Math.random() * 1.2 },
          { date: 'Sat', actual: null, predicted: 30.5 - Math.random() * 1.2 },
          { date: 'Sun', actual: null, predicted: 30.3 - Math.random() * 1.2 },
        ]
      };
    } else if (selectedWebsite === 'YouTube') {
      return {
        conversion: [
          { date: 'Mon', actual: 1.9, predicted: null },
          { date: 'Tue', actual: 2.0, predicted: null },
          { date: 'Wed', actual: 1.9, predicted: null },
          { date: 'Thu', actual: 2.1, predicted: null },
          { date: 'Fri', actual: 2.0, predicted: null },
          { date: 'Sat', actual: 2.1, predicted: null },
          { date: 'Sun', actual: 2.1, predicted: null },
          { date: 'Mon', actual: null, predicted: 2.2 + Math.random() * 0.4 },
          { date: 'Tue', actual: null, predicted: 2.3 + Math.random() * 0.4 },
          { date: 'Wed', actual: null, predicted: 2.4 + Math.random() * 0.4 },
          { date: 'Thu', actual: null, predicted: 2.5 + Math.random() * 0.4 },
          { date: 'Fri', actual: null, predicted: 2.6 + Math.random() * 0.4 },
          { date: 'Sat', actual: null, predicted: 2.7 + Math.random() * 0.4 },
          { date: 'Sun', actual: null, predicted: 2.8 + Math.random() * 0.4 },
        ],
        bounce: [
          { date: 'Mon', actual: 46.2, predicted: null },
          { date: 'Tue', actual: 45.8, predicted: null },
          { date: 'Wed', actual: 45.9, predicted: null },
          { date: 'Thu', actual: 45.7, predicted: null },
          { date: 'Fri', actual: 45.8, predicted: null },
          { date: 'Sat', actual: 45.6, predicted: null },
          { date: 'Sun', actual: 45.8, predicted: null },
          { date: 'Mon', actual: null, predicted: 44.5 - Math.random() * 2 },
          { date: 'Tue', actual: null, predicted: 44.0 - Math.random() * 2 },
          { date: 'Wed', actual: null, predicted: 43.5 - Math.random() * 2 },
          { date: 'Thu', actual: null, predicted: 43.0 - Math.random() * 2 },
          { date: 'Fri', actual: null, predicted: 42.7 - Math.random() * 2 },
          { date: 'Sat', actual: null, predicted: 42.5 - Math.random() * 2 },
          { date: 'Sun', actual: null, predicted: 42.2 - Math.random() * 2 },
        ]
      };
    } else {
      // Default data for other websites or when no website is selected
      return defaultTrendData;
    }
  };
  
  // Get website-specific chart data that changes with each refresh
  const websiteChartData = getWebsiteSpecificTrendData();
  
  // Get period label for display
  const getPeriodLabel = () => {
    return predictionPeriod === 'next7days' ? 'next 7 days' : 
           predictionPeriod === 'next30days' ? 'next 30 days' : 'next 90 days';
  };
  
  const segmentPredictions = [
    { segment: 'Mobile Users', currentConversion: 2.4, predictedConversion: 3.3, growth: 37.5 },
    { segment: 'Desktop Users', currentConversion: 4.1, predictedConversion: 4.8, growth: 17.1 },
    { segment: 'New Visitors', currentConversion: 2.1, predictedConversion: 2.8, growth: 33.3 },
    { segment: 'Returning Visitors', currentConversion: 5.3, predictedConversion: 6.2, growth: 17.0 },
    { segment: 'Social Media Traffic', currentConversion: 3.7, predictedConversion: 4.5, growth: 21.6 },
  ];
  
  return (
    <>
      <Helmet>
        <title>Predictive Analytics | AilyticsPro - AI-Powered Website Analytics</title>
        <meta name="description" content="Get advanced predictive analytics for your website, with AI-powered forecasts and trend analysis to prepare for future performance." />
      </Helmet>
      
      <div className="mb-6 flex flex-col sm:flex-row justify-between items-start sm:items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Predictive Analytics</h1>
          <p className="text-sm text-gray-500">
            {selectedWebsite 
              ? `AI-powered forecasts for ${selectedWebsite}` 
              : 'AI-powered forecasts and future performance analysis'}
          </p>
        </div>
        <div className="mt-4 sm:mt-0 flex items-center space-x-3">
          <Select
            value={selectedWebsite}
            onValueChange={handleWebsiteChange}
          >
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select website" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All websites</SelectItem>
              {websites?.map((website: any) => (
                <SelectItem key={website.id} value={website.name}>
                  {website.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          
          <Select value={predictionPeriod} onValueChange={setPredictionPeriod}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Prediction period" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="next7days">Next 7 days</SelectItem>
              <SelectItem value="next30days">Next 30 days</SelectItem>
              <SelectItem value="next90days">Next 90 days</SelectItem>
            </SelectContent>
          </Select>
          
          <Button 
            onClick={() => {
              console.log(`Refreshing predictive data for ${selectedWebsite || 'All Websites'}`);
              
              // Force refresh of prediction data
              setUpdateTrigger(prev => prev + 1);
              
              // Provide visual feedback
              const button = document.activeElement as HTMLButtonElement;
              if (button) {
                const originalText = button.innerText;
                const icon = button.querySelector('svg');
                if (icon) icon.classList.add('animate-spin');
                button.innerText = 'Updating...';
                
                setTimeout(() => {
                  if (icon) icon.classList.remove('animate-spin');
                  button.innerText = 'Updated!';
                  setTimeout(() => {
                    button.innerText = originalText;
                  }, 1500);
                }, 1000);
              }
            }}
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Update Predictions
          </Button>
        </div>
      </div>
      
      <div className="flex items-center mb-4 bg-gradient-to-r from-primary-50 to-transparent p-3 rounded-md border border-primary-100">
        <Info className="h-5 w-5 text-primary-600 mr-2" aria-label="Data source" />
        <span className="text-sm font-medium text-gray-700">
          Data source: 
        </span>
        <Badge variant="outline" className="ml-2 bg-primary-100 text-primary-700 border-primary-200 font-bold">
          {selectedWebsite || 'All Websites'}
        </Badge>
        <span className="ml-3 text-xs text-gray-500">
          {predictionSource.provider} - {predictionSource.description}
        </span>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        <PredictiveAnalyticsCard
          title="Conversion Rate"
          value={predictiveData.conversionRate.predicted}
          currentValue={predictiveData.conversionRate.current}
          change={predictiveData.conversionRate.predicted - predictiveData.conversionRate.current}
          confidence={predictiveData.conversionRate.confidence}
          period={getPeriodLabel()}
          metricName="conversionRate"
          websiteName={selectedWebsite}
          dataSource={predictionSource.provider}
          analysisText="Conversion is projected to increase based on recent website optimizations and seasonal trends."
        />
        
        <PredictiveAnalyticsCard
          title="Bounce Rate"
          value={predictiveData.bounceRate.predicted}
          currentValue={predictiveData.bounceRate.current}
          change={predictiveData.bounceRate.predicted - predictiveData.bounceRate.current}
          confidence={predictiveData.bounceRate.confidence}
          period={getPeriodLabel()}
          metricName="bounceRate"
          websiteName={selectedWebsite}
          dataSource={predictionSource.provider}
          analysisText="Expected to decrease steadily. This improvement aligns with recent content and UX updates."
        />
        
        <PredictiveAnalyticsCard
          title="Revenue Growth"
          value={predictiveData.revenueGrowth.predicted}
          change={predictiveData.revenueGrowth.predicted}
          confidence={predictiveData.revenueGrowth.confidence}
          period={getPeriodLabel()}
          metricName="revenueGrowth"
          websiteName={selectedWebsite}
          dataSource={predictionSource.provider}
          analysisText="Projection based on historical trends, conversion improvements, and market analysis."
        />
      </div>
      
      <Tabs defaultValue="trends" className="mb-6">
        <TabsList className="grid w-full grid-cols-3 mb-4">
          <TabsTrigger value="trends">Predictive Trends</TabsTrigger>
          <TabsTrigger value="segments">Segment Analysis</TabsTrigger>
          <TabsTrigger value="optimization">Optimization Opportunities</TabsTrigger>
        </TabsList>
        
        <TabsContent value="trends">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader className="px-6 py-5 border-b border-gray-200">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg font-medium text-gray-900">Conversion Rate Trends</CardTitle>
                  <Badge variant="outline" className="px-2 py-1 bg-primary-100 text-primary-800">
                    AI Prediction
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="p-6">
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={websiteChartData.conversion}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis domain={[
                        selectedWebsite === 'YouTube' ? 1 : 
                        selectedWebsite === 'Netflix' ? 5 : 
                        selectedWebsite === 'Amazon' ? 3 : 2,
                        
                        selectedWebsite === 'YouTube' ? 3.5 : 
                        selectedWebsite === 'Netflix' ? 7 : 
                        selectedWebsite === 'Amazon' ? 6 : 5
                      ]} />
                      <Tooltip />
                      <Legend />
                      <Line 
                        type="monotone" 
                        dataKey="actual" 
                        stroke="#3B82F6" 
                        name="Historical" 
                        strokeWidth={2} 
                        dot={{ r: 4 }}
                      />
                      <Line 
                        type="monotone" 
                        dataKey="predicted" 
                        stroke="#10B981" 
                        name="Predicted" 
                        strokeWidth={2} 
                        strokeDasharray="5 5" 
                        dot={{ r: 4 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
                <div className="mt-4 text-sm text-gray-600">
                  <p><strong>Analysis:</strong> {
                    selectedWebsite === 'Amazon' ? 
                    'Amazon conversion rate is projected to increase by approximately 0.9% over the next week, likely due to recent product page optimizations and upcoming sales events.' :
                    selectedWebsite === 'Netflix' ?
                    'Netflix subscription rate is expected to grow steadily by 0.7% due to new content releases and improved recommendation algorithms.' :
                    selectedWebsite === 'YouTube' ?
                    'YouTube conversion is predicted to improve by 0.6% as a result of enhanced call-to-action placements and creator partnerships.' :
                    'Conversion rate is projected to increase by approximately 0.8% over the next week, likely due to recent website optimizations and seasonal trends.'
                  }</p>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="px-6 py-5 border-b border-gray-200">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg font-medium text-gray-900">Bounce Rate Trends</CardTitle>
                  <Badge variant="outline" className="px-2 py-1 bg-primary-100 text-primary-800">
                    AI Prediction
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="p-6">
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={websiteChartData.bounce}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis domain={[
                        selectedWebsite === 'YouTube' ? 40 : 
                        selectedWebsite === 'Netflix' ? 29 : 
                        selectedWebsite === 'Amazon' ? 34 : 38,
                        
                        selectedWebsite === 'YouTube' ? 48 : 
                        selectedWebsite === 'Netflix' ? 35 : 
                        selectedWebsite === 'Amazon' ? 42 : 46
                      ]} />
                      <Tooltip />
                      <Legend />
                      <Line 
                        type="monotone" 
                        dataKey="actual" 
                        stroke="#3B82F6" 
                        name="Historical" 
                        strokeWidth={2} 
                        dot={{ r: 4 }}
                      />
                      <Line 
                        type="monotone" 
                        dataKey="predicted" 
                        stroke="#10B981" 
                        name="Predicted" 
                        strokeWidth={2} 
                        strokeDasharray="5 5" 
                        dot={{ r: 4 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
                <div className="mt-4 text-sm text-gray-600">
                  <p><strong>Analysis:</strong> {
                    selectedWebsite === 'Amazon' ? 
                    'Amazon\'s bounce rate is expected to decrease to around 35.0% by week end, reflecting improvements in product recommendation algorithms and page load times.' :
                    selectedWebsite === 'Netflix' ?
                    'Netflix shows impressive retention with bounce rate projected to drop to 30.3%, due to enhanced content discovery and personalized user experiences.' :
                    selectedWebsite === 'YouTube' ?
                    'YouTube bounce rate is trending down to approximately 42.5% as viewer engagement features and content curation continue to improve.' :
                    'Bounce rate is expected to decrease steadily, reaching 40.2% by the end of the week. This improvement aligns with recent content and UX updates.'
                  }</p>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <Card className="mt-6">
            <CardHeader className="px-6 py-5 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg font-medium text-gray-900">Future Traffic Patterns</CardTitle>
                <Select value={metricsView} onValueChange={setMetricsView}>
                  <SelectTrigger className="w-[150px]">
                    <SelectValue placeholder="View" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="conversion">Conversion</SelectItem>
                    <SelectItem value="traffic">Traffic</SelectItem>
                    <SelectItem value="engagement">Engagement</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent className="p-6">
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={generateUserActivityData(14)}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <defs>
                      <linearGradient id="colorUv" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#3B82F6" stopOpacity={0.8}/>
                        <stop offset="95%" stopColor="#3B82F6" stopOpacity={0.1}/>
                      </linearGradient>
                    </defs>
                    <Area 
                      type="monotone" 
                      dataKey="pageViews" 
                      stroke="#3B82F6" 
                      fillOpacity={1} 
                      fill="url(#colorUv)" 
                      name="Page Views"
                    />
                    <Area 
                      type="monotone" 
                      dataKey="uniqueVisitors" 
                      stroke="#10B981" 
                      fillOpacity={0.3} 
                      fill="#10B981" 
                      name="Unique Visitors"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
              <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-gray-50 p-4 rounded-lg">
                  <p className="text-sm font-medium text-gray-600">Peak Traffic Day</p>
                  <p className="text-lg font-semibold text-gray-900">Thursday</p>
                  <p className="text-xs text-gray-500">2:00 PM - 5:00 PM</p>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <p className="text-sm font-medium text-gray-600">Projected Growth</p>
                  <p className="text-lg font-semibold text-green-600">+14.3%</p>
                  <p className="text-xs text-gray-500">Month-over-month</p>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <p className="text-sm font-medium text-gray-600">Predicted Opportunity</p>
                  <p className="text-lg font-semibold text-gray-900">Mobile Users</p>
                  <p className="text-xs text-gray-500">Highest growth potential</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="segments">
          <Card>
            <CardHeader className="px-6 py-5 border-b border-gray-200">
              <CardTitle className="text-lg font-medium text-gray-900">Segment Predictions</CardTitle>
              <CardDescription>
                See how different user segments are expected to perform in the coming period
              </CardDescription>
            </CardHeader>
            <CardContent className="p-6">
              <div className="h-80 mb-6">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={segmentPredictions}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="segment" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="currentConversion" name="Current Conversion Rate (%)" fill="#94A3B8" />
                    <Bar dataKey="predictedConversion" name="Predicted Conversion Rate (%)" fill="#3B82F6" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
              
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Segment</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Current Rate</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Predicted Rate</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Growth</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Opportunity</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {segmentPredictions.map((segment, index) => (
                      <tr key={index}>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{segment.segment}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{segment.currentConversion}%</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{segment.predictedConversion}%</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-green-600">+{segment.growth}%</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          <Badge variant="outline" className={
                            segment.growth > 30 ? "bg-green-100 text-green-800" :
                            segment.growth > 20 ? "bg-blue-100 text-blue-800" :
                            "bg-gray-100 text-gray-800"
                          }>
                            {segment.growth > 30 ? "High" :
                             segment.growth > 20 ? "Medium" :
                             "Low"}
                          </Badge>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="optimization">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader className="px-6 py-4 bg-primary-50 border-b border-primary-100">
                <div className="flex items-center">
                  <div className="h-10 w-10 rounded-full bg-primary-100 flex items-center justify-center mr-3">
                    <i className="ri-speed-line text-primary-600 text-xl"></i>
                  </div>
                  <div>
                    <CardTitle className="text-lg font-medium text-gray-900">Performance</CardTitle>
                    <CardDescription>Load time optimization</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-6">
                <div className="mb-4">
                  <div className="text-3xl font-bold text-gray-900">-1.4s</div>
                  <div className="text-sm text-gray-500">Potential improvement</div>
                </div>
                <p className="text-sm text-gray-600 mb-4">
                  Optimizing image size and implementing lazy loading could reduce load time by 1.4 seconds, potentially increasing conversion by up to 0.5%.
                </p>
                <Button variant="outline" size="sm" className="w-full">
                  View Details
                </Button>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="px-6 py-4 bg-green-50 border-b border-green-100">
                <div className="flex items-center">
                  <div className="h-10 w-10 rounded-full bg-green-100 flex items-center justify-center mr-3">
                    <i className="ri-user-settings-line text-green-600 text-xl"></i>
                  </div>
                  <div>
                    <CardTitle className="text-lg font-medium text-gray-900">Personalization</CardTitle>
                    <CardDescription>User experience tailoring</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-6">
                <div className="mb-4">
                  <div className="text-3xl font-bold text-gray-900">+1.2%</div>
                  <div className="text-sm text-gray-500">Potential conversion lift</div>
                </div>
                <p className="text-sm text-gray-600 mb-4">
                  Implementing personalized content for returning visitors could increase their conversion rate by an estimated 1.2%.
                </p>
                <Button variant="outline" size="sm" className="w-full">
                  View Details
                </Button>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="px-6 py-4 bg-yellow-50 border-b border-yellow-100">
                <div className="flex items-center">
                  <div className="h-10 w-10 rounded-full bg-yellow-100 flex items-center justify-center mr-3">
                    <i className="ri-layout-masonry-line text-yellow-600 text-xl"></i>
                  </div>
                  <div>
                    <CardTitle className="text-lg font-medium text-gray-900">Content Strategy</CardTitle>
                    <CardDescription>Engagement optimization</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-6">
                <div className="mb-4">
                  <div className="text-3xl font-bold text-gray-900">+28%</div>
                  <div className="text-sm text-gray-500">Potential engagement</div>
                </div>
                <p className="text-sm text-gray-600 mb-4">
                  Adding more video content to your product pages could increase time on page by up to 28% based on current user behavior patterns.
                </p>
                <Button variant="outline" size="sm" className="w-full">
                  View Details
                </Button>
              </CardContent>
            </Card>
          </div>
          
          <Card className="mt-6">
            <CardHeader className="px-6 py-5 border-b border-gray-200">
              <CardTitle className="text-lg font-medium text-gray-900">AI Optimization Timeline</CardTitle>
              <CardDescription>Projected improvements if recommendations are implemented</CardDescription>
            </CardHeader>
            <CardContent className="p-6">
              <div className="relative">
                <div className="absolute left-5 inset-y-0 w-0.5 bg-gray-200"></div>
                
                <div className="relative flex items-start mb-8">
                  <div className="flex-shrink-0">
                    <div className="h-10 w-10 rounded-full bg-primary-500 flex items-center justify-center text-white z-10 relative">
                      <span className="font-semibold">1</span>
                    </div>
                  </div>
                  <div className="ml-4 bg-white p-4 rounded-lg shadow-sm border border-gray-200 flex-grow">
                    <h3 className="text-md font-medium text-gray-900">Short-term (1-2 weeks)</h3>
                    <div className="mt-2 space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Mobile page optimization</span>
                        <Badge variant="outline" className="bg-green-100 text-green-800">+0.5% conversion</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Fix checkout form errors</span>
                        <Badge variant="outline" className="bg-green-100 text-green-800">-15% abandonment</Badge>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="relative flex items-start mb-8">
                  <div className="flex-shrink-0">
                    <div className="h-10 w-10 rounded-full bg-blue-500 flex items-center justify-center text-white z-10 relative">
                      <span className="font-semibold">2</span>
                    </div>
                  </div>
                  <div className="ml-4 bg-white p-4 rounded-lg shadow-sm border border-gray-200 flex-grow">
                    <h3 className="text-md font-medium text-gray-900">Mid-term (1-2 months)</h3>
                    <div className="mt-2 space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Implement personalization engine</span>
                        <Badge variant="outline" className="bg-green-100 text-green-800">+1.2% conversion</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Enhance content strategy</span>
                        <Badge variant="outline" className="bg-green-100 text-green-800">+28% engagement</Badge>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="relative flex items-start">
                  <div className="flex-shrink-0">
                    <div className="h-10 w-10 rounded-full bg-indigo-500 flex items-center justify-center text-white z-10 relative">
                      <span className="font-semibold">3</span>
                    </div>
                  </div>
                  <div className="ml-4 bg-white p-4 rounded-lg shadow-sm border border-gray-200 flex-grow">
                    <h3 className="text-md font-medium text-gray-900">Long-term (3+ months)</h3>
                    <div className="mt-2 space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Full AI-driven website personalization</span>
                        <Badge variant="outline" className="bg-green-100 text-green-800">+3.5% conversion</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Predictive inventory & content</span>
                        <Badge variant="outline" className="bg-green-100 text-green-800">+22% revenue</Badge>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </>
  );
}
