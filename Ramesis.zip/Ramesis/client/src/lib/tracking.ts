import { queryClient } from './queryClient';
import DOMPurify from 'dompurify';

// Types for tracking data
interface VisitData {
  sessionId: string;
  page: string;
  device: string;
  browser: string;
  referrer?: string;
  country?: string;
}

interface EventData {
  sessionId: string;
  eventType: string;
  eventData: any;
  page: string;
}

// Generate a unique session ID
const generateSessionId = (): string => {
  return Date.now().toString(36) + Math.random().toString(36).substring(2);
};

// Sanitize data before sending to server
const sanitizeData = (data: unknown): string => {
  return DOMPurify.sanitize(JSON.stringify(data));
};

// Get or create a session ID using secure cookies
const getSessionId = (): string => {
  // Try to get from existing cookie
  const sessionId = getCookie('analytics_session_id') || localStorage.getItem('analytics_session_id');
  
  if (sessionId) {
    return sessionId;
  }
  
  // Create new session ID
  const newSessionId = generateSessionId();
  
  // Set in both cookie (primary) and localStorage (fallback)
  setSecureCookie('analytics_session_id', newSessionId);
  localStorage.setItem('analytics_session_id', newSessionId);
  
  return newSessionId;
};

// Get cookie by name
const getCookie = (name: string): string | null => {
  const match = document.cookie.match(new RegExp(`(^| )${name}=([^;]+)`));
  return match ? match[2] : null;
};

// Set secure cookie
const setSecureCookie = (name: string, value: string): void => {
  // Use Secure flag in production, SameSite=Strict for CSRF protection
  const secure = location.protocol === 'https:' ? 'Secure;' : '';
  document.cookie = `${name}=${value}; ${secure} SameSite=Strict; path=/; max-age=86400`; // 24 hours
};

// Detect browser
const detectBrowser = (): string => {
  const userAgent = navigator.userAgent;
  
  if (userAgent.indexOf('Firefox') > -1) {
    return 'Firefox';
  } else if (userAgent.indexOf('Chrome') > -1) {
    return 'Chrome';
  } else if (userAgent.indexOf('Safari') > -1) {
    return 'Safari';
  } else if (userAgent.indexOf('Edge') > -1 || userAgent.indexOf('Edg/') > -1) {
    return 'Edge';
  } else if (userAgent.indexOf('MSIE') > -1 || userAgent.indexOf('Trident/') > -1) {
    return 'Internet Explorer';
  } else {
    return 'Unknown';
  }
};

// Detect device type
const detectDevice = (): string => {
  const userAgent = navigator.userAgent;
  
  if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(userAgent)) {
    if (/iPad|tablet|Nexus (7|9)|Kindle Fire|Pad|Tab/i.test(userAgent)) {
      return 'Tablet';
    }
    return 'Mobile';
  }
  
  return 'Desktop';
};

// Record a page visit
const recordVisit = async (): Promise<void> => {
  const sessionId = getSessionId();
  const page = window.location.pathname;
  const device = detectDevice();
  const browser = detectBrowser();
  // Sanitize the referrer to prevent potential security issues
  const referrer = DOMPurify.sanitize(document.referrer);
  
  const visitData: VisitData = {
    sessionId,
    page,
    device,
    browser,
    referrer,
  };
  
  try {
    const response = await fetch('/api/visits', {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'X-CSRF-Protection': 'true'
      },
      body: JSON.stringify(visitData),
      credentials: 'include'
    });
    
    if (response.ok) {
      console.log('Visit recorded successfully');
      // Invalidate visits query to update real-time data
      queryClient.invalidateQueries({ queryKey: ['/api/visits'] });
    } else {
      throw new Error(`Error ${response.status}: ${response.statusText}`);
    }
  } catch (error) {
    console.error('Error recording visit:', error);
  }
};

// Record a user event
const recordEvent = async (eventType: string, eventData: any): Promise<void> => {
  const sessionId = getSessionId();
  const page = window.location.pathname;
  
  // Sanitize the event data before sending to server
  const safeData = typeof eventData === 'object' ? 
    JSON.parse(sanitizeData(eventData)) : eventData;
  
  const event: EventData = {
    sessionId,
    eventType,
    eventData: safeData,
    page,
  };
  
  try {
    const response = await fetch('/api/events', {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'X-CSRF-Protection': 'true'
      },
      body: JSON.stringify(event),
      credentials: 'include'
    });
    
    if (response.ok) {
      console.log(`Event '${eventType}' recorded successfully`);
      // Invalidate events query to update real-time data
      queryClient.invalidateQueries({ queryKey: ['/api/events'] });
    } else {
      throw new Error(`Error ${response.status}: ${response.statusText}`);
    }
  } catch (error) {
    console.error(`Error recording event '${eventType}':`, error);
  }
};

// Track clicks
const setupClickTracking = (): void => {
  document.addEventListener('click', (e) => {
    const target = e.target as HTMLElement;
    let element = target;
    let elementType = element.tagName.toLowerCase();
    let elementId = element.id;
    let elementClass = Array.from(element.classList).join(' ');
    let elementText = element.textContent?.trim().substring(0, 50);
    
    recordEvent('click', {
      elementType,
      elementId,
      elementClass,
      elementText,
      x: e.clientX,
      y: e.clientY,
    });
  });
};

// Track form submissions
const setupFormTracking = (): void => {
  document.addEventListener('submit', (e) => {
    const form = e.target as HTMLFormElement;
    const formId = form.id;
    const formAction = form.action;
    const formElements = Array.from(form.elements).length;
    
    recordEvent('form_submit', {
      formId,
      formAction,
      formElements,
    });
  });
};

// Initialize tracking
export const initializeTracking = (): void => {
  // Record initial page visit
  recordVisit();
  
  // Set up event listeners for user interactions
  setupClickTracking();
  setupFormTracking();
  
  // Track page navigation (for SPAs)
  let currentPath = window.location.pathname;
  
  // Check for path changes every second (simplified approach)
  setInterval(() => {
    const newPath = window.location.pathname;
    if (newPath !== currentPath) {
      currentPath = newPath;
      recordVisit();
    }
  }, 1000);
};

// Export individual functions for specific use cases
export {
  recordVisit,
  recordEvent,
  getSessionId
};