import html2canvas from 'html2canvas';

/**
 * Options for exporting charts and visualizations
 */
export interface ExportVisualizationOptions {
  fileName?: string;
  backgroundColor?: string;
  includeTimestamp?: boolean;
  quality?: number;  // For jpeg exports
  scale?: number;    // For canvas rendering
}

const defaultOptions: ExportVisualizationOptions = {
  fileName: 'analytics-visualization',
  backgroundColor: '#ffffff',
  includeTimestamp: true,
  quality: 0.95,
  scale: 2
};

/**
 * Export an element as an image
 * @param element The DOM element to export
 * @param options Export options
 * @returns Promise that resolves when the export is complete
 */
export async function exportElementAsImage(
  element: HTMLElement, 
  options?: ExportVisualizationOptions
): Promise<void> {
  try {
    const mergedOptions = { ...defaultOptions, ...options };
    
    // Generate a filename with timestamp if needed
    let fileName = mergedOptions.fileName || 'analytics-visualization';
    if (mergedOptions.includeTimestamp) {
      const timestamp = new Date().toISOString().replace(/:/g, '-').replace(/\..+/, '');
      fileName = `${fileName}-${timestamp}`;
    }
    
    // Create canvas from the element
    const canvas = await html2canvas(element, {
      backgroundColor: mergedOptions.backgroundColor,
      scale: mergedOptions.scale,
      useCORS: true, // Allow cross-origin images
      allowTaint: true, // Allow tainted canvas
      logging: false, // Disable logging
    });
    
    // Convert canvas to blob
    const blob = await new Promise<Blob>((resolve) => {
      canvas.toBlob(
        (blob) => resolve(blob as Blob),
        'image/png',
        mergedOptions.quality
      );
    });
    
    // Create download link and trigger download
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${fileName}.png`;
    document.body.appendChild(link);
    link.click();
    
    // Clean up
    setTimeout(() => {
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    }, 100);
    
    return Promise.resolve();
  } catch (error) {
    console.error('Error exporting visualization:', error);
    return Promise.reject(error);
  }
}

/**
 * Export a chart or visualization component as an image
 * @param elementId The ID of the element to export
 * @param options Export options
 * @returns Promise that resolves when the export is complete
 */
export async function exportVisualization(
  elementId: string,
  options?: ExportVisualizationOptions
): Promise<void> {
  const element = document.getElementById(elementId);
  if (!element) {
    console.error(`Element with ID "${elementId}" not found`);
    return Promise.reject(new Error(`Element with ID "${elementId}" not found`));
  }
  
  return exportElementAsImage(element, options);
}