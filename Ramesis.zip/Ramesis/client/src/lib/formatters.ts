/**
 * Format a number as a percentage string with % symbol
 * @param value Number to format as percentage
 * @param decimals Number of decimal places (default: 1)
 * @returns Formatted percentage string
 */
export function formatPercent(value: number, decimals: number = 1): string {
  if (isNaN(value)) return '0%';
  const multiplier = Math.pow(10, decimals);
  const formatted = Math.round(value * multiplier) / multiplier;
  return `${formatted}%`;
}

/**
 * Format a number with comma thousands separators
 * @param value Number to format
 * @returns Formatted number string with commas
 */
export function formatNumberWithCommas(value: number): string {
  if (isNaN(value)) return '0';
  return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

/**
 * Format a date to a readable string
 * @param date Date to format
 * @param includeTime Whether to include time in the formatted string
 * @returns Formatted date string
 */
export function formatDate(date: Date | string, includeTime: boolean = false): string {
  if (!date) return '';
  
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  
  if (includeTime) {
    return dateObj.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  }
  
  return dateObj.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric'
  });
}

/**
 * Format a number to a compact representation (e.g., 1.2K, 5.3M)
 * @param value Number to format
 * @param decimals Number of decimal places (default: 1)
 * @returns Formatted compact number string
 */
export function formatCompactNumber(value: number, decimals: number = 1): string {
  if (isNaN(value)) return '0';
  
  const suffixes = ['', 'K', 'M', 'B', 'T'];
  const suffixIndex = Math.floor(Math.log10(Math.abs(value)) / 3);
  
  if (suffixIndex === 0) return value.toString();
  
  const shortValue = value / Math.pow(10, suffixIndex * 3);
  const multiplier = Math.pow(10, decimals);
  const formatted = Math.round(shortValue * multiplier) / multiplier;
  
  return `${formatted}${suffixes[suffixIndex]}`;
}