import type { MetricTooltipContentProps } from '@/components/analytics/MetricTooltipContent';

// Mapping of metric names to their tooltip content
type MetricTooltipMap = Record<string, MetricTooltipContentProps>;

// Website-specific tooltip content
type WebsiteTooltipMap = Record<string, MetricTooltipMap>;

// Default tooltips for common metrics
const commonTooltips: MetricTooltipMap = {
  pageViews: {
    title: 'Page Views',
    description: 'The total number of pages viewed by users. Repeated views of a single page are counted.',
    impact: 'neutral',
    recommendations: [
      'Try adding more internal links to encourage exploration',
      'Create compelling calls-to-action to increase engagement'
    ]
  },
  uniqueVisitors: {
    title: 'Unique Visitors',
    description: 'The number of distinct individuals who visited your site during a specified time period.',
    impact: 'neutral',
    recommendations: [
      'Share content on social media to reach new audiences',
      'Optimize for relevant keywords to attract more organic traffic'
    ]
  },
  bounceRate: {
    title: 'Bounce Rate',
    description: 'The percentage of visitors who navigate away after viewing only one page. A lower rate is generally better.',
    impact: 'negative',
    recommendations: [
      'Improve page load speed to reduce bounces',
      'Add related content suggestions to keep users engaged',
      'Ensure mobile responsiveness for all devices'
    ]
  },
  avgSessionDuration: {
    title: 'Average Session Duration',
    description: 'The average length of time users spend on your site per session. Longer is typically better.',
    impact: 'positive',
    recommendations: [
      'Create more engaging, in-depth content',
      'Use interactive elements to keep users engaged',
      'Implement a content recommendation engine'
    ]
  },
  conversionRate: {
    title: 'Conversion Rate',
    description: 'The percentage of visitors who complete a desired action (purchase, signup, etc.). Higher is better.',
    impact: 'positive',
    recommendations: [
      'A/B test your call-to-action buttons',
      'Simplify your checkout or signup process',
      'Add testimonials to build trust'
    ]
  }
};

// Amazon-specific tooltips
const amazonTooltips: MetricTooltipMap = {
  pageViews: {
    title: 'Product Page Views',
    description: 'The total number of product pages viewed by shoppers. Higher numbers indicate strong product discovery.',
    impact: 'neutral',
    dataSource: 'Amazon Analytics',
    recommendations: [
      'Improve product title and images to increase click-through',
      'Optimize product categories for better discoverability'
    ]
  },
  conversionRate: {
    title: 'Purchase Conversion Rate',
    description: 'The percentage of visitors who make a purchase. Amazon average is ~12-15%.',
    impact: 'positive',
    dataSource: 'Amazon Analytics',
    recommendations: [
      'Enhance product descriptions with specific details',
      'Add more high-quality product images',
      'Respond promptly to customer questions'
    ]
  },
  avgSessionDuration: {
    title: 'Browsing Duration',
    description: 'How long shoppers spend browsing products on average. Longer sessions often lead to more purchases.',
    impact: 'positive',
    dataSource: 'Amazon Analytics',
    recommendations: [
      'Use enhanced brand content to tell your story',
      'Create product comparison tables',
      'Add detailed product specifications'
    ]
  }
};

// YouTube-specific tooltips
const youtubeTooltips: MetricTooltipMap = {
  pageViews: {
    title: 'Video Views',
    description: 'The total number of times your videos have been viewed. Includes repeat views.',
    impact: 'neutral',
    dataSource: 'YouTube Analytics',
    recommendations: [
      'Create compelling thumbnails that stand out',
      'Optimize video titles with relevant keywords',
      'Post consistently to build audience expectations'
    ]
  },
  bounceRate: {
    title: 'Audience Retention',
    description: 'The inverse of bounce rate - how well you retain viewers throughout your videos.',
    impact: 'positive',
    dataSource: 'YouTube Analytics',
    recommendations: [
      'Create a strong hook in the first 15 seconds',
      'Use pattern interrupts to maintain interest',
      'Keep videos concise and to the point'
    ]
  },
  avgSessionDuration: {
    title: 'Average Watch Time',
    description: 'The average amount of time viewers spend watching your videos. Critical for YouTube\'s algorithm.',
    impact: 'positive',
    dataSource: 'YouTube Analytics',
    recommendations: [
      'Create longer, high-value content',
      'Use end screens to promote related videos',
      'Create playlists to encourage binge-watching'
    ]
  }
};

// Netflix-specific tooltips
const netflixTooltips: MetricTooltipMap = {
  pageViews: {
    title: 'Title Views',
    description: 'The number of content title pages viewed by subscribers. Indicates browsing activity.',
    impact: 'neutral',
    dataSource: 'Netflix Analytics',
    recommendations: [
      'Optimize title artwork to increase clicks',
      'Improve synopsis writing to highlight key appeals',
      'Add more relevant tags for better recommendations'
    ]
  },
  uniqueVisitors: {
    title: 'Unique Subscribers',
    description: 'The number of individual subscriber accounts that accessed content.',
    impact: 'neutral',
    dataSource: 'Netflix Analytics',
    recommendations: [
      'Create content for underserved audience segments',
      'Promote new releases to less active subscribers',
      'Analyze viewing patterns to identify subscriber preferences'
    ]
  },
  avgSessionDuration: {
    title: 'Viewing Duration',
    description: 'How long subscribers spend watching content in a single session. Longer is better.',
    impact: 'positive',
    dataSource: 'Netflix Analytics',
    recommendations: [
      'Create binge-worthy series with compelling cliffhangers',
      'Optimize auto-play features for seamless viewing',
      'Improve content recommendation algorithms'
    ]
  }
};

// Instagram-specific tooltips
const instagramTooltips: MetricTooltipMap = {
  pageViews: {
    title: 'Profile Views',
    description: 'The number of times users viewed your Instagram profile.',
    impact: 'neutral',
    dataSource: 'Instagram Insights',
    recommendations: [
      'Optimize your bio with clear value proposition',
      'Pin top-performing content to your profile',
      'Use relevant hashtags to increase discoverability'
    ]
  },
  bounceRate: {
    title: 'Engagement Rate',
    description: 'The percentage of viewers who engage with your content (likes, comments, saves, shares).',
    impact: 'positive',
    dataSource: 'Instagram Insights',
    recommendations: [
      'Ask questions in captions to encourage comments',
      'Create shareable content like infographics or quotes',
      'Respond to comments to boost algorithm visibility'
    ]
  },
  avgSessionDuration: {
    title: 'Average Time Spent',
    description: 'The average time users spend engaging with your content.',
    impact: 'positive',
    dataSource: 'Instagram Insights',
    recommendations: [
      'Create carousel posts to increase dwell time',
      'Write longer, value-packed captions',
      'Post engaging reels and videos'
    ]
  }
};

// Map of website-specific tooltips
export const websiteTooltips: WebsiteTooltipMap = {
  'amazon': amazonTooltips,
  'youtube': youtubeTooltips,
  'netflix': netflixTooltips,
  'instagram': instagramTooltips,
  // Add other websites as needed
};

/**
 * Get tooltip content for a metric
 * @param metricName The name of the metric
 * @param websiteName The name of the website (optional)
 * @returns The tooltip content for the metric
 */
export function getMetricTooltipContent(metricName: string, websiteName?: string): MetricTooltipContentProps {
  // If website name is provided, try to get website-specific tooltip
  if (websiteName && websiteTooltips[websiteName.toLowerCase()]) {
    const websiteSpecificTooltip = websiteTooltips[websiteName.toLowerCase()][metricName];
    if (websiteSpecificTooltip) {
      return websiteSpecificTooltip;
    }
  }
  
  // Fallback to common tooltips
  return commonTooltips[metricName] || {
    title: metricName,
    description: `Information about ${metricName}`,
    impact: 'neutral'
  };
}