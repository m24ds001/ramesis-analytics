// Mock data generators for charts
import { subDays, format } from 'date-fns';

/**
 * Generate daily user activity data for the last N days
 * @param days Number of days to generate data for
 * @param websiteId Optional website ID to customize data
 * @param websiteName Optional website name to customize data
 * @param dateRange Optional date range for data variation
 */
export function generateUserActivityData(days = 7, websiteId?: number | null, websiteName?: string, dateRange = 'last7days') {
  const data = [];
  
  // Website-specific multipliers to make each website unique
  const websiteMultipliers: Record<string, number> = {
    'Amazon': 2.4,
    'Flipkart': 1.8,
    'YouTube': 3.2,
    'Netflix': 2.1,
    'Myntra': 1.5,
    'Instagram': 2.7,
    'Twitter': 2.0,
    'Walmart': 1.9,
    'Shopify': 1.6,
    'Airbnb': 1.7
  };
  
  // Different base values for different date ranges
  const baseValues: Record<string, { pageViews: number, visitors: number }> = {
    'last7days': { pageViews: 10000, visitors: 5000 },
    'last30days': { pageViews: 8500, visitors: 4200 },
    'last90days': { pageViews: 7000, visitors: 3500 },
    'thismonth': { pageViews: 9000, visitors: 4500 },
    'lastmonth': { pageViews: 8000, visitors: 4000 },
    'custom': { pageViews: 8800, visitors: 4400 }
  };
  
  // Normalize the date range (case-insensitive)
  const normalizedDateRange = dateRange.toLowerCase();
  console.log(`[chartUtils] Using normalized date range: ${normalizedDateRange} (original: ${dateRange})`);
  
  // Get the base values for the selected date range
  const baseValue = baseValues[normalizedDateRange] || baseValues.last7days;
  
  // Apply website-specific multiplier if a website is selected
  let multiplier = 1;
  if (websiteId && websiteName && websiteMultipliers[websiteName]) {
    multiplier = websiteMultipliers[websiteName];
  }
  
  for (let i = days - 1; i >= 0; i--) {
    const date = subDays(new Date(), i);
    // Add some day-to-day variation
    const dayVariation = 0.7 + (Math.random() * 0.6); // 0.7 to 1.3
    
    data.push({
      date: format(date, 'MMM dd'),
      pageViews: Math.floor((baseValue.pageViews * multiplier * dayVariation) + (Math.random() * 2000)),
      uniqueVisitors: Math.floor((baseValue.visitors * multiplier * dayVariation) + (Math.random() * 1000)),
      avgTimeOnPage: Math.floor((60 + (30 * multiplier * dayVariation)) + (Math.random() * 60)), // seconds
    });
  }
  return data;
}

/**
 * Generate hourly user activity data for the last N hours
 * @param hours Number of hours to generate data for
 * @param websiteId Optional website ID to customize data
 * @param websiteName Optional website name to customize data
 * @param dateRange Optional date range for data variation
 */
export function generateHourlyUserActivityData(hours = 24, websiteId?: number | null, websiteName?: string, dateRange = 'last7days') {
  const data = [];
  const now = new Date();
  
  // Website-specific multipliers to make each website unique
  const websiteMultipliers: Record<string, number> = {
    'Amazon': 2.4,
    'Flipkart': 1.8,
    'YouTube': 3.2,
    'Netflix': 2.1,
    'Myntra': 1.5,
    'Instagram': 2.7,
    'Twitter': 2.0,
    'Walmart': 1.9,
    'Shopify': 1.6,
    'Airbnb': 1.7
  };
  
  // Different base values for different date ranges
  const baseValues: Record<string, { pageViews: number, visitors: number }> = {
    'last7days': { pageViews: 350, visitors: 175 },
    'last30days': { pageViews: 280, visitors: 140 },
    'last90days': { pageViews: 240, visitors: 120 },
    'thismonth': { pageViews: 320, visitors: 160 },
    'lastmonth': { pageViews: 300, visitors: 150 },
    'custom': { pageViews: 330, visitors: 165 }
  };
  
  // Get the base values for the selected date range
  const baseValue = baseValues[dateRange] || baseValues.last7days;
  
  // Apply website-specific multiplier if a website is selected
  let multiplier = 1;
  if (websiteId && websiteName && websiteMultipliers[websiteName]) {
    multiplier = websiteMultipliers[websiteName];
  }
  
  for (let i = hours - 1; i >= 0; i--) {
    const hour = new Date(now);
    hour.setHours(now.getHours() - i);
    
    // Add time-of-day patterns
    // More traffic during working hours (9am-5pm)
    const hourOfDay = hour.getHours();
    let timeOfDayFactor = 1.0;
    if (hourOfDay >= 9 && hourOfDay <= 17) {
      timeOfDayFactor = 1.5; // 50% more traffic during working hours
    } else if (hourOfDay >= 0 && hourOfDay <= 5) {
      timeOfDayFactor = 0.5; // 50% less traffic in early morning
    }
    
    // Add some hour-to-hour variation
    const hourVariation = 0.7 + (Math.random() * 0.6); // 0.7 to 1.3
    
    data.push({
      hour: format(hour, 'HH:mm'),
      pageViews: Math.floor((baseValue.pageViews * multiplier * timeOfDayFactor * hourVariation) + (Math.random() * 100)),
      uniqueVisitors: Math.floor((baseValue.visitors * multiplier * timeOfDayFactor * hourVariation) + (Math.random() * 50)),
      avgTimeOnPage: Math.floor((60 + (15 * multiplier * hourVariation)) + (Math.random() * 30)), // seconds
    });
  }
  return data;
}

/**
 * Generate weekly user activity data for the last N weeks
 * @param weeks Number of weeks to generate data for
 * @param websiteId Optional website ID to customize data
 * @param websiteName Optional website name to customize data 
 * @param dateRange Optional date range for data variation
 */
export function generateWeeklyUserActivityData(weeks = 4, websiteId?: number | null, websiteName?: string, dateRange = 'last7days') {
  const data = [];
  
  // Website-specific multipliers to make each website unique
  const websiteMultipliers: Record<string, number> = {
    'Amazon': 2.4,
    'Flipkart': 1.8,
    'YouTube': 3.2,
    'Netflix': 2.1,
    'Myntra': 1.5,
    'Instagram': 2.7,
    'Twitter': 2.0,
    'Walmart': 1.9,
    'Shopify': 1.6,
    'Airbnb': 1.7
  };
  
  // Different base values for different date ranges
  const baseValues: Record<string, { pageViews: number, visitors: number }> = {
    'last7days': { pageViews: 50000, visitors: 25000 },
    'last30days': { pageViews: 42500, visitors: 21000 },
    'last90days': { pageViews: 35000, visitors: 17500 },
    'thismonth': { pageViews: 45000, visitors: 22500 },
    'lastmonth': { pageViews: 40000, visitors: 20000 },
    'custom': { pageViews: 44000, visitors: 22000 }
  };
  
  // Get the base values for the selected date range
  const baseValue = baseValues[dateRange] || baseValues.last7days;
  
  // Apply website-specific multiplier if a website is selected
  let multiplier = 1;
  if (websiteId && websiteName && websiteMultipliers[websiteName]) {
    multiplier = websiteMultipliers[websiteName];
  }
  
  for (let i = weeks - 1; i >= 0; i--) {
    const date = subDays(new Date(), i * 7);
    // Add some week-to-week variation
    const weekVariation = 0.7 + (Math.random() * 0.6); // 0.7 to 1.3
    
    data.push({
      week: `Week ${weeks - i}`,
      date: format(date, 'MMM dd'),
      pageViews: Math.floor((baseValue.pageViews * multiplier * weekVariation) + (Math.random() * 10000)),
      uniqueVisitors: Math.floor((baseValue.visitors * multiplier * weekVariation) + (Math.random() * 5000)),
      avgTimeOnPage: Math.floor((60 + (30 * multiplier * weekVariation)) + (Math.random() * 60)), // seconds
    });
  }
  return data;
}

/**
 * Generate traffic sources data based on date range
 */
export function generateTrafficSourcesData(dateRange = 'last7days') {
  // Different traffic source distributions for different date ranges
  const dataByRange: Record<string, any[]> = {
    'last7days': [
      { name: 'Organic Search', value: 42.8 },
      { name: 'Direct', value: 25.1 },
      { name: 'Social Media', value: 15.7 },
      { name: 'Referral', value: 10.3 },
      { name: 'Paid Search', value: 6.1 },
    ],
    'last30days': [
      { name: 'Organic Search', value: 38.4 },
      { name: 'Direct', value: 22.7 },
      { name: 'Social Media', value: 19.5 },
      { name: 'Referral', value: 11.8 },
      { name: 'Paid Search', value: 7.6 },
    ],
    'last90days': [
      { name: 'Organic Search', value: 36.2 },
      { name: 'Direct', value: 20.5 },
      { name: 'Social Media', value: 22.1 },
      { name: 'Referral', value: 12.8 },
      { name: 'Paid Search', value: 8.4 },
    ],
    'thismonth': [
      { name: 'Organic Search', value: 40.3 },
      { name: 'Direct', value: 23.9 },
      { name: 'Social Media', value: 17.2 },
      { name: 'Referral', value: 11.1 },
      { name: 'Paid Search', value: 7.5 },
    ],
    'lastmonth': [
      { name: 'Organic Search', value: 39.5 },
      { name: 'Direct', value: 24.2 },
      { name: 'Social Media', value: 16.8 },
      { name: 'Referral', value: 11.5 },
      { name: 'Paid Search', value: 8.0 },
    ],
    'custom': [
      { name: 'Organic Search', value: 41.2 },
      { name: 'Direct', value: 24.8 },
      { name: 'Social Media', value: 16.5 },
      { name: 'Referral', value: 10.9 },
      { name: 'Paid Search', value: 6.6 },
    ]
  };
  
  return dataByRange[dateRange] || dataByRange.last7days;
}

/**
 * Generate color for traffic sources chart
 */
export function getTrafficSourceColor(name: string) {
  const colorMap: Record<string, string> = {
    'Organic Search': '#3B82F6', // primary-500
    'Direct': '#6366F1', // indigo-500 
    'Social Media': '#10B981', // green-500
    'Referral': '#F59E0B', // yellow-500
    'Paid Search': '#EF4444', // red-500
  };
  
  return colorMap[name] || '#CBD5E1'; // gray-300 as fallback
}

/**
 * Generate predictive analytics data based on date range
 */
export function generatePredictiveData(dateRange = 'last7days') {
  // Different predictive data for different date ranges
  const dataByRange: Record<string, any> = {
    'last7days': {
      conversionRate: {
        current: 3.2,
        predicted: 4.0,
        confidence: 0.75
      },
      bounceRate: {
        current: 42.5,
        predicted: 40.2,
        confidence: 0.65
      },
      revenueGrowth: {
        predicted: 12.4,
        confidence: 0.85
      }
    },
    'last30days': {
      conversionRate: {
        current: 3.8,
        predicted: 4.5,
        confidence: 0.82
      },
      bounceRate: {
        current: 39.2,
        predicted: 36.7,
        confidence: 0.78
      },
      revenueGrowth: {
        predicted: 18.6,
        confidence: 0.88
      }
    },
    'last90days': {
      conversionRate: {
        current: 4.1,
        predicted: 4.8,
        confidence: 0.89
      },
      bounceRate: {
        current: 35.6,
        predicted: 32.8,
        confidence: 0.84
      },
      revenueGrowth: {
        predicted: 25.2,
        confidence: 0.92
      }
    },
    'thismonth': {
      conversionRate: {
        current: 3.5,
        predicted: 4.2,
        confidence: 0.79
      },
      bounceRate: {
        current: 40.1,
        predicted: 38.4,
        confidence: 0.76
      },
      revenueGrowth: {
        predicted: 15.7,
        confidence: 0.86
      }
    },
    'lastmonth': {
      conversionRate: {
        current: 3.6,
        predicted: 4.3,
        confidence: 0.77
      },
      bounceRate: {
        current: 41.3,
        predicted: 39.6,
        confidence: 0.72
      },
      revenueGrowth: {
        predicted: 14.2,
        confidence: 0.82
      }
    },
    'custom': {
      conversionRate: {
        current: 3.4,
        predicted: 4.1,
        confidence: 0.71
      },
      bounceRate: {
        current: 41.8,
        predicted: 40.0,
        confidence: 0.68
      },
      revenueGrowth: {
        predicted: 13.5,
        confidence: 0.80
      }
    }
  };
  
  return dataByRange[dateRange] || dataByRange.last7days;
}

/**
 * Generate top performing pages data
 */
export function generateTopPagesData() {
  return [
    { page: '/home', views: 12482, conversion: 4.2, bounce: 32.5 },
    { page: '/features', views: 8743, conversion: 3.7, bounce: 40.1 },
    { page: '/pricing', views: 6291, conversion: 5.3, bounce: 28.7 },
    { page: '/blog/main', views: 4829, conversion: 2.1, bounce: 45.3 },
    { page: '/contact', views: 3142, conversion: 2.9, bounce: 38.6 },
  ];
}

/**
 * Generate analytics summary data for a website based on date range
 */
export function getAnalyticsSummaryForWebsite(websiteId?: number | null, websiteName?: string, dateRange = 'last7days') {
  // Base metrics for different date ranges
  const baseMetrics: Record<string, any> = {
    'last7days': {
      activeVisitors: 427,
      conversionRate: 3.2,
      conversionChange: 0.4,
      bounceRate: 42.5,
      bounceChange: -2.1,
      sessionDuration: 124,
      sessionChange: 5.2
    },
    'last30days': {
      activeVisitors: 1827,
      conversionRate: 3.8,
      conversionChange: 0.6,
      bounceRate: 39.2,
      bounceChange: -3.8,
      sessionDuration: 137,
      sessionChange: 7.9
    },
    'last90days': {
      activeVisitors: 5438,
      conversionRate: 4.1,
      conversionChange: 0.9,
      bounceRate: 35.6,
      bounceChange: -5.2,
      sessionDuration: 145,
      sessionChange: 12.3
    },
    'thismonth': {
      activeVisitors: 1245,
      conversionRate: 3.5,
      conversionChange: 0.5,
      bounceRate: 40.1,
      bounceChange: -3.0,
      sessionDuration: 132,
      sessionChange: 6.7
    },
    'lastmonth': {
      activeVisitors: 1586,
      conversionRate: 3.6,
      conversionChange: 0.4,
      bounceRate: 41.3,
      bounceChange: -2.5,
      sessionDuration: 128,
      sessionChange: 5.9
    },
    'custom': {
      activeVisitors: 872,
      conversionRate: 3.4,
      conversionChange: 0.3,
      bounceRate: 41.8,
      bounceChange: -2.3,
      sessionDuration: 126,
      sessionChange: 4.8
    }
  };
  
  // Website-specific multipliers to make each website unique
  const websiteMultipliers: Record<string, number> = {
    'Amazon': 2.4,
    'Flipkart': 1.8,
    'YouTube': 3.2,
    'Netflix': 2.1,
    'Myntra': 1.5,
    'Instagram': 2.7,
    'Twitter': 2.0,
    'Walmart': 1.9,
    'Shopify': 1.6,
    'Airbnb': 1.7
  };
  
  // Get the base metrics for the selected date range
  const metrics = baseMetrics[dateRange] || baseMetrics.last7days;
  
  // Apply website-specific multipliers if a website is selected
  if (websiteId && websiteName && websiteMultipliers[websiteName]) {
    const multiplier = websiteMultipliers[websiteName];
    return {
      ...metrics,
      activeVisitors: Math.round(metrics.activeVisitors * multiplier),
      conversionRate: +(metrics.conversionRate * (0.8 + (multiplier * 0.1))).toFixed(1),
      sessionDuration: Math.round(metrics.sessionDuration * (0.9 + (multiplier * 0.05)))
    };
  }
  
  return metrics;
}
