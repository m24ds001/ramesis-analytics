/**
 * Export data utilities
 */

/**
 * Export data in the specified format
 * @param dataType The type of data to export
 * @param format The format to export the data in
 * @param dateRange The date range for the data
 * @param filters Any additional filters to apply
 */
export async function exportData(
  dataType: string,
  format: 'json' | 'csv' | 'pdf',
  dateRange?: string,
  filters?: Record<string, any>
) {
  try {
    // For website analysis, use the new working endpoint
    if (dataType === 'website-analysis') {
      const response = await fetch('/api/export-website-report', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          website: filters?.website || 'google.com',
          websiteName: filters?.websiteName || 'Google',
          dateRange: dateRange || 'last7days'
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to generate report');
      }

      const reportData = await response.json();
      
      // Create and download the file
      const blob = new Blob([JSON.stringify(reportData, null, 2)], { 
        type: 'application/json' 
      });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${filters?.website || 'website'}-report-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
      
      return true;
    }
    
    // For other data types, use the original form approach
    const form = document.createElement('form');
    form.method = 'POST';
    form.action = '/api/export';
    form.target = '_blank';
    
    // Create input fields for each parameter
    const dataTypeInput = document.createElement('input');
    dataTypeInput.type = 'hidden';
    dataTypeInput.name = 'dataType';
    dataTypeInput.value = dataType;
    form.appendChild(dataTypeInput);
    
    const formatInput = document.createElement('input');
    formatInput.type = 'hidden';
    formatInput.name = 'format';
    formatInput.value = format;
    form.appendChild(formatInput);
    
    if (dateRange) {
      const dateRangeInput = document.createElement('input');
      dateRangeInput.type = 'hidden';
      dateRangeInput.name = 'dateRange';
      dateRangeInput.value = dateRange;
      form.appendChild(dateRangeInput);
    }
    
    if (filters) {
      const filtersInput = document.createElement('input');
      filtersInput.type = 'hidden';
      filtersInput.name = 'filters';
      filtersInput.value = JSON.stringify(filters);
      form.appendChild(filtersInput);
    }
    
    // Add the form to the body, submit it, and then remove it
    document.body.appendChild(form);
    form.submit();
    document.body.removeChild(form);
    
    return true;
  } catch (error) {
    console.error('Error exporting data:', error);
    return false;
  }
}

/**
 * Export user behavior data
 * @param format The format to export the data in
 * @param dateRange The date range for the data
 */
export function exportUserBehavior(
  format: 'json' | 'csv' | 'pdf' = 'csv',
  dateRange: string = 'last30days'
) {
  return exportData('events', format, dateRange, { type: 'behavior' });
}

/**
 * Export analytics reports
 * @param reportType The type of report to export
 * @param format The format to export the data in
 * @param dateRange The date range for the data
 * @param filters Additional filters for the report
 */
export function exportReport(
  reportType: string,
  format: 'pdf' | 'csv' | 'json' = 'pdf',
  dateRange: string = 'last30days',
  filters?: Record<string, any>
) {
  return exportData(reportType, format, dateRange, filters);
}