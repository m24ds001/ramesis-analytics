// Define the gtag function globally
declare global {
  interface Window {
    dataLayer: any[];
    gtag: (...args: any[]) => void;
  }
}

// Initialize Google Analytics
export const initGA = () => {
  const measurementId = import.meta.env.VITE_GA_MEASUREMENT_ID;

  if (!measurementId) {
    console.warn('Missing required Google Analytics key: VITE_GA_MEASUREMENT_ID');
    return;
  }

  // Validate measurement ID format to prevent XSS
  const validMeasurementIdPattern = /^G-[A-Z0-9]{10}$/;
  if (!validMeasurementIdPattern.test(measurementId)) {
    console.error('Invalid Google Analytics measurement ID format');
    return;
  }

  // Add Google Analytics script to the head
  const script1 = document.createElement('script');
  script1.async = true;
  script1.src = `https://www.googletagmanager.com/gtag/js?id=${measurementId}`;
  document.head.appendChild(script1);

  // Initialize gtag using safe DOM manipulation instead of innerHTML
  const script2 = document.createElement('script');
  script2.textContent = `
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    gtag('config', '${measurementId}');
  `;
  document.head.appendChild(script2);
};

// Track page views - useful for single-page applications
export const trackPageView = (url: string) => {
  if (typeof window === 'undefined' || !window.gtag) return;
  
  const measurementId = import.meta.env.VITE_GA_MEASUREMENT_ID;
  if (!measurementId) return;
  
  window.gtag('config', measurementId, {
    page_path: url
  });
};

// Track events
export const trackEvent = (
  action: string, 
  category?: string, 
  label?: string, 
  value?: number
) => {
  if (typeof window === 'undefined' || !window.gtag) return;
  
  window.gtag('event', action, {
    event_category: category,
    event_label: label,
    value: value,
  });
};

// Get analytics summary data from the GA4 API
export const getAnalyticsSummary = async (websiteId?: number | null) => {
  try {
    const measurementId = import.meta.env.VITE_GA_MEASUREMENT_ID;
    if (!measurementId) {
      throw new Error('Missing GA Measurement ID');
    }
    
    // Create body with optional website ID
    const body: any = { measurementId };
    if (websiteId) {
      body.websiteId = websiteId;
    }
    
    // Call our server GA4 endpoint
    const response = await fetch('/api/ga4-data', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(body),
    });
    
    if (!response.ok) {
      throw new Error(`GA4 API returned ${response.status}`);
    }
    
    const data = await response.json();
    
    // Format the data for the UI
    return {
      activeVisitors: data.activeUsers || 0,
      bounceRate: {
        value: `${data.bounceRate?.toFixed(1) || 0.0}%`,
        change: `${data.bounceRateChange?.toFixed(1) || 0.0}%`
      },
      conversionRate: {
        value: `${data.conversionRate?.toFixed(1) || 0.0}%`,
        change: `${data.conversionRateChange?.toFixed(1) || 0.0}%`
      },
      avgSession: {
        value: formatDuration(data.averageSessionDuration || 0),
        change: `${data.sessionDurationChange?.toFixed(1) || 0.0}%`
      }
    };
  } catch (error) {
    console.error('Error fetching analytics summary:', error);
    
    // Return an empty data structure with explicit error message
    // This will inform the user that real analytics data cannot be loaded
    return {
      activeVisitors: 0,
      bounceRate: {
        value: 'Error',
        change: 'N/A'
      },
      conversionRate: {
        value: 'Error',
        change: 'N/A'
      },
      avgSession: {
        value: 'Error',
        change: 'N/A'
      },
      isError: true,
      errorMessage: 'Unable to fetch real-time analytics data. Please check your connection and API credentials.'
    };
  }
};

// Helper function to format duration in seconds to mm:ss
function formatDuration(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
}

// A/B Testing functions
export const getAbTests = async () => {
  try {
    const response = await fetch('/api/abtests');
    if (!response.ok) {
      throw new Error(`Error fetching A/B tests: ${response.statusText}`);
    }
    return await response.json();
  } catch (error) {
    console.error('Error fetching A/B tests:', error);
    return [];
  }
};

export const createAbTest = async (testData: any) => {
  try {
    const response = await fetch('/api/abtests', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(testData),
    });
    
    if (!response.ok) {
      throw new Error(`Error creating A/B test: ${response.statusText}`);
    }
    
    return await response.json();
  } catch (error) {
    console.error('Error creating A/B test:', error);
    throw error;
  }
};

// Fetch AI-generated insights based on analytics data
export const getInsights = async () => {
  try {
    const response = await fetch('/api/insights');
    if (!response.ok) {
      throw new Error(`Error fetching insights: ${response.statusText}`);
    }
    return await response.json();
  } catch (error) {
    console.error('Error fetching insights:', error);
    return [];
  }
};