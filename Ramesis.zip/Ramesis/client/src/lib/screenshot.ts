import html2canvas from 'html2canvas';
import { trackEvent } from './analytics';

/**
 * Export a DOM element as a screenshot
 * @param elementId The ID of the element to capture
 * @param fileName The name of the downloaded file (without extension)
 * @param reportType The type of report being exported (for analytics tracking)
 */
export const exportElementAsScreenshot = async (
  elementId: string, 
  fileName: string = 'analytics-report',
  reportType: string = 'general'
): Promise<boolean> => {
  try {
    // Get the element to capture
    const element = document.getElementById(elementId);
    
    if (!element) {
      console.error(`Element with ID '${elementId}' not found`);
      return false;
    }
    
    // Track the export attempt
    trackEvent('export_screenshot_started', 'export', reportType);
    
    // Capture the element as a canvas
    const canvas = await html2canvas(element, {
      scale: 2, // Increase quality by scaling up 2x
      useCORS: true, // Allow images from other domains
      logging: false,
      backgroundColor: '#ffffff', // Ensure white background
      allowTaint: true, // Allow potential tainted canvas with cross-origin content
    });
    
    // Convert canvas to blob
    const blob = await new Promise<Blob | null>((resolve) => {
      canvas.toBlob(
        (blob) => resolve(blob),
        'image/png',
        1.0 // Quality
      );
    });
    
    if (!blob) {
      console.error('Failed to convert canvas to blob');
      trackEvent('export_screenshot_error', 'export', 'blob_conversion_failed');
      return false;
    }
    
    // Create download link
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.download = `${fileName}-${new Date().toISOString().split('T')[0]}.png`;
    link.href = url;
    link.click();
    
    // Clean up
    URL.revokeObjectURL(url);
    
    // Track successful export
    trackEvent('export_screenshot_complete', 'export', reportType);
    
    return true;
  } catch (error) {
    console.error('Error exporting screenshot:', error);
    trackEvent('export_screenshot_error', 'export', String(error));
    return false;
  }
};