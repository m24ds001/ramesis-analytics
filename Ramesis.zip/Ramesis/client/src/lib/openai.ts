import { apiRequest } from "./queryClient";

// This is a client-side wrapper for server-side OpenAI operations
// The actual OpenAI API calls are handled on the server

// We're not using the OpenAI client directly on the frontend
// Instead, we're using our backend API proxy for all OpenAI operations

/**
 * Generate AI insights based on analytics data
 */
export async function generateInsights(analyticsData: any) {
  try {
    const response = await apiRequest('POST', '/api/insights/generate', {
      analyticsData
    });
    return await response.json();
  } catch (error) {
    console.error('Error generating insights:', error);
    throw new Error('Failed to generate AI insights');
  }
}

/**
 * Generate recommendations based on analytics data and insights
 */
export async function generateRecommendations(analyticsData: any, insights: any) {
  try {
    const response = await apiRequest('POST', '/api/recommendations/generate', {
      analyticsData,
      insights
    });
    return await response.json();
  } catch (error) {
    console.error('Error generating recommendations:', error);
    throw new Error('Failed to generate recommendations');
  }
}

/**
 * Analytics data for pattern analysis - uses OpenAI for real pattern detection
 */
export async function analyzePatterns(data: any) {
  try {
    // Call our server endpoint to analyze patterns with OpenAI
    const response = await apiRequest('POST', '/api/patterns/analyze', {
      analyticsData: data
    });
    
    // Return the response as pattern analysis
    return await response.json();
  } catch (error) {
    console.error('Error analyzing patterns:', error);
    // Return empty patterns array instead of fake data
    return {
      patterns: [],
      error: 'Failed to analyze patterns'
    };
  }
}

/**
 * Predict future metrics based on historical data using OpenAI's predictive capabilities
 */
export async function predictMetrics(historicalData: any) {
  try {
    // Call our server endpoint for metric predictions with GPT-4o
    const response = await apiRequest('POST', '/api/metrics/predict', {
      historicalData
    });
    
    // Return the response with predictions
    return await response.json();
  } catch (error) {
    console.error('Error predicting metrics:', error);
    // Return empty predictions instead of fake data
    return {
      predictions: {},
      error: 'Failed to predict metrics'
    };
  }
}
