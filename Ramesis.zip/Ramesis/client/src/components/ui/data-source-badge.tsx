import React, { useState, useEffect } from 'react';
import { Badge } from '@/components/ui/badge';
import { Info, Loader2, BarChart3, Globe, Database, PieChart } from 'lucide-react';
import { cn } from '@/lib/utils';

// Define provider types for better type safety
export type ProviderType = 
  | 'google' 
  | 'adobe' 
  | 'mixpanel'
  | 'amplitude'
  | 'segment'
  | 'matomo'
  | 'real-time-tracking'
  | 'real-time-analytics'
  | 'hotjar'
  | 'crazy-egg';

// Add icon configuration map - using Lucide icons as a fallback
// In a real implementation you would import custom SVG icons
const PROVIDER_ICONS: Record<string, React.ComponentType> = {
  'google': () => <Globe className="h-3 w-3" aria-label="Google data source" role="img" />,
  'google analytics': () => <BarChart3 className="h-3 w-3" aria-label="Google Analytics data source" role="img" />,
  'adobe': () => <PieChart className="h-3 w-3" aria-label="Adobe data source" role="img" />,
  'adobe analytics': () => <PieChart className="h-3 w-3" aria-label="Adobe Analytics data source" role="img" />,
  'mixpanel': () => <BarChart3 className="h-3 w-3" aria-label="Mixpanel data source" role="img" />,
  'amplitude': () => <BarChart3 className="h-3 w-3" aria-label="Amplitude data source" role="img" />,
  'segment': () => <Database className="h-3 w-3" aria-label="Segment data source" role="img" />,
  'matomo': () => <Globe className="h-3 w-3" aria-label="Matomo data source" role="img" />,
  'real-time-tracking': () => <BarChart3 className="h-3 w-3" aria-label="Real-time tracking data source" role="img" />,
  'real-time-analytics': () => <BarChart3 className="h-3 w-3" aria-label="Real-time analytics data source" role="img" />,
  'hotjar': () => <PieChart className="h-3 w-3" aria-label="Hotjar data source" role="img" />,
  'crazy-egg': () => <BarChart3 className="h-3 w-3" aria-label="Crazy Egg data source" role="img" />,
};

// Create an icon loader service for dynamic loading
export class IconService {
  private static iconCache = new Map<string, React.ComponentType>();
  
  /**
   * Get provider icon synchronously (for components that don't need to handle loading states)
   * @param provider The provider name or type
   * @returns A React component representing the icon
   */
  static getProviderIcon(provider: string): React.ComponentType {
    if (!provider) return () => <Info aria-label="Unknown source" role="img" className="h-3 w-3" />;
    
    const normalizedName = provider.toLowerCase();
    return PROVIDER_ICONS[normalizedName] || 
      (() => <Info aria-label="Unknown source" role="img" className="h-3 w-3" />);
  }
  
  /**
   * Asynchronously load an icon for a provider with caching
   * @param providerName The provider name or type 
   * @returns A React component representing the icon
   */
  static async loadIcon(providerName: string) {
    if (!providerName) return () => <Info aria-label="No provider specified" role="img" className="h-3 w-3" />;
    
    const normalizedName = providerName.toLowerCase();
    
    if (this.iconCache.has(normalizedName)) {
      return this.iconCache.get(normalizedName)!;
    }
    
    try {
      // In a real implementation, this would load from your assets directory
      // For now, we're just using the static mapping above
      const IconComponent = PROVIDER_ICONS[normalizedName] 
        ? PROVIDER_ICONS[normalizedName] 
        : () => <Info aria-label={`${providerName} data source`} role="img" className="h-3 w-3" />;
      
      this.iconCache.set(normalizedName, IconComponent);
      return IconComponent;
    } catch (error) {
      console.error(`Failed to load icon for ${providerName}:`, error);
      const FallbackIcon = () => <Info aria-label="Error loading icon" role="img" className="h-3 w-3" />;
      return FallbackIcon;
    }
  }
}

interface DataSourceBadgeProps {
  sourceName: string;
  providerName?: string;
  providerType?: ProviderType | keyof typeof PROVIDER_ICONS;
  className?: string;
  icon?: React.ComponentType; // Optional prop for custom icon
}

export function DataSourceBadge({ 
  sourceName,
  providerName,
  providerType,
  icon: CustomIcon,
  className = ''
}: DataSourceBadgeProps) {
  const [Icon, setIcon] = useState<React.ComponentType | null>(CustomIcon || null);
  const [isLoading, setIsLoading] = useState(!CustomIcon);
  
  useEffect(() => {
    const loadIcon = async () => {
      if (!CustomIcon) {
        setIsLoading(true);
        try {
          // If providerType is explicitly specified, use it
          // Otherwise try provider name and fallback to source name
          const iconKey = providerType || providerName || sourceName;
          const icon = await IconService.loadIcon(iconKey);
          setIcon(() => icon);
        } catch (error) {
          console.error('Failed to load icon:', error);
          setIcon(() => Info);
        } finally {
          setIsLoading(false);
        }
      }
    };

    loadIcon();
  }, [CustomIcon, providerType, providerName, sourceName]);

  return (
    <div className={cn(
      "absolute top-0 right-0 z-10 flex items-center bg-gradient-to-l from-primary-600 to-primary-700 text-white text-xs px-2 py-1 rounded-bl-md",
      className
    )}>
      <span className="mr-1">
        {isLoading ? (
          <Loader2 className="h-3 w-3 animate-spin" aria-label="Loading icon" />
        ) : Icon ? (
          <Icon aria-label={`${sourceName} icon`} />
        ) : (
          <Info className="h-3 w-3" aria-label="Info icon" />
        )}
      </span>
      {sourceName}
      {providerName && (
        <span className="ml-1 opacity-80">({providerName})</span>
      )}
    </div>
  );
}

interface DataSourceHeaderProps {
  sourceName: string;
  providerType?: keyof typeof PROVIDER_ICONS;
  className?: string;
}

export function DataSourceHeader({ 
  sourceName,
  providerType,
  className = ''
}: DataSourceHeaderProps) {
  const [Icon, setIcon] = useState<React.ComponentType>(() => Info);

  useEffect(() => {
    const loadIcon = async () => {
      try {
        // If providerType is specified, use it; otherwise fall back to sourceName
        const iconKey = providerType || sourceName;
        const icon = await IconService.loadIcon(iconKey);
        setIcon(() => icon);
      } catch (error) {
        console.error('Failed to load icon:', error);
        setIcon(() => Info);
      }
    };
    
    loadIcon();
  }, [providerType, sourceName]);

  return (
    <div className={cn(
      "flex items-center mb-4 bg-gradient-to-r from-primary-50 to-transparent p-3 rounded-md border border-primary-100",
      className
    )}>
      <Icon 
        className="h-5 w-5 text-primary-600 mr-2" 
        aria-label={`${sourceName} data source`}
      />
      <span className="text-sm font-medium text-gray-700">
        Data source:
      </span>
      <Badge variant="outline" className="ml-2 bg-primary-100 text-primary-700 border-primary-200 font-bold">
        {sourceName}
      </Badge>
    </div>
  );
}