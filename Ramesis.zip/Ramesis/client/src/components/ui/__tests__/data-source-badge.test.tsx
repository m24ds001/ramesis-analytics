import React from 'react';
import { render, screen, waitFor } from '@testing-library/react';
import { DataSourceBadge, DataSourceHeader, IconService } from '../data-source-badge';
import { Info } from 'lucide-react';

// Mock the IconService
jest.mock('../data-source-badge', () => {
  const original = jest.requireActual('../data-source-badge');
  return {
    ...original,
    IconService: {
      loadIcon: jest.fn().mockImplementation(async (name) => {
        if (name === 'google') {
          return () => <div data-testid="google-icon" />;
        }
        return original.Info;
      })
    }
  };
});

describe('DataSourceBadge', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('renders with correct source name', () => {
    render(<DataSourceBadge sourceName="Test Source" />);
    expect(screen.getByText('Test Source')).toBeInTheDocument();
  });

  it('renders with provider name when provided', () => {
    render(<DataSourceBadge sourceName="Test Source" providerName="Google Analytics" />);
    expect(screen.getByText('Test Source')).toBeInTheDocument();
    expect(screen.getByText('(Google Analytics)')).toBeInTheDocument();
  });

  it('uses custom icon when provided', () => {
    const CustomIcon = () => <div data-testid="custom-icon">Custom</div>;
    render(<DataSourceBadge sourceName="Test" icon={CustomIcon} />);
    expect(screen.getByTestId('custom-icon')).toBeInTheDocument();
  });

  it('loads icon from IconService when no custom icon is provided', async () => {
    render(<DataSourceBadge sourceName="google" />);
    
    // Initially shows loading state
    expect(screen.getByLabelText('Loading icon')).toBeInTheDocument();
    
    // Wait for icon to load
    await waitFor(() => {
      expect(IconService.loadIcon).toHaveBeenCalledWith('google');
    });
  });

  it('displays Info icon as fallback if icon loading fails', async () => {
    // Mock a failed icon load
    (IconService.loadIcon as jest.Mock).mockRejectedValueOnce(new Error('Failed to load'));
    
    render(<DataSourceBadge sourceName="unknown-source" />);
    
    await waitFor(() => {
      expect(screen.getByLabelText('Info icon')).toBeInTheDocument();
    });
  });
});

describe('DataSourceHeader', () => {
  it('renders with correct source name', () => {
    render(<DataSourceHeader sourceName="Test Dashboard" />);
    expect(screen.getByText('Test Dashboard')).toBeInTheDocument();
  });

  it('uses providerType to determine icon', async () => {
    render(<DataSourceHeader sourceName="Dashboard" providerType="google" />);
    
    await waitFor(() => {
      expect(IconService.loadIcon).toHaveBeenCalledWith('google');
    });
  });

  it('has proper accessibility attributes', () => {
    render(<DataSourceHeader sourceName="Analytics" />);
    expect(screen.getByLabelText('Analytics data source')).toBeInTheDocument();
  });
});