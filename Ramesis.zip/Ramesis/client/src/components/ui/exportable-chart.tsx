import React, { useRef, useState } from 'react';
import { exportElementAsImage } from '@/lib/exportVisual';
import { Download, Share2, Check, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';

interface ExportableChartProps {
  children: React.ReactNode;
  title?: string;
  className?: string;
  fileName?: string;
  showShareButton?: boolean;
}

export function ExportableChart({
  children,
  title,
  className = '',
  fileName = 'chart',
  showShareButton = true,
}: ExportableChartProps) {
  const chartRef = useRef<HTMLDivElement>(null);
  const [isExporting, setIsExporting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  // Handle chart export
  const handleExport = async () => {
    if (!chartRef.current) return;
    
    try {
      setIsExporting(true);
      await exportElementAsImage(chartRef.current, {
        fileName,
        includeTimestamp: true,
      });
      
      // Show success message briefly
      setIsSuccess(true);
      setTimeout(() => setIsSuccess(false), 2000);
    } catch (error) {
      console.error('Failed to export chart:', error);
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className={`relative ${className}`}>
      {/* Export Button with Animation */}
      <AnimatePresence>
        <motion.div 
          className="absolute top-3 right-3 z-10 flex space-x-2"
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          <Button
            size="sm"
            variant="outline"
            className="bg-white/90 backdrop-blur-sm shadow-sm hover:bg-white transition-all"
            onClick={handleExport}
            disabled={isExporting}
          >
            {isExporting ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : isSuccess ? (
              <Check className="h-4 w-4 text-green-500" />
            ) : (
              <Download className="h-4 w-4" />
            )}
            <span className="ml-2">{isSuccess ? 'Saved!' : 'Export'}</span>
          </Button>
          
          {showShareButton && (
            <Button
              size="sm"
              variant="outline"
              className="bg-white/90 backdrop-blur-sm shadow-sm hover:bg-white transition-all"
              onClick={() => {
                // Implementation for sharing would go here
                // Could use Web Share API or copy to clipboard
                if (navigator.share) {
                  navigator.share({
                    title: title || 'Analytics Chart',
                    text: 'Check out this analytics chart',
                  });
                } else {
                  // Fallback - copy to clipboard
                  alert('Share functionality coming soon!');
                }
              }}
            >
              <Share2 className="h-4 w-4" />
              <span className="ml-2">Share</span>
            </Button>
          )}
        </motion.div>
      </AnimatePresence>
      
      {/* The actual chart content */}
      <div ref={chartRef} className="relative">
        {children}
      </div>
    </div>
  );
}