import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

// Define types for A/B tests
type Variant = {
  id: string;
  name: string;
  conversionRate: number;
  description: string;
};

type AbTest = {
  id: number;
  name: string;
  description: string;
  status: string;
  daysLeft: number;
  variants: Variant[];
  confidence: number;
  domain: string;
};

const WebsiteAbTestsSimple = () => {
  const [selectedDomain, setSelectedDomain] = useState<string>('google.com');
  
  // Fetch all website A/B tests data
  const { data: allTests, isLoading: testsLoading } = useQuery({
    queryKey: ['/api/website-abtests'],
  });
  
  // Fetch website summary data with test counts
  const { data: websiteSummary, isLoading: summaryLoading } = useQuery({
    queryKey: ['/api/website-abtests-summary'],
  });
  
  // Loading state
  const isLoading = testsLoading || summaryLoading;
  
  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-12 w-full" />
        <Skeleton className="h-48 w-full" />
        <Skeleton className="h-48 w-full" />
      </div>
    );
  }
  
  // Filter tests for the selected domain
  const testsForDomain = Array.isArray(allTests) 
    ? allTests.filter((test: AbTest) => test.domain === selectedDomain)
    : [];
  
  // Get available domains
  const availableDomains = Array.isArray(websiteSummary) 
    ? websiteSummary 
    : [];
  
  return (
    <div className="space-y-4">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <h2 className="text-2xl font-bold">Website-Specific A/B Tests</h2>
        
        <div className="flex items-center gap-2">
          <span className="text-sm text-gray-500">Select Website:</span>
          <Select 
            value={selectedDomain} 
            onValueChange={setSelectedDomain}
          >
            <SelectTrigger className="w-[200px]">
              <SelectValue placeholder="Select website" />
            </SelectTrigger>
            <SelectContent>
              {availableDomains.map((website: any) => (
                <SelectItem key={website.domain} value={website.domain}>
                  {website.domain} ({website.activeTestCount} tests)
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
      
      {testsForDomain.length === 0 ? (
        <Card>
          <CardContent className="pt-6">
            <p className="text-center text-gray-500">No A/B tests found for {selectedDomain}</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-6">
          {testsForDomain.map((test: AbTest) => (
            <Card key={test.id} className="overflow-hidden">
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle>{test.name}</CardTitle>
                    <CardDescription>{test.description}</CardDescription>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge 
                      className={
                        test.status === 'active' 
                          ? 'bg-green-500' 
                          : test.status === 'completed' 
                          ? 'bg-blue-500' 
                          : 'bg-yellow-500'
                      }
                    >
                      {test.status}
                    </Badge>
                    <Badge variant="outline">{test.daysLeft} days left</Badge>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent>
                <Tabs defaultValue="overview">
                  <TabsList className="mb-4">
                    <TabsTrigger value="overview">Overview</TabsTrigger>
                    <TabsTrigger value="variants">Variants</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="overview">
                    <div className="space-y-4">
                      <div>
                        <h3 className="text-lg font-semibold mb-2">Confidence: {test.confidence}%</h3>
                        <Progress value={test.confidence} className="h-2 w-full" />
                      </div>
                      
                      <div>
                        <h3 className="text-lg font-semibold mb-2">Variants</h3>
                        {test.variants.map((variant) => (
                          <div key={variant.id} className="flex justify-between items-center mb-2 border-b pb-2">
                            <div>
                              <p className="font-medium">Variant {variant.id}: {variant.name}</p>
                              <p className="text-sm text-gray-500">{variant.description}</p>
                            </div>
                            <Badge>{variant.conversionRate}%</Badge>
                          </div>
                        ))}
                      </div>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="variants">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {test.variants.map((variant, index) => (
                        <Card key={variant.id} className="border-l-4 border-l-blue-500">
                          <CardHeader>
                            <CardTitle>Variant {variant.id}: {variant.name}</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <p className="text-gray-500 mb-4">{variant.description}</p>
                            <div className="space-y-2">
                              <div className="flex justify-between">
                                <span className="text-sm">Conversion Rate</span>
                                <span className="text-sm font-medium">{variant.conversionRate}%</span>
                              </div>
                              <Progress value={variant.conversionRate * 5} className="h-1" />
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default WebsiteAbTestsSimple;