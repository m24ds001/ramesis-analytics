import { Link, useLocation } from 'wouter';
import { cn } from '@/lib/utils';
import { BarChart, LayoutDashboard, Users, Brain, LineChart, TestTube, FileText, Settings, Globe, BarChart2, Table, CheckSquare } from 'lucide-react';

// List of navigation items with Lucide React icons
const navigationItems = [
  { name: 'Dashboard', href: '/', icon: LayoutDashboard },
  { name: 'User Behavior', href: '/user-behavior', icon: Users },
  { name: 'Website Catalog', href: '/websites', icon: Globe },
  { name: 'AI Insights', href: '/ai-insights', icon: Brain },
  { name: 'Action Items', href: '/action-items', icon: CheckSquare },
  { name: 'Predictive Analytics', href: '/predictive-analytics', icon: LineChart },

  { name: 'Reports', href: '/reports', icon: FileText },

  { name: 'Settings', href: '/settings', icon: Settings },
];

export default function Sidebar() {
  const [location] = useLocation();

  return (
    <div className="hidden md:flex md:flex-col md:w-64 md:fixed md:inset-y-0 bg-gray-900 text-white">
      <div className="flex-1 flex flex-col min-h-0">
        <div className="flex items-center h-16 px-4 bg-gray-800">
          <div className="flex items-center">
            <BarChart className="h-6 w-6 text-primary-500" />
            <span className="ml-2 text-xl font-semibold">Ramesis</span>
          </div>
        </div>
        <nav className="flex-1 px-2 py-4 space-y-1">
          {navigationItems.map((item) => {
            const isActive = location === item.href;
            return (
              <Link 
                key={item.name} 
                href={item.href}
                className={cn(
                  "flex items-center px-2 py-2 text-sm font-medium rounded-md", 
                  isActive 
                    ? "bg-gray-800 text-white" 
                    : "text-gray-300 hover:bg-gray-700"
                )}
              >
                <span className="mr-3">
                  {item.name === "Dashboard" && <LayoutDashboard className="h-5 w-5" />}
                  {item.name === "User Behavior" && <Users className="h-5 w-5" />}
                  {item.name === "Website Catalog" && <Globe className="h-5 w-5" />}
                  {item.name === "AI Insights" && <Brain className="h-5 w-5" />}
                  {item.name === "Action Items" && <CheckSquare className="h-5 w-5" />}
                  {item.name === "Predictive Analytics" && <LineChart className="h-5 w-5" />}

                  {item.name === "Reports" && <FileText className="h-5 w-5" />}

                  {item.name === "Settings" && <Settings className="h-5 w-5" />}
                </span>
                {item.name}
              </Link>
            );
          })}
        </nav>
      </div>
      {/* User profile section removed */}
    </div>
  );
}
