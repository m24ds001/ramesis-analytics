import React, { useEffect, useState } from 'react';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Download } from 'lucide-react';
import { DetailedWebsiteChart } from './DetailedWebsiteChart';
import AIInsights from '@/components/analytics/AIInsights';
import { ExternalWebsiteCatalog } from '@shared/schema';

interface DetailedWebsiteMetricsProps {
  websiteId: number;
  websiteName?: string;
  onClose?: () => void;
}

export function DetailedWebsiteMetrics({
  websiteId,
  websiteName = 'Website',
  onClose
}: DetailedWebsiteMetricsProps) {
  const [selectedProvider, setSelectedProvider] = useState<string>('google');
  const [selectedDateRange, setSelectedDateRange] = useState<string>('last7days');
  
  // Provider options for the select dropdown
  const PROVIDER_OPTIONS = [
    { value: 'google', label: 'Google Analytics 4' },
    { value: 'adobe', label: 'Adobe Analytics' },
    { value: 'mixpanel', label: 'Mixpanel' }
  ];

  const handleExportData = () => {
    console.log(`Exporting data for ${websiteName} with provider ${selectedProvider} for ${selectedDateRange}`);
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-3 gap-3 mb-6">
        <Select 
          value={selectedProvider} 
          onValueChange={setSelectedProvider}
        >
          <SelectTrigger>
            <SelectValue placeholder="Select provider" />
          </SelectTrigger>
          <SelectContent>
            {PROVIDER_OPTIONS.map(provider => (
              <SelectItem key={provider.value} value={provider.value}>
                {provider.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        
        <Select 
          value={selectedDateRange} 
          onValueChange={setSelectedDateRange}
        >
          <SelectTrigger>
            <SelectValue placeholder="Select time period" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="last7days">Last 7 days</SelectItem>
            <SelectItem value="last14days">Last 14 days</SelectItem>
            <SelectItem value="last30days">Last 30 days</SelectItem>
            <SelectItem value="last90days">Last 90 days</SelectItem>
            <SelectItem value="lastYear">Last year</SelectItem>
          </SelectContent>
        </Select>
        
        <Button 
          variant="outline" 
          onClick={handleExportData}
          className="flex items-center gap-2"
        >
          <Download className="h-4 w-4" />
          Export Data
        </Button>
      </div>
      
      <div className="space-y-4">
        <p className="text-sm text-gray-500 flex items-center">
          <span>Showing analytics for {websiteName} from {selectedProvider} for {selectedDateRange}</span>
          <Badge variant="outline" className="ml-2 bg-green-50 text-green-700 border-green-200">
            <span className="flex items-center gap-1">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
              </span>
              Live
            </span>
          </Badge>
        </p>
        
        {/* Real-time charts grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Conversion Metrics with proper scaling */}
          <div className="col-span-1">
            <DetailedWebsiteChart
              websiteId={websiteId}
              websiteName={websiteName}
              metricType="conversion"
              provider={selectedProvider}
              dateRange={selectedDateRange}
              title="Conversion Metrics"
              chartType="bar"
            />
          </div>
          
          {/* Traffic sources */}
          <div className="col-span-1">
            <DetailedWebsiteChart
              websiteId={websiteId}
              websiteName={websiteName}
              metricType="traffic"
              provider={selectedProvider}
              dateRange={selectedDateRange}
              title="Traffic Sources"
              chartType="pie"
            />
          </div>
          
          {/* Page views */}
          <div className="col-span-1">
            <DetailedWebsiteChart
              websiteId={websiteId}
              websiteName={websiteName}
              metricType="pageviews"
              provider={selectedProvider}
              dateRange={selectedDateRange}
              title="Page Views Distribution"
              chartType="bar"
            />
          </div>
          
          {/* Device usage */}
          <div className="col-span-1">
            <DetailedWebsiteChart
              websiteId={websiteId}
              websiteName={websiteName}
              metricType="devices"
              provider={selectedProvider}
              dateRange={selectedDateRange}
              title="Device Usage"
              chartType="pie"
            />
          </div>
        </div>
        
        {/* Website-specific AI Insights */}
        <div className="mt-6">
          <AIInsights 
            insights={[]}
            websiteId={websiteId}
            dateRange={selectedDateRange}
            className="w-full"
          />
        </div>
      </div>
    </div>
  );
}