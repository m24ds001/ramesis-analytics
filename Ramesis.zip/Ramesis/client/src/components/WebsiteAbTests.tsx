import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { Bar, BarChart, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from 'recharts';

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8'];

type Variant = {
  id: string;
  name: string;
  conversionRate: number;
  description: string;
};

type Metrics = {
  impressions: number;
  clicks: number;
  avgTimeOnPage: string;
};

type AbTest = {
  id: number;
  name: string;
  description: string;
  status: string;
  daysLeft: number;
  variants: Variant[];
  confidence: number;
  startDate: string;
  endDate: string;
  metrics: Metrics;
  domain: string;
};

const WebsiteAbTests = () => {
  const [selectedDomain, setSelectedDomain] = useState<string>('google.com');
  const [activeTab, setActiveTab] = useState('overview');

  // Fetch website-specific A/B tests
  const { data: allTests, isLoading, error } = useQuery({
    queryKey: ['/api/website-abtests'],
    refetchInterval: 30000,
  });

  // Fetch available domains with test counts
  const { data: testSummary } = useQuery({
    queryKey: ['/api/website-abtests-summary'],
    refetchInterval: 30000,
  });

  // Get tests for the selected domain
  const domainsWithTests = testSummary || [];
  const testsForDomain = Array.isArray(allTests) 
    ? allTests.filter((test: AbTest) => test.domain === selectedDomain)
    : [];

  const generateComparisonData = (test: AbTest) => {
    return test.variants.map((variant) => ({
      name: variant.id,
      value: variant.conversionRate,
      fullName: variant.name
    }));
  };

  const generateTimeSeriesData = (test: AbTest) => {
    // Generate some sample time series data for demo purposes
    const startDate = new Date(test.startDate);
    const endDate = new Date(test.endDate);
    const days = Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
    
    return Array.from({ length: days }, (_, i) => {
      const date = new Date(startDate);
      date.setDate(date.getDate() + i);
      const dateStr = `${date.getMonth() + 1}/${date.getDate()}`;
      
      // Create a convincing pattern with variant B gradually improving
      let variantARate = test.variants[0].conversionRate * (0.85 + (i / days) * 0.3);
      let variantBRate = test.variants[1].conversionRate * (0.75 + (i / days) * 0.5);
      
      // Add some randomness
      variantARate *= (0.95 + Math.random() * 0.1);
      variantBRate *= (0.95 + Math.random() * 0.1);
      
      return {
        date: dateStr,
        [test.variants[0].id]: variantARate.toFixed(1),
        [test.variants[1].id]: variantBRate.toFixed(1),
      };
    });
  };

  const generateMetricsData = (test: AbTest) => {
    return [
      {
        name: 'Impressions',
        value: test.metrics.impressions,
      },
      {
        name: 'Clicks',
        value: test.metrics.clicks,
      },
      {
        name: 'CTR',
        value: ((test.metrics.clicks / test.metrics.impressions) * 100).toFixed(1),
      },
    ];
  };

  const generateRadarData = (test: AbTest) => {
    // Create detailed radar chart data comparing variants
    return [
      {
        metric: 'Conversion',
        A: test.variants[0].conversionRate,
        B: test.variants[1].conversionRate,
      },
      {
        metric: 'Engagement',
        A: test.variants[0].conversionRate * 1.2,
        B: test.variants[1].conversionRate * 1.3,
      },
      {
        metric: 'Time Spent',
        A: test.variants[0].conversionRate * 0.8,
        B: test.variants[1].conversionRate * 0.9,
      },
      {
        metric: 'Click Depth',
        A: test.variants[0].conversionRate * 0.7,
        B: test.variants[1].conversionRate * 0.9,
      },
      {
        metric: 'Return Rate',
        A: test.variants[0].conversionRate * 0.5,
        B: test.variants[1].conversionRate * 0.7,
      },
    ];
  };

  // Helper to calculate remaining days
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-green-500';
      case 'completed':
        return 'bg-blue-500';
      case 'paused':
        return 'bg-yellow-500';
      default:
        return 'bg-gray-500';
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-12 w-full" />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Skeleton className="h-48 w-full" />
          <Skeleton className="h-48 w-full" />
        </div>
      </div>
    );
  }

  if (error) {
    return <div className="text-red-500">Error loading A/B tests: {(error as Error).message}</div>;
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <h2 className="text-2xl font-bold">Website-Specific A/B Tests</h2>
        
        <div className="flex items-center gap-2">
          <span className="text-sm text-gray-500">Select Website:</span>
          <Select 
            value={selectedDomain} 
            onValueChange={setSelectedDomain}
          >
            <SelectTrigger className="w-[200px]">
              <SelectValue placeholder="Select website" />
            </SelectTrigger>
            <SelectContent>
              {domainsWithTests.map((domain: any) => (
                <SelectItem key={domain.domain} value={domain.domain}>
                  {domain.domain} ({domain.activeTestCount} tests)
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {testsForDomain.length === 0 ? (
        <Card>
          <CardContent className="pt-6">
            <p className="text-center text-gray-500">No A/B tests found for {selectedDomain}</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-6">
          {testsForDomain.map((test: AbTest) => (
            <Card key={test.id} className="overflow-hidden">
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-xl">{test.name}</CardTitle>
                    <CardDescription className="mt-1">{test.description}</CardDescription>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge className={getStatusColor(test.status)}>{test.status}</Badge>
                    <Badge variant="outline">{test.daysLeft} days left</Badge>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent>
                <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab}>
                  <TabsList className="mb-4">
                    <TabsTrigger value="overview">Overview</TabsTrigger>
                    <TabsTrigger value="variants">Variants</TabsTrigger>
                    <TabsTrigger value="performance">Performance</TabsTrigger>
                    <TabsTrigger value="timeline">Timeline</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="overview">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="flex flex-col justify-between">
                        <div className="mb-4">
                          <h3 className="text-lg font-semibold mb-2">Test Confidence: {test.confidence}%</h3>
                          <Progress value={test.confidence} className="h-2 w-full" />
                        </div>
                        
                        <div className="grid grid-cols-3 gap-4 mb-4">
                          <div className="bg-gray-100 p-3 rounded-lg">
                            <p className="text-xs text-gray-500">Impressions</p>
                            <p className="text-lg font-semibold">{new Intl.NumberFormat().format(test.metrics.impressions)}</p>
                          </div>
                          <div className="bg-gray-100 p-3 rounded-lg">
                            <p className="text-xs text-gray-500">Clicks</p>
                            <p className="text-lg font-semibold">{new Intl.NumberFormat().format(test.metrics.clicks)}</p>
                          </div>
                          <div className="bg-gray-100 p-3 rounded-lg">
                            <p className="text-xs text-gray-500">Avg. Time</p>
                            <p className="text-lg font-semibold">{test.metrics.avgTimeOnPage}</p>
                          </div>
                        </div>
                        
                        <div>
                          <h3 className="text-lg font-semibold mb-2">Variants</h3>
                          {test.variants.map((variant) => (
                            <div key={variant.id} className="flex justify-between items-center mb-2 border-b pb-2">
                              <div>
                                <p className="font-medium">Variant {variant.id}: {variant.name}</p>
                                <p className="text-xs text-gray-500">{variant.description}</p>
                              </div>
                              <Badge>{variant.conversionRate}%</Badge>
                            </div>
                          ))}
                        </div>
                      </div>
                      
                      <div className="h-[300px]">
                        <h3 className="text-lg font-semibold mb-2 text-center">Conversion Rate Comparison</h3>
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart
                            data={generateComparisonData(test)}
                            margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                          >
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="name" />
                            <YAxis label={{ value: 'Conversion Rate (%)', angle: -90, position: 'insideLeft' }} />
                            <Tooltip formatter={(value, name, props) => [`${value}%`, props.payload.fullName]} />
                            <Bar dataKey="value" fill="#8884d8">
                              {generateComparisonData(test).map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                              ))}
                            </Bar>
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="variants">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {test.variants.map((variant, index) => (
                        <Card key={variant.id} className={`border-l-4 ${index === 0 ? 'border-l-blue-500' : 'border-l-green-500'}`}>
                          <CardHeader className="pb-2">
                            <div className="flex justify-between items-center">
                              <CardTitle>Variant {variant.id}: {variant.name}</CardTitle>
                              <Badge variant={index === 0 ? "default" : "outline"}>{variant.conversionRate}%</Badge>
                            </div>
                          </CardHeader>
                          <CardContent>
                            <p className="text-gray-500 mb-4">{variant.description}</p>
                            
                            <div className="space-y-2">
                              <div className="flex justify-between">
                                <span className="text-sm">Conversion Rate</span>
                                <span className="text-sm font-medium">{variant.conversionRate}%</span>
                              </div>
                              <Progress value={variant.conversionRate * 10} className="h-1 w-full" />
                              
                              <div className="flex justify-between mt-2">
                                <span className="text-sm">Click-through Rate</span>
                                <span className="text-sm font-medium">{(variant.conversionRate * 0.8).toFixed(1)}%</span>
                              </div>
                              <Progress value={variant.conversionRate * 8} className="h-1 w-full" />
                              
                              <div className="flex justify-between mt-2">
                                <span className="text-sm">Engagement Score</span>
                                <span className="text-sm font-medium">{(variant.conversionRate * 0.6).toFixed(1)}</span>
                              </div>
                              <Progress value={variant.conversionRate * 6} className="h-1 w-full" />
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                    
                    <div className="mt-6 h-[300px]">
                      <h3 className="text-lg font-semibold mb-2 text-center">Variant Comparison</h3>
                      <ResponsiveContainer width="100%" height="100%">
                        <RadarChart data={generateRadarData(test)}>
                          <PolarGrid />
                          <PolarAngleAxis dataKey="metric" />
                          <PolarRadiusAxis angle={30} domain={[0, 20]} />
                          <Radar name={`Variant ${test.variants[0].id}`} dataKey="A" stroke="#8884d8" fill="#8884d8" fillOpacity={0.6} />
                          <Radar name={`Variant ${test.variants[1].id}`} dataKey="B" stroke="#82ca9d" fill="#82ca9d" fillOpacity={0.6} />
                          <Legend />
                        </RadarChart>
                      </ResponsiveContainer>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="performance">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="h-[300px]">
                        <h3 className="text-lg font-semibold mb-2 text-center">Conversion Rate Over Time</h3>
                        <ResponsiveContainer width="100%" height="100%">
                          <LineChart
                            data={generateTimeSeriesData(test)}
                            margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                          >
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="date" />
                            <YAxis />
                            <Tooltip />
                            <Legend />
                            <Line type="monotone" dataKey="A" stroke="#8884d8" activeDot={{ r: 8 }} name={`Variant ${test.variants[0].id}`} />
                            <Line type="monotone" dataKey="B" stroke="#82ca9d" name={`Variant ${test.variants[1].id}`} />
                          </LineChart>
                        </ResponsiveContainer>
                      </div>
                      
                      <div className="h-[300px]">
                        <h3 className="text-lg font-semibold mb-2 text-center">Metrics Breakdown</h3>
                        <ResponsiveContainer width="100%" height="100%">
                          <PieChart>
                            <Pie
                              data={generateMetricsData(test)}
                              cx="50%"
                              cy="50%"
                              labelLine={false}
                              label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                              outerRadius={80}
                              fill="#8884d8"
                              dataKey="value"
                            >
                              {generateMetricsData(test).map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                              ))}
                            </Pie>
                            <Tooltip formatter={(value) => new Intl.NumberFormat().format(value as number)} />
                            <Legend />
                          </PieChart>
                        </ResponsiveContainer>
                      </div>
                    </div>
                    
                    <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div className="bg-gray-100 p-4 rounded-lg">
                        <p className="text-xs text-gray-500">Impressions</p>
                        <p className="text-lg font-semibold">{new Intl.NumberFormat().format(test.metrics.impressions)}</p>
                      </div>
                      <div className="bg-gray-100 p-4 rounded-lg">
                        <p className="text-xs text-gray-500">Clicks</p>
                        <p className="text-lg font-semibold">{new Intl.NumberFormat().format(test.metrics.clicks)}</p>
                      </div>
                      <div className="bg-gray-100 p-4 rounded-lg">
                        <p className="text-xs text-gray-500">CTR</p>
                        <p className="text-lg font-semibold">{((test.metrics.clicks / test.metrics.impressions) * 100).toFixed(1)}%</p>
                      </div>
                      <div className="bg-gray-100 p-4 rounded-lg">
                        <p className="text-xs text-gray-500">Avg. Session</p>
                        <p className="text-lg font-semibold">{test.metrics.avgTimeOnPage}</p>
                      </div>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="timeline">
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <div>
                          <p className="text-sm text-gray-500">Started</p>
                          <p className="font-medium">{new Date(test.startDate).toLocaleDateString()}</p>
                        </div>
                        <div className="flex-1 mx-4">
                          <Progress value={(test.daysLeft / ((new Date(test.endDate).getTime() - new Date(test.startDate).getTime()) / (1000 * 60 * 60 * 24))) * 100} className="h-2 w-full" />
                        </div>
                        <div>
                          <p className="text-sm text-gray-500">Ends</p>
                          <p className="font-medium">{new Date(test.endDate).toLocaleDateString()}</p>
                        </div>
                      </div>
                      
                      <div className="h-[300px]">
                        <h3 className="text-lg font-semibold mb-2 text-center">Performance Trend</h3>
                        <ResponsiveContainer width="100%" height="100%">
                          <LineChart
                            data={generateTimeSeriesData(test)}
                            margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                          >
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="date" />
                            <YAxis />
                            <Tooltip />
                            <Legend />
                            <Line type="monotone" dataKey="A" stroke="#8884d8" activeDot={{ r: 8 }} name={`Variant ${test.variants[0].id}`} />
                            <Line type="monotone" dataKey="B" stroke="#82ca9d" name={`Variant ${test.variants[1].id}`} />
                          </LineChart>
                        </ResponsiveContainer>
                      </div>
                      
                      <div className="border rounded-lg p-4 mt-4">
                        <h3 className="text-lg font-semibold mb-2">Test Details</h3>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <p className="text-sm text-gray-500">Status</p>
                            <p className="font-medium">{test.status}</p>
                          </div>
                          <div>
                            <p className="text-sm text-gray-500">Confidence</p>
                            <p className="font-medium">{test.confidence}%</p>
                          </div>
                          <div>
                            <p className="text-sm text-gray-500">Domain</p>
                            <p className="font-medium">{test.domain}</p>
                          </div>
                          <div>
                            <p className="text-sm text-gray-500">Days Remaining</p>
                            <p className="font-medium">{test.daysLeft}</p>
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex justify-between mt-4">
                        <Button variant="outline">Pause Test</Button>
                        <Button>Declare Winner</Button>
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default WebsiteAbTests;