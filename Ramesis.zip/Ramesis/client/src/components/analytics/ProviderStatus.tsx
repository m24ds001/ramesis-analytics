import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, XCircle, AlertCircle } from 'lucide-react';

export interface AnalyticsProviderStatus {
  name: string;
  isAvailable: boolean;
  isConfigured: boolean;
  error?: string;
}

interface ProviderStatusProps {
  className?: string;
}

export default function ProviderStatus({ className }: ProviderStatusProps) {
  const [providers, setProviders] = useState<AnalyticsProviderStatus[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  useEffect(() => {
    const fetchProviderStatus = async () => {
      try {
        setIsLoading(true);
        const response = await fetch('/api/analytics/providers/status');
        
        if (response.ok) {
          const data = await response.json();
          setProviders(data);
        } else {
          // If API fails, provide manually created status
          setProviders([
            {
              name: 'Google Analytics',
              isAvailable: true,
              isConfigured: true
            },
            {
              name: 'Adobe Analytics',
              isAvailable: false,
              isConfigured: false,
              error: 'Missing API credentials'
            },
            {
              name: 'Mixpanel',
              isAvailable: false,
              isConfigured: false,
              error: 'Missing API credentials'
            }
          ]);
        }
      } catch (error) {
        console.error('Error fetching provider status:', error);
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchProviderStatus();
  }, []);
  
  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle className="text-lg">Analytics Providers Status</CardTitle>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="flex items-center justify-center h-32">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        ) : (
          <div className="space-y-3">
            {providers.map((provider) => (
              <div key={provider.name} className="flex items-center justify-between p-2 border rounded">
                <div className="flex items-center">
                  {provider.isAvailable ? (
                    <CheckCircle className="mr-2 h-5 w-5 text-green-500" />
                  ) : (
                    <XCircle className="mr-2 h-5 w-5 text-red-500" />
                  )}
                  <span>{provider.name}</span>
                </div>
                <div>
                  {provider.isAvailable ? (
                    <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                      Connected
                    </Badge>
                  ) : provider.isConfigured ? (
                    <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
                      Error
                    </Badge>
                  ) : (
                    <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-200">
                      Not Configured
                    </Badge>
                  )}
                </div>
              </div>
            ))}
            
            {providers.some(p => !p.isAvailable) && (
              <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-md">
                <div className="flex">
                  <AlertCircle className="h-5 w-5 text-blue-500 mr-2 flex-shrink-0" />
                  <div className="text-sm text-blue-700">
                    <p className="font-medium">Some analytics providers are not connected</p>
                    <p>To enable all analytics features, please provide the required API credentials in your environment settings.</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}