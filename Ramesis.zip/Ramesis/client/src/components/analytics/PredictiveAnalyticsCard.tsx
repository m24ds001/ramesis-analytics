import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ExportableChart } from '@/components/ui/exportable-chart';
import { DataSourceBadge } from '@/components/ui/data-source-badge';
import { AnimatedTooltip } from '@/components/ui/animated-tooltip';
import { MetricTooltipContent } from '@/components/analytics/MetricTooltipContent';
import { getMetricTooltipContent } from '@/lib/tooltipContent';
import { motion } from 'framer-motion';
import { Info, AlertTriangle } from 'lucide-react';

interface PredictiveAnalyticsCardProps {
  title: string;
  value: string | number;
  currentValue?: string | number;
  change: number;
  confidence: number;
  period?: string;
  metricName: string;
  websiteName?: string;
  className?: string;
  analysisText?: string;
  dataSource?: string;
  children?: React.ReactNode;
}

export function PredictiveAnalyticsCard({
  title,
  value,
  currentValue,
  change,
  confidence,
  period = 'next 7 days',
  metricName,
  websiteName,
  className = '',
  analysisText,
  dataSource = 'ML Prediction Engine',
  children
}: PredictiveAnalyticsCardProps) {
  const tooltipContent = getMetricTooltipContent(metricName, websiteName);
  
  // Add confidence information to the tooltip
  tooltipContent.description = `${tooltipContent.description}\n\nPrediction confidence: ${Math.round(confidence * 100)}%`;
  
  // Animation variants for the value
  const numberVariants = {
    initial: { opacity: 0, y: 20 },
    animate: { 
      opacity: 1, 
      y: 0,
      transition: { 
        duration: 0.8,
        ease: "easeOut",
      }
    }
  };

  return (
    <Card className={`overflow-hidden ${className}`}>
      <DataSourceBadge 
        sourceName={websiteName || 'All Websites'} 
        providerName={dataSource} 
        className="from-indigo-600 to-indigo-700"
      />
      <CardHeader className="px-6 py-5 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-lg font-medium text-gray-900 flex items-center gap-2">
              {title}
              <AnimatedTooltip
                content={<MetricTooltipContent {...tooltipContent} />}
                icon={<Info size={16} />}
                iconClassName="text-gray-400 hover:text-gray-600"
              />
            </CardTitle>
            {websiteName && (
              <div className="text-xs font-medium text-indigo-600 mt-1">
                Real-time data from {websiteName}
              </div>
            )}
          </div>
          <Badge variant="outline" className={`${change >= 0 ? 'bg-green-100 text-green-800' : 'bg-amber-100 text-amber-800'}`}>
            {change >= 0 ? '+' : ''}{typeof change === 'number' ? change.toFixed(1) : change}%
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <motion.div 
          className="text-3xl font-bold text-gray-900 mb-2"
          initial="initial"
          animate="animate"
          variants={numberVariants}
        >
          {typeof value === 'number' ? value.toFixed(1) : value}%
        </motion.div>
        <div className="text-sm text-gray-500 mb-4">
          Predicted for {period}
        </div>
        <div className="flex justify-between items-center">
          {currentValue && (
            <div className="text-sm">
              <span className="text-gray-500">Current: </span>
              <span className="font-medium">{currentValue}%</span>
            </div>
          )}
          <div className="text-sm">
            <span className="text-gray-500">Confidence: </span>
            <span className={`font-medium ${confidence < 0.6 ? 'text-amber-500' : 'text-green-500'}`}>
              {Math.round(confidence * 100)}%
              {confidence < 0.6 && <AlertTriangle className="inline ml-1 w-3 h-3" />}
            </span>
          </div>
        </div>
        
        {analysisText && (
          <div className="mt-4 text-sm text-gray-600 border-t border-gray-100 pt-4">
            <p><strong>Analysis:</strong> {analysisText}</p>
          </div>
        )}
        
        {children && (
          <div className="mt-4">
            <ExportableChart title={`${title} - ${websiteName || 'All Websites'}`} fileName={`prediction-${metricName}`}>
              {children}
            </ExportableChart>
          </div>
        )}
      </CardContent>
    </Card>
  );
}