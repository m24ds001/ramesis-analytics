import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { useRealtimePredictions } from '@/hooks/use-realtime-predictions';
import { 
  ArrowUpIcon, 
  ArrowDownIcon, 
  Loader2, 
  Smartphone, 
  Monitor, 
  Tablet, 
  TrendingUp, 
  TrendingDown, 
  Minus 
} from 'lucide-react';

interface PredictiveAnalyticsProps {
  websiteId?: number | null;
  dateRange?: string;
}

export default function PredictiveAnalytics({ websiteId, dateRange = 'last7days' }: PredictiveAnalyticsProps) {
  // Use real-time predictions hook to get live predictive data
  const { predictions, isReceivingRealData, activeUsers, error } = useRealtimePredictions(websiteId, dateRange);
  
  // Format time since last update
  const getTimeAgo = () => {
    const now = new Date();
    const seconds = Math.floor((now.getTime() - predictions.lastUpdated.getTime()) / 1000);
    
    if (seconds < 60) return `${seconds}s ago`;
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
    return `${Math.floor(seconds / 3600)}h ago`;
  };
  
  // Helper to render trend icon based on trend direction
  const renderTrendIcon = (trend: 'up' | 'down' | 'stable') => {
    if (trend === 'up') return <TrendingUp className="h-3 w-3 text-green-500" />;
    if (trend === 'down') return <TrendingDown className="h-3 w-3 text-red-500" />;
    return <Minus className="h-3 w-3 text-gray-500" />;
  };
  
  return (
    <Card>
      <CardHeader className="px-4 py-5 border-b border-gray-200 sm:px-6 flex flex-row items-center justify-between">
        <div className="flex flex-col">
          <CardTitle className="text-lg leading-6 font-medium text-gray-900">Predictive Analytics</CardTitle>
          <div className="text-xs text-gray-500 flex items-center mt-1">
            {isReceivingRealData ? (
              <>
                <div className="h-2 w-2 rounded-full bg-green-500 animate-pulse mr-1"></div>
                <span>Real-time predictions • Updated {getTimeAgo()}</span>
              </>
            ) : (
              <span>Waiting for real-time data...</span>
            )}
          </div>
        </div>
        <Badge variant="outline" className="px-2 py-1 text-xs rounded-full bg-indigo-100 text-indigo-800 font-medium">
          Machine Learning
        </Badge>
      </CardHeader>
      <CardContent className="px-4 py-5 sm:p-6">
        {error ? (
          <div className="bg-amber-50 p-4 rounded-lg border border-amber-200">
            <p className="text-amber-800 font-medium">Analytics Connection Issue</p>
            <p className="text-amber-700 text-sm">Unable to fetch real-time data for predictions. Please check your analytics connection.</p>
          </div>
        ) : !isReceivingRealData ? (
          <div className="flex flex-col items-center justify-center py-8">
            <Loader2 className="h-8 w-8 text-primary animate-spin mb-4" />
            <p className="text-gray-600">Connecting to real-time data sources...</p>
            <p className="text-xs text-gray-500 mt-2">Predictions will appear when users are active</p>
          </div>
        ) : (
          <>
            {/* Live visualization indicator */}
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center">
                <div className="mr-2 p-2 bg-gray-100 rounded-full">
                  <div className="h-3 w-3 rounded-full bg-green-500 animate-pulse"></div>
                </div>
                <span className="text-sm font-medium text-gray-700">
                  Live Prediction Model
                </span>
              </div>
              <div className="bg-gray-100 px-3 py-1 rounded-full text-xs font-medium">
                {activeUsers} active user{activeUsers !== 1 ? 's' : ''}
              </div>
            </div>
            
            {/* Traffic forecast */}
            <div className="mb-6">
              <div className="flex justify-between items-center mb-1">
                <h4 className="text-sm font-medium text-gray-900">Traffic Forecast (Next 24 Hours)</h4>
                <span className={`text-sm font-medium flex items-center ${
                  predictions.trafficForecast.predicted > predictions.trafficForecast.current 
                    ? 'text-green-500' 
                    : 'text-red-500'
                }`}>
                  {predictions.trafficForecast.predicted > predictions.trafficForecast.current ? (
                    <ArrowUpIcon className="h-3 w-3 mr-1" />
                  ) : (
                    <ArrowDownIcon className="h-3 w-3 mr-1" />
                  )}
                  {Math.abs(predictions.trafficForecast.predicted - predictions.trafficForecast.current)} visitors
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-blue-500 h-2 rounded-full" 
                  style={{ width: `${predictions.trafficForecast.confidence * 100}%` }}
                ></div>
              </div>
              <p className="text-xs text-gray-500 mt-1">
                Current: {predictions.trafficForecast.current} → Predicted: {predictions.trafficForecast.predicted}
              </p>
            </div>
            
            {/* Device forecasts */}
            <div className="mb-6">
              <h4 className="text-sm font-medium text-gray-900 mb-3">Device-Specific Traffic Forecast</h4>
              <div className="grid grid-cols-3 gap-2">
                {/* Mobile forecast */}
                <div className="p-3 bg-gray-50 rounded-lg border border-gray-100">
                  <div className="flex items-center mb-2">
                    <Smartphone className="h-4 w-4 mr-2 text-blue-500" />
                    <span className="text-xs font-medium">Mobile</span>
                    <div className="ml-auto">
                      {renderTrendIcon(predictions.deviceBreakdown.mobile.trend)}
                    </div>
                  </div>
                  <div className="text-lg font-semibold">
                    {predictions.deviceBreakdown.mobile.predicted}
                  </div>
                  <div className="text-xs text-gray-500 mt-1">
                    Current: {predictions.deviceBreakdown.mobile.current}
                  </div>
                </div>
                
                {/* Desktop forecast */}
                <div className="p-3 bg-gray-50 rounded-lg border border-gray-100">
                  <div className="flex items-center mb-2">
                    <Monitor className="h-4 w-4 mr-2 text-indigo-500" />
                    <span className="text-xs font-medium">Desktop</span>
                    <div className="ml-auto">
                      {renderTrendIcon(predictions.deviceBreakdown.desktop.trend)}
                    </div>
                  </div>
                  <div className="text-lg font-semibold">
                    {predictions.deviceBreakdown.desktop.predicted}
                  </div>
                  <div className="text-xs text-gray-500 mt-1">
                    Current: {predictions.deviceBreakdown.desktop.current}
                  </div>
                </div>
                
                {/* Tablet forecast */}
                <div className="p-3 bg-gray-50 rounded-lg border border-gray-100">
                  <div className="flex items-center mb-2">
                    <Tablet className="h-4 w-4 mr-2 text-purple-500" />
                    <span className="text-xs font-medium">Tablet</span>
                    <div className="ml-auto">
                      {renderTrendIcon(predictions.deviceBreakdown.tablet.trend)}
                    </div>
                  </div>
                  <div className="text-lg font-semibold">
                    {predictions.deviceBreakdown.tablet.predicted}
                  </div>
                  <div className="text-xs text-gray-500 mt-1">
                    Current: {predictions.deviceBreakdown.tablet.current}
                  </div>
                </div>
              </div>
              <div className="text-xs text-gray-500 mt-2 text-center">
                Based on time-of-day usage patterns and current traffic
              </div>
            </div>
            
            {/* Conversion rate predictions */}
            <div className="mb-6">
              <div className="flex justify-between items-center mb-1">
                <h4 className="text-sm font-medium text-gray-900">Predicted Conversion Rate</h4>
                <span className="text-sm font-medium text-green-500">
                  +{(predictions.conversionRate.predicted - predictions.conversionRate.current).toFixed(1)}%
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-green-500 h-2 rounded-full" 
                  style={{ width: `${predictions.conversionRate.confidence * 100}%` }}
                ></div>
              </div>
              <p className="text-xs text-gray-500 mt-1">
                Current: {predictions.conversionRate.current}% → Predicted: {predictions.conversionRate.predicted}%
              </p>
            </div>
            
            {/* Bounce rate predictions */}
            <div className="mb-6">
              <div className="flex justify-between items-center mb-1">
                <h4 className="text-sm font-medium text-gray-900">Predicted Bounce Rate</h4>
                <span className={`text-sm font-medium ${
                  predictions.bounceRate.predicted < predictions.bounceRate.current 
                    ? 'text-green-500' 
                    : 'text-red-500'
                }`}>
                  {predictions.bounceRate.predicted < predictions.bounceRate.current ? '-' : '+'}
                  {Math.abs(predictions.bounceRate.predicted - predictions.bounceRate.current).toFixed(1)}%
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-primary-500 h-2 rounded-full" 
                  style={{ width: `${predictions.bounceRate.confidence * 100}%` }}
                ></div>
              </div>
              <p className="text-xs text-gray-500 mt-1">
                Current: {predictions.bounceRate.current}% → Predicted: {predictions.bounceRate.predicted}%
              </p>
            </div>
            
            {/* Revenue growth predictions */}
            <div>
              <div className="flex justify-between items-center mb-1">
                <h4 className="text-sm font-medium text-gray-900">Expected Revenue Growth</h4>
                <span className="text-sm font-medium text-green-500">+{predictions.revenueGrowth.predicted}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-indigo-500 h-2 rounded-full" 
                  style={{ width: `${predictions.revenueGrowth.confidence * 100}%` }}
                ></div>
              </div>
              <p className="text-xs text-gray-500 mt-1">
                Based on current user behavior and market trends
              </p>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}
