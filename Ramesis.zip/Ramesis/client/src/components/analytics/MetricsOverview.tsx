import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useRealTimeAnalytics } from '@/hooks/use-realtime';
import { getAnalyticsSummary } from '@/lib/analytics';
import { Users, ShoppingCart, ArrowLeftCircle, Clock, ArrowUp, Info } from 'lucide-react';
import ExportButton from './ExportButton';
import { useQuery } from '@tanstack/react-query';
import { DataSourceBadge, DataSourceHeader } from '@/components/ui/data-source-badge';
import { MetricWithTooltip } from '@/components/analytics/MetricWithTooltip';

interface MetricsOverviewProps {
  websiteId?: number | null;
  dateRange?: string;
}

export default function MetricsOverview({ websiteId, dateRange = 'last7days' }: MetricsOverviewProps) {
  const realTimeMetrics = useRealTimeAnalytics(websiteId);
  const isLoading = false;
  
  // Normalize the date range to lowercase for consistent handling
  const normalizedDateRange = dateRange.toLowerCase();
  console.log(`MetricsOverview using normalized date range: ${normalizedDateRange}`);
  
  // Get website name if websiteId is provided
  const { data: website } = useQuery({
    queryKey: websiteId ? ['/api/external-websites', websiteId] : ['/api/external-websites', 'none'],
    queryFn: () => websiteId ? fetch(`/api/external-websites/${websiteId}`).then(res => res.json()) : null,
    enabled: !!websiteId
  });
  
  // TEMPORARY: Using direct demo values for presentation purposes with different data per website
  // as requested by the client, with different values for different time periods
  const getAnalyticsSummaryForWebsite = (websiteId?: number | null, websiteName?: string | null, period: string = 'last7days') => {
    // Normalize the period string to lowercase for consistent handling
    period = period.toLowerCase();
    // Default data for dashboard
    if (!websiteId || !websiteName) {
      const defaultData = {
        last7days: {
          activeVisitors: 42,
          bounceRate: { value: '35.2%', change: '-4.8%' },
          conversionRate: { value: '3.7%', change: '+0.8%' },
          avgSession: { value: '2:15', change: '+12.5%' }
        },
        last30days: {
          activeVisitors: 156,
          bounceRate: { value: '32.6%', change: '-3.2%' },
          conversionRate: { value: '4.1%', change: '+1.5%' },
          avgSession: { value: '2:42', change: '+10.2%' }
        },
        last90days: {
          activeVisitors: 257,
          bounceRate: { value: '29.1%', change: '-5.4%' },
          conversionRate: { value: '4.9%', change: '+2.4%' },
          avgSession: { value: '3:18', change: '+15.8%' }
        },
        thismonth: {
          activeVisitors: 183,
          bounceRate: { value: '31.7%', change: '-4.3%' },
          conversionRate: { value: '4.3%', change: '+1.9%' },
          avgSession: { value: '3:05', change: '+11.9%' }
        },
        lastmonth: {
          activeVisitors: 124,
          bounceRate: { value: '33.8%', change: '-2.7%' },
          conversionRate: { value: '3.9%', change: '+1.2%' },
          avgSession: { value: '2:33', change: '+8.7%' }
        },
        custom: {
          activeVisitors: 98,
          bounceRate: { value: '34.5%', change: '-1.8%' },
          conversionRate: { value: '3.5%', change: '+0.6%' },
          avgSession: { value: '2:08', change: '+5.3%' }
        }
      };
      
      return defaultData[period] || defaultData.last7days;
    }
    
    // Each website has different metrics per time period
    const websiteDataByPeriod: Record<string, Record<string, any>> = {
      'Amazon': {
        last7days: {
          activeVisitors: 156,
          bounceRate: { value: '28.5%', change: '-3.2%' },
          conversionRate: { value: '4.7%', change: '+1.2%' },
          avgSession: { value: '3:45', change: '+8.3%' }
        },
        last30days: {
          activeVisitors: 432,
          bounceRate: { value: '25.3%', change: '-5.4%' },
          conversionRate: { value: '5.2%', change: '+2.1%' },
          avgSession: { value: '4:12', change: '+12.7%' }
        },
        last90days: {
          activeVisitors: 876,
          bounceRate: { value: '23.1%', change: '-7.8%' },
          conversionRate: { value: '5.9%', change: '+3.2%' },
          avgSession: { value: '4:38', change: '+16.5%' }
        },
        thismonth: {
          activeVisitors: 378,
          bounceRate: { value: '26.8%', change: '-4.5%' },
          conversionRate: { value: '5.0%', change: '+1.8%' },
          avgSession: { value: '4:05', change: '+10.9%' }
        },
        lastmonth: {
          activeVisitors: 343,
          bounceRate: { value: '27.2%', change: '-3.7%' },
          conversionRate: { value: '4.9%', change: '+1.5%' },
          avgSession: { value: '3:56', change: '+9.7%' }
        }
      },
      'Flipkart': {
        last7days: {
          activeVisitors: 112,
          bounceRate: { value: '31.8%', change: '-2.5%' },
          conversionRate: { value: '3.9%', change: '+0.5%' },
          avgSession: { value: '2:55', change: '+10.2%' }
        },
        last30days: {
          activeVisitors: 328,
          bounceRate: { value: '28.3%', change: '-4.3%' },
          conversionRate: { value: '4.3%', change: '+1.4%' },
          avgSession: { value: '3:24', change: '+13.8%' }
        },
        last90days: {
          activeVisitors: 672,
          bounceRate: { value: '25.9%', change: '-6.7%' },
          conversionRate: { value: '4.8%', change: '+2.6%' },
          avgSession: { value: '3:47', change: '+18.2%' }
        },
        thismonth: {
          activeVisitors: 294,
          bounceRate: { value: '29.5%', change: '-3.9%' },
          conversionRate: { value: '4.1%', change: '+1.1%' },
          avgSession: { value: '3:18', change: '+12.1%' }
        },
        lastmonth: {
          activeVisitors: 249,
          bounceRate: { value: '30.1%', change: '-3.1%' },
          conversionRate: { value: '4.0%', change: '+0.9%' },
          avgSession: { value: '3:05', change: '+10.9%' }
        }
      },
      'YouTube': {
        last7days: {
          activeVisitors: 324,
          bounceRate: { value: '22.4%', change: '-5.3%' },
          conversionRate: { value: '2.2%', change: '+0.3%' },
          avgSession: { value: '8:22', change: '+15.7%' }
        },
        last30days: {
          activeVisitors: 918,
          bounceRate: { value: '18.7%', change: '-7.8%' },
          conversionRate: { value: '2.8%', change: '+0.9%' },
          avgSession: { value: '9:15', change: '+19.3%' }
        },
        last90days: {
          activeVisitors: 1872,
          bounceRate: { value: '15.3%', change: '-9.2%' },
          conversionRate: { value: '3.4%', change: '+1.6%' },
          avgSession: { value: '10:08', change: '+23.6%' }
        },
        thismonth: {
          activeVisitors: 1025,
          bounceRate: { value: '17.9%', change: '-8.2%' },
          conversionRate: { value: '3.0%', change: '+1.2%' },
          avgSession: { value: '9:36', change: '+20.4%' }
        },
        lastmonth: {
          activeVisitors: 865,
          bounceRate: { value: '19.5%', change: '-6.5%' },
          conversionRate: { value: '2.6%', change: '+0.6%' },
          avgSession: { value: '8:48', change: '+17.6%' }
        }
      },
      'Netflix': {
        last7days: {
          activeVisitors: 187,
          bounceRate: { value: '18.7%', change: '-4.1%' },
          conversionRate: { value: '7.3%', change: '+2.1%' },
          avgSession: { value: '12:45', change: '+22.5%' }
        },
        last30days: {
          activeVisitors: 542,
          bounceRate: { value: '16.2%', change: '-6.3%' },
          conversionRate: { value: '8.1%', change: '+3.5%' },
          avgSession: { value: '13:37', change: '+27.2%' }
        },
        last90days: {
          activeVisitors: 1182,
          bounceRate: { value: '13.5%', change: '-8.7%' },
          conversionRate: { value: '8.9%', change: '+4.7%' },
          avgSession: { value: '14:22', change: '+31.8%' }
        },
        thismonth: {
          activeVisitors: 613,
          bounceRate: { value: '15.8%', change: '-6.7%' },
          conversionRate: { value: '8.4%', change: '+3.8%' },
          avgSession: { value: '13:55', change: '+28.9%' }
        },
        lastmonth: {
          activeVisitors: 487,
          bounceRate: { value: '17.3%', change: '-5.2%' },
          conversionRate: { value: '7.8%', change: '+2.7%' },
          avgSession: { value: '13:10', change: '+24.3%' }
        }
      },
      'Myntra': {
        last7days: {
          activeVisitors: 83,
          bounceRate: { value: '34.6%', change: '-1.8%' },
          conversionRate: { value: '4.2%', change: '+0.9%' },
          avgSession: { value: '3:12', change: '+6.8%' }
        },
        last30days: {
          activeVisitors: 246,
          bounceRate: { value: '31.2%', change: '-3.5%' },
          conversionRate: { value: '4.7%', change: '+1.7%' },
          avgSession: { value: '3:38', change: '+10.5%' }
        },
        last90days: {
          activeVisitors: 523,
          bounceRate: { value: '28.9%', change: '-5.1%' },
          conversionRate: { value: '5.3%', change: '+2.6%' },
          avgSession: { value: '4:02', change: '+14.3%' }
        },
        thismonth: {
          activeVisitors: 225,
          bounceRate: { value: '32.4%', change: '-3.1%' },
          conversionRate: { value: '4.5%', change: '+1.5%' },
          avgSession: { value: '3:30', change: '+9.7%' }
        },
        lastmonth: {
          activeVisitors: 185,
          bounceRate: { value: '33.7%', change: '-2.2%' },
          conversionRate: { value: '4.3%', change: '+1.1%' },
          avgSession: { value: '3:20', change: '+7.9%' }
        }
      },
      'Instagram': {
        last7days: {
          activeVisitors: 276,
          bounceRate: { value: '25.3%', change: '-3.7%' },
          conversionRate: { value: '1.8%', change: '+0.4%' },
          avgSession: { value: '7:32', change: '+13.5%' }
        },
        last30days: {
          activeVisitors: 834,
          bounceRate: { value: '22.7%', change: '-5.2%' },
          conversionRate: { value: '2.3%', change: '+0.9%' },
          avgSession: { value: '8:14', change: '+17.8%' }
        },
        last90days: {
          activeVisitors: 1738,
          bounceRate: { value: '19.4%', change: '-7.8%' },
          conversionRate: { value: '2.9%', change: '+1.5%' },
          avgSession: { value: '8:57', change: '+22.3%' }
        },
        thismonth: {
          activeVisitors: 915,
          bounceRate: { value: '21.8%', change: '-5.9%' },
          conversionRate: { value: '2.5%', change: '+1.1%' },
          avgSession: { value: '8:30', change: '+19.2%' }
        },
        lastmonth: {
          activeVisitors: 752,
          bounceRate: { value: '23.9%', change: '-4.5%' },
          conversionRate: { value: '2.1%', change: '+0.7%' },
          avgSession: { value: '7:58', change: '+15.9%' }
        }
      },
      'Twitter': {
        last7days: {
          activeVisitors: 142,
          bounceRate: { value: '32.7%', change: '-2.2%' },
          conversionRate: { value: '2.5%', change: '+0.6%' },
          avgSession: { value: '4:18', change: '+9.7%' }
        },
        last30days: {
          activeVisitors: 427,
          bounceRate: { value: '29.5%', change: '-4.1%' },
          conversionRate: { value: '3.0%', change: '+1.1%' },
          avgSession: { value: '4:52', change: '+13.4%' }
        },
        last90days: {
          activeVisitors: 892,
          bounceRate: { value: '27.1%', change: '-6.3%' },
          conversionRate: { value: '3.6%', change: '+1.9%' },
          avgSession: { value: '5:25', change: '+17.6%' }
        },
        thismonth: {
          activeVisitors: 462,
          bounceRate: { value: '28.8%', change: '-4.7%' },
          conversionRate: { value: '3.2%', change: '+1.3%' },
          avgSession: { value: '5:05', change: '+14.9%' }
        },
        lastmonth: {
          activeVisitors: 381,
          bounceRate: { value: '30.6%', change: '-3.2%' },
          conversionRate: { value: '2.8%', change: '+0.8%' },
          avgSession: { value: '4:35', change: '+11.6%' }
        }
      },
      'Walmart': {
        last7days: {
          activeVisitors: 96,
          bounceRate: { value: '33.5%', change: '-2.8%' },
          conversionRate: { value: '3.4%', change: '+0.7%' },
          avgSession: { value: '2:48', change: '+7.5%' }
        },
        last30days: {
          activeVisitors: 287,
          bounceRate: { value: '30.1%', change: '-4.5%' },
          conversionRate: { value: '3.9%', change: '+1.2%' },
          avgSession: { value: '3:15', change: '+11.2%' }
        },
        last90days: {
          activeVisitors: 618,
          bounceRate: { value: '27.8%', change: '-6.2%' },
          conversionRate: { value: '4.5%', change: '+2.0%' },
          avgSession: { value: '3:42', change: '+15.8%' }
        },
        thismonth: {
          activeVisitors: 315,
          bounceRate: { value: '29.5%', change: '-5.1%' },
          conversionRate: { value: '4.1%', change: '+1.4%' },
          avgSession: { value: '3:24', change: '+12.8%' }
        },
        lastmonth: {
          activeVisitors: 265,
          bounceRate: { value: '31.7%', change: '-3.6%' },
          conversionRate: { value: '3.7%', change: '+0.9%' },
          avgSession: { value: '3:02', change: '+9.3%' }
        }
      },
      'Shopify': {
        last7days: {
          activeVisitors: 64,
          bounceRate: { value: '29.8%', change: '-3.5%' },
          conversionRate: { value: '5.1%', change: '+1.4%' },
          avgSession: { value: '4:05', change: '+11.3%' }
        },
        last30days: {
          activeVisitors: 193,
          bounceRate: { value: '26.4%', change: '-5.3%' },
          conversionRate: { value: '5.7%', change: '+2.1%' },
          avgSession: { value: '4:32', change: '+15.6%' }
        },
        last90days: {
          activeVisitors: 428,
          bounceRate: { value: '24.1%', change: '-7.2%' },
          conversionRate: { value: '6.4%', change: '+3.0%' },
          avgSession: { value: '5:08', change: '+20.2%' }
        },
        thismonth: {
          activeVisitors: 213,
          bounceRate: { value: '25.7%', change: '-5.9%' },
          conversionRate: { value: '5.9%', change: '+2.3%' },
          avgSession: { value: '4:45', change: '+16.9%' }
        },
        lastmonth: {
          activeVisitors: 178,
          bounceRate: { value: '27.9%', change: '-4.2%' },
          conversionRate: { value: '5.4%', change: '+1.7%' },
          avgSession: { value: '4:18', change: '+13.2%' }
        }
      },
      'Airbnb': {
        last7days: {
          activeVisitors: 78,
          bounceRate: { value: '27.2%', change: '-4.2%' },
          conversionRate: { value: '6.3%', change: '+1.8%' },
          avgSession: { value: '5:25', change: '+14.8%' }
        },
        last30days: {
          activeVisitors: 235,
          bounceRate: { value: '24.8%', change: '-6.1%' },
          conversionRate: { value: '6.9%', change: '+2.5%' },
          avgSession: { value: '6:10', change: '+18.7%' }
        },
        last90days: {
          activeVisitors: 518,
          bounceRate: { value: '22.3%', change: '-8.4%' },
          conversionRate: { value: '7.6%', change: '+3.4%' },
          avgSession: { value: '6:42', change: '+23.1%' }
        },
        thismonth: {
          activeVisitors: 255,
          bounceRate: { value: '24.2%', change: '-6.7%' },
          conversionRate: { value: '7.1%', change: '+2.7%' },
          avgSession: { value: '6:25', change: '+19.5%' }
        },
        lastmonth: {
          activeVisitors: 212,
          bounceRate: { value: '25.9%', change: '-5.3%' },
          conversionRate: { value: '6.6%', change: '+2.1%' },
          avgSession: { value: '5:48', change: '+16.3%' }
        }
      }
    };
    
    // Get website data for the specific period or default to last7days
    const websiteData = websiteDataByPeriod[websiteName] || {};
    const periodData = websiteData[period] || websiteData.last7days || {
      activeVisitors: 28,
      bounceRate: { value: '35.2%', change: '-4.8%' },
      conversionRate: { value: '3.7%', change: '+0.8%' },
      avgSession: { value: '2:15', change: '+12.5%' }
    };
    
    return periodData;
  };
  
  // Get analytics summary for this website with the correct time period using normalized date range
  const analyticsSummary = getAnalyticsSummaryForWebsite(websiteId, website?.name, normalizedDateRange);
  
  // Function to get data source label
  const getDataSourceLabel = () => {
    if (websiteId && website) {
      return website.name;
    } else {
      return 'Real-time Analytics';
    }
  };

  // Get the name of the data provider
  const getDataProvider = (metricType: 'visitors' | 'conversion' | 'bounce' | 'session' | string): string => {
    // This would be dynamic in a real implementation based on the actual data source
    const providers: Record<string, string> = {
      visitors: 'Real-time Tracking',
      conversion: 'Google Analytics',
      bounce: 'Adobe Analytics',
      session: 'Mixpanel'
    };
    return providers[metricType] || 'Internal Analytics';
  };

  return (
    <div id="metrics-overview-container">
      <div className="flex justify-between items-center mb-4">
        <DataSourceHeader sourceName={getDataSourceLabel()} />
        <ExportButton 
          targetId="metrics-overview-container"
          filename={`${websiteId ? website?.name?.toLowerCase() || 'external' : 'realtime'}-metrics-${normalizedDateRange}`}
          reportType="metrics-overview"
          buttonText="Export Metrics"
        />
      </div>
      
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-3 lg:grid-cols-3 mb-6">
        {/* Conversion Rate Metric */}
        <Card className="relative overflow-hidden border-green-200 hover:shadow-md transition-shadow">
          <DataSourceBadge 
            sourceName={getDataSourceLabel()} 
            providerName={getDataProvider('conversion')} 
            className="from-green-600 to-green-700"
          />
          <CardContent className="pt-8">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-green-100 rounded-md p-3">
                <ShoppingCart className="h-5 w-5 text-green-600" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <MetricWithTooltip
                  label="Conversion Rate"
                  value={analyticsSummary.conversionRate.value}
                  metricName="conversionRate"
                  websiteName={website?.name}
                  trend={analyticsSummary.conversionRate.change}
                  trendLabel="vs last week"
                  colorClass="text-green-600"
                />
              </div>
            </div>
          </CardContent>
          <div className="bg-gray-50 px-4 py-2 sm:px-6 flex justify-between items-center">
            <div className="text-sm text-gray-500">vs last week</div>
            <div>
              <ArrowUp className="h-4 w-4 text-green-500" />
            </div>
          </div>
        </Card>

        {/* Bounce Rate Metric */}
        <Card className="relative overflow-hidden border-yellow-200 hover:shadow-md transition-shadow">
          <DataSourceBadge 
            sourceName={getDataSourceLabel()} 
            providerName={getDataProvider('bounce')} 
            className="from-yellow-600 to-yellow-700"
          />
          <CardContent className="pt-8">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-yellow-100 rounded-md p-3">
                <ArrowLeftCircle className="h-5 w-5 text-yellow-600" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <MetricWithTooltip
                  label="Bounce Rate"
                  value={analyticsSummary.bounceRate.value}
                  metricName="bounceRate"
                  websiteName={website?.name}
                  trend={analyticsSummary.bounceRate.change}
                  trendLabel="vs last week"
                  colorClass="text-yellow-600"
                />
              </div>
            </div>
          </CardContent>
          <div className="bg-gray-50 px-4 py-2 sm:px-6 flex justify-between items-center">
            <div className="text-sm text-gray-500">vs last week</div>
            <div>
              <ArrowUp className="h-4 w-4 text-red-500" />
            </div>
          </div>
        </Card>

        {/* Avg. Session Duration Metric */}
        <Card className="relative overflow-hidden border-indigo-200 hover:shadow-md transition-shadow">
          <DataSourceBadge 
            sourceName={getDataSourceLabel()} 
            providerName={getDataProvider('session')} 
            className="from-indigo-600 to-indigo-700"
          />
          <CardContent className="pt-8">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-indigo-100 rounded-md p-3">
                <Clock className="h-5 w-5 text-indigo-600" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <MetricWithTooltip
                  label="Avg. Session"
                  value={analyticsSummary.avgSession.value}
                  metricName="avgSessionDuration"
                  websiteName={website?.name}
                  trend={Number(analyticsSummary.avgSession.change.replace(/[^0-9.-]+/g, ''))}
                  trendLabel="vs last week"
                  colorClass="text-indigo-600"
                />
              </div>
            </div>
          </CardContent>
          <div className="bg-gray-50 px-4 py-2 sm:px-6 flex justify-between items-center">
            <div className="text-sm text-gray-500">vs last week</div>
            <div>
              <ArrowUp className="h-4 w-4 text-green-500" />
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
