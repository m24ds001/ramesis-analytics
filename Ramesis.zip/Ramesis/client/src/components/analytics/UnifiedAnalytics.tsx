import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Skeleton } from '@/components/ui/skeleton';
import { ExternalLink, RefreshCw, AlertCircle } from 'lucide-react';
import { useActiveUsers } from '@/hooks/use-realtime';
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';

interface UnifiedAnalyticsProps {
  className?: string;
  websiteId?: string;
}

interface AnalyticsData {
  source: string;
  activeUsers: number;
  pageViews: number;
  bounceRate: number;
  conversionRate: number;
  averageSessionDuration: number;
  isLoading: boolean;
  error: string | null;
}

// Initial data structure for each provider
const initialData: AnalyticsData[] = [
  {
    source: 'Google Analytics',
    activeUsers: 0,
    pageViews: 0,
    bounceRate: 0,
    conversionRate: 0,
    averageSessionDuration: 0,
    isLoading: true,
    error: null
  },
  {
    source: 'Adobe Analytics',
    activeUsers: 0,
    pageViews: 0,
    bounceRate: 0,
    conversionRate: 0,
    averageSessionDuration: 0,
    isLoading: true,
    error: null
  },
  {
    source: 'Mixpanel',
    activeUsers: 0,
    pageViews: 0,
    bounceRate: 0,
    conversionRate: 0,
    averageSessionDuration: 0,
    isLoading: true,
    error: null
  }
];

// Colors for charts
const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8'];

export default function UnifiedAnalytics({ className, websiteId }: UnifiedAnalyticsProps) {
  const [analyticsData, setAnalyticsData] = useState<AnalyticsData[]>(initialData);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [activeTab, setActiveTab] = useState('overview');
  
  // Get real-time active user data from websocket
  const { activeUsers } = useActiveUsers();
  
  // Format the data for comparison charts
  const getComparisonData = (metric: keyof AnalyticsData) => {
    return analyticsData.map(provider => ({
      name: provider.source,
      value: provider[metric] as number
    }));
  };
  
  // Calculate aggregated data across providers (taking the max value for each metric)
  const getAggregatedData = () => {
    const availableData = analyticsData.filter(data => !data.isLoading && !data.error);
    
    if (availableData.length === 0) return null;
    
    return {
      activeUsers: Math.max(...availableData.map(data => data.activeUsers)),
      pageViews: Math.max(...availableData.map(data => data.pageViews)),
      bounceRate: availableData.reduce((sum, data) => sum + data.bounceRate, 0) / availableData.length,
      conversionRate: availableData.reduce((sum, data) => sum + data.conversionRate, 0) / availableData.length,
      averageSessionDuration: Math.max(...availableData.map(data => data.averageSessionDuration))
    };
  };
  
  // Fetch data from each analytics provider
  useEffect(() => {
    const fetchAnalyticsData = async () => {
      setIsRefreshing(true);
      
      try {
        // Fetch Google Analytics data
        const gaResponse = await fetch(`/api/ga4-data${websiteId ? `?websiteId=${websiteId}` : ''}`);
        if (gaResponse.ok) {
          const gaData = await gaResponse.json();
          updateProviderData('Google Analytics', gaData);
        } else {
          setProviderError('Google Analytics', 'Failed to fetch Google Analytics data');
        }
        
        // Fetch Adobe Analytics data
        const adobeResponse = await fetch(`/api/adobe-analytics-data${websiteId ? `?websiteId=${websiteId}` : ''}`);
        if (adobeResponse.ok) {
          const adobeData = await adobeResponse.json();
          updateProviderData('Adobe Analytics', adobeData);
        } else {
          setProviderError('Adobe Analytics', 'Failed to fetch Adobe Analytics data');
        }
        
        // Fetch Mixpanel data
        const mixpanelResponse = await fetch(`/api/mixpanel-data${websiteId ? `?websiteId=${websiteId}` : ''}`);
        if (mixpanelResponse.ok) {
          const mixpanelData = await mixpanelResponse.json();
          updateProviderData('Mixpanel', mixpanelData);
        } else {
          setProviderError('Mixpanel', 'Failed to fetch Mixpanel data');
        }
      } catch (error) {
        console.error('Error fetching analytics data:', error);
      } finally {
        setIsRefreshing(false);
      }
    };
    
    // Helper to update a specific provider's data
    const updateProviderData = (source: string, data: any) => {
      setAnalyticsData(prevData => 
        prevData.map(provider => 
          provider.source === source 
            ? { 
                ...provider, 
                ...data, 
                isLoading: false, 
                error: null,
                // Use real-time active users from WebSocket for Google Analytics
                activeUsers: source === 'Google Analytics' ? activeUsers : data.activeUsers
              } 
            : provider
        )
      );
    };
    
    // Helper to set error for a specific provider
    const setProviderError = (source: string, errorMessage: string) => {
      setAnalyticsData(prevData => 
        prevData.map(provider => 
          provider.source === source 
            ? { ...provider, isLoading: false, error: errorMessage } 
            : provider
        )
      );
    };
    
    fetchAnalyticsData();
    
    // Refresh data every 60 seconds
    const interval = setInterval(fetchAnalyticsData, 60000);
    
    return () => clearInterval(interval);
  }, [websiteId, activeUsers]);
  
  // Format session duration to readable format
  const formatDuration = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = Math.round(seconds % 60);
    return `${minutes}m ${remainingSeconds}s`;
  };
  
  // Handle manual refresh
  const handleRefresh = async () => {
    setIsRefreshing(true);
    setAnalyticsData(initialData);
    
    // Small delay to show loading state
    setTimeout(async () => {
      try {
        // Fetch Google Analytics data
        const gaResponse = await fetch(`/api/ga4-data${websiteId ? `?websiteId=${websiteId}` : ''}`);
        if (gaResponse.ok) {
          const gaData = await gaResponse.json();
          updateProviderData('Google Analytics', gaData);
        } else {
          setProviderError('Google Analytics', 'Failed to fetch Google Analytics data');
        }
        
        // Fetch Adobe Analytics data
        const adobeResponse = await fetch(`/api/adobe-analytics-data${websiteId ? `?websiteId=${websiteId}` : ''}`);
        if (adobeResponse.ok) {
          const adobeData = await adobeResponse.json();
          updateProviderData('Adobe Analytics', adobeData);
        } else {
          setProviderError('Adobe Analytics', 'Failed to fetch Adobe Analytics data');
        }
        
        // Fetch Mixpanel data
        const mixpanelResponse = await fetch(`/api/mixpanel-data${websiteId ? `?websiteId=${websiteId}` : ''}`);
        if (mixpanelResponse.ok) {
          const mixpanelData = await mixpanelResponse.json();
          updateProviderData('Mixpanel', mixpanelData);
        } else {
          setProviderError('Mixpanel', 'Failed to fetch Mixpanel data');
        }
      } catch (error) {
        console.error('Error refreshing analytics data:', error);
      } finally {
        setIsRefreshing(false);
      }
    }, 500);
    
    // Helper to update a specific provider's data
    const updateProviderData = (source: string, data: any) => {
      setAnalyticsData(prevData => 
        prevData.map(provider => 
          provider.source === source 
            ? { 
                ...provider, 
                ...data, 
                isLoading: false, 
                error: null,
                // Use real-time active users from WebSocket for Google Analytics
                activeUsers: source === 'Google Analytics' ? activeUsers : data.activeUsers
              } 
            : provider
        )
      );
    };
    
    // Helper to set error for a specific provider
    const setProviderError = (source: string, errorMessage: string) => {
      setAnalyticsData(prevData => 
        prevData.map(provider => 
          provider.source === source 
            ? { ...provider, isLoading: false, error: errorMessage } 
            : provider
        )
      );
    };
  };
  
  // Get aggregated data from all providers
  const aggregatedData = getAggregatedData();
  
  return (
    <Card className={className}>
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle className="text-xl">Unified Analytics</CardTitle>
            <CardDescription>
              Combined data from Google Analytics, Adobe Analytics, and Mixpanel
            </CardDescription>
          </div>
          <div 
            className={`cursor-pointer p-2 hover:bg-gray-100 rounded-full ${isRefreshing ? 'animate-spin' : ''}`}
            onClick={handleRefresh}
          >
            <RefreshCw size={20} />
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="comparison">Provider Comparison</TabsTrigger>
            <TabsTrigger value="details">Provider Details</TabsTrigger>
          </TabsList>
          
          <TabsContent value="overview" className="space-y-4">
            {aggregatedData ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <Card>
                  <CardHeader className="py-4">
                    <CardTitle className="text-sm font-medium">Active Users</CardTitle>
                  </CardHeader>
                  <CardContent className="py-2">
                    <div className="text-3xl font-bold">{aggregatedData.activeUsers}</div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="py-4">
                    <CardTitle className="text-sm font-medium">Page Views</CardTitle>
                  </CardHeader>
                  <CardContent className="py-2">
                    <div className="text-3xl font-bold">{aggregatedData.pageViews.toLocaleString()}</div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="py-4">
                    <CardTitle className="text-sm font-medium">Bounce Rate</CardTitle>
                  </CardHeader>
                  <CardContent className="py-2">
                    <div className="text-3xl font-bold">{aggregatedData.bounceRate.toFixed(2)}%</div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="py-4">
                    <CardTitle className="text-sm font-medium">Conversion Rate</CardTitle>
                  </CardHeader>
                  <CardContent className="py-2">
                    <div className="text-3xl font-bold">{aggregatedData.conversionRate.toFixed(2)}%</div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="py-4">
                    <CardTitle className="text-sm font-medium">Avg. Session Duration</CardTitle>
                  </CardHeader>
                  <CardContent className="py-2">
                    <div className="text-3xl font-bold">{formatDuration(aggregatedData.averageSessionDuration)}</div>
                  </CardContent>
                </Card>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="text-center py-8">
                  <Skeleton className="h-8 w-40 mx-auto mb-4" />
                  <Skeleton className="h-4 w-60 mx-auto" />
                </div>
              </div>
            )}
            
            <div className="h-80 mt-8">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={getComparisonData('activeUsers')}
                  margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip formatter={(value) => [value, 'Active Users']} />
                  <Legend />
                  <Bar dataKey="value" name="Active Users" fill="#0088FE">
                    {getComparisonData('activeUsers').map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </TabsContent>
          
          <TabsContent value="comparison" className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="h-80">
                <div className="font-medium mb-2">Active Users by Provider</div>
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={getComparisonData('activeUsers')}
                      cx="50%"
                      cy="50%"
                      labelLine={true}
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      outerRadius={80}
                      dataKey="value"
                    >
                      {getComparisonData('activeUsers').map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => [value, 'Active Users']} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              
              <div className="h-80">
                <div className="font-medium mb-2">Page Views by Provider</div>
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={getComparisonData('pageViews')}
                      cx="50%"
                      cy="50%"
                      labelLine={true}
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      outerRadius={80}
                      dataKey="value"
                    >
                      {getComparisonData('pageViews').map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => [value, 'Page Views']} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>
            
            <div className="h-80">
              <div className="font-medium mb-2">Bounce Rate Comparison</div>
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={getComparisonData('bounceRate')}
                  margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip formatter={(value) => [`${value.toFixed(2)}%`, 'Bounce Rate']} />
                  <Legend />
                  <Bar dataKey="value" name="Bounce Rate" fill="#FF8042">
                    {getComparisonData('bounceRate').map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </TabsContent>
          
          <TabsContent value="details" className="space-y-6">
            {analyticsData.map((provider, index) => (
              <Card key={provider.source} className="overflow-hidden">
                <CardHeader className="py-4 bg-gray-50">
                  <CardTitle className="text-lg flex items-center justify-between">
                    {provider.source}
                    <ExternalLink size={16} className="text-gray-400" />
                  </CardTitle>
                </CardHeader>
                <CardContent className="py-6">
                  {provider.error ? (
                    <div className="flex items-center text-amber-600 p-3 bg-amber-50 rounded-md">
                      <AlertCircle size={18} className="mr-2" />
                      <span>{provider.error}</span>
                    </div>
                  ) : provider.isLoading ? (
                    <div className="space-y-4">
                      <Skeleton className="h-4 w-full" />
                      <Skeleton className="h-4 w-3/4" />
                      <Skeleton className="h-4 w-1/2" />
                    </div>
                  ) : (
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                      <div>
                        <div className="text-sm font-medium text-gray-500">Active Users</div>
                        <div className="text-2xl font-bold mt-1">{provider.activeUsers}</div>
                      </div>
                      <div>
                        <div className="text-sm font-medium text-gray-500">Page Views</div>
                        <div className="text-2xl font-bold mt-1">{provider.pageViews.toLocaleString()}</div>
                      </div>
                      <div>
                        <div className="text-sm font-medium text-gray-500">Bounce Rate</div>
                        <div className="text-2xl font-bold mt-1">{provider.bounceRate.toFixed(2)}%</div>
                      </div>
                      <div>
                        <div className="text-sm font-medium text-gray-500">Conversion Rate</div>
                        <div className="text-2xl font-bold mt-1">{provider.conversionRate.toFixed(2)}%</div>
                      </div>
                      <div>
                        <div className="text-sm font-medium text-gray-500">Avg. Session Duration</div>
                        <div className="text-2xl font-bold mt-1">{formatDuration(provider.averageSessionDuration)}</div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}