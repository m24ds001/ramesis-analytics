import React from 'react';
import { CheckCircle2, AlertTriangle, TrendingUp, TrendingDown, ArrowRightCircle, HelpCircle } from 'lucide-react';

export interface MetricTooltipContentProps {
  title: string;
  description: string;
  impact?: 'positive' | 'negative' | 'neutral';
  trend?: number;
  recommendations?: string[];
  dataSource?: string;
}

export function MetricTooltipContent({
  title,
  description,
  impact = 'neutral',
  trend,
  recommendations = [],
  dataSource,
}: MetricTooltipContentProps) {
  const getImpactIcon = () => {
    switch (impact) {
      case 'positive':
        return <CheckCircle2 className="text-green-500 h-4 w-4" />;
      case 'negative':
        return <AlertTriangle className="text-amber-500 h-4 w-4" />;
      default:
        return <HelpCircle className="text-gray-400 h-4 w-4" />;
    }
  };

  const getTrendIcon = () => {
    if (!trend) return null;
    return trend > 0 ? (
      <TrendingUp className="text-green-500 h-4 w-4" />
    ) : (
      <TrendingDown className="text-red-500 h-4 w-4" />
    );
  };

  return (
    <div className="w-64 space-y-2">
      <div className="flex justify-between items-center">
        <div className="font-medium">{title}</div>
        <div className="flex items-center gap-1">
          {getImpactIcon()}
          {getTrendIcon()}
        </div>
      </div>
      
      <p className="text-xs text-gray-200">{description}</p>
      
      {recommendations.length > 0 && (
        <div className="pt-1">
          <p className="text-xs font-medium text-gray-100 mb-1">Quick suggestions:</p>
          <ul className="pl-1 space-y-1">
            {recommendations.map((rec, index) => (
              <li key={index} className="text-xs flex items-start gap-1">
                <ArrowRightCircle className="text-primary-400 h-3 w-3 mt-0.5 flex-shrink-0" />
                <span>{rec}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
      
      {dataSource && (
        <div className="pt-1 text-xs text-gray-400">
          Source: {dataSource}
        </div>
      )}
    </div>
  );
}