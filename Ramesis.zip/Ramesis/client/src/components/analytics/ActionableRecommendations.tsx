import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Recommendation } from '@shared/schema';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { queryClient } from '@/lib/queryClient';

interface ActionableRecommendationsProps {
  recommendations: Recommendation[];
  websiteId?: number | null;
}

export default function ActionableRecommendations({ recommendations, websiteId }: ActionableRecommendationsProps) {
  const { toast } = useToast();
  
  const implementRecommendation = async (id: number) => {
    try {
      await apiRequest('PATCH', `/api/recommendations/${id}/implement`, {});
      
      // Invalidate the recommendations cache to refresh the data
      queryClient.invalidateQueries({ queryKey: ['/api/recommendations'] });
      
      toast({
        title: "Recommendation Implemented",
        description: "The recommendation has been marked as implemented.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to implement recommendation. Please try again.",
        variant: "destructive",
      });
      console.error(error);
    }
  };
  
  // Get recommendation icon based on category
  const getRecommendationIcon = (category: string) => {
    switch (category) {
      case 'performance':
        return { icon: 'ri-speed-line', bgColor: 'bg-primary-500' };
      case 'marketing':
        return { icon: 'ri-user-voice-line', bgColor: 'bg-green-500' };
      case 'testing':
        return { icon: 'ri-test-tube-line', bgColor: 'bg-yellow-500' };
      case 'content':
        return { icon: 'ri-file-text-line', bgColor: 'bg-indigo-500' };
      case 'design':
        return { icon: 'ri-paint-brush-line', bgColor: 'bg-purple-500' };
      default:
        return { icon: 'ri-lightbulb-line', bgColor: 'bg-blue-500' };
    }
  };
  
  // Filter for unimplemented recommendations
  const unimplementedRecs = recommendations.filter(rec => !rec.implemented);
  
  return (
    <Card className="mb-6">
      <CardHeader className="px-4 py-5 border-b border-gray-200 sm:px-6 flex flex-row items-center justify-between">
        <CardTitle className="text-lg leading-6 font-medium text-gray-900">Actionable Recommendations</CardTitle>
        <div>
          <Badge variant="outline" className="bg-green-100 text-green-800">
            {unimplementedRecs.length} New
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="px-4 py-5 sm:p-6">
        <div className="flow-root">
          <ul className="-mb-8">
            {unimplementedRecs.slice(0, 3).map((rec, index) => {
              const { icon, bgColor } = getRecommendationIcon(rec.category);
              return (
                <li key={rec.id} className={`relative ${index < unimplementedRecs.length - 1 ? 'pb-8' : ''}`}>
                  <div className="relative flex space-x-3">
                    <div>
                      <span className={`h-8 w-8 rounded-full ${bgColor} flex items-center justify-center`}>
                        <i className={`${icon} text-white`}></i>
                      </span>
                    </div>
                    <div className="min-w-0 flex-1 pt-1.5 flex justify-between space-x-4">
                      <div>
                        <p className="text-sm text-gray-900">{rec.title}</p>
                        <p className="mt-1 text-sm text-gray-500">{rec.description}</p>
                      </div>
                      <div className="text-right text-sm whitespace-nowrap text-gray-500">
                        <Button 
                          variant="link" 
                          className="text-primary-600 hover:text-primary-800 font-medium"
                          onClick={() => implementRecommendation(rec.id)}
                        >
                          {rec.category === 'testing' ? 'Create Test' : 'Implement'}
                        </Button>
                      </div>
                    </div>
                  </div>
                </li>
              );
            })}
            
            {unimplementedRecs.length === 0 && (
              <li className="text-center py-4">
                <p className="text-gray-500">No pending recommendations</p>
              </li>
            )}
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}
