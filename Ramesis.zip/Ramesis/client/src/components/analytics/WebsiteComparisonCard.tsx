import React, { useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ExportableChart } from '@/components/ui/exportable-chart';
import { DataSourceBadge } from '@/components/ui/data-source-badge';
import { ArrowUpRight, ArrowDownRight, Minus, BarChart2, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { exportElementAsImage } from '@/lib/exportVisual';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer, 
  Cell 
} from 'recharts';

interface WebsiteMetric {
  name: string;
  value: number;
  change?: number;
  trend?: 'up' | 'down' | 'neutral';
  color?: string;
}

interface WebsiteComparisonCardProps {
  title: string;
  description?: string;
  metrics: WebsiteMetric[];
  metricName: string;
  dataSource?: string;
  metricFormatter?: (value: number) => string;
  sortOrder?: 'asc' | 'desc';
  highlightIndex?: number;
}

export function WebsiteComparisonCard({
  title,
  description,
  metrics,
  metricName,
  dataSource = 'Comparative Analysis',
  metricFormatter = (value) => `${value}%`,
  sortOrder = 'desc',
  highlightIndex
}: WebsiteComparisonCardProps) {
  // Sort metrics if requested
  const sortedMetrics = [...metrics].sort((a, b) => {
    return sortOrder === 'desc' 
      ? b.value - a.value 
      : a.value - b.value;
  });
  
  // Get default colors for bars
  const getDefaultColor = (index: number) => {
    const colors = [
      '#3B82F6', // blue
      '#10B981', // green
      '#F59E0B', // amber
      '#EF4444', // red
      '#8B5CF6', // purple
      '#EC4899', // pink
      '#06B6D4', // cyan
      '#F97316', // orange
      '#14B8A6', // teal
      '#6366F1'  // indigo
    ];
    return colors[index % colors.length];
  };

  // Get trend icon
  const getTrendIcon = (trend?: 'up' | 'down' | 'neutral', size = 16) => {
    if (trend === 'up') return <ArrowUpRight size={size} className="text-green-500" />;
    if (trend === 'down') return <ArrowDownRight size={size} className="text-red-500" />;
    return <Minus size={size} className="text-gray-400" />;
  };

  return (
    <Card className="overflow-hidden">
      <DataSourceBadge 
        sourceName="All Websites" 
        providerName={dataSource} 
        className="from-purple-600 to-indigo-700"
      />
      <CardHeader className="px-6 py-5 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-lg font-medium text-gray-900">{title}</CardTitle>
            {description && <p className="text-sm text-gray-500 mt-1">{description}</p>}
          </div>
          <BarChart2 className="h-5 w-5 text-gray-400" />
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <ExportableChart 
          title={`${title} - Website Comparison`}
          fileName={`website-comparison-${metricName}`}
        >
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={sortedMetrics}
                layout="vertical"
                margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} />
                <XAxis type="number" domain={[0, 'dataMax']} />
                <YAxis 
                  dataKey="name" 
                  type="category" 
                  width={120}
                  tick={{ fontSize: 12 }}
                />
                <Tooltip 
                  formatter={(value) => [metricFormatter(value as number), metricName]}
                  labelFormatter={(label) => `Website: ${label}`}
                />
                <Legend />
                <Bar 
                  dataKey="value" 
                  name={metricName}
                  radius={[0, 4, 4, 0]}
                >
                  {sortedMetrics.map((entry, index) => (
                    <Cell 
                      key={`cell-${index}`} 
                      fill={entry.color || getDefaultColor(index)}
                      stroke={entry.color || getDefaultColor(index)}
                      opacity={highlightIndex === index ? 1 : 0.75}
                      strokeWidth={highlightIndex === index ? 2 : 1}
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </ExportableChart>
        
        {/* List view of the same data with export functionality */}
        <div className="mt-6 space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-medium text-gray-900">Rankings</h4>
            <Button 
              variant="ghost" 
              size="sm"
              className="text-xs h-7 px-2"
              onClick={async () => {
                const element = document.getElementById(`${title.replace(/\s+/g, '-').toLowerCase()}-rankings`);
                if (element) {
                  await exportElementAsImage(element, {
                    fileName: `${title.replace(/\s+/g, '-').toLowerCase()}-rankings`,
                    includeTimestamp: true,
                  });
                }
              }}
            >
              <Download className="h-3.5 w-3.5 mr-1" />
              Export Rankings
            </Button>
          </div>
          
          <div 
            id={`${title.replace(/\s+/g, '-').toLowerCase()}-rankings`}
            className="space-y-2 p-4 bg-white border border-gray-100 rounded-md"
          >
            <div className="mb-2 pb-2 border-b border-gray-100">
              <h3 className="text-sm font-medium text-gray-900">{title} Rankings</h3>
              <p className="text-xs text-gray-500">{dataSource}</p>
            </div>
            
            {sortedMetrics.map((metric, index) => (
              <div 
                key={metric.name}
                className={`flex items-center justify-between p-3 rounded-md ${
                  highlightIndex === index 
                    ? 'bg-indigo-50 border border-indigo-100' 
                    : 'bg-gray-50'
                }`}
              >
                <div className="flex items-center">
                  <div className="flex-shrink-0 h-6 w-6 flex items-center justify-center rounded-full bg-gray-200 text-gray-800 font-medium text-xs">
                    {index + 1}
                  </div>
                  <span className="ml-3 text-sm font-medium text-gray-900">{metric.name}</span>
                </div>
                <div className="flex items-center">
                  <span className="text-sm font-medium text-gray-900 mr-2">
                    {metricFormatter(metric.value)}
                  </span>
                  {metric.change && (
                    <div className="flex items-center text-xs">
                      {getTrendIcon(metric.trend)}
                      <span 
                        className={`ml-1 ${
                          metric.trend === 'up' ? 'text-green-500' : 
                          metric.trend === 'down' ? 'text-red-500' : 
                          'text-gray-500'
                        }`}
                      >
                        {metric.change > 0 ? '+' : ''}{metric.change}%
                      </span>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}