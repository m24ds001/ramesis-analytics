import React from 'react';
import { Button } from '@/components/ui/button';
import { Download } from 'lucide-react';
import { exportElementAsScreenshot } from '@/lib/screenshot';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { useToast } from '@/hooks/use-toast';

interface ExportButtonProps {
  targetId: string;
  filename?: string;
  reportType?: string;
  className?: string;
  buttonText?: string;
  showIcon?: boolean;
  variant?: 'default' | 'destructive' | 'outline' | 'secondary' | 'ghost' | 'link';
  size?: 'default' | 'sm' | 'lg' | 'icon';
}

/**
 * A reusable button component for exporting any element as a screenshot
 */
const ExportButton: React.FC<ExportButtonProps> = ({
  targetId,
  filename = 'analytics-report',
  reportType = 'general',
  className = '',
  buttonText = 'Export',
  showIcon = true,
  variant = 'outline',
  size = 'sm',
}) => {
  const { toast } = useToast();

  const handleExport = async () => {
    try {
      const success = await exportElementAsScreenshot(targetId, filename, reportType);
      
      if (success) {
        toast({
          title: 'Export successful',
          description: 'Your report has been downloaded as an image',
          variant: 'default',
        });
      } else {
        toast({
          title: 'Export failed',
          description: 'There was a problem exporting your report',
          variant: 'destructive',
        });
      }
    } catch (error) {
      console.error('Error in export:', error);
      toast({
        title: 'Export error',
        description: 'An unexpected error occurred while exporting',
        variant: 'destructive',
      });
    }
  };

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <Button 
            onClick={handleExport} 
            variant={variant} 
            size={size}
            className={className}
          >
            {showIcon && <Download className="h-4 w-4 mr-2" />}
            {buttonText}
          </Button>
        </TooltipTrigger>
        <TooltipContent>
          <p>Save this report as an image</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
};

export default ExportButton;