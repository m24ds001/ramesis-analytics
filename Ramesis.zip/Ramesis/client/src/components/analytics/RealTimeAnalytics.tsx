import React, { useState, useEffect } from 'react';
import { Calendar, CalendarIcon, Filter } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { DataSourceBadge } from '@/components/ui/data-source-badge';
import { useRealTimeAnalytics } from '@/hooks/use-realtime';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

/**
 * Live counter component for real-time metrics
 */
const LiveCounter = ({ label, value }: { label: string, value: number | string }) => {
  return (
    <div className="bg-card p-4 rounded-lg shadow">
      <h3 className="text-sm font-medium text-muted-foreground">{label}</h3>
      <p className="text-2xl font-bold">{value}</p>
    </div>
  );
};

/**
 * Live chart component for real-time data visualization
 */
const LiveChart = ({ data }: { data: any[] }) => {
  return (
    <div className="h-64 w-full bg-card p-4 rounded-lg shadow">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="name" />
          <YAxis />
          <Tooltip />
          <Bar dataKey="value" fill="#8884d8" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};

/**
 * Return empty chart data - no simulation
 */
const getEmptyChartData = () => {
  const data = [];
  const pages = ['Home', 'Products', 'About', 'Contact', 'Blog'];
  
  for (const page of pages) {
    data.push({
      name: page,
      value: 0 // No simulated data, only zeros
    });
  }
  
  return data;
};

/**
 * Real-time analytics dashboard component
 */
const RealTimeAnalytics = ({ websiteId }: { websiteId?: number | null }) => {
  // Use the custom hook to get real-time metrics for the specific website (if any)
  const metrics = useRealTimeAnalytics(websiteId);
  const [chartData, setChartData] = useState(getEmptyChartData());
  const [timeframe, setTimeframe] = useState("15min");
  const [metricType, setMetricType] = useState("pageviews");
  const [filterOpen, setFilterOpen] = useState(false);
  
  useEffect(() => {
    // Update chart data when metrics change
    if (metrics.chartData && metrics.chartData.length > 0) {
      setChartData(metrics.chartData);
    } else {
      // If no data, use empty chart data with zeros
      setChartData(getEmptyChartData());
    }
  }, [metrics]);

  // Format conversion rate as percentage
  const formattedConversionRate = typeof metrics.conversionRate === 'number' 
    ? `${(metrics.conversionRate * 100).toFixed(1)}%` 
    : '0.0%';

  // Get the website name to display in the DataSourceBadge
  const [websiteName, setWebsiteName] = useState<string>("Current Website");
  
  useEffect(() => {
    if (websiteId) {
      // Fetch website name using API from the external-websites endpoint
      fetch(`/api/external-websites/${websiteId}`)
        .then(res => {
          if (!res.ok) {
            throw new Error(`HTTP error ${res.status}`);
          }
          return res.json();
        })
        .then(data => {
          if (data && data.name) {
            setWebsiteName(data.name);
            console.log(`Set website name to: ${data.name}`);
          }
        })
        .catch(err => {
          console.error("Error fetching website name:", err);
          // Fallback to a default name
          setWebsiteName(`Website #${websiteId}`);
        });
    } else {
      setWebsiteName("Current Website");
    }
  }, [websiteId]);

  return (
    <Card className="relative">
      <CardHeader>
        <div className="flex flex-row justify-between items-center">
          <CardTitle>Real-Time Dashboard</CardTitle>
          <div className="flex space-x-2">
            <Select value={timeframe} onValueChange={setTimeframe}>
              <SelectTrigger className="w-[120px]">
                <CalendarIcon className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Timeframe" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="15min">Last 15 min</SelectItem>
                <SelectItem value="30min">Last 30 min</SelectItem>
                <SelectItem value="1hour">Last 1 hour</SelectItem>
                <SelectItem value="today">Today</SelectItem>
              </SelectContent>
            </Select>
            
            <Button variant="outline" size="icon" onClick={() => setFilterOpen(!filterOpen)}>
              <Filter className="h-4 w-4" />
            </Button>
          </div>
        </div>
        
        {/* Error indicator */}
        {metrics.error ? (
          <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-md">
            <div className="text-sm text-red-800">
              <p className="font-medium">Analytics Connection Error:</p>
              <p>{metrics.errorMessage || 'Failed to connect to analytics service. Please check API credentials.'}</p>
            </div>
          </div>
        ) : metrics.activeUsers === 0 && (
          <div className="mt-4 p-3 bg-amber-50 border border-amber-200 rounded-md">
            <div className="text-sm text-amber-800">
              <p className="font-medium">Analytics Connection Status:</p>
              <p>
                No active users detected. This may indicate an issue with the Google Analytics connection.
                Please verify that your API keys are correctly configured.
              </p>
            </div>
          </div>
        )}
        
        {/* Data source explanation */}
        {websiteId && (
          <div className="mt-4 p-3 bg-amber-50 border border-amber-200 rounded-md">
            <div className="text-sm text-amber-800">
              <p className="font-medium">Data Access Information:</p>
              <p>
                Analytics for {websiteName} shows zeros because we don't have authorized access to their Google Analytics data. 
                Only websites that have granted us API access will display real metrics.
              </p>
            </div>
          </div>
        )}
        
        {filterOpen && (
          <div className="mt-4 p-3 bg-muted/30 border rounded-md">
            <div className="text-sm font-medium mb-2">Filter Data</div>
            <div className="flex flex-col sm:flex-row gap-2">
              <Select value={metricType} onValueChange={setMetricType}>
                <SelectTrigger className="w-full sm:w-[180px]">
                  <SelectValue placeholder="Metric Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pageviews">Page Views</SelectItem>
                  <SelectItem value="visitors">Visitors</SelectItem>
                  <SelectItem value="bounces">Bounce Rate</SelectItem>
                  <SelectItem value="conversions">Conversions</SelectItem>
                </SelectContent>
              </Select>
              
              <Button size="sm" variant="default" onClick={() => {
                // Apply the filter and close the filter panel
                console.log(`Filtering by ${metricType} for timeframe ${timeframe}`);
                setFilterOpen(false);
              }}>
                Apply Filters
              </Button>
            </div>
          </div>
        )}
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <LiveCounter label="Active Users" value={metrics.activeUsers} />
          <LiveCounter label="Page Views" value={metrics.pageViews} />
          <LiveCounter label="Conversion Rate" value={formattedConversionRate} />
          <LiveCounter label="Avg. Session (sec)" value={metrics.averageSessionDuration} />
        </div>
        <LiveChart data={chartData} />
      </CardContent>
    </Card>
  );
};

export default RealTimeAnalytics;