import React from 'react';
import { AnimatedTooltip } from '@/components/ui/animated-tooltip';
import { MetricTooltipContent } from '@/components/analytics/MetricTooltipContent';
import { getMetricTooltipContent } from '@/lib/tooltipContent';
import { HelpCircle, TrendingUp, TrendingDown } from 'lucide-react';
import { motion } from 'framer-motion';

interface MetricWithTooltipProps {
  label: string;
  value: string | number;
  metricName: string;
  websiteName?: string;
  trend?: number;
  trendLabel?: string;
  isLoading?: boolean;
  colorClass?: string;
  icon?: React.ReactNode;
}

export function MetricWithTooltip({
  label,
  value,
  metricName,
  websiteName,
  trend,
  trendLabel,
  isLoading = false,
  colorClass = 'text-primary-500',
  icon
}: MetricWithTooltipProps) {
  const tooltipContent = getMetricTooltipContent(metricName, websiteName);
  
  // Add trend to tooltip content if provided
  if (trend !== undefined) {
    tooltipContent.trend = trend;
  }

  const valueVariants = {
    initial: { scale: 1 },
    animate: { 
      scale: [1, 1.05, 1],
      transition: { 
        duration: 0.5,
        ease: "easeInOut",
        repeat: 0,
        repeatType: "reverse" as const
      }
    }
  };

  return (
    <div className="group relative">
      <div className="flex items-start">
        <div className="mr-auto">
          <div className="flex items-center gap-1">
            <h3 className="text-sm font-medium text-gray-500">{label}</h3>
            <AnimatedTooltip
              content={<MetricTooltipContent {...tooltipContent} />}
              icon={<HelpCircle size={14} />}
              iconClassName="text-gray-400 group-hover:opacity-100 opacity-50 transition-opacity ml-1"
            />
          </div>
          
          <div className="flex items-baseline gap-2">
            <motion.div
              className={`text-2xl font-bold ${colorClass}`}
              initial="initial"
              whileHover="animate"
              variants={valueVariants}
            >
              {isLoading ? '...' : value}
            </motion.div>
            
            {trend !== undefined && (
              <div className={`flex items-center text-xs font-medium ${trend >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                {trend >= 0 ? <TrendingUp size={12} className="mr-1" /> : <TrendingDown size={12} className="mr-1" />}
                {trend >= 0 ? '+' : ''}{trend}% 
                {trendLabel && <span className="text-gray-500 ml-1">{trendLabel}</span>}
              </div>
            )}
          </div>
        </div>
        
        {icon && (
          <div className={`h-8 w-8 rounded-full flex items-center justify-center bg-opacity-10 ${colorClass}`}>
            {icon}
          </div>
        )}
      </div>
    </div>
  );
}