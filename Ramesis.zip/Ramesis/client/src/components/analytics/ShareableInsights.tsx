import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Plus } from 'lucide-react';
import ShareableInsightCard, { InsightData } from './ShareableInsightCard';
import { formatPercent, formatNumberWithCommas } from '@/lib/formatters';
import { useToast } from '@/hooks/use-toast';

interface ShareableInsightsProps {
  websiteId?: number | null;
  dateRange?: string;
}

export default function ShareableInsights({ websiteId, dateRange = 'last7days' }: ShareableInsightsProps) {
  const [selectedTab, setSelectedTab] = useState('traffic');
  const { toast } = useToast();
  
  // Get website data if we have a website ID
  const { data: website } = useQuery({
    queryKey: websiteId ? ['/api/external-websites', websiteId] : ['/api/external-websites', 'none'],
    queryFn: () => websiteId ? fetch(`/api/external-websites/${websiteId}`).then(res => res.json()) : null,
    enabled: !!websiteId
  });
  
  // Get traffic data for the website
  const { data: trafficData } = useQuery({
    queryKey: ['/api/traffic-estimate', website?.domain, dateRange],
    queryFn: () => 
      fetch(`/api/traffic-estimate/${website?.domain}`).then(res => res.json()),
    enabled: !!website?.domain
  });
  
  // Generate shareable insights based on available data
  const generateInsights = (): InsightData[] => {
    const insights: InsightData[] = [];
    const now = new Date().toISOString();
    
    // If we have a website and traffic data, create traffic insights
    if (website && trafficData) {
      // Monthly Traffic Insight
      insights.push({
        title: `${website.name} Monthly Traffic Insights`,
        description: `Key traffic metrics for ${website.name} based on our latest analysis.`,
        metric: 'Monthly Visits',
        value: formatNumberWithCommas(trafficData.monthlyVisits),
        change: formatPercent(trafficData.trafficChange),
        trend: trafficData.trafficChange > 0 ? 'up' : trafficData.trafficChange < 0 ? 'down' : 'neutral',
        source: 'Traffic Analysis',
        websiteName: website.name,
        timestamp: now
      });
      
      // Top Countries Insight (if available)
      if (trafficData.countryDistribution && trafficData.countryDistribution.length > 0) {
        const topCountry = trafficData.countryDistribution[0];
        insights.push({
          title: `${website.name} Geographic Distribution`,
          description: `${topCountry.country} leads visitor traffic for ${website.name}, followed by ${
            trafficData.countryDistribution.length > 1 ? trafficData.countryDistribution[1].country : 'other regions'
          }.`,
          metric: `Visitors from ${topCountry.country}`,
          value: formatPercent(topCountry.percentage),
          source: 'Geographic Analysis',
          websiteName: website.name,
          timestamp: now
        });
      }
      
      // Bounce Rate Insight (if available)
      if (trafficData.metrics && trafficData.metrics.bounceRate !== undefined) {
        insights.push({
          title: `${website.name} Engagement Metrics`,
          description: `Key engagement metrics for ${website.name} showing visitor behavior patterns.`,
          metric: 'Bounce Rate',
          value: formatPercent(trafficData.metrics.bounceRate),
          change: trafficData.metrics.bounceRateChange !== undefined ? 
            formatPercent(trafficData.metrics.bounceRateChange) : undefined,
          trend: trafficData.metrics.bounceRateChange > 0 ? 'up' : 
            trafficData.metrics.bounceRateChange < 0 ? 'down' : 'neutral',
          source: 'Engagement Analysis',
          websiteName: website.name,
          timestamp: now
        });
      }
    }
    
    // Add default insights if no website is selected or no data is available
    if (insights.length === 0) {
      insights.push({
        title: 'Website Traffic Overview',
        description: 'Select a website to view detailed traffic insights that you can share with your team.',
        timestamp: now
      });
    }
    
    return insights;
  };
  
  const insights = generateInsights();
  
  return (
    <Card>
      <CardHeader className="border-b border-gray-200">
        <div className="flex justify-between items-center">
          <CardTitle className="text-lg leading-6 font-medium text-gray-900">
            Shareable Insights
          </CardTitle>
          <Button variant="outline" size="sm" onClick={() => {
            toast({
              title: "Creating custom insight",
              description: "This feature is coming soon!"
            });
          }}>
            <Plus className="h-4 w-4 mr-1" />
            Create Custom
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-4">
        <p className="text-sm text-gray-500 mb-4">
          Generate one-click shareable insights about website traffic and user behavior. 
          These cards can be downloaded as images or shared via link.
        </p>
        
        <Tabs defaultValue="traffic" className="w-full" onValueChange={setSelectedTab}>
          <TabsList className="mb-4">
            <TabsTrigger value="traffic">Traffic</TabsTrigger>
            <TabsTrigger value="behavior">Behavior</TabsTrigger>
            <TabsTrigger value="performance">Performance</TabsTrigger>
          </TabsList>
          
          <TabsContent value="traffic" className="space-y-4">
            {insights.map((insight, index) => (
              <ShareableInsightCard key={`traffic-insight-${index}`} insight={insight} />
            ))}
          </TabsContent>
          
          <TabsContent value="behavior" className="space-y-4">
            <div className="text-center py-6">
              <p className="text-gray-500">
                Select a website to view shareable behavior insights.
              </p>
            </div>
          </TabsContent>
          
          <TabsContent value="performance" className="space-y-4">
            <div className="text-center py-6">
              <p className="text-gray-500">
                Select a website to view shareable performance insights.
              </p>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}