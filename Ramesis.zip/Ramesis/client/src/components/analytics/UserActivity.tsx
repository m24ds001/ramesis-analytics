import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { 
  generateUserActivityData, 
  generateHourlyUserActivityData, 
  generateWeeklyUserActivityData 
} from '@/lib/chartUtils';
import { useQuery } from '@tanstack/react-query';
import { fetchExternalWebsites } from '@/lib/externalWebsites';
import { Info } from 'lucide-react';

type TimeFrame = 'hourly' | 'daily' | 'weekly';

interface UserActivityProps {
  className?: string;
  websiteId?: number | null;
  dateRange?: string;
}

export default function UserActivity({ className, websiteId, dateRange = 'last7days' }: UserActivityProps) {
  const [timeFrame, setTimeFrame] = useState<TimeFrame>('daily');
  const [selectedWebsiteId, setSelectedWebsiteId] = useState<number | null>(websiteId || null);
  
  // Fetch external websites for the selector with strong deduplication
  const { data: externalWebsitesRaw, isLoading: isLoadingWebsites } = useQuery({
    queryKey: ['/api/external-websites'],
    queryFn: fetchExternalWebsites,
  });
  
  // Apply strong deduplication to prevent multiple entries
  const externalWebsites = React.useMemo(() => {
    if (!externalWebsitesRaw) return [];
    
    const uniqueMap = new Map();
    externalWebsitesRaw.forEach((site: any) => {
      if (!uniqueMap.has(site.id)) {
        uniqueMap.set(site.id, site);
      }
    });
    
    return Array.from(uniqueMap.values());
  }, [externalWebsitesRaw]);
  
  // Get website name if websiteId is provided
  const { data: website } = useQuery({
    queryKey: selectedWebsiteId ? ['/api/external-websites', selectedWebsiteId] : ['/api/websites', 'none'],
    queryFn: () => selectedWebsiteId ? fetch(`/api/external-websites/${selectedWebsiteId}`).then(res => res.json()) : null,
    enabled: !!selectedWebsiteId
  });
  
  // Function to get data source label
  const getDataSourceLabel = () => {
    if (selectedWebsiteId && website) {
      return website.name;
    } else {
      return 'This Application';
    }
  };

  // Get the name of the data provider
  const getDataProvider = (): string => {
    // This would be dynamic in a real implementation based on the actual data source
    return timeFrame === 'hourly' ? 'Real-time Tracking' : 
           timeFrame === 'weekly' ? 'Google Analytics' : 'Mixpanel';
  };
  
  // Get data based on selected timeframe and date range
  const getData = () => {
    // Map dateRange to number of days/weeks/hours
    const periodMap: Record<string, any> = {
      'last7days': { days: 7, weeks: 1, hours: 24 },
      'last30days': { days: 30, weeks: 4, hours: 72 },
      'last90days': { days: 90, weeks: 13, hours: 168 },
      'thisMonth': { days: 30, weeks: 4, hours: 72 }, // approximation
      'lastMonth': { days: 30, weeks: 4, hours: 72 }, // approximation
      'custom': { days: 14, weeks: 2, hours: 48 } // default for custom
    };
    
    // Normalize the date range, ensuring case-insensitive matching
    const normalizedDateRange = dateRange.toLowerCase();
    console.log(`Normalized date range: ${normalizedDateRange}`);
    
    const period = periodMap[normalizedDateRange] || periodMap.last7days;
    
    // Log for debugging
    console.log(`Generating data for ${timeFrame} with dateRange: ${dateRange}, websiteId: ${websiteId}, websiteName: ${website?.name}`);
    
    switch (timeFrame) {
      case 'hourly':
        return generateHourlyUserActivityData(period.hours, websiteId, website?.name, dateRange);
      case 'weekly':
        return generateWeeklyUserActivityData(period.weeks, websiteId, website?.name, dateRange);
      case 'daily':
      default:
        return generateUserActivityData(period.days, websiteId, website?.name, dateRange);
    }
  };
  
  const data = getData();
  
  const xAxisKey = timeFrame === 'hourly' ? 'hour' : timeFrame === 'weekly' ? 'week' : 'date';
  
  const getColorScheme = () => {
    switch(timeFrame) {
      case 'hourly': return { bgColor: 'bg-blue-600', textColor: 'text-blue-600', borderColor: 'border-blue-200' };
      case 'weekly': return { bgColor: 'bg-purple-600', textColor: 'text-purple-600', borderColor: 'border-purple-200' };
      default: return { bgColor: 'bg-emerald-600', textColor: 'text-emerald-600', borderColor: 'border-emerald-200' };
    }
  };
  
  const colorScheme = getColorScheme();

  return (
    <Card className={`${className} relative overflow-hidden ${colorScheme.borderColor} hover:shadow-md transition-shadow`}>
      <div className={`absolute top-0 right-0 ${colorScheme.bgColor} text-white text-xs px-2 py-1 rounded-bl-md`}>
        Source: {getDataProvider()}
      </div>
      <CardHeader className="px-4 py-5 border-b border-gray-200 sm:px-6 flex flex-row items-center justify-between pt-8">
        <div>
          <CardTitle className="text-lg leading-6 font-medium text-gray-900">
            User Activity
          </CardTitle>
          <CardDescription>Tracking user engagement over time</CardDescription>
          
          {/* Website Selector */}
          <div className="mt-3 flex items-center gap-2">
            <span className="text-sm text-gray-600">Website:</span>
            <Select 
              value={selectedWebsiteId?.toString() || "current"} 
              onValueChange={(value) => setSelectedWebsiteId(value === "current" ? null : parseInt(value))}
            >
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Select website" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="current">This Application</SelectItem>
                {externalWebsites?.map((site: any) => (
                  <SelectItem key={site.id} value={site.id.toString()}>
                    {site.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        <div className="flex space-x-2">
          <Button 
            variant={timeFrame === 'hourly' ? 'default' : 'outline'} 
            size="sm"
            onClick={() => setTimeFrame('hourly')}
          >
            Hourly
          </Button>
          <Button 
            variant={timeFrame === 'daily' ? 'default' : 'outline'} 
            size="sm"
            onClick={() => setTimeFrame('daily')}
          >
            Daily
          </Button>
          <Button 
            variant={timeFrame === 'weekly' ? 'default' : 'outline'} 
            size="sm"
            onClick={() => setTimeFrame('weekly')}
          >
            Weekly
          </Button>
        </div>
      </CardHeader>
      <div className="flex items-center mt-2 mx-6 bg-gradient-to-r from-gray-50 to-transparent p-2 rounded-md border border-gray-100">
        <Info className="h-4 w-4 text-gray-500 mr-2" />
        <span className="text-xs text-gray-600">Data source: {getDataProvider()} | Website: {getDataSourceLabel()}</span>
      </div>
      <CardContent className="px-4 py-5 sm:p-6">
        <div className="h-64 relative rounded-md overflow-hidden">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart
              data={data}
              margin={{
                top: 5,
                right: 30,
                left: 20,
                bottom: 5,
              }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey={xAxisKey} />
              <YAxis yAxisId="left" />
              <YAxis yAxisId="right" orientation="right" />
              <Tooltip 
                content={({ active, payload, label }) => {
                  if (active && payload && payload.length) {
                    return (
                      <div className={`bg-white p-3 border ${colorScheme.borderColor} shadow-md rounded-md`}>
                        <p className="font-medium text-gray-900 mb-1">{label}</p>
                        {payload.map((entry, index) => (
                          <p key={index} className={`text-sm ${index === 0 ? 'text-blue-600' : index === 1 ? 'text-green-600' : 'text-indigo-600'}`}>
                            {entry.name}: {entry.value}
                          </p>
                        ))}
                        <div className="mt-2 pt-2 border-t border-gray-100">
                          <p className="text-xs text-gray-500">Source: {getDataProvider()}</p>
                          <p className="text-xs text-gray-500">Website: {getDataSourceLabel()}</p>
                        </div>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Legend 
                wrapperStyle={{ paddingTop: '10px' }}
                formatter={(value) => <span className="text-sm font-medium">{value}</span>}
              />
              <Line 
                yAxisId="left"
                type="monotone" 
                dataKey="pageViews" 
                name="Page Views" 
                stroke="#3B82F6" 
                activeDot={{ r: 8 }} 
              />
              <Line 
                yAxisId="left"
                type="monotone" 
                dataKey="uniqueVisitors" 
                name="Unique Visitors" 
                stroke="#10B981" 
              />
              <Line 
                yAxisId="right"
                type="monotone" 
                dataKey="avgTimeOnPage" 
                name="Avg. Time (sec)" 
                stroke="#6366F1" 
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
        <div className="mt-4 grid grid-cols-3 gap-3">
          <div className={`rounded-md p-3 border ${colorScheme.borderColor} bg-gradient-to-br from-white to-gray-50`}>
            <div className="flex items-center justify-between">
              <p className="text-sm font-medium text-gray-500">Page Views</p>
              <Badge variant="outline" className={`${colorScheme.textColor} ${colorScheme.borderColor} text-xs bg-white/80`}>
                {getDataSourceLabel()}
              </Badge>
            </div>
            <p className="text-lg font-semibold text-gray-900 mt-1">
              {dateRange === 'last7days' ? '14,582' : 
               dateRange === 'last30days' ? '67,429' : 
               dateRange === 'last90days' ? '192,754' : 
               dateRange === 'thisMonth' ? '58,326' : 
               dateRange === 'lastMonth' ? '62,105' : '14,582'}
            </p>
            <p className="text-xs text-gray-400 mt-1">Source: {getDataProvider()}</p>
          </div>
          
          <div className={`rounded-md p-3 border ${colorScheme.borderColor} bg-gradient-to-br from-white to-gray-50`}>
            <div className="flex items-center justify-between">
              <p className="text-sm font-medium text-gray-500">Unique Visitors</p>
              <Badge variant="outline" className={`${colorScheme.textColor} ${colorScheme.borderColor} text-xs bg-white/80`}>
                {getDataSourceLabel()}
              </Badge>
            </div>
            <p className="text-lg font-semibold text-gray-900 mt-1">
              {dateRange === 'last7days' ? '8,147' : 
               dateRange === 'last30days' ? '35,821' : 
               dateRange === 'last90days' ? '98,436' : 
               dateRange === 'thisMonth' ? '31,245' : 
               dateRange === 'lastMonth' ? '33,784' : '8,147'}
            </p>
            <p className="text-xs text-gray-400 mt-1">Source: {getDataProvider()}</p>
          </div>
          
          <div className={`rounded-md p-3 border ${colorScheme.borderColor} bg-gradient-to-br from-white to-gray-50`}>
            <div className="flex items-center justify-between">
              <p className="text-sm font-medium text-gray-500">Avg. Time on Page</p>
              <Badge variant="outline" className={`${colorScheme.textColor} ${colorScheme.borderColor} text-xs bg-white/80`}>
                {getDataSourceLabel()}
              </Badge>
            </div>
            <p className="text-lg font-semibold text-gray-900 mt-1">
              {dateRange === 'last7days' ? '1m 34s' : 
               dateRange === 'last30days' ? '2m 12s' : 
               dateRange === 'last90days' ? '2m 48s' : 
               dateRange === 'thisMonth' ? '2m 05s' : 
               dateRange === 'lastMonth' ? '1m 58s' : '1m 34s'}
            </p>
            <p className="text-xs text-gray-400 mt-1">Source: {getDataProvider()}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
