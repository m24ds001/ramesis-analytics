import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer,
  CartesianGrid,
  Legend
} from 'recharts';
import { useQuery } from '@tanstack/react-query';
import { Skeleton } from '@/components/ui/skeleton';
import { format, subDays } from 'date-fns';

interface UserActivityWeeklyProps {
  websiteId?: number | null;
  dateRange?: string;
}

// Generate weekly mock data since we're using simulated data
const generateWeeklyData = (websiteId?: number | null, websiteName?: string) => {
  const days = Array.from({ length: 7 }, (_, i) => {
    const date = subDays(new Date(), 6 - i);
    return format(date, 'EEE');
  });

  // Different patterns for different websites
  let baseValues = [320, 380, 400, 550, 490, 600, 700];
  
  // Use different patterns based on website
  if (websiteName) {
    if (websiteName.includes('Google')) {
      baseValues = [720, 880, 940, 1020, 980, 1100, 1250];
    } else if (websiteName.includes('Facebook')) {
      baseValues = [620, 580, 740, 820, 870, 910, 950];
    } else if (websiteName.includes('Amazon')) {
      baseValues = [520, 640, 590, 710, 690, 750, 830];
    } else if (websiteName.includes('YouTube')) {
      baseValues = [820, 780, 860, 950, 1020, 1100, 1190];
    } else if (websiteName.includes('Twitter')) {
      baseValues = [320, 290, 380, 410, 390, 440, 470];
    } else if (websiteName.includes('Instagram')) {
      baseValues = [580, 610, 590, 680, 720, 690, 750];
    } else if (websiteName.includes('Netflix')) {
      baseValues = [420, 470, 510, 480, 550, 640, 680];
    }
  }

  // Add some variability to the data
  const data = days.map((day, index) => {
    const baseValue = baseValues[index];
    const desktop = Math.round(baseValue * (0.6 + Math.random() * 0.1));
    const mobile = Math.round(baseValue * (0.3 + Math.random() * 0.1));
    const tablet = Math.round(baseValue * (0.1 + Math.random() * 0.05));
    
    return {
      name: day,
      Desktop: desktop,
      Mobile: mobile,
      Tablet: tablet,
      Total: desktop + mobile + tablet
    };
  });

  return data;
};

export default function UserActivityWeekly({ websiteId, dateRange = 'last7days' }: UserActivityWeeklyProps) {
  // Get website name if websiteId is provided
  const { data: website, isLoading: isWebsiteLoading } = useQuery({
    queryKey: websiteId ? ['/api/external-websites', websiteId] : ['/api/external-websites', 'none'],
    queryFn: () => websiteId ? fetch(`/api/external-websites/${websiteId}`).then(res => res.json()) : null,
    enabled: !!websiteId
  });

  // Weekly activity data
  const weeklyData = generateWeeklyData(websiteId, website?.name);

  if (isWebsiteLoading) {
    return (
      <Card className="col-span-full">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Skeleton className="h-5 w-[250px]" />
          </CardTitle>
        </CardHeader>
        <CardContent className="h-[350px] flex items-center justify-center">
          <Skeleton className="h-[300px] w-full" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="col-span-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          Weekly User Activity {websiteId && website ? `- ${website.name}` : ''}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-[350px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={weeklyData}
              margin={{ top: 20, right: 30, left: 0, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip 
                formatter={(value, name) => [Number(value).toLocaleString(), name]}
                labelFormatter={(label) => `${label}`}
              />
              <Legend />
              <Bar dataKey="Desktop" stackId="a" fill="#8884d8" name="Desktop" />
              <Bar dataKey="Mobile" stackId="a" fill="#82ca9d" name="Mobile" />
              <Bar dataKey="Tablet" stackId="a" fill="#ffc658" name="Tablet" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}