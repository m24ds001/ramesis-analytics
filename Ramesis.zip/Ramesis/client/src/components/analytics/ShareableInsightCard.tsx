import { useState, useRef } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Share, Download, Link, Check, Copy } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import html2canvas from 'html2canvas';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { toast } from '@/hooks/use-toast';

export interface InsightData {
  title: string;
  description: string;
  metric?: string;
  value?: string | number;
  change?: string | number;
  trend?: 'up' | 'down' | 'neutral';
  source?: string;
  websiteName?: string;
  timestamp?: string;
  imageUrl?: string;
}

interface ShareableInsightCardProps {
  insight: InsightData;
  className?: string;
}

export default function ShareableInsightCard({ insight, className = '' }: ShareableInsightCardProps) {
  const [copied, setCopied] = useState(false);
  const [shareUrl, setShareUrl] = useState<string | null>(null);
  const cardRef = useRef<HTMLDivElement>(null);
  
  // Generate a shareable link
  const generateShareableLink = () => {
    // Create a URL-friendly version of the insight data
    const params = new URLSearchParams();
    params.append('title', insight.title);
    params.append('description', insight.description);
    if (insight.metric) params.append('metric', insight.metric);
    if (insight.value) params.append('value', insight.value.toString());
    if (insight.change) params.append('change', insight.change.toString());
    if (insight.trend) params.append('trend', insight.trend);
    if (insight.source) params.append('source', insight.source);
    if (insight.websiteName) params.append('website', insight.websiteName);
    
    // Create the shareable URL
    const shareableUrl = `${window.location.origin}/shared-insight?${params.toString()}`;
    setShareUrl(shareableUrl);
    
    return shareableUrl;
  };
  
  // Copy link to clipboard
  const copyToClipboard = () => {
    const url = shareUrl || generateShareableLink();
    navigator.clipboard.writeText(url).then(() => {
      setCopied(true);
      toast({
        title: "Link copied to clipboard",
        description: "You can now share this insight with others",
      });
      setTimeout(() => setCopied(false), 2000);
    }).catch(err => {
      console.error('Failed to copy: ', err);
      toast({
        title: "Failed to copy link",
        description: "Please try again",
        variant: "destructive",
      });
    });
  };
  
  // Download as image
  const downloadAsImage = async () => {
    if (!cardRef.current) return;
    
    try {
      const canvas = await html2canvas(cardRef.current, {
        scale: 2,
        backgroundColor: '#ffffff',
        logging: false,
      });
      
      const link = document.createElement('a');
      link.download = `insight-${insight.title.toLowerCase().replace(/\s+/g, '-')}.png`;
      link.href = canvas.toDataURL('image/png');
      link.click();
      
      toast({
        title: "Insight downloaded",
        description: "Your insight has been saved as an image",
      });
    } catch (error) {
      console.error('Error generating image:', error);
      toast({
        title: "Failed to download",
        description: "An error occurred while creating the image",
        variant: "destructive",
      });
    }
  };
  
  // Get trend color and icon
  const getTrendInfo = () => {
    if (!insight.trend) return { color: 'text-gray-500', bgColor: 'bg-gray-100' };
    
    switch (insight.trend) {
      case 'up':
        return { color: 'text-green-500', bgColor: 'bg-green-50' };
      case 'down':
        return { color: 'text-red-500', bgColor: 'bg-red-50' };
      default:
        return { color: 'text-gray-500', bgColor: 'bg-gray-100' };
    }
  };
  
  const { color, bgColor } = getTrendInfo();
  
  return (
    <Card className={`overflow-hidden ${className}`} ref={cardRef}>
      <CardHeader className="bg-gradient-to-r from-indigo-500 to-purple-600 text-white">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle>{insight.title}</CardTitle>
            {insight.websiteName && (
              <div className="text-xs font-medium mt-1 opacity-90">
                {insight.websiteName}
              </div>
            )}
          </div>
          {insight.source && (
            <div className="rounded-full bg-white/20 px-2 py-1 text-xs">
              Source: {insight.source}
            </div>
          )}
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <CardDescription className="text-base text-gray-600 mb-4">
          {insight.description}
        </CardDescription>
        
        {insight.metric && insight.value && (
          <div className="mt-4">
            <div className="text-sm font-medium text-gray-500">
              {insight.metric}
            </div>
            <div className="flex items-baseline mt-1">
              <div className="text-3xl font-bold">{insight.value}</div>
              {insight.change && (
                <div className={`ml-2 text-sm font-medium ${color} flex items-center`}>
                  <span className={`inline-flex items-center justify-center p-1 rounded-full ${bgColor} mr-1`}>
                    {insight.trend === 'up' ? '↑' : insight.trend === 'down' ? '↓' : '→'}
                  </span>
                  {insight.change}
                </div>
              )}
            </div>
          </div>
        )}
        
        {insight.imageUrl && (
          <div className="mt-4 rounded-md overflow-hidden">
            <img 
              src={insight.imageUrl} 
              alt={insight.title} 
              className="w-full h-auto object-cover"
            />
          </div>
        )}
        
        {insight.timestamp && (
          <div className="mt-4 text-xs text-gray-400">
            Generated: {new Date(insight.timestamp).toLocaleString()}
          </div>
        )}
      </CardContent>
      <CardFooter className="bg-gray-50 px-6 py-4">
        <div className="flex space-x-2 w-full">
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="flex-1"
                  onClick={copyToClipboard}
                >
                  {copied ? <Check className="h-4 w-4 mr-1" /> : <Link className="h-4 w-4 mr-1" />}
                  {copied ? 'Copied' : 'Copy Link'}
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Copy shareable link to clipboard</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
          
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="flex-1"
                  onClick={downloadAsImage}
                >
                  <Download className="h-4 w-4 mr-1" />
                  Download
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Download insight as image</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
          
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  variant="default" 
                  size="sm" 
                  className="flex-1"
                  onClick={() => {
                    const url = shareUrl || generateShareableLink();
                    window.open(url, '_blank');
                  }}
                >
                  <Share className="h-4 w-4 mr-1" />
                  Share
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Share this insight</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
      </CardFooter>
    </Card>
  );
}