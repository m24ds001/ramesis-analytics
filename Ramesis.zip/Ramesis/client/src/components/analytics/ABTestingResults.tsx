import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { AbTest } from '@shared/schema';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { createAbTest } from '@/lib/analytics';
import { queryClient } from '@/lib/queryClient';
import { useState } from 'react';

interface ABTestingResultsProps {
  abTests: AbTest[];
  websiteId?: number | null;
  dateRange?: string;
}

export default function ABTestingResults({ abTests, websiteId, dateRange = 'last7days' }: ABTestingResultsProps) {
  // Normalize the date range to lowercase for consistent handling
  const normalizedDateRange = dateRange.toLowerCase();
  console.log(`ABTestingResults using normalized date range: ${normalizedDateRange}`);
  const { toast } = useToast();
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  
  // Form schema
  const formSchema = z.object({
    name: z.string().min(1, "Name is required"),
    description: z.string().min(1, "Description is required"),
    variantA: z.string().min(1, "Variant A is required"),
    variantB: z.string().min(1, "Variant B is required"),
    endDate: z.string().min(1, "End date is required"),
  });
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      description: "",
      variantA: "",
      variantB: "",
      endDate: "",
    },
  });
  
  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    try {
      // Convert string date to actual Date object
      const endDate = new Date(values.endDate);
      
      await createAbTest({
        ...values,
        startDate: new Date(),
        endDate,
        status: "active",
        variantAConversion: "0",
        variantBConversion: "0",
        confidence: "0",
      });
      
      // Invalidate the AB tests cache to refresh the data
      queryClient.invalidateQueries({ queryKey: ['/api/abtests'] });
      
      toast({
        title: "A/B Test Created",
        description: "Your new A/B test has been created successfully.",
      });
      
      // Close the dialog and reset the form
      setIsCreateDialogOpen(false);
      form.reset();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create A/B test. Please try again.",
        variant: "destructive",
      });
      console.error(error);
    }
  };
  
  // Active tests count
  const activeTestsCount = abTests.filter(test => test.status === 'active').length;
  
  return (
    <Card>
      <CardHeader className="px-4 py-5 border-b border-gray-200 sm:px-6 flex flex-row items-center justify-between">
        <CardTitle className="text-lg leading-6 font-medium text-gray-900">A/B Testing Results</CardTitle>
        <Badge variant="outline" className="px-2 py-1 text-xs rounded-full bg-green-100 text-green-800 font-medium">
          Active: {activeTestsCount} tests
        </Badge>
      </CardHeader>
      <CardContent className="px-4 py-5 sm:p-6">
        <div className="space-y-6">
          {abTests.length > 0 ? (
            abTests.map((test, index) => {
              // Calculate remaining days
              const endDate = new Date(test.endDate);
              const today = new Date();
              const remainingDays = Math.max(0, Math.ceil((endDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24)));
              
              return (
                <div key={test.id}>
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="text-sm font-medium text-gray-900">{test.name}</h4>
                    <span className="text-xs text-gray-500">{remainingDays} days remaining</span>
                  </div>
                  <div className="bg-gray-100 p-3 rounded-md">
                    <div className="flex justify-between items-center mb-2">
                      <div className="flex items-center">
                        <span className="text-xs font-medium text-gray-700 bg-white px-2 py-1 rounded mr-2">A</span>
                        <span className="text-sm">"{test.variantA}"</span>
                      </div>
                      <span className="text-sm font-medium text-gray-900">{test.variantAConversion}% conv.</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <div className="flex items-center">
                        <span className={`text-xs font-medium ${
                          parseFloat(test.variantBConversion) > parseFloat(test.variantAConversion) 
                            ? 'text-white bg-primary-500' 
                            : 'text-gray-700 bg-white'
                        } px-2 py-1 rounded mr-2`}>B</span>
                        <span className="text-sm">"{test.variantB}"</span>
                      </div>
                      <span className="text-sm font-medium text-gray-900">{test.variantBConversion}% conv.</span>
                    </div>
                    <div className="mt-3 flex items-center">
                      {parseFloat(test.confidence) >= 95 ? (
                        <>
                          <i className="ri-arrow-up-line text-green-500 mr-1"></i>
                          <span className="text-sm text-green-700">
                            {parseFloat(test.variantBConversion) > parseFloat(test.variantAConversion) 
                              ? `+${(parseFloat(test.variantBConversion) - parseFloat(test.variantAConversion)).toFixed(1)}% improvement with variant B` 
                              : `+${(parseFloat(test.variantAConversion) - parseFloat(test.variantBConversion)).toFixed(1)}% improvement with variant A`
                            } ({test.confidence}% confidence)
                          </span>
                        </>
                      ) : (
                        <>
                          <i className="ri-information-line text-gray-500 mr-1"></i>
                          <span className="text-sm text-gray-700">
                            Inconclusive results ({test.confidence}% confidence)
                          </span>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              );
            })
          ) : (
            <div className="text-center py-4">
              <p className="text-gray-500">No A/B tests available</p>
            </div>
          )}
          
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button className="w-full justify-center">
                <i className="ri-add-line mr-2"></i>
                Create New Test
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New A/B Test</DialogTitle>
                <DialogDescription>
                  Set up a new A/B test to compare different variants of your website.
                </DialogDescription>
              </DialogHeader>
              
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Test Name</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g. Homepage Hero Message" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Description</FormLabel>
                        <FormControl>
                          <Textarea placeholder="Describe the purpose of this test" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="variantA"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Variant A (Control)</FormLabel>
                          <FormControl>
                            <Input placeholder="Original version" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="variantB"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Variant B (Test)</FormLabel>
                          <FormControl>
                            <Input placeholder="New version to test" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <FormField
                    control={form.control}
                    name="endDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>End Date</FormLabel>
                        <FormControl>
                          <Input type="date" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <DialogFooter>
                    <Button type="submit">Create Test</Button>
                  </DialogFooter>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>
      </CardContent>
    </Card>
  );
}
