import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Filter, MousePointer, PieChart, Check, Download } from 'lucide-react';
import { useState, useEffect, useRef } from 'react';
import { useQuery } from '@tanstack/react-query';
import { exportElementAsImage } from '@/lib/exportVisual';
import { ExportableChart } from '@/components/ui/exportable-chart';

interface UserBehaviorProps {
  websiteId?: number | null;
  dateRange?: string;
}

// Different heatmap image URLs for different websites
const websiteHeatmaps: { [key: string]: string } = {
  // Website-specific heatmaps
  'Amazon': 'https://images.unsplash.com/photo-1551434678-e076c223a692?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&h=600',
  'Flipkart': 'https://images.unsplash.com/photo-1563986768494-4dee2763ff3f?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&h=600',
  'YouTube': 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&h=600',
  'Netflix': 'https://images.unsplash.com/photo-1542744173-05336fcc7ad4?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&h=600',
  'Instagram': 'https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&h=600',
  'Twitter': 'https://images.unsplash.com/photo-1611605698335-8b1569810432?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&h=600',
  'Walmart': 'https://images.unsplash.com/photo-1561715276-a2d087060f1d?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&h=600',
  'Myntra': 'https://images.unsplash.com/photo-1558769132-cb1aea458c5e?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&h=600',
  // Default for other IDs
  'default': 'https://images.unsplash.com/photo-1551434678-e076c223a692?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&h=600'
};

// Interaction data for different websites
const websiteInteractions: { [key: string]: Array<{element: string, rate: string}> } = {
  // Amazon
  'Amazon': [
    { element: 'Product Image Gallery', rate: '78% click rate' },
    { element: 'Buy Now Button', rate: '62% interaction' },
    { element: 'Reviews Section', rate: '45% scrolled to' }
  ],
  // Flipkart
  'Flipkart': [
    { element: 'Price Comparison Widget', rate: '65% click rate' },
    { element: 'Add to Cart Button', rate: '53% interaction' },
    { element: 'Search Bar', rate: '48% used' }
  ],
  // YouTube
  'YouTube': [
    { element: 'Video Thumbnail', rate: '82% click rate' },
    { element: 'Subscribe Button', rate: '27% interaction' },
    { element: 'Like Button', rate: '36% used' }
  ],
  // Netflix
  'Netflix': [
    { element: 'Continue Watching Row', rate: '76% click rate' },
    { element: 'New Releases Section', rate: '58% interaction' },
    { element: 'Profile Selector', rate: '31% switches' }
  ],
  // Instagram
  'Instagram': [
    { element: 'Profile Photos', rate: '81% click rate' },
    { element: 'Stories', rate: '73% viewed' },
    { element: 'Comment Button', rate: '22% used' }
  ],
  // Twitter
  'Twitter': [
    { element: 'Tweet Button', rate: '45% click rate' },
    { element: 'Trending Topics', rate: '67% viewed' },
    { element: 'Profile Links', rate: '39% clicks' }
  ],
  // Walmart
  'Walmart': [
    { element: 'Add to Cart Button', rate: '58% click rate' },
    { element: 'Product Recommendations', rate: '42% clicked' },
    { element: 'Store Locator', rate: '31% searches' }
  ],
  // Myntra
  'Myntra': [
    { element: 'Product Filters', rate: '72% used' },
    { element: 'Wishlist Button', rate: '49% clicked' },
    { element: 'Size Guide', rate: '38% expanded' }
  ],
  // Default
  'default': [
    { element: 'Homepage Hero Button', rate: '62% click rate' },
    { element: 'Pricing Comparison Table', rate: '48% interaction' },
    { element: 'Contact Form Submit', rate: '23% completion' }
  ]
};

export default function UserBehavior({ websiteId, dateRange = 'last7days' }: UserBehaviorProps) {
  // Get website data
  const { data: website } = useQuery({
    queryKey: websiteId ? ['/api/external-websites', websiteId] : ['/api/external-websites', 'none'],
    queryFn: () => websiteId ? fetch(`/api/external-websites/${websiteId}`).then(res => res.json()) : null,
    enabled: !!websiteId
  });

  // Get real-time user behavior data
  const { data: behaviorData, isLoading: isBehaviorLoading } = useQuery({
    queryKey: ['user-behavior', website?.domain],
    queryFn: async () => {
      if (!website?.domain) return null;
      
      console.log(`Fetching real-time behavior data for ${website.domain}`);
      try {
        const response = await fetch(`/api/user-behavior/${website.domain}`);
        if (!response.ok) {
          throw new Error(`Failed to fetch behavior data: ${response.statusText}`);
        }
        return response.json();
      } catch (error) {
        console.error('Error fetching behavior data:', error);
        return null;
      }
    },
    enabled: !!website?.domain,
    // Refresh every 30 seconds to keep data current
    refetchInterval: 30000
  });

  // Get heatmap and interactions based on website name
  const getHeatmapUrl = (websiteName?: string) => {
    if (!websiteName) return websiteHeatmaps['default'];
    return websiteHeatmaps[websiteName] || websiteHeatmaps['default'];
  };

  // Use real-time data if available, fallback to static data if not
  const getInteractions = (websiteName?: string) => {
    // If we have real-time data, use it
    if (behaviorData?.interactionPoints) {
      return behaviorData.interactionPoints;
    }
    
    // Otherwise use static data
    if (!websiteName) return websiteInteractions['default'];
    return websiteInteractions[websiteName] || websiteInteractions['default'];
  };

  const interactions = getInteractions(website?.name);
  const heatmapUrl = getHeatmapUrl(website?.name);
  
  // Format the lastUpdated time for display
  const getLastUpdatedTime = () => {
    if (!behaviorData?.lastUpdated) return 'N/A';
    const lastUpdated = new Date(behaviorData.lastUpdated);
    return lastUpdated.toLocaleTimeString();
  };

  return (
    <Card>
      <CardHeader className="px-4 py-5 border-b border-gray-200 sm:px-6 flex flex-row items-center justify-between">
        <div>
          <CardTitle className="text-lg leading-6 font-medium text-gray-900">
            User Behavior Map
          </CardTitle>
          {website ? (
            <div className="mt-1 flex items-center">
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                {website.name}
              </span>
              <span className="ml-2 text-xs text-gray-500">Website-specific data</span>
            </div>
          ) : (
            <span className="text-xs text-gray-500 mt-1">Select a website to view specific behavior data</span>
          )}
        </div>
        <div className="flex items-center gap-2">
          {behaviorData && (
            <div className="bg-green-50 text-green-700 text-xs px-2 py-1 rounded-full flex items-center">
              <div className="h-2 w-2 rounded-full bg-green-500 animate-pulse mr-1"></div>
              <span>Real-time</span>
            </div>
          )}
          <span className="text-xs text-gray-500">Updated: {getLastUpdatedTime()}</span>
          <Button variant="outline" size="sm">
            <Filter className="w-4 h-4 mr-1" />
            Filter
          </Button>
        </div>
      </CardHeader>
      <CardContent className="px-4 py-5 sm:p-6">
        {/* A heatmap of user clicks and interactions with export functionality */}
        <ExportableChart 
          title={`User Behavior Heatmap - ${website?.name || 'All Websites'}`}
          fileName={`heatmap-${website?.name?.toLowerCase().replace(/\s+/g, '-') || 'all-websites'}`}
        >
          <div className="h-72 relative rounded-md overflow-hidden">
            <img 
              src={heatmapUrl}
              alt="User behavior heatmap" 
              className="w-full h-full object-cover" 
              crossOrigin="anonymous"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-white/40 to-transparent"></div>
            
            {/* Overlay hotspots to show interaction points */}
            <div className="absolute top-1/4 left-1/3 h-8 w-8 rounded-full bg-red-500/30 animate-pulse border-2 border-red-500"></div>
            <div className="absolute top-2/3 left-1/2 h-6 w-6 rounded-full bg-red-500/30 animate-pulse border-2 border-red-500"></div>
            <div className="absolute top-1/2 right-1/4 h-10 w-10 rounded-full bg-red-500/30 animate-pulse border-2 border-red-500"></div>
            
            {/* Add website info overlay for exported image */}
            {website && (
              <div className="absolute bottom-3 left-3 bg-white/80 backdrop-blur-sm px-3 py-1 rounded-md text-xs font-medium text-gray-800 shadow-sm">
                {website.name} User Behavior Map
              </div>
            )}
          </div>
        </ExportableChart>
        <div className="mt-6 pt-4 border-t border-gray-100">
          <div className="flex items-center justify-between mb-3">
            <h4 className="text-sm font-medium text-gray-900">Top Interaction Points</h4>
            <Button 
              variant="ghost" 
              size="sm"
              className="text-xs h-7 px-2"
              onClick={async () => {
                const element = document.getElementById('top-interactions');
                if (element) {
                  await exportElementAsImage(element, {
                    fileName: `interactions-${website?.name?.toLowerCase().replace(/\s+/g, '-') || 'all-websites'}`,
                    includeTimestamp: true,
                  });
                }
              }}
            >
              <Download className="h-3.5 w-3.5 mr-1" />
              Save
            </Button>
          </div>
          
          <div id="top-interactions" className="p-3 bg-white rounded-md border border-gray-100">
            {website && (
              <div className="mb-2 pb-2 border-b border-gray-100">
                <span className="text-xs font-medium text-gray-500">{website.name} Interaction Analysis</span>
              </div>
            )}
            
            <ul className="space-y-2">
              {interactions.map((item, index) => (
                <li key={index} className="flex justify-between items-center text-sm p-2 rounded-md hover:bg-gray-50">
                  <span className="text-gray-600 flex items-center">
                    {index === 0 ? <MousePointer className="h-4 w-4 mr-2 text-primary-500" /> : 
                     index === 1 ? <PieChart className="h-4 w-4 mr-2 text-green-500" /> :
                     <Check className="h-4 w-4 mr-2 text-blue-500" />}
                    {item.element}
                  </span>
                  <span className="font-medium text-gray-900">{item.rate}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
