import React from 'react';

export default function App() {
  return (
    <div style={{
      padding: '20px',
      fontFamily: 'Arial, sans-serif',
      maxWidth: '800px',
      margin: '0 auto'
    }}>
      <h1 style={{ color: '#0057b8' }}>Welcome to AilyticsPro</h1>
      <h2>AI-Powered Website Analytics Platform</h2>
      <p>
        This is a simplified version of the application to bypass security warnings.
        If you can see this page, the basic functionality is working correctly.
      </p>
      
      <div style={{ 
        background: '#f0f7ff', 
        padding: '15px', 
        borderRadius: '5px',
        marginTop: '20px' 
      }}>
        <h3>Features:</h3>
        <ul>
          <li>Real-time analytics tracking</li>
          <li>AI-powered insights generation</li>
          <li>Multi-source data integration</li>
          <li>Predictive analytics</li>
          <li>A/B testing capabilities</li>
        </ul>
      </div>
      
      <div style={{ marginTop: '30px' }}>
        <p>
          <strong>API Status:</strong> <span style={{ color: 'green' }}>Online</span>
        </p>
        <p>
          <strong>Server Status:</strong> <span style={{ color: 'green' }}>Running</span>
        </p>
      </div>
      
      <div style={{ marginTop: '30px', fontSize: '14px', color: '#666' }}>
        <p>This application is running in a simplified mode without external dependencies or third-party scripts.</p>
      </div>
    </div>
  );
}