import { Request, Response, Express } from 'express';
import { analyticsABTestService } from './services/analytics-abtest-service';

/**
 * Register analytics-based A/B testing routes that use real Google Analytics data
 */
export const registerAnalyticsABTestRoutes = (app: Express) => {
  /**
   * GET /api/analytics-abtests
   * Returns A/B tests generated from real Google Analytics performance data
   */
  app.get('/api/analytics-abtests', async (req: Request, res: Response) => {
    try {
      // Get real active users from the request or use a default
      const activeUsers = parseInt(req.query.activeUsers as string) || 4;
      
      console.log(`Generating A/B tests based on ${activeUsers} active users from real analytics`);
      
      // Generate tests based on real analytics data
      const tests = await analyticsABTestService.generateAnalyticsBasedTests(activeUsers);
      const statistics = analyticsABTestService.getTestStatistics(activeUsers);
      
      res.json({
        tests,
        statistics,
        dataSource: 'Google Analytics',
        timestamp: new Date().toISOString(),
        message: `Generated ${tests.length} A/B tests based on real traffic data`
      });
    } catch (error: any) {
      console.error('Error generating analytics-based A/B tests:', error.message);
      res.status(500).json({
        error: 'Failed to generate analytics-based A/B tests',
        message: error.message
      });
    }
  });

  /**
   * GET /api/analytics-abtests/:testId
   * Returns detailed information about a specific analytics-based A/B test
   */
  app.get('/api/analytics-abtests/:testId', async (req: Request, res: Response) => {
    try {
      const testId = req.params.testId;
      const activeUsers = parseInt(req.query.activeUsers as string) || 4;
      
      const tests = await analyticsABTestService.generateAnalyticsBasedTests(activeUsers);
      const test = tests.find(t => t.id === testId);
      
      if (!test) {
        return res.status(404).json({
          error: 'Test not found',
          message: `A/B test with ID ${testId} not found`
        });
      }
      
      res.json({
        test,
        dataSource: 'Google Analytics',
        timestamp: new Date().toISOString()
      });
    } catch (error: any) {
      console.error('Error fetching analytics-based A/B test:', error.message);
      res.status(500).json({
        error: 'Failed to fetch analytics-based A/B test',
        message: error.message
      });
    }
  });

  /**
   * POST /api/analytics-abtests/refresh
   * Refreshes A/B test data based on latest Google Analytics metrics
   */
  app.post('/api/analytics-abtests/refresh', async (req: Request, res: Response) => {
    try {
      const { activeUsers } = req.body;
      
      if (!activeUsers || activeUsers < 1) {
        return res.status(400).json({
          error: 'Invalid request',
          message: 'Active users count is required and must be greater than 0'
        });
      }
      
      console.log(`Refreshing A/B tests with ${activeUsers} active users from real analytics`);
      
      const tests = await analyticsABTestService.generateAnalyticsBasedTests(activeUsers);
      const statistics = analyticsABTestService.getTestStatistics(activeUsers);
      
      res.json({
        tests,
        statistics,
        dataSource: 'Google Analytics',
        refreshedAt: new Date().toISOString(),
        message: `Refreshed ${tests.length} A/B tests based on current traffic patterns`
      });
    } catch (error: any) {
      console.error('Error refreshing analytics-based A/B tests:', error.message);
      res.status(500).json({
        error: 'Failed to refresh analytics-based A/B tests',
        message: error.message
      });
    }
  });
};