import { Express, Request, Response } from 'express';
import { z } from 'zod';
import { WebSocketServer } from 'ws';
import { storage } from './storage';
import { AnalyticsUpdate, broadcastAnalyticsUpdate } from './websocket-server';

// Define validation schema for tracking events
const trackingEventSchema = z.object({
  sessionId: z.string(),
  eventType: z.string(),
  page: z.string(),
  eventData: z.any()
});

// Implement debounce function
function debounce<T extends (...args: any[]) => any>(
  func: T, 
  wait: number
): (...args: Parameters<T>) => void {
  let timeout: NodeJS.Timeout | null = null;
  
  return function(...args: Parameters<T>): void {
    const later = () => {
      timeout = null;
      func(...args);
    };
    
    if (timeout !== null) {
      clearTimeout(timeout);
    }
    timeout = setTimeout(later, wait);
  };
}

/**
 * Register tracking-related routes
 */
export const registerTrackingRoutes = (app: Express, wss: WebSocketServer) => {
  // Set up batched updates
  const batch: AnalyticsUpdate[] = [];
  
  // Create debounced broadcast function
  const debouncedBroadcast = debounce(
    (update: AnalyticsUpdate) => broadcastAnalyticsUpdate(wss, update),
    100
  );
  
  // Set up batch processing interval
  setInterval(() => {
    if (batch.length > 0) {
      broadcastAnalyticsUpdate(wss, { 
        eventType: 'BATCH_UPDATE', 
        data: [...batch]
      });
      batch.length = 0;
    }
  }, 1000);
  
  // Tracking event endpoint
  app.post('/api/tracking-event', async (req: Request, res: Response) => {
    try {
      // Validate request body
      const result = trackingEventSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ 
          error: 'Invalid tracking data',
          details: result.error.format()
        });
      }
      
      const event = result.data;
      
      // Store event in database
      const storedEvent = await storage.createEvent({
        sessionId: event.sessionId,
        eventType: event.eventType,
        eventData: event.eventData,
        page: event.page,
        timestamp: new Date()
      });
      
      // For high-priority events, use debounced broadcast
      if (event.eventType === 'conversion' || event.eventType === 'purchase') {
        debouncedBroadcast({
          eventType: 'NEW_EVENT',
          data: storedEvent
        });
      } else {
        // For regular events, add to batch
        batch.push({
          eventType: 'NEW_EVENT',
          data: storedEvent
        });
      }
      
      res.status(201).json(storedEvent);
    } catch (error) {
      console.error('Error processing tracking event:', error);
      res.status(500).json({ error: 'Failed to process tracking event' });
    }
  });
  
  // Test utility endpoint to simulate events
  app.post('/api/test/simulate-events', async (req: Request, res: Response) => {
    try {
      const { count = 50 } = req.body;
      const events = [];
      const sessionId = `test-${Date.now()}`;
      const eventTypes = ['page_view', 'click', 'scroll', 'conversion'];
      
      for (let i = 0; i < count; i++) {
        const eventType = eventTypes[Math.floor(Math.random() * eventTypes.length)];
        const event = {
          sessionId,
          eventType,
          page: '/test-page',
          eventData: { testId: i },
          timestamp: new Date()
        };
        
        // Store event
        await storage.createEvent(event);
        events.push(event);
        
        // Add to batch
        batch.push({
          eventType: 'NEW_EVENT',
          data: event
        });
      }
      
      res.json({ success: true, eventsGenerated: count });
    } catch (error) {
      console.error('Error simulating events:', error);
      res.status(500).json({ error: 'Failed to simulate events' });
    }
  });
  
  // Tracking a single event with verification
  app.post('/api/track-event', async (req: Request, res: Response) => {
    try {
      const event = await storage.createEvent({
        sessionId: req.body.sessionId || `session-${Date.now()}`,
        eventType: req.body.eventType || 'button_click',
        eventData: req.body.eventData || {},
        page: req.body.page || '/',
        timestamp: new Date()
      });
      
      // Broadcast immediately for testing/verification
      broadcastAnalyticsUpdate(wss, {
        eventType: 'NEW_EVENT',
        data: event
      });
      
      res.status(201).json({ 
        success: true, 
        message: 'Event tracked and broadcasted',
        event
      });
    } catch (error) {
      console.error('Error tracking event:', error);
      res.status(500).json({ error: 'Failed to track event' });
    }
  });
};