import { Express, Request, Response } from 'express';
import { storage } from './storage';
import { authenticate } from './middleware/auth';
import { z } from 'zod';
import { insertAchievementSchema, insertUserAchievementSchema } from '@shared/schema';

/**
 * Register achievement-related routes
 */
export const registerAchievementRoutes = (app: Express) => {
  // Get all achievements
  app.get('/api/achievements', async (req: Request, res: Response) => {
    try {
      const type = req.query.type as string | undefined;
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 100;
      
      const achievements = await storage.getAchievements(type, limit);
      res.json(achievements);
    } catch (error) {
      console.error('Error fetching achievements:', error);
      res.status(500).json({ error: 'Failed to fetch achievements' });
    }
  });

  // Get a specific achievement by ID
  app.get('/api/achievements/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: 'Invalid achievement ID' });
      }
      
      const achievement = await storage.getAchievementById(id);
      if (!achievement) {
        return res.status(404).json({ error: 'Achievement not found' });
      }
      
      res.json(achievement);
    } catch (error) {
      console.error('Error fetching achievement:', error);
      res.status(500).json({ error: 'Failed to fetch achievement' });
    }
  });

  // Create a new achievement (admin only)
  app.post('/api/achievements', authenticate, async (req: Request, res: Response) => {
    try {
      const parsedData = insertAchievementSchema.safeParse(req.body);
      if (!parsedData.success) {
        return res.status(400).json({ error: 'Invalid achievement data', details: parsedData.error });
      }
      
      const achievement = await storage.createAchievement(parsedData.data);
      res.status(201).json(achievement);
    } catch (error) {
      console.error('Error creating achievement:', error);
      res.status(500).json({ error: 'Failed to create achievement' });
    }
  });

  // Update an achievement (admin only)
  app.patch('/api/achievements/:id', authenticate, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: 'Invalid achievement ID' });
      }
      
      const parsedData = insertAchievementSchema.partial().safeParse(req.body);
      if (!parsedData.success) {
        return res.status(400).json({ error: 'Invalid achievement data', details: parsedData.error });
      }
      
      const achievement = await storage.updateAchievement(id, parsedData.data);
      if (!achievement) {
        return res.status(404).json({ error: 'Achievement not found' });
      }
      
      res.json(achievement);
    } catch (error) {
      console.error('Error updating achievement:', error);
      res.status(500).json({ error: 'Failed to update achievement' });
    }
  });

  // Delete an achievement (admin only)
  app.delete('/api/achievements/:id', authenticate, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: 'Invalid achievement ID' });
      }
      
      await storage.deleteAchievement(id);
      res.status(204).send();
    } catch (error) {
      console.error('Error deleting achievement:', error);
      res.status(500).json({ error: 'Failed to delete achievement' });
    }
  });

  // Get user achievements 
  app.get('/api/user-achievements', authenticate, async (req: Request, res: Response) => {
    try {
      if (!req.session?.user?.id) {
        return res.status(401).json({ error: 'Authentication required' });
      }
      
      const userAchievements = await storage.getUserAchievements(req.session.user.id);
      res.json(userAchievements);
    } catch (error) {
      console.error('Error fetching user achievements:', error);
      res.status(500).json({ error: 'Failed to fetch user achievements' });
    }
  });

  // Get a specific user achievement
  app.get('/api/user-achievements/:id', authenticate, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: 'Invalid user achievement ID' });
      }
      
      const userAchievement = await storage.getUserAchievementById(id);
      if (!userAchievement) {
        return res.status(404).json({ error: 'User achievement not found' });
      }
      
      // Make sure the user is accessing their own achievements
      if (req.session?.user?.id !== userAchievement.userId) {
        return res.status(403).json({ error: 'Forbidden' });
      }
      
      res.json(userAchievement);
    } catch (error) {
      console.error('Error fetching user achievement:', error);
      res.status(500).json({ error: 'Failed to fetch user achievement' });
    }
  });

  // Track achievement progress (used by frontend to update achievement progress)
  app.post('/api/achievements/track', authenticate, async (req: Request, res: Response) => {
    try {
      if (!req.session?.user?.id) {
        return res.status(401).json({ error: 'Authentication required' });
      }
      
      const schema = z.object({
        achievementId: z.number(),
        progress: z.number().int().min(0).max(100),
      });
      
      const parsedData = schema.safeParse(req.body);
      if (!parsedData.success) {
        return res.status(400).json({ error: 'Invalid data', details: parsedData.error });
      }
      
      const { achievementId, progress } = parsedData.data;
      
      // Get the achievement to verify it exists
      const achievement = await storage.getAchievementById(achievementId);
      if (!achievement) {
        return res.status(404).json({ error: 'Achievement not found' });
      }
      
      // Update the user's progress
      const userAchievement = await storage.updateUserAchievementProgress(
        req.session.user.id, 
        achievementId, 
        progress
      );
      
      // If progress is 100%, mark as completed if not already completed
      if (progress === 100 && userAchievement && !userAchievement.completed) {
        const completedAchievement = await storage.markAchievementCompleted(req.session.user.id, achievementId);
        return res.json({ 
          ...completedAchievement, 
          completed: true, 
          justCompleted: true, 
          points: achievement.points 
        });
      }
      
      res.json(userAchievement);
    } catch (error) {
      console.error('Error tracking achievement progress:', error);
      res.status(500).json({ error: 'Failed to track achievement progress' });
    }
  });

  // Get user total points
  app.get('/api/user/points', authenticate, async (req: Request, res: Response) => {
    try {
      if (!req.session?.user?.id) {
        return res.status(401).json({ error: 'Authentication required' });
      }
      
      const points = await storage.getUserPoints(req.session.user.id);
      res.json({ points });
    } catch (error) {
      console.error('Error fetching user points:', error);
      res.status(500).json({ error: 'Failed to fetch user points' });
    }
  });
};