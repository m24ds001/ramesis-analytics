import { Express, Request, Response } from 'express';

/**
 * Direct GrowthBook A/B testing route that bypasses storage issues
 */
export const registerGrowthBookAbTestRoutes = (app: Express) => {
  // Direct GrowthBook A/B tests endpoint
  app.get('/api/abtests-growthbook', async (req: Request, res: Response) => {
    try {
      const hasGrowthBookAccess = !!process.env.GROWTHBOOK_API_KEY && !!process.env.GROWTHBOOK_API_HOST;
      
      if (!hasGrowthBookAccess) {
        return res.json({
          message: 'GrowthBook not configured',
          experiments: []
        });
      }

      // Import and use GrowthBook service
      const { growthBookService } = await import('./services/growthbook-service');
      
      // Fetch real experiments from GrowthBook
      const experiments = await growthBookService.getExperiments();
      console.log('Direct GrowthBook fetch:', experiments.length, 'experiments');
      
      // Transform to A/B test format
      const tests = experiments.map(exp => growthBookService.transformToAbTest(exp));
      
      res.json(tests);
      
    } catch (error) {
      console.error('GrowthBook direct fetch error:', error);
      res.status(500).json({ 
        error: 'Failed to fetch GrowthBook experiments',
        experiments: []
      });
    }
  });
};