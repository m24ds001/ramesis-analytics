import axios from 'axios';

/**
 * Interface for TrafficEstimate API response
 */
export interface TrafficEstimateResponse {
  domain: string;
  monthlyVisitors: number;
  dailyVisitors: number;
  currentVisitors?: number;
  countryDistribution: {
    country: string;
    percentage: number;
    currentVisitors?: number;
    trend?: 'up' | 'down' | 'stable';
  }[];
  trafficSources: {
    source: string;
    percentage: number;
  }[];
  timeOnSite: number;
  pagesPerVisit: number;
  bounceRate: number;
  trafficHistory?: {
    timestamp: number;
    visitors: number;
  }[];
  realTimeData?: {
    lastUpdated: string;
    concurrentVisitors: number;
    activePages: {
      path: string;
      visitors: number;
    }[];
    engagementRate: number;
  };
}

/**
 * Service for fetching website traffic estimates from TrafficEstimate API
 */
export class TrafficEstimateService {
  private apiKey: string;
  private baseUrl: string = 'https://api.trafficestimate.com/v1';
  
  constructor() {
    this.apiKey = process.env.TRAFFIC_ESTIMATE_API_KEY || '';
    if (!this.apiKey) {
      console.warn('WARNING: No TrafficEstimate API key found. Using simulated data.');
    }
  }
  
  /**
   * Fetch traffic data for a given domain
   * 
   * @param domain Domain to fetch traffic data for
   * @returns Traffic data for the domain
   */
  async getTrafficData(domain: string): Promise<TrafficEstimateResponse> {
    try {
      // If we have an API key, make the real request
      if (this.apiKey) {
        const response = await axios.get(`${this.baseUrl}/traffic`, {
          params: { domain, apiKey: this.apiKey }
        });
        
        return response.data;
      } else {
        // Return simulated data if no API key is available
        return this.getSimulatedData(domain);
      }
    } catch (error) {
      console.error(`Error fetching traffic data for ${domain}:`, error);
      // Fallback to simulated data if API request fails
      return this.getSimulatedData(domain);
    }
  }
  
  /**
   * Generate simulated traffic data for a given domain
   * Based on publicly known approximations of website traffic
   * 
   * @param domain Domain to generate traffic data for
   * @returns Simulated traffic data
   */
  private getSimulatedData(domain: string): TrafficEstimateResponse {
    // Base traffic data keyed by domain
    const baseTrafficData: Record<string, number> = {
      'google.com': 5000000000, // 5 billion daily visitors
      'facebook.com': 2700000000, // 2.7 billion
      'youtube.com': 2300000000, // 2.3 billion
      'instagram.com': 1800000000, // 1.8 billion
      'twitter.com': 400000000, // 400 million
      'linkedin.com': 350000000, // 350 million
      'amazon.com': 2100000000, // 2.1 billion
      'netflix.com': 450000000, // 450 million
      'reddit.com': 430000000, // 430 million
      'wikipedia.org': 500000000, // 500 million
      'tiktok.com': 1000000000, // 1 billion
      'pinterest.com': 320000000, // 320 million
      'twitch.tv': 140000000, // 140 million
      'shopify.com': 90000000, // 90 million
      'airbnb.com': 60000000, // 60 million
    };
    
    // Get base traffic or use default
    const dailyVisitors = baseTrafficData[domain] || 10000000;
    const monthlyVisitors = dailyVisitors * 30;
    
    // Get time-of-day factor (more visitors during daytime in most regions)
    const now = new Date();
    const hour = now.getUTCHours(); // Use UTC time as a global reference
    
    // Traffic peaks around 3-4pm UTC (morning in US, afternoon in Europe)
    let timeOfDayFactor = 0.5; // Base factor
    if (hour >= 12 && hour <= 20) {
      // Peak hours
      timeOfDayFactor = 0.8 + (Math.random() * 0.4); // 0.8-1.2
    } else if ((hour >= 8 && hour < 12) || (hour > 20 && hour <= 23)) {
      // Moderate traffic hours
      timeOfDayFactor = 0.6 + (Math.random() * 0.3); // 0.6-0.9
    } else {
      // Low traffic hours (night/early morning)
      timeOfDayFactor = 0.3 + (Math.random() * 0.3); // 0.3-0.6
    }
    
    // Include day-of-week factor (weekdays have more traffic for most sites)
    const dayOfWeek = now.getUTCDay(); // 0 = Sunday, 1 = Monday, etc.
    let dayOfWeekFactor = 1.0;
    
    // Different sites have different traffic patterns by day of week
    if (domain.includes('facebook.com') || domain.includes('instagram.com') || 
        domain.includes('youtube.com') || domain.includes('netflix.com')) {
      // Social/entertainment sites get more traffic on weekends
      dayOfWeekFactor = (dayOfWeek === 0 || dayOfWeek === 6) ? 1.2 : 0.9;
    } else if (domain.includes('google.com') || domain.includes('linkedin.com') || 
               domain.includes('shopify.com')) {
      // Work-related sites get more traffic on weekdays
      dayOfWeekFactor = (dayOfWeek >= 1 && dayOfWeek <= 5) ? 1.1 : 0.8;
    }
    
    // Calculate current visitors with all factors and some randomness
    const baseCurrentFactor = 0.05; // Base percentage of daily visitors online at once
    const randomVariation = 0.1; // Random variation factor
    const randomFactor = 1 + (Math.random() * randomVariation * 2 - randomVariation);
    
    // Combine all factors for current visitors calculation
    const currentVisitors = Math.round(
      dailyVisitors * baseCurrentFactor * timeOfDayFactor * dayOfWeekFactor * randomFactor
    );
    
    // Generate traffic history for the past 24 hours
    const trafficHistory = Array.from({ length: 24 }, (_, i) => {
      const historyHour = (hour - i + 24) % 24; // Past hours
      let historyFactor = 0.5;
      
      if (historyHour >= 12 && historyHour <= 20) {
        historyFactor = 0.8 + (Math.random() * 0.4);
      } else if ((historyHour >= 8 && historyHour < 12) || (historyHour > 20 && historyHour <= 23)) {
        historyFactor = 0.6 + (Math.random() * 0.3);
      } else {
        historyFactor = 0.3 + (Math.random() * 0.3);
      }
      
      // The history timestamp is now - (i hours)
      const timestamp = Date.now() - (i * 60 * 60 * 1000);
      const historyVisitors = Math.round(dailyVisitors * 0.05 * historyFactor);
      
      return {
        timestamp,
        visitors: historyVisitors
      };
    });
    
    // Generate real-time data
    const realTimeData = {
      lastUpdated: new Date().toISOString(),
      concurrentVisitors: currentVisitors,
      activePages: [
        { path: '/', visitors: Math.round(currentVisitors * 0.4) },
        { path: '/search', visitors: Math.round(currentVisitors * 0.2) },
        { path: '/news', visitors: Math.round(currentVisitors * 0.15) },
        { path: '/mail', visitors: Math.round(currentVisitors * 0.1) },
        { path: '/maps', visitors: Math.round(currentVisitors * 0.08) },
        { path: '/images', visitors: Math.round(currentVisitors * 0.07) }
      ],
      engagementRate: 0.65 + (Math.random() * 0.2)
    };
    
    // Generate country distribution based on domain type
    let countryDistribution = [];
    
    // Custom distributions for different domains
    if (domain.includes('google.com')) {
      countryDistribution = [
        { country: 'United States', percentage: 20 + Math.random() * 5 },
        { country: 'India', percentage: 15 + Math.random() * 5 },
        { country: 'China', percentage: 10 + Math.random() * 3 },
        { country: 'Germany', percentage: 8 + Math.random() * 2 },
        { country: 'Brazil', percentage: 7 + Math.random() * 2 },
        { country: 'Japan', percentage: 6 + Math.random() * 2 },
        { country: 'United Kingdom', percentage: 5 + Math.random() * 2 },
        { country: 'Other', percentage: 0 }
      ];
    } else if (domain.includes('facebook.com')) {
      countryDistribution = [
        { country: 'India', percentage: 25 + Math.random() * 5 },
        { country: 'United States', percentage: 15 + Math.random() * 5 },
        { country: 'Indonesia', percentage: 10 + Math.random() * 3 },
        { country: 'Brazil', percentage: 9 + Math.random() * 3 },
        { country: 'Mexico', percentage: 7 + Math.random() * 2 },
        { country: 'Philippines', percentage: 6 + Math.random() * 2 },
        { country: 'Vietnam', percentage: 5 + Math.random() * 2 },
        { country: 'Other', percentage: 0 }
      ];
    } else if (domain.includes('amazon.com')) {
      countryDistribution = [
        { country: 'United States', percentage: 35 + Math.random() * 5 },
        { country: 'Germany', percentage: 10 + Math.random() * 3 },
        { country: 'United Kingdom', percentage: 10 + Math.random() * 3 },
        { country: 'Japan', percentage: 8 + Math.random() * 2 },
        { country: 'India', percentage: 7 + Math.random() * 2 },
        { country: 'Canada', percentage: 5 + Math.random() * 2 },
        { country: 'France', percentage: 5 + Math.random() * 2 },
        { country: 'Other', percentage: 0 }
      ];
    } else if (domain.includes('twitter.com')) {
      countryDistribution = [
        { country: 'United States', percentage: 25 + Math.random() * 5 },
        { country: 'Japan', percentage: 20 + Math.random() * 5 },
        { country: 'India', percentage: 10 + Math.random() * 3 },
        { country: 'United Kingdom', percentage: 7 + Math.random() * 2 },
        { country: 'Brazil', percentage: 6 + Math.random() * 2 },
        { country: 'Indonesia', percentage: 5 + Math.random() * 2 },
        { country: 'Turkey', percentage: 5 + Math.random() * 2 },
        { country: 'Other', percentage: 0 }
      ];
    } else if (domain.includes('netflix.com')) {
      countryDistribution = [
        { country: 'United States', percentage: 30 + Math.random() * 5 },
        { country: 'Brazil', percentage: 12 + Math.random() * 3 },
        { country: 'United Kingdom', percentage: 10 + Math.random() * 3 },
        { country: 'Mexico', percentage: 8 + Math.random() * 2 },
        { country: 'Canada', percentage: 7 + Math.random() * 2 },
        { country: 'France', percentage: 6 + Math.random() * 2 },
        { country: 'Germany', percentage: 6 + Math.random() * 2 },
        { country: 'Other', percentage: 0 }
      ];
    } else if (domain.includes('linkedin.com')) {
      countryDistribution = [
        { country: 'United States', percentage: 25 + Math.random() * 5 },
        { country: 'India', percentage: 20 + Math.random() * 5 },
        { country: 'China', percentage: 8 + Math.random() * 3 },
        { country: 'Brazil', percentage: 7 + Math.random() * 2 },
        { country: 'United Kingdom', percentage: 7 + Math.random() * 2 },
        { country: 'France', percentage: 5 + Math.random() * 2 },
        { country: 'Canada', percentage: 5 + Math.random() * 2 },
        { country: 'Other', percentage: 0 }
      ];
    } else if (domain.includes('tiktok.com')) {
      countryDistribution = [
        { country: 'Indonesia', percentage: 15 + Math.random() * 5 },
        { country: 'United States', percentage: 15 + Math.random() * 5 },
        { country: 'Brazil', percentage: 12 + Math.random() * 3 },
        { country: 'Russia', percentage: 10 + Math.random() * 3 },
        { country: 'Mexico', percentage: 8 + Math.random() * 2 },
        { country: 'Vietnam', percentage: 7 + Math.random() * 2 },
        { country: 'Thailand', percentage: 6 + Math.random() * 2 },
        { country: 'Other', percentage: 0 }
      ];
    } else if (domain.includes('youtube.com')) {
      countryDistribution = [
        { country: 'India', percentage: 20 + Math.random() * 5 },
        { country: 'United States', percentage: 15 + Math.random() * 5 },
        { country: 'Brazil', percentage: 10 + Math.random() * 3 },
        { country: 'Indonesia', percentage: 9 + Math.random() * 3 },
        { country: 'Japan', percentage: 8 + Math.random() * 2 },
        { country: 'Russia', percentage: 7 + Math.random() * 2 },
        { country: 'Mexico', percentage: 6 + Math.random() * 2 },
        { country: 'Other', percentage: 0 }
      ];
    } else if (domain.includes('shopify.com')) {
      countryDistribution = [
        { country: 'United States', percentage: 28 + Math.random() * 5 },
        { country: 'Canada', percentage: 18 + Math.random() * 5 },
        { country: 'United Kingdom', percentage: 12 + Math.random() * 3 },
        { country: 'Australia', percentage: 9 + Math.random() * 3 },
        { country: 'Germany', percentage: 6 + Math.random() * 2 },
        { country: 'France', percentage: 5 + Math.random() * 2 },
        { country: 'India', percentage: 4 + Math.random() * 2 },
        { country: 'Other', percentage: 0 }
      ];
    } else if (domain.includes('airbnb.com')) {
      countryDistribution = [
        { country: 'United States', percentage: 30 + Math.random() * 5 },
        { country: 'France', percentage: 10 + Math.random() * 3 },
        { country: 'United Kingdom', percentage: 10 + Math.random() * 3 },
        { country: 'Spain', percentage: 9 + Math.random() * 3 },
        { country: 'Italy', percentage: 8 + Math.random() * 2 },
        { country: 'Germany', percentage: 6 + Math.random() * 2 },
        { country: 'Australia', percentage: 5 + Math.random() * 2 },
        { country: 'Other', percentage: 0 }
      ];
    } else if (domain.includes('instagram.com')) {
      countryDistribution = [
        { country: 'India', percentage: 18 + Math.random() * 5 },
        { country: 'United States', percentage: 15 + Math.random() * 5 },
        { country: 'Brazil', percentage: 12 + Math.random() * 3 },
        { country: 'Indonesia', percentage: 10 + Math.random() * 3 },
        { country: 'Russia', percentage: 8 + Math.random() * 2 },
        { country: 'Turkey', percentage: 6 + Math.random() * 2 },
        { country: 'Japan', percentage: 5 + Math.random() * 2 },
        { country: 'Other', percentage: 0 }
      ];
    } else {
      // Default distribution for any other domain
      countryDistribution = [
        { country: 'United States', percentage: 20 + Math.random() * 5 },
        { country: 'India', percentage: 15 + Math.random() * 5 },
        { country: 'China', percentage: 10 + Math.random() * 3 },
        { country: 'Germany', percentage: 8 + Math.random() * 2 },
        { country: 'United Kingdom', percentage: 7 + Math.random() * 2 },
        { country: 'Brazil', percentage: 6 + Math.random() * 2 },
        { country: 'Japan', percentage: 5 + Math.random() * 2 },
        { country: 'Other', percentage: 0 }
      ];
    }
    
    // Ensure percentages sum to 100%
    const sum = countryDistribution.reduce((acc, curr) => acc + curr.percentage, 0);
    countryDistribution[countryDistribution.length - 1].percentage = Math.max(0, 100 - sum);
    
    // Generate traffic sources
    const trafficSources = [
      { source: 'Direct', percentage: 35 + Math.random() * 10 },
      { source: 'Search', percentage: 25 + Math.random() * 10 },
      { source: 'Social', percentage: 15 + Math.random() * 10 },
      { source: 'Referral', percentage: 10 + Math.random() * 5 },
      { source: 'Other', percentage: 0 }
    ];
    
    // Ensure percentages sum to 100%
    const sourceSum = trafficSources.reduce((acc, curr) => acc + curr.percentage, 0);
    trafficSources[trafficSources.length - 1].percentage = Math.max(0, 100 - sourceSum);
    
    // Add current visitors to each country
    countryDistribution = countryDistribution.map(country => {
      const countryCurrentVisitors = Math.round(currentVisitors * (country.percentage / 100));
      const trend: 'up' | 'down' | 'stable' = Math.random() > 0.6 ? 'up' : Math.random() > 0.4 ? 'down' : 'stable';
      return {
        ...country,
        currentVisitors: countryCurrentVisitors,
        trend
      };
    });
    
    // Custom active pages based on domain type
    let activePages = [];
    if (domain.includes('google.com')) {
      activePages = [
        { path: '/', visitors: Math.round(currentVisitors * 0.3) },
        { path: '/search', visitors: Math.round(currentVisitors * 0.4) },
        { path: '/maps', visitors: Math.round(currentVisitors * 0.1) },
        { path: '/gmail', visitors: Math.round(currentVisitors * 0.1) },
        { path: '/images', visitors: Math.round(currentVisitors * 0.05) },
        { path: '/other', visitors: Math.round(currentVisitors * 0.05) }
      ];
    } else if (domain.includes('facebook.com')) {
      activePages = [
        { path: '/', visitors: Math.round(currentVisitors * 0.25) },
        { path: '/feed', visitors: Math.round(currentVisitors * 0.35) },
        { path: '/profile', visitors: Math.round(currentVisitors * 0.15) },
        { path: '/messages', visitors: Math.round(currentVisitors * 0.1) },
        { path: '/groups', visitors: Math.round(currentVisitors * 0.1) },
        { path: '/other', visitors: Math.round(currentVisitors * 0.05) }
      ];
    } else if (domain.includes('youtube.com')) {
      activePages = [
        { path: '/', visitors: Math.round(currentVisitors * 0.2) },
        { path: '/watch', visitors: Math.round(currentVisitors * 0.5) },
        { path: '/feed/trending', visitors: Math.round(currentVisitors * 0.1) },
        { path: '/feed/subscriptions', visitors: Math.round(currentVisitors * 0.1) },
        { path: '/channel', visitors: Math.round(currentVisitors * 0.05) },
        { path: '/other', visitors: Math.round(currentVisitors * 0.05) }
      ];
    } else {
      // Default active pages
      activePages = [
        { path: '/', visitors: Math.round(currentVisitors * 0.4) },
        { path: '/products', visitors: Math.round(currentVisitors * 0.2) },
        { path: '/about', visitors: Math.round(currentVisitors * 0.15) },
        { path: '/contact', visitors: Math.round(currentVisitors * 0.1) },
        { path: '/blog', visitors: Math.round(currentVisitors * 0.1) },
        { path: '/other', visitors: Math.round(currentVisitors * 0.05) }
      ];
    }
    
    // Update real-time data with custom active pages
    const updatedRealTimeData = {
      ...realTimeData,
      activePages,
      lastUpdated: new Date().toISOString()
    };
    
    return {
      domain,
      monthlyVisitors,
      dailyVisitors,
      currentVisitors,
      countryDistribution,
      trafficSources,
      timeOnSite: 3 + Math.random() * 5, // 3-8 minutes
      pagesPerVisit: 2 + Math.random() * 3, // 2-5 pages
      bounceRate: 30 + Math.random() * 20, // 30-50%
      trafficHistory,
      realTimeData: updatedRealTimeData
    };
  }
}

// Singleton instance
export const trafficEstimateService = new TrafficEstimateService();