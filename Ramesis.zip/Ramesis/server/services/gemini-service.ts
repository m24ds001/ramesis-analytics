import { GoogleGenerativeAI } from '@google/generative-ai';

export class GeminiService {
  private genAI: GoogleGenerativeAI;
  private model: any;

  constructor() {
    if (!process.env.GOOGLE_AI_API_KEY) {
      throw new Error('GOOGLE_AI_API_KEY environment variable is required');
    }
    
    this.genAI = new GoogleGenerativeAI(process.env.GOOGLE_AI_API_KEY);
    this.model = this.genAI.getGenerativeModel({ model: "gemini-pro" });
  }

  async generateInsights(analyticsData: any): Promise<any[]> {
    try {
      const prompt = `
        As an expert web analytics consultant, analyze the following website analytics data and provide 3 specific, actionable insights:

        Analytics Data:
        - Active Users: ${analyticsData.activeUsers || 'N/A'}
        - Bounce Rate: ${analyticsData.bounceRate || 'N/A'}%
        - Conversion Rate: ${analyticsData.conversionRate || 'N/A'}%
        - Page Views: ${analyticsData.pageViews || 'N/A'}
        - Session Duration: ${analyticsData.sessionDuration || 'N/A'} minutes
        - Top Traffic Sources: ${JSON.stringify(analyticsData.topSources || [])}
        - Top Pages: ${JSON.stringify(analyticsData.topPages || [])}

        Provide exactly 3 insights in this JSON format:
        [
          {
            "insight": "specific insight text",
            "category": "warning|suggestion|success",
            "confidence": "high|medium|low"
          }
        ]

        Focus on:
        1. Performance compared to industry standards
        2. Specific optimization recommendations
        3. Growth opportunities

        Return only valid JSON, no additional text.
      `;

      const result = await this.model.generateContent(prompt);
      const response = await result.response;
      const text = response.text();
      
      try {
        const insights = JSON.parse(text);
        return Array.isArray(insights) ? insights : [insights];
      } catch (parseError) {
        console.error('Failed to parse Gemini response as JSON:', text);
        // Fallback to basic insights if JSON parsing fails
        return this.generateFallbackInsights(analyticsData);
      }
    } catch (error) {
      console.error('Error calling Gemini API:', error);
      throw error;
    }
  }

  private generateFallbackInsights(analyticsData: any): any[] {
    const insights = [];
    
    if (analyticsData.bounceRate && analyticsData.bounceRate > 50) {
      insights.push({
        insight: `Your bounce rate of ${analyticsData.bounceRate}% is above the industry average. Consider improving page load speed and content relevance.`,
        category: 'warning',
        confidence: 'high'
      });
    }
    
    if (analyticsData.conversionRate && analyticsData.conversionRate < 3) {
      insights.push({
        insight: `Conversion rate of ${analyticsData.conversionRate}% has room for improvement. Test different call-to-action buttons and landing page designs.`,
        category: 'suggestion',
        confidence: 'medium'
      });
    }
    
    insights.push({
      insight: 'Your analytics show consistent user engagement patterns. Consider expanding successful content categories.',
      category: 'success',
      confidence: 'medium'
    });
    
    return insights.slice(0, 3);
  }
}

export const geminiService = new GeminiService();