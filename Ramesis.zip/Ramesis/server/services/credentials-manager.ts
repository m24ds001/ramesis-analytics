import { db } from '../db';
import { websiteCredentials } from '@shared/schema';
import { eq } from 'drizzle-orm';

export interface CredentialsData {
  provider: string;
  credentials: any;
}

export class CredentialsManager {
  async storeCredentials(websiteId: number, provider: string, credentials: any): Promise<void> {
    try {
      // Check if credentials already exist for this website and provider
      const [existingCredentials] = await db
        .select()
        .from(websiteCredentials)
        .where(
          eq(websiteCredentials.websiteId, websiteId) && 
          eq(websiteCredentials.provider, provider)
        );
      
      if (existingCredentials) {
        // Update existing credentials
        await db
          .update(websiteCredentials)
          .set({ 
            credentials: JSON.stringify(credentials),
            updatedAt: new Date()
          })
          .where(eq(websiteCredentials.id, existingCredentials.id));
      } else {
        // Insert new credentials
        await db
          .insert(websiteCredentials)
          .values({
            websiteId,
            provider,
            credentials: JSON.stringify(credentials),
            createdAt: new Date(),
            updatedAt: new Date()
          });
      }
    } catch (error) {
      console.error('Error storing credentials:', error);
      throw error;
    }
  }
  
  async getCredentials(websiteId: number, provider: string): Promise<any> {
    try {
      const [storedCredentials] = await db
        .select()
        .from(websiteCredentials)
        .where(
          eq(websiteCredentials.websiteId, websiteId) && 
          eq(websiteCredentials.provider, provider)
        );
      
      if (!storedCredentials) {
        return null;
      }
      
      return JSON.parse(storedCredentials.credentials);
    } catch (error) {
      console.error('Error retrieving credentials:', error);
      throw error;
    }
  }
  
  async deleteCredentials(websiteId: number, provider: string): Promise<void> {
    try {
      await db
        .delete(websiteCredentials)
        .where(
          eq(websiteCredentials.websiteId, websiteId) && 
          eq(websiteCredentials.provider, provider)
        );
    } catch (error) {
      console.error('Error deleting credentials:', error);
      throw error;
    }
  }
}

export const credentialsManager = new CredentialsManager();