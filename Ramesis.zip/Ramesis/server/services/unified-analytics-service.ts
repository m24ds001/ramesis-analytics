import { ga4Service } from './ga4-service';
import { adobeAnalyticsService } from './adobe-analytics-service';
import { mixpanelService } from './mixpanel-service';
import { matomoService } from './matomo-service';

// Common analytics response interface
export interface AnalyticsResponse {
  activeUsers: number;
  pageViews: number; 
  bounceRate: number;
  conversionRate: number;
  averageSessionDuration: number;
  source: string;
  timestamp: number;
}

// Available analytics providers
export type AnalyticsProvider = 'google' | 'adobe' | 'mixpanel' | 'matomo';

// Class for unified analytics integration
export class UnifiedAnalyticsService {
  private initialized: boolean = false;
  
  constructor() {
    // Initialize all available analytics services
    this.initializeProviders();
  }
  
  /**
   * Initialize all analytics providers
   */
  async initializeProviders(): Promise<void> {
    console.log('Initializing analytics providers...');
    
    // Initialize Google Analytics
    const ga4Initialized = await ga4Service.initialize();
    if (ga4Initialized) {
      console.log('Google Analytics initialized successfully');
    }
    
    // Initialize Adobe Analytics (credentials should be provided)
    const adobeInitialized = await adobeAnalyticsService.initialize();
    if (adobeInitialized) {
      console.log('Adobe Analytics initialized successfully');
    }
    
    // Initialize Mixpanel (credentials should be provided)
    const mixpanelInitialized = await mixpanelService.initialize();
    if (mixpanelInitialized) {
      console.log('Mixpanel initialized successfully');
    }
    
    // Initialize Matomo (credentials should be provided)
    const matomoInitialized = await matomoService.initialize();
    if (matomoInitialized) {
      console.log('Matomo initialized successfully');
    }
    
    this.initialized = true;
    console.log('Finished initializing analytics providers');
  }
  
  /**
   * Get real-time analytics data from all available providers
   */
  async getRealTimeData(websiteName?: string): Promise<AnalyticsResponse[]> {
    try {
      // Ensure providers are initialized
      if (!this.initialized) {
        await this.initializeProviders();
      }
      
      const responses: AnalyticsResponse[] = [];
      const timestamp = Date.now();
      
      // Get Google Analytics data
      try {
        const ga4Data = await ga4Service.getRealTimeData(websiteName || 'current');
        if (ga4Data) {
          responses.push({
            ...ga4Data,
            source: 'google',
            timestamp
          });
        }
      } catch (gaError) {
        console.error('Error getting Google Analytics real-time data:', gaError);
      }
      
      // Get Adobe Analytics data
      try {
        const adobeData = await adobeAnalyticsService.getRealTimeData(websiteName || 'current');
        if (adobeData) {
          responses.push({
            ...adobeData,
            source: 'adobe',
            timestamp
          });
        }
      } catch (adobeError) {
        console.error('Error getting Adobe Analytics real-time data:', adobeError);
      }
      
      // Get Mixpanel data
      try {
        const mixpanelData = await mixpanelService.getRealTimeData(websiteName || 'current');
        if (mixpanelData) {
          responses.push({
            ...mixpanelData,
            source: 'mixpanel',
            timestamp
          });
        }
      } catch (mixpanelError) {
        console.error('Error getting Mixpanel real-time data:', mixpanelError);
      }
      
      // Get Matomo data
      try {
        const matomoData = await matomoService.getRealTimeData(websiteName || 'current');
        if (matomoData) {
          responses.push({
            ...matomoData,
            source: 'matomo',
            timestamp
          });
        }
      } catch (matomoError) {
        console.error('Error getting Matomo real-time data:', matomoError);
      }
      
      return responses;
    } catch (error) {
      console.error('Error getting unified real-time data:', error);
      return [];
    }
  }
  
  /**
   * Get website's analytics data from a specific provider
   */
  async getProviderData(websiteName: string, provider: AnalyticsProvider): Promise<AnalyticsResponse | null> {
    try {
      // Ensure providers are initialized
      if (!this.initialized) {
        await this.initializeProviders();
      }
      
      const timestamp = Date.now();
      
      // Get data from the specified provider
      switch (provider) {
        case 'google':
          const ga4Data = await ga4Service.getRealTimeData(websiteName);
          return { ...ga4Data, source: 'google', timestamp };
          
        case 'adobe':
          const adobeData = await adobeAnalyticsService.getRealTimeData(websiteName);
          return { ...adobeData, source: 'adobe', timestamp };
          
        case 'mixpanel':
          const mixpanelData = await mixpanelService.getRealTimeData(websiteName);
          return { ...mixpanelData, source: 'mixpanel', timestamp };
          
        case 'matomo':
          const matomoData = await matomoService.getRealTimeData(websiteName);
          return { ...matomoData, source: 'matomo', timestamp };
          
        default:
          console.error(`Unknown provider: ${provider}`);
          return null;
      }
    } catch (error) {
      console.error(`Error getting ${provider} data for ${websiteName}:`, error);
      return null;
    }
  }
}

// Singleton instance
export const unifiedAnalyticsService = new UnifiedAnalyticsService();