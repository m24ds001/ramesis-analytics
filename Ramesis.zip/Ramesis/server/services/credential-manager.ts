import CryptoJS from 'crypto-js';

// Make sure we have an encryption key
if (!process.env.ENCRYPTION_KEY) {
  console.warn('WARNING: ENCRYPTION_KEY is not set. Using a default key for development only.');
  process.env.ENCRYPTION_KEY = 'default-development-key-do-not-use-in-production';
}

/**
 * Encrypt sensitive credential data
 * @param data The data to encrypt (can be a string or object)
 * @returns Encrypted string
 */
export const encrypt = (data: string | object): string => {
  // Convert object to string if needed
  const dataString = typeof data === 'string' ? data : JSON.stringify(data);
  
  // Encrypt with AES using environment variable as key
  return CryptoJS.AES.encrypt(dataString, process.env.ENCRYPTION_KEY!).toString();
};

/**
 * Decrypt sensitive credential data
 * @param encryptedData The encrypted string
 * @returns Decrypted data as string
 */
export const decrypt = (encryptedData: string): string => {
  // Decrypt with AES
  const bytes = CryptoJS.AES.decrypt(encryptedData, process.env.ENCRYPTION_KEY!);
  return bytes.toString(CryptoJS.enc.Utf8);
};

/**
 * Decrypt and parse JSON data
 * @param encryptedData The encrypted string containing JSON
 * @returns Parsed object from decrypted JSON
 */
export const decryptJSON = <T>(encryptedData: string): T => {
  const decrypted = decrypt(encryptedData);
  return JSON.parse(decrypted) as T;
};

/**
 * Store credentials securely
 * @param credentials The credentials to store
 * @returns Encrypted string for database storage
 */
export const storeCredentials = (credentials: any): string => {
  // Remove any sensitive data that shouldn't be stored at all
  const cleanedCredentials = { ...credentials };
  
  // Encrypt the cleaned credentials
  return encrypt(cleanedCredentials);
};