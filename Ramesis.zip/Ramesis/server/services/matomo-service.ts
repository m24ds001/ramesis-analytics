import axios from 'axios';

// Define interface for Matomo response
interface MatomoResponse {
  activeUsers: number;
  pageViews: number;
  bounceRate: number;
  conversionRate: number;
  averageSessionDuration: number;
}

// Class for Matomo (formerly Piwik) API integration
export class MatomoService {
  private apiUrl: string | null = null;
  private tokenAuth: string | null = null;
  private initialized: boolean = false;
  
  constructor() {
    // Look for Matomo credentials in environment
    this.apiUrl = process.env.MATOMO_API_URL || 'https://demo.matomo.cloud';
    this.tokenAuth = process.env.MATOMO_TOKEN_AUTH || null;
    
    if (this.apiUrl && this.tokenAuth) {
      console.log('Found Matomo credentials');
      this.initialized = true;
    }
  }
  
  /**
   * Check if the Matomo service is available
   */
  async isAvailable(): Promise<boolean> {
    // If we're already initialized, we're available
    if (this.initialized) return true;
    
    // Try to initialize if we haven't yet
    return await this.initialize();
  }
  
  /**
   * Initialize Matomo API client
   */
  async initialize(apiUrl?: string, tokenAuth?: string): Promise<boolean> {
    try {
      if (apiUrl) this.apiUrl = apiUrl;
      if (tokenAuth) this.tokenAuth = tokenAuth;
      
      // If we already have the credentials, we're initialized
      if (this.apiUrl && this.tokenAuth) {
        this.initialized = true;
        console.log('Successfully initialized Matomo API');
        return true;
      }
      
      console.error('Missing Matomo credentials');
      return false;
    } catch (error) {
      console.error('Error initializing Matomo service:', error);
      return false;
    }
  }
  
  /**
   * Get real-time analytics data from Matomo
   */
  async getRealTimeData(siteId: string): Promise<MatomoResponse> {
    try {
      // Ensure we're initialized
      if (!this.initialized) {
        if (!(await this.initialize())) {
          // Return true zeros when API isn't available
          return this.getEmptyResponse();
        }
      }
      
      if (!this.apiUrl || !this.tokenAuth) {
        console.error('Matomo API URL or token not set');
        return this.getEmptyResponse();
      }
      
      try {
        // Query for live visitor count (active users)
        const liveResponse = await axios.get(`${this.apiUrl}?module=API&method=Live.getCounters&idSite=${siteId}&lastMinutes=30&format=JSON&token_auth=${this.tokenAuth}`);
        
        // Query for page view metrics
        const pageViewsResponse = await axios.get(`${this.apiUrl}?module=API&method=VisitsSummary.get&idSite=${siteId}&period=day&date=today&format=JSON&token_auth=${this.tokenAuth}`);
        
        // Extract metrics from responses
        let activeUsers = 0;
        let pageViews = 0;
        let bounceRate = 0;
        let conversionRate = 0;
        let averageSessionDuration = 0;
        
        // Extract active users
        if (liveResponse.data && Array.isArray(liveResponse.data) && liveResponse.data.length > 0) {
          activeUsers = liveResponse.data[0].visits || 0;
        }
        
        // Extract pageviews, bounce rate, and average time on site
        if (pageViewsResponse.data) {
          pageViews = pageViewsResponse.data.nb_pageviews || 0;
          bounceRate = pageViewsResponse.data.bounce_rate || 0;
          averageSessionDuration = pageViewsResponse.data.avg_time_on_site || 0;
          
          // Get conversion rate from goals if available
          const goalConversions = pageViewsResponse.data.nb_conversions || 0;
          const visits = pageViewsResponse.data.nb_visits || 1; // Avoid division by zero
          conversionRate = (goalConversions / visits) * 100;
        }
        
        return {
          activeUsers,
          pageViews,
          bounceRate,
          conversionRate,
          averageSessionDuration
        };
        
      } catch (apiError) {
        console.error('Error calling Matomo API:', apiError);
        return this.getEmptyResponse();
      }
    } catch (error) {
      console.error('Error getting Matomo real-time data:', error);
      return this.getEmptyResponse();
    }
  }
  
  /**
   * Get empty response (zeros) when Matomo API is not available
   */
  private getEmptyResponse(): MatomoResponse {
    return {
      activeUsers: 0,
      pageViews: 0,
      bounceRate: 0,
      conversionRate: 0,
      averageSessionDuration: 0
    };
  }
}

// Singleton instance
export const matomoService = new MatomoService();