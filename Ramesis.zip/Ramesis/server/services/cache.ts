import { createClient } from 'redis';
import { createChildSpan } from '../middleware/tracing';

// Initialize Redis client with fallback to in-memory cache
let redisClient: ReturnType<typeof createClient>;
let inMemoryCache: Map<string, { value: any; expiry: number }>;
let usingInMemory = false;

// Initialize cache
async function initializeCache() {
  try {
    // Use Redis client when REDIS_URL is available
    if (process.env.REDIS_URL) {
      redisClient = createClient({
        url: process.env.REDIS_URL,
        socket: {
          reconnectStrategy: (retries) => Math.min(retries * 50, 2000), // Exponential backoff
        }
      });
      
      // Add error handling
      redisClient.on('error', (err) => {
        console.error('Redis client error', err);
        // If we haven't already switched to in-memory, do so now
        if (!usingInMemory) {
          console.warn('Switching to in-memory cache due to Redis error');
          setupInMemoryCache();
        }
      });
      
      await redisClient.connect();
      console.info('Connected to Redis cache');
    } else {
      // If no REDIS_URL, use in-memory cache
      console.info('No REDIS_URL available, using in-memory cache');
      setupInMemoryCache();
    }
  } catch (error) {
    console.error('Failed to initialize Redis cache:', error);
    // Fall back to in-memory cache
    setupInMemoryCache();
  }
}

// Set up in-memory cache as fallback
function setupInMemoryCache() {
  usingInMemory = true;
  inMemoryCache = new Map();
  
  // Clean up expired items periodically
  setInterval(() => {
    const now = Date.now();
    for (const [key, { expiry }] of inMemoryCache.entries()) {
      if (expiry < now) {
        inMemoryCache.delete(key);
      }
    }
  }, 60000); // Run every minute
}

// Call initialize at module load time
initializeCache();

/**
 * Generic cache interface that handles both Redis and in-memory storage
 */
class CacheService {
  private prefix: string;
  private defaultTtl: number;
  
  constructor({ prefix, ttl = 300 }: { prefix: string; ttl?: number }) {
    this.prefix = prefix;
    this.defaultTtl = ttl; // Time in seconds
  }
  
  private getFullKey(key: string): string {
    return `${this.prefix}:${key}`;
  }
  
  /**
   * Get an item from cache. Returns null if not found.
   */
  async get<T>(key: string): Promise<T | null> {
    return createChildSpan(`cache:get:${this.prefix}`, async () => {
      const fullKey = this.getFullKey(key);
      
      if (usingInMemory) {
        const item = inMemoryCache.get(fullKey);
        if (!item || item.expiry < Date.now()) {
          return null;
        }
        return item.value as T;
      } else {
        const value = await redisClient.get(fullKey);
        if (!value) return null;
        
        try {
          return JSON.parse(value) as T;
        } catch (e) {
          console.error(`Failed to parse cached value for key ${key}`, e);
          return null;
        }
      }
    });
  }
  
  /**
   * Store an item in cache with optional TTL
   */
  async set<T>(key: string, value: T, ttl: number = this.defaultTtl): Promise<boolean> {
    return createChildSpan(`cache:set:${this.prefix}`, async () => {
      const fullKey = this.getFullKey(key);
      
      if (usingInMemory) {
        inMemoryCache.set(fullKey, {
          value,
          expiry: Date.now() + ttl * 1000
        });
        return true;
      } else {
        try {
          const serialized = JSON.stringify(value);
          await redisClient.set(fullKey, serialized, { EX: ttl });
          return true;
        } catch (error) {
          console.error(`Failed to cache value for key ${key}:`, error);
          return false;
        }
      }
    });
  }
  
  /**
   * Delete an item from cache
   */
  async delete(key: string): Promise<boolean> {
    return createChildSpan(`cache:delete:${this.prefix}`, async () => {
      const fullKey = this.getFullKey(key);
      
      if (usingInMemory) {
        return inMemoryCache.delete(fullKey);
      } else {
        const deleted = await redisClient.del(fullKey);
        return deleted > 0;
      }
    });
  }
  
  /**
   * Clear all items with this prefix
   */
  async clear(): Promise<boolean> {
    return createChildSpan(`cache:clear:${this.prefix}`, async () => {
      if (usingInMemory) {
        for (const key of inMemoryCache.keys()) {
          if (key.startsWith(this.prefix)) {
            inMemoryCache.delete(key);
          }
        }
        return true;
      } else {
        try {
          // Find all keys with this prefix
          let cursor = 0;
          let keys: string[] = [];
          
          do {
            const result = await redisClient.scan(cursor, {
              MATCH: `${this.prefix}:*`,
              COUNT: 100
            });
            
            cursor = result.cursor;
            keys = keys.concat(result.keys);
          } while (cursor !== 0);
          
          // Delete all keys found
          if (keys.length > 0) {
            await redisClient.del(keys);
          }
          
          return true;
        } catch (error) {
          console.error('Failed to clear cache with prefix', this.prefix, error);
          return false;
        }
      }
    });
  }
}

// Export pre-configured caches for different parts of the application
export const analyticsCache = new CacheService({
  prefix: 'analytics',
  ttl: 300 // 5 minutes
});

export const websiteCache = new CacheService({
  prefix: 'websites',
  ttl: 3600 // 1 hour
});

export const userCache = new CacheService({
  prefix: 'users',
  ttl: 1800 // 30 minutes
});

// Function to wrap an async function with caching
export async function withCache<T>(
  cache: CacheService,
  key: string,
  fn: () => Promise<T>,
  ttl?: number
): Promise<T> {
  // Try to get from cache first
  const cached = await cache.get<T>(key);
  if (cached !== null) {
    return cached;
  }
  
  // If not in cache, execute the function
  const result = await fn();
  
  // Store in cache for next time
  await cache.set(key, result, ttl);
  
  return result;
}