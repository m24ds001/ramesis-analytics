import { WebSocketServer } from 'ws';
import { AnalyticsUpdate, broadcastAnalyticsUpdate } from '../websocket-server';
import { storage } from '../storage';

/**
 * Debounce function to limit frequent broadcasts
 */
function debounce<T extends (...args: any[]) => any>(
  func: T, 
  wait: number
): (...args: Parameters<T>) => void {
  let timeout: NodeJS.Timeout | null = null;
  
  return function(...args: Parameters<T>): void {
    const later = () => {
      timeout = null;
      func(...args);
    };
    
    if (timeout !== null) {
      clearTimeout(timeout);
    }
    timeout = setTimeout(later, wait);
  };
}

/**
 * Realtime analytics service with optimization features
 */
export class RealtimeAnalyticsService {
  private wss: WebSocketServer;
  private updateBatch: AnalyticsUpdate[] = [];
  private batchInterval: NodeJS.Timeout | null = null;
  
  // Create debounced version of broadcast function (100ms wait)
  private debouncedBroadcast = debounce(
    (update: AnalyticsUpdate) => broadcastAnalyticsUpdate(this.wss, update),
    100
  );
  
  constructor(wss: WebSocketServer) {
    this.wss = wss;
    this.startBatchProcessor();
  }
  
  /**
   * Start the batch processing interval (sends updates every second)
   */
  private startBatchProcessor(): void {
    this.batchInterval = setInterval(() => {
      if (this.updateBatch.length > 0) {
        broadcastAnalyticsUpdate(this.wss, {
          eventType: 'BATCH_UPDATE',
          data: [...this.updateBatch]
        });
        this.updateBatch = [];
      }
    }, 1000);
  }
  
  /**
   * Stop the batch processor (called on service shutdown)
   */
  public stopBatchProcessor(): void {
    if (this.batchInterval) {
      clearInterval(this.batchInterval);
      this.batchInterval = null;
    }
  }
  
  /**
   * Process a tracking event and broadcast update
   * For high-frequency events, this adds to batch
   * For important events, this uses debounced immediate broadcast
   */
  public async processTrackingEvent(event: any): Promise<void> {
    // Store event in database
    const storedEvent = await storage.createEvent(event);
    
    // Determine if this is a high-priority event that needs immediate broadcast
    const isHighPriority = event.eventType === 'conversion' || 
                          event.eventType === 'purchase';
    
    if (isHighPriority) {
      // Use debounced broadcast for important but potentially frequent events
      this.debouncedBroadcast({
        eventType: 'NEW_EVENT',
        data: storedEvent
      });
    } else {
      // Add to batch for regular events
      this.updateBatch.push({
        eventType: 'NEW_EVENT',
        data: storedEvent
      });
    }
    
    // Update active visitor count asynchronously
    this.updateActiveVisitorCount();
  }
  
  /**
   * Update the active visitor count and broadcast
   */
  private async updateActiveVisitorCount(): Promise<void> {
    try {
      // Get active visitor count from last 5 minutes
      const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000);
      const recentVisits = await storage.getVisitsByTimeRange(fiveMinutesAgo, new Date());
      
      // Count unique session IDs
      const uniqueSessions = new Set(recentVisits.map(visit => visit.sessionId));
      const activeVisitors = uniqueSessions.size;
      
      // Broadcast update (no need to batch or debounce this less frequent metric)
      broadcastAnalyticsUpdate(this.wss, {
        eventType: 'ACTIVE_VISITORS_UPDATE',
        data: {
          metricType: 'activeUsers',
          value: activeVisitors,
          timestamp: Date.now()
        }
      });
    } catch (error) {
      console.error('Error updating active visitor count:', error);
    }
  }
  
  /**
   * Test utility to simulate analytics events for load testing
   */
  public async simulateEvents(count: number): Promise<void> {
    const events = [];
    const sessionId = `test-${Date.now()}`;
    const eventTypes = ['page_view', 'click', 'scroll', 'conversion'];
    
    for (let i = 0; i < count; i++) {
      const eventType = eventTypes[Math.floor(Math.random() * eventTypes.length)];
      events.push({
        sessionId,
        eventType,
        page: '/test-page',
        eventData: { testId: i }
      });
    }
    
    // Process all events
    for (const event of events) {
      await this.processTrackingEvent(event);
    }
    
    console.log(`Simulated ${count} events for testing`);
  }
}