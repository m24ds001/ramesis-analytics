import { z } from 'zod';
import OpenAI from 'openai';
import { AiInsight, InsertAiInsight } from '@shared/schema';

// Initialize OpenAI client
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY || (() => {
    console.warn('WARNING: OPENAI_API_KEY is not set. AI features will not work.');
    return '';
  })()
});

// Define schema for insight responses
export const insightResponseSchema = z.object({
  insight: z.string().min(10),
  explanation: z.string().min(20),
  confidence: z.number().min(0).max(1),
  recommendedActions: z.array(z.string().min(5)),
  category: z.enum(['performance', 'engagement', 'conversion', 'content', 'user_experience']).optional(),
  priority: z.enum(['low', 'medium', 'high']).optional().default('medium')
});

export type InsightResponse = z.infer<typeof insightResponseSchema>;

/**
 * Parse and validate insight response from OpenAI
 */
export const parseInsightsResponse = (response: string): InsightResponse => {
  try {
    return insightResponseSchema.parse(JSON.parse(response));
  } catch (error) {
    console.error('Failed to parse OpenAI response:', error);
    throw new Error('Invalid AI response format');
  }
};

/**
 * Generate insights from analytics data
 */
export async function generateInsightsFromData(
  analyticsData: any,
  websiteName: string
): Promise<InsightResponse> {
  const prompt = `
    Analyze the following analytics data for the website "${websiteName}":
    
    ${JSON.stringify(analyticsData, null, 2)}
    
    Please provide:
    1. A key insight about user behavior or performance
    2. A brief explanation of why this insight matters
    3. A confidence score between 0 and 1
    4. 2-3 recommended actions based on this insight
    5. A category from: performance, engagement, conversion, content, user_experience
    6. A priority level: low, medium, or high

    Format as a JSON object with fields: 
    insight, explanation, confidence, recommendedActions, category, priority
  `;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        { role: "system", content: "You are an expert analytics consultant." },
        { role: "user", content: prompt }
      ],
      response_format: { type: "json_object" }
    });

    const content = response.choices[0].message.content;
    return parseInsightsResponse(content);
  } catch (error) {
    console.error("Error generating insights with OpenAI:", error);
    throw new Error("Failed to generate AI insights");
  }
}

/**
 * Convert InsightResponse to InsertAiInsight for database storage
 */
export function convertToInsertAiInsight(
  insight: InsightResponse, 
  websiteId: number
): InsertAiInsight {
  return {
    websiteId,
    title: insight.insight.substring(0, 100), // Limit title length
    content: insight.explanation,
    category: insight.category || 'performance',
    insightType: 'automatic',
    confidence: insight.confidence,
    actionItems: insight.recommendedActions,
    isRead: false,
    timestamp: new Date()
  };
}