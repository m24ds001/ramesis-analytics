/**
 * Utility to generate realistic analytics data that scales with time periods
 */

// Base analytics data structure
export interface BaseAnalyticsData {
  activeUsers: number;
  pageViews: number;
  bounceRate: number;
  conversionRate: number;
  averageSessionDuration: number;
}

// Seed data for different providers to ensure consistent but varying numbers
const providerSeeds = {
  'google': { users: 768, views: 2450, bounce: 52.6, conversion: 4.2, duration: 187 },
  'adobe': { users: 825, views: 2710, bounce: 48.9, conversion: 3.8, duration: 203 },
  'mixpanel': { users: 712, views: 2280, bounce: 55.3, conversion: 4.7, duration: 175 },
  'default': { users: 750, views: 2500, bounce: 50.0, conversion: 4.0, duration: 180 }
};

// Domain-specific multipliers to create variation between websites
const domainMultipliers: Record<string, number> = {
  'google.com': 52.6,
  'amazon.com': 43.2,
  'facebook.com': 37.8,
  'apple.com': 24.5,
  'netflix.com': 18.7,
  'microsoft.com': 21.3,
  'ebay.com': 12.6,
  'instagram.com': 31.4,
  'twitter.com': 28.9,
  'youtube.com': 45.1,
  'linkedin.com': 15.8,
  'default': 10.0
};

/**
 * Get time period scaling factors
 * @param timePeriod The time period to scale for (7days, 14days, 30days, 90days, year)
 */
export function getTimePeriodScalingFactors(timePeriod: string): {
  userFactor: number,
  viewFactor: number,
  bounceFactor: number,
  conversionFactor: number,
  durationFactor: number
} {
  switch(timePeriod) {
    case '7days':
      return {
        userFactor: 0.35,
        viewFactor: 0.32,
        bounceFactor: 1.15,
        conversionFactor: 1.35, // Significantly higher conversion rates for short time periods
        durationFactor: 0.85
      };
    case '14days':
      return {
        userFactor: 0.55,
        viewFactor: 0.52,
        bounceFactor: 1.08,
        conversionFactor: 1.15, // Higher conversion rates for shorter time periods
        durationFactor: 0.92
      };
    case '30days':
      return {
        userFactor: 1.0,
        viewFactor: 1.0,
        bounceFactor: 1.0,
        conversionFactor: 1.0, // Baseline
        durationFactor: 1.0
      };
    case '90days':
      return {
        userFactor: 2.75,
        viewFactor: 2.85,
        bounceFactor: 0.92,
        conversionFactor: 0.75, // Lower conversion rates for longer time periods
        durationFactor: 1.08
      };
    case 'year':
      return {
        userFactor: 10.5,
        viewFactor: 11.2,
        bounceFactor: 0.85,
        conversionFactor: 0.55, // Significantly lower conversion rates for very long time periods
        durationFactor: 1.15
      };
    default:
      return {
        userFactor: 1.0,
        viewFactor: 1.0,
        bounceFactor: 1.0,
        conversionFactor: 1.0,
        durationFactor: 1.0
      };
  }
}

/**
 * Generate analytics data scaled for a specific time period and provider
 * @param provider The analytics provider (google, adobe, mixpanel)
 * @param timePeriod The time period to scale for (7days, 14days, 30days, 90days, year)
 * @param domain Optional domain to add website-specific variation
 */
export function generateTimeScaledAnalyticsData(
  provider: string,
  timePeriod: string,
  domain?: string
): BaseAnalyticsData {
  // Get the base values for the selected provider
  const seed = providerSeeds[provider] || providerSeeds.default;
  
  // Get the time period scaling factors
  const {
    userFactor,
    viewFactor,
    bounceFactor,
    conversionFactor,
    durationFactor
  } = getTimePeriodScalingFactors(timePeriod);
  
  // Apply domain-specific multiplier if available
  const domainMultiplier = domain ? 
    (domainMultipliers[domain] || domainMultipliers.default) : 
    domainMultipliers.default;
  
  // Add slight randomization (±5%) to make values dynamic but predictable
  const randomFactor = (base: number) => {
    // Use a predictable random factor based on the current hour to keep values somewhat stable
    const hourOfDay = new Date().getHours();
    const offsetPercent = ((hourOfDay % 10) - 5) / 100; // -5% to +5%
    return base * (1 + offsetPercent);
  };
  
  // Calculate the final values with all factors applied
  const activeUsers = Math.round(randomFactor(seed.users * userFactor * (domainMultiplier / 10)));
  const pageViews = Math.round(randomFactor(seed.views * viewFactor * (domainMultiplier / 10)));
  const bounceRate = Math.min(100, randomFactor(seed.bounce * bounceFactor));
  const conversionRate = Math.min(100, randomFactor(seed.conversion * conversionFactor));
  const averageSessionDuration = Math.round(randomFactor(seed.duration * durationFactor));
  
  return {
    activeUsers,
    pageViews,
    bounceRate,
    conversionRate,
    averageSessionDuration
  };
}

/**
 * Apply time period scaling to existing analytics data
 * @param data The base analytics data to scale
 * @param timePeriod The time period to scale for (7days, 14days, 30days, 90days, year)
 */
export function scaleAnalyticsDataForTimePeriod(
  data: BaseAnalyticsData,
  timePeriod: string
): BaseAnalyticsData {
  // Get the time period scaling factors
  const {
    userFactor,
    viewFactor,
    bounceFactor,
    conversionFactor,
    durationFactor
  } = getTimePeriodScalingFactors(timePeriod);
  
  // Apply explicit time multipliers to ensure consistent scaling across time periods
  let timeMultiplier = 1.0;
  switch(timePeriod) {
    case '7days':
      timeMultiplier = 1.0;
      break;
    case '14days':
      timeMultiplier = 1.6;
      break;
    case '30days':
      timeMultiplier = 4.0;
      break;
    case '90days':
      timeMultiplier = 12.0;
      break;
    case 'year':
      timeMultiplier = 52.0;
      break;
    default:
      timeMultiplier = 4.0; // Default to 30 days
  }
  
  // Ensure minimum meaningful values regardless of time period
  return {
    activeUsers: Math.max(20, Math.round(data.activeUsers * userFactor * timeMultiplier)),
    pageViews: Math.max(50, Math.round(data.pageViews * viewFactor * timeMultiplier)),
    bounceRate: Math.min(100, data.bounceRate * bounceFactor),
    conversionRate: Math.min(100, data.conversionRate * conversionFactor),
    averageSessionDuration: Math.round(data.averageSessionDuration * durationFactor)
  };
}