import axios from 'axios';

interface GrowthBookExperiment {
  id: string;
  name: string;
  description?: string;
  status: 'draft' | 'running' | 'stopped';
  phases: Array<{
    name: string;
    startDate: string;
    endDate?: string;
    traffic: number;
    variations: Array<{
      key: string;
      name: string;
      weight: number;
    }>;
  }>;
  results?: {
    [key: string]: {
      users: number;
      conversionRate: number;
      confidence: number;
    };
  };
}

interface GrowthBookMetric {
  id: string;
  name: string;
  type: 'conversion' | 'revenue' | 'retention';
  description?: string;
}

class GrowthBookService {
  private apiKey: string;
  private apiHost: string;
  private baseURL: string;

  constructor() {
    this.apiKey = process.env.GROWTHBOOK_API_KEY || '';
    this.apiHost = process.env.GROWTHBOOK_API_HOST || 'https://api.growthbook.io';
    this.baseURL = this.apiHost; // Use the host directly since it already includes the path
    
    console.log('GrowthBook service initialized with host:', this.apiHost);
    if (!this.apiKey) {
      console.warn('GrowthBook API key not found');
    }
  }

  private getHeaders() {
    return {
      'Authorization': `Bearer ${this.apiKey}`,
      'Content-Type': 'application/json',
    };
  }

  async getExperiments(): Promise<GrowthBookExperiment[]> {
    try {
      if (!this.apiKey) {
        throw new Error('GrowthBook API key not configured');
      }

      // Use the exact working API endpoint format
      const endpoint = `${this.apiHost}/api/v1/experiments`;
      
      console.log('Fetching GrowthBook experiments from:', endpoint);
      console.log('Using API key:', this.apiKey.substring(0, 20) + '...');
      
      const response = await axios.get(endpoint, {
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json',
        },
        timeout: 10000,
      });

      console.log('GrowthBook API response status:', response.status);
      
      if (response.data && response.data.experiments) {
        const experiments = response.data.experiments;
        console.log(`GrowthBook: Successfully found ${experiments.length} experiment(s)`);
        return experiments;
      }

      // Return empty array to maintain data integrity
      console.log('No experiments returned from GrowthBook API');
      return [];
    } catch (error: any) {
      console.error('Error fetching GrowthBook experiments:', error.message);
      // Return empty array to maintain data integrity
      return [];
    }
  }

  private generateSampleTests(): GrowthBookExperiment[] {
    return [
      {
        id: 'btn_color_test',
        name: 'Button Color Optimization',
        description: 'Testing different button colors for conversion rate',
        status: 'running',
        phases: [{
          name: 'Phase 1',
          startDate: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
          endDate: new Date(Date.now() + 23 * 24 * 60 * 60 * 1000).toISOString(),
          traffic: 0.5,
          variations: [
            { key: 'control', name: 'Blue Button', weight: 0.5 },
            { key: 'variant', name: 'Green Button', weight: 0.5 }
          ]
        }],
        results: {
          control: { users: 1247, conversionRate: 0.042, confidence: 0.78 },
          variant: { users: 1312, conversionRate: 0.051, confidence: 0.82 }
        }
      },
      {
        id: 'headline_test',
        name: 'Homepage Headline Test',
        description: 'Testing different headlines for user engagement',
        status: 'running',
        phases: [{
          name: 'Phase 1',
          startDate: new Date(Date.now() - 12 * 24 * 60 * 60 * 1000).toISOString(),
          endDate: new Date(Date.now() + 18 * 24 * 60 * 60 * 1000).toISOString(),
          traffic: 0.8,
          variations: [
            { key: 'control', name: 'Original Headline', weight: 0.5 },
            { key: 'variant', name: 'New Headline', weight: 0.5 }
          ]
        }],
        results: {
          control: { users: 2156, conversionRate: 0.034, confidence: 0.91 },
          variant: { users: 2203, conversionRate: 0.039, confidence: 0.89 }
        }
      },
      {
        id: 'pricing_test',
        name: 'Pricing Page Layout',
        description: 'Testing different pricing page layouts',
        status: 'running',
        phases: [{
          name: 'Phase 1',
          startDate: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
          endDate: new Date(Date.now() + 25 * 24 * 60 * 60 * 1000).toISOString(),
          traffic: 0.3,
          variations: [
            { key: 'control', name: 'Standard Layout', weight: 0.5 },
            { key: 'variant', name: 'Enhanced Layout', weight: 0.5 }
          ]
        }],
        results: {
          control: { users: 892, conversionRate: 0.067, confidence: 0.76 },
          variant: { users: 934, conversionRate: 0.074, confidence: 0.83 }
        }
      }
    ];
  }

  async getExperiment(experimentId: string): Promise<GrowthBookExperiment | null> {
    try {
      if (!this.apiKey) {
        throw new Error('GrowthBook API key not configured');
      }

      const response = await axios.get(`${this.baseURL}/experiments/${experimentId}`, {
        headers: this.getHeaders(),
        timeout: 10000,
      });

      return response.data.experiment || null;
    } catch (error: any) {
      console.error(`Error fetching GrowthBook experiment ${experimentId}:`, error.message);
      return null;
    }
  }

  async getMetrics(): Promise<GrowthBookMetric[]> {
    try {
      if (!this.apiKey) {
        throw new Error('GrowthBook API key not configured');
      }

      const response = await axios.get(`${this.baseURL}/metrics`, {
        headers: this.getHeaders(),
        timeout: 10000,
      });

      return response.data.metrics || [];
    } catch (error: any) {
      console.error('Error fetching GrowthBook metrics:', error.message);
      throw new Error(`Failed to fetch metrics: ${error.message}`);
    }
  }

  async getExperimentResults(experimentId: string, metricId?: string): Promise<any> {
    try {
      if (!this.apiKey) {
        throw new Error('GrowthBook API key not configured');
      }

      const url = metricId 
        ? `${this.baseURL}/experiments/${experimentId}/results?metric=${metricId}`
        : `${this.baseURL}/experiments/${experimentId}/results`;

      const response = await axios.get(url, {
        headers: this.getHeaders(),
        timeout: 10000,
      });

      return response.data.results || {};
    } catch (error: any) {
      console.error(`Error fetching experiment results for ${experimentId}:`, error.message);
      return {};
    }
  }

  // Convert GrowthBook experiment to our A/B test format
  transformToAbTest(experiment: GrowthBookExperiment): any {
    const currentPhase = experiment.phases[experiment.phases.length - 1];
    const variations = currentPhase?.variations || [];
    
    // Get results for each variation
    const results = experiment.results || {};
    const variationKeys = variations.map(v => v.key);
    
    const variantA = variations[0];
    const variantB = variations[1];
    
    const variantAResults = results[variantA?.key] || { conversionRate: 0, confidence: 0 };
    const variantBResults = results[variantB?.key] || { conversionRate: 0, confidence: 0 };

    return {
      id: experiment.id,
      name: experiment.name,
      description: experiment.description || '',
      status: experiment.status === 'running' ? 'active' : experiment.status,
      startDate: currentPhase?.startDate || new Date().toISOString(),
      endDate: currentPhase?.endDate || new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
      variantA: variantA?.name || 'Control',
      variantB: variantB?.name || 'Variation',
      variantAConversion: (variantAResults.conversionRate * 100).toFixed(1),
      variantBConversion: (variantBResults.conversionRate * 100).toFixed(1),
      confidence: Math.max(variantAResults.confidence || 0, variantBResults.confidence || 0).toFixed(0),
      domain: 'growthbook.io', // Mark as GrowthBook experiment
    };
  }

  async getConnectionStatus(): Promise<{ connected: boolean; message: string }> {
    try {
      if (!this.apiKey) {
        return { 
          connected: false, 
          message: 'GrowthBook API key not configured' 
        };
      }

      // Test connection by fetching experiments
      await this.getExperiments();
      
      return { 
        connected: true, 
        message: 'Successfully connected to GrowthBook' 
      };
    } catch (error: any) {
      return { 
        connected: false, 
        message: `Connection failed: ${error.message}` 
      };
    }
  }
}

export const growthBookService = new GrowthBookService();