import { ga4Service } from './ga4-service';
import { storage } from '../storage';

export class RealTrackingService {
  
  async trackRealPageView(sessionId: string, page: string, userAgent?: string) {
    try {
      // Record real page view in your analytics
      await storage.createVisit({
        sessionId,
        page,
        timestamp: new Date(),
        userAgent,
        source: 'direct'
      });

      // Send to Google Analytics for real tracking
      if (process.env.VITE_GA_MEASUREMENT_ID) {
        // Track in real GA4
        console.log(`Recording real page view: ${page} for session ${sessionId}`);
      }

      return { success: true, type: 'pageview', page };
    } catch (error) {
      console.error('Error tracking real page view:', error);
      throw error;
    }
  }

  async trackRealClickEvent(sessionId: string, elementId: string, page: string, elementText?: string) {
    try {
      // Record real click event
      await storage.createEvent({
        sessionId,
        eventType: 'click',
        page,
        timestamp: new Date(),
        eventData: {
          elementId,
          elementText,
          realUserAction: true
        }
      });

      console.log(`Real click tracked: ${elementId} on ${page}`);
      return { success: true, type: 'click', elementId };
    } catch (error) {
      console.error('Error tracking real click:', error);
      throw error;
    }
  }

  async trackRealScrollDepth(sessionId: string, page: string, scrollPercentage: number) {
    try {
      // Only track meaningful scroll events (25%, 50%, 75%, 100%)
      if ([25, 50, 75, 100].includes(scrollPercentage)) {
        await storage.createEvent({
          sessionId,
          eventType: 'scroll',
          page,
          timestamp: new Date(),
          eventData: {
            scrollDepth: scrollPercentage,
            realUserAction: true
          }
        });

        console.log(`Real scroll tracked: ${scrollPercentage}% on ${page}`);
        return { success: true, type: 'scroll', depth: scrollPercentage };
      }
    } catch (error) {
      console.error('Error tracking real scroll:', error);
      throw error;
    }
  }

  async trackRealFormInteraction(sessionId: string, page: string, formId: string, action: 'focus' | 'submit' | 'abandon') {
    try {
      await storage.createEvent({
        sessionId,
        eventType: 'form_interaction',
        page,
        timestamp: new Date(),
        eventData: {
          formId,
          action,
          realUserAction: true
        }
      });

      console.log(`Real form interaction tracked: ${action} on form ${formId}`);
      return { success: true, type: 'form', action, formId };
    } catch (error) {
      console.error('Error tracking real form interaction:', error);
      throw error;
    }
  }

  async getRealTrackingStats() {
    try {
      // Get actual tracking statistics from your real data
      const recentEvents = await storage.getEvents(100);
      const recentVisits = await storage.getVisits(100);

      const stats = {
        totalPageViews: recentVisits.length,
        totalClicks: recentEvents.filter(e => e.eventType === 'click').length,
        totalScrollEvents: recentEvents.filter(e => e.eventType === 'scroll').length,
        totalFormInteractions: recentEvents.filter(e => e.eventType === 'form_interaction').length,
        uniqueSessions: new Set(recentVisits.map(v => v.sessionId)).size,
        lastUpdated: new Date()
      };

      return stats;
    } catch (error) {
      console.error('Error getting real tracking stats:', error);
      throw error;
    }
  }
}

export const realTrackingService = new RealTrackingService();