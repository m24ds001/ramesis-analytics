import type { Express, Request, Response } from "express";
import { storage } from "./storage";
import { insertTransactionSchema, insertRevenueGoalSchema } from "@shared/schema";
import { authenticate } from "./middleware/auth";

/**
 * Register revenue tracking routes
 */
export const registerRevenueRoutes = (app: Express) => {
  /**
   * GET /api/revenue/transactions
   * Returns recent transactions with EUR currency formatting
   */
  app.get('/api/revenue/transactions', async (req: Request, res: Response) => {
    try {
      const limit = parseInt(req.query.limit as string) || 50;
      const transactions = await storage.getTransactions(limit);
      
      // Format transactions with EUR currency display
      const formattedTransactions = transactions.map(transaction => ({
        ...transaction,
        formattedAmount: `€${(transaction.amount / 100).toFixed(2)}`,
        currency: transaction.currency || 'EUR'
      }));

      res.json(formattedTransactions);
    } catch (error: any) {
      console.error('Error fetching transactions:', error);
      res.status(500).json({ message: 'Failed to fetch transactions' });
    }
  });

  /**
   * POST /api/revenue/transactions
   * Create a new transaction (for testing EUR display)
   */
  app.post('/api/revenue/transactions', async (req: Request, res: Response) => {
    try {
      const validatedData = insertTransactionSchema.parse(req.body);
      
      // Ensure currency defaults to EUR
      const transactionData = {
        ...validatedData,
        currency: validatedData.currency || 'EUR'
      };

      const transaction = await storage.createTransaction(transactionData);
      
      // Return formatted transaction with EUR display
      const formattedTransaction = {
        ...transaction,
        formattedAmount: `€${(transaction.amount / 100).toFixed(2)}`
      };

      res.status(201).json(formattedTransaction);
    } catch (error: any) {
      console.error('Error creating transaction:', error);
      res.status(400).json({ message: error.message || 'Failed to create transaction' });
    }
  });

  /**
   * GET /api/revenue/stats
   * Returns revenue statistics formatted in EUR
   */
  app.get('/api/revenue/stats', async (req: Request, res: Response) => {
    try {
      const period = req.query.period as string || 'monthly';
      const stats = await storage.getRevenueStats(period);
      
      // Format all monetary values in EUR
      const formattedStats = {
        totalRevenue: `€${(stats.totalRevenue / 100).toFixed(2)}`,
        averageOrderValue: `€${(stats.averageOrderValue / 100).toFixed(2)}`,
        revenuePerVisitor: `€${(stats.revenuePerVisitor / 100).toFixed(2)}`,
        totalTransactions: stats.totalTransactions,
        topProducts: stats.topProducts?.map(product => ({
          ...product,
          revenue: `€${(product.revenue / 100).toFixed(2)}`
        })),
        revenueByDay: stats.revenueByDay?.map(day => ({
          ...day,
          amount: `€${(day.amount / 100).toFixed(2)}`
        })),
        currency: 'EUR',
        period
      };

      res.json(formattedStats);
    } catch (error: any) {
      console.error('Error fetching revenue stats:', error);
      res.status(500).json({ message: 'Failed to fetch revenue statistics' });
    }
  });

  /**
   * GET /api/revenue/goals
   * Returns revenue goals formatted in EUR
   */
  app.get('/api/revenue/goals', async (req: Request, res: Response) => {
    try {
      const goals = await storage.getRevenueGoals();
      
      // Format goals with EUR currency display
      const formattedGoals = goals.map(goal => ({
        ...goal,
        formattedTarget: `€${(goal.targetAmount / 100).toFixed(2)}`,
        currency: goal.currency || 'EUR'
      }));

      res.json(formattedGoals);
    } catch (error: any) {
      console.error('Error fetching revenue goals:', error);
      res.status(500).json({ message: 'Failed to fetch revenue goals' });
    }
  });

  /**
   * POST /api/revenue/goals
   * Create a new revenue goal in EUR
   */
  app.post('/api/revenue/goals', authenticate, async (req: Request, res: Response) => {
    try {
      const validatedData = insertRevenueGoalSchema.parse(req.body);
      
      // Ensure currency defaults to EUR
      const goalData = {
        ...validatedData,
        currency: validatedData.currency || 'EUR'
      };

      const goal = await storage.createRevenueGoal(goalData);
      
      // Return formatted goal with EUR display
      const formattedGoal = {
        ...goal,
        formattedTarget: `€${(goal.targetAmount / 100).toFixed(2)}`
      };

      res.status(201).json(formattedGoal);
    } catch (error: any) {
      console.error('Error creating revenue goal:', error);
      res.status(400).json({ message: error.message || 'Failed to create revenue goal' });
    }
  });

  /**
   * POST /api/revenue/simulate
   * Create sample transactions to demonstrate EUR currency display
   */
  app.post('/api/revenue/simulate', async (req: Request, res: Response) => {
    try {
      const sampleTransactions = [
        {
          websiteId: 1,
          sessionId: 'demo_session_1',
          amount: 2550, // €25.50
          currency: 'EUR',
          description: 'Premium Analytics Package',
          productName: 'Ramesis Pro',
          productCategory: 'Analytics Software',
          transactionType: 'purchase' as const,
          paymentMethod: 'card'
        },
        {
          websiteId: 1,
          sessionId: 'demo_session_2',
          amount: 9900, // €99.00
          currency: 'EUR',
          description: 'Annual Subscription',
          productName: 'Ramesis Enterprise',
          productCategory: 'Analytics Software',
          transactionType: 'subscription' as const,
          paymentMethod: 'bank_transfer'
        },
        {
          websiteId: 1,
          sessionId: 'demo_session_3',
          amount: 4900, // €49.00
          currency: 'EUR',
          description: 'Monthly Subscription',
          productName: 'Ramesis Standard',
          productCategory: 'Analytics Software',
          transactionType: 'subscription' as const,
          paymentMethod: 'paypal'
        }
      ];

      const createdTransactions = [];
      for (const transactionData of sampleTransactions) {
        const transaction = await storage.createTransaction(transactionData);
        createdTransactions.push({
          ...transaction,
          formattedAmount: `€${(transaction.amount / 100).toFixed(2)}`
        });
      }

      res.status(201).json({
        message: 'Sample EUR transactions created successfully',
        transactions: createdTransactions,
        totalValue: `€${(sampleTransactions.reduce((sum, t) => sum + t.amount, 0) / 100).toFixed(2)}`
      });
    } catch (error: any) {
      console.error('Error creating sample transactions:', error);
      res.status(500).json({ message: 'Failed to create sample transactions' });
    }
  });
};