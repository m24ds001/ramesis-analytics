import { Request, Response, NextFunction } from 'express';
import { NodeTracerProvider } from '@opentelemetry/sdk-trace-node';
import { trace, context, SpanStatusCode, SpanKind } from '@opentelemetry/api';

// Initialize tracer provider
const provider = new NodeTracerProvider();
provider.register();

// Create a tracer
const tracer = trace.getTracer('analytics-platform-tracer');

/**
 * Middleware to add distributed tracing to Express requests.
 * Each HTTP request gets a span that tracks its execution.
 */
export const tracingMiddleware = (req: Request, res: Response, next: NextFunction) => {
  // Extract the path and normalize it to avoid high cardinality
  const normalizedPath = req.path.replace(/\/[0-9]+/g, '/:id');
  
  // Create a new span for this request
  const span = tracer.startSpan(`${req.method} ${normalizedPath}`, {
    kind: SpanKind.SERVER,
    attributes: {
      'http.method': req.method,
      'http.url': req.url,
      'http.host': req.headers.host,
      'http.user_agent': req.headers['user-agent'],
      'http.path': normalizedPath,
    },
  });
  
  // Store this request ID in the span for correlation
  const requestId = req.headers['x-request-id'] || Math.random().toString(36).substring(2, 15);
  span.setAttribute('request.id', requestId);
  
  // Create a context with the current span
  const spanContext = trace.setSpan(context.active(), span);
  
  // Execute the rest of the request in this context
  context.with(spanContext, () => {
    // Add response handlers to record the result
    res.on('finish', () => {
      const { statusCode } = res;
      
      // Add response attributes
      span.setAttribute('http.status_code', statusCode);
      
      // Set span status based on HTTP status code
      if (statusCode >= 400) {
        span.setStatus({
          code: SpanStatusCode.ERROR,
          message: `HTTP Error ${statusCode}`,
        });
      } else {
        span.setStatus({ code: SpanStatusCode.OK });
      }
      
      // End the span
      span.end();
    });
    
    // Add error handler
    res.on('error', (error) => {
      span.recordException(error);
      span.setStatus({
        code: SpanStatusCode.ERROR,
        message: error.message,
      });
      span.end();
    });
    
    // Continue with the request
    next();
  });
};

/**
 * Creates a child span for a database query or other operation.
 * @param name The name of the operation
 * @param fn The function to execute within the span
 * @returns The result of the function
 */
export const createChildSpan = async <T>(name: string, fn: () => Promise<T>): Promise<T> => {
  const span = tracer.startSpan(name);
  
  try {
    const result = await fn();
    span.setStatus({ code: SpanStatusCode.OK });
    return result;
  } catch (error) {
    span.recordException(error);
    span.setStatus({
      code: SpanStatusCode.ERROR,
      message: error.message,
    });
    throw error;
  } finally {
    span.end();
  }
};