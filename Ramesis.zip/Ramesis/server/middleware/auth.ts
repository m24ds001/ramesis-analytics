import { Request, Response, NextFunction } from 'express';

// Custom error type for authentication errors
export class AuthenticationError extends Error {
  statusCode: number;
  
  constructor(message: string, statusCode = 401) {
    super(message);
    this.name = 'AuthenticationError';
    this.statusCode = statusCode;
  }
}

/**
 * Authentication middleware to ensure user is logged in
 * @throws AuthenticationError if user is not authenticated
 */
export const authenticate = (req: Request, res: Response, next: NextFunction) => {
  if (!req.session || !req.session.user) {
    throw new AuthenticationError('Unauthorized');
  }
  next();
};

/**
 * Express error handler for authentication errors
 */
export const authErrorHandler = (err: any, req: Request, res: Response, next: NextFunction) => {
  if (err instanceof AuthenticationError) {
    return res.status(err.statusCode).json({ error: err.message });
  }
  next(err);
};