import { Request, Response } from 'express';
import { pool } from '../db';
import { createChildSpan } from './tracing';

type HealthStatus = {
  status: 'healthy' | 'degraded' | 'unhealthy';
  database: {
    connected: boolean;
    latency?: number;
  };
  api: {
    healthy: boolean;
  };
  openai: {
    configured: boolean;
  };
  details?: Record<string, any>;
  timestamp: string;
};

/**
 * Health check handler function for the /health endpoint
 */
export const healthCheckHandler = async (req: Request, res: Response) => {
  // Use tracing on health check function
  return createChildSpan('health-check', async () => {
    const health: HealthStatus = {
      status: 'healthy',
      database: {
        connected: false,
      },
      api: {
        healthy: true,
      },
      openai: {
        configured: !!process.env.OPENAI_API_KEY,
      },
      timestamp: new Date().toISOString(),
    };
    
    // Check database connection
    let dbHealthy = false;
    try {
      const start = Date.now();
      await pool.query('SELECT 1');
      const latency = Date.now() - start;
      
      health.database.connected = true;
      health.database.latency = latency;
      dbHealthy = true;
    } catch (error) {
      health.database.connected = false;
      health.details = {
        ...health.details,
        database_error: error.message,
      };
    }
    
    // Set overall status based on component health
    if (!dbHealthy) {
      health.status = 'unhealthy';
    } else if (!health.openai.configured) {
      health.status = 'degraded';
    }
    
    // Set appropriate HTTP status code
    const statusCode = health.status === 'healthy' ? 200 :
                       health.status === 'degraded' ? 200 : 503;
    
    // Return health status
    return res.status(statusCode).json(health);
  });
};

/**
 * Liveness probe handler function for the /health/liveness endpoint
 * This is a simplified health check for Kubernetes/container liveness probes.
 */
export const livenessProbeHandler = async (_req: Request, res: Response) => {
  return res.status(200).json({ status: 'alive' });
};

/**
 * Readiness probe handler function for the /health/readiness endpoint
 * This checks if the application is ready to handle requests.
 */
export const readinessProbeHandler = async (_req: Request, res: Response) => {
  // Check database connectivity
  try {
    await pool.query('SELECT 1');
    return res.status(200).json({ status: 'ready' });
  } catch (error) {
    return res.status(503).json({ 
      status: 'not ready',
      reason: 'database connection failed'
    });
  }
};