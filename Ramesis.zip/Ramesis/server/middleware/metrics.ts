import { Request, Response, NextFunction } from 'express';
import client from 'prom-client';
import { pool } from '../db';

// Initialize metrics registry
const register = new client.Registry();

// Add default metrics (Memory, CPU, etc.)
client.collectDefaultMetrics({ register });

// Create HTTP request duration histogram
const httpRequestDuration = new client.Histogram({
  name: 'http_request_duration_seconds',
  help: 'Duration of HTTP requests in seconds',
  labelNames: ['method', 'path', 'status'],
  buckets: [0.05, 0.1, 0.5, 1, 2, 5, 10],
  registers: [register]
});

// Create active websocket connections gauge
const activeWebSockets = new client.Gauge({
  name: 'websocket_connections_active',
  help: 'Number of active WebSocket connections',
  registers: [register]
});

// Create database connection pool metrics
const dbConnectionsTotal = new client.Gauge({
  name: 'db_connections_total',
  help: 'Total number of database connections',
  registers: [register]
});

const dbConnectionsIdle = new client.Gauge({
  name: 'db_connections_idle',
  help: 'Number of idle database connections',
  registers: [register]
});

// Update database metrics periodically
setInterval(async () => {
  try {
    // Get pool statistics
    const poolStats = await pool.query('SELECT count(*) as total, count(*) FILTER (WHERE state = \'idle\') as idle FROM pg_stat_activity WHERE application_name LIKE \'%pooler%\'');
    
    if (poolStats.rows?.[0]) {
      dbConnectionsTotal.set(parseInt(poolStats.rows[0].total) || 0);
      dbConnectionsIdle.set(parseInt(poolStats.rows[0].idle) || 0);
    }
  } catch (error) {
    console.error('Error updating DB metrics:', error);
  }
}, 30000);

// Middleware function to measure HTTP request duration
export const metricsMiddleware = (req: Request, res: Response, next: NextFunction) => {
  // Skip metrics endpoints to avoid circular measurements
  if (req.path === '/metrics') {
    return next();
  }
  
  // Start timer
  const end = httpRequestDuration.startTimer();
  
  // Track response
  res.on('finish', () => {
    // Record metric with labels
    end({
      method: req.method,
      path: req.path.replace(/\/[0-9]+/g, '/:id'), // Normalize paths with IDs
      status: res.statusCode
    });
  });
  
  next();
};

// Export functions to manage websocket metrics
export const incrementWebSocketConnections = () => activeWebSockets.inc();
export const decrementWebSocketConnections = () => activeWebSockets.dec();

// Metrics endpoint handler
export const metricsHandler = async (_req: Request, res: Response) => {
  try {
    res.set('Content-Type', register.contentType);
    res.end(await register.metrics());
  } catch (error) {
    res.status(500).send('Error generating metrics');
  }
};