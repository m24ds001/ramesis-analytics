import { Request, Response, Express } from 'express';
import { trafficEstimateService } from './services/traffic-estimate-service';

/**
 * Register routes for traffic estimation
 */
export const registerTrafficEstimationRoutes = (app: Express) => {
  /**
   * GET /api/traffic-estimate/:domain
   * Returns traffic estimate data for a specific domain
   */
  app.get('/api/traffic-estimate/:domain', async (req: Request, res: Response) => {
    try {
      const domain = req.params.domain;
      
      if (!domain) {
        return res.status(400).json({ error: 'Domain is required' });
      }
      
      const trafficData = await trafficEstimateService.getTrafficData(domain);
      res.json(trafficData);
    } catch (error) {
      console.error('Error getting traffic estimate:', error);
      res.status(500).json({ error: 'Failed to get traffic estimate' });
    }
  });
  
  /**
   * GET /api/traffic-estimate/multi
   * Returns traffic estimates for multiple domains
   * Query params: domains=domain1.com,domain2.com,domain3.com
   */
  app.get('/api/traffic-estimate/multi', async (req: Request, res: Response) => {
    try {
      const domainsParam = req.query.domains as string;
      
      if (!domainsParam) {
        return res.status(400).json({ error: 'Domains parameter is required' });
      }
      
      const domains = domainsParam.split(',');
      
      if (!domains.length) {
        return res.status(400).json({ error: 'At least one domain is required' });
      }
      
      const results = await Promise.all(
        domains.map(async (domain) => {
          try {
            const data = await trafficEstimateService.getTrafficData(domain);
            return { domain, data, success: true };
          } catch (error) {
            return { domain, error: 'Failed to get traffic data', success: false };
          }
        })
      );
      
      res.json(results);
    } catch (error) {
      console.error('Error getting multi-domain traffic estimates:', error);
      res.status(500).json({ error: 'Failed to get traffic estimates' });
    }
  });
  
  /**
   * GET /api/traffic-estimate/realtime/:domain
   * Returns real-time traffic estimate for a specific domain
   */
  app.get('/api/traffic-estimate/realtime/:domain', async (req: Request, res: Response) => {
    try {
      const domain = req.params.domain;
      
      if (!domain) {
        return res.status(400).json({ error: 'Domain is required' });
      }
      
      const trafficData = await trafficEstimateService.getTrafficData(domain);
      
      // Only return real-time relevant data
      res.json({
        domain: trafficData.domain,
        currentVisitors: trafficData.currentVisitors,
        dailyVisitors: trafficData.dailyVisitors
      });
    } catch (error) {
      console.error('Error getting real-time traffic estimate:', error);
      res.status(500).json({ error: 'Failed to get real-time traffic estimate' });
    }
  });
};