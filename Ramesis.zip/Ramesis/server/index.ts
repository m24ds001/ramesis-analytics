import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";
import { storage } from "./storage";
import { ga4Service } from './services/ga4-service';

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Add security headers to prevent content from being blocked
app.use((req, res, next) => {
  // Security headers
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval'; style-src 'self' 'unsafe-inline'; img-src 'self' https: data:; font-src 'self' data:; connect-src 'self' wss: ws:");
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  next();
});

// Add multiple simplified endpoints to test which one works with your security settings
app.get('/simplified', (req, res) => {
  res.set({
    'Content-Type': 'text/html',
    'Content-Security-Policy': "default-src 'self'; script-src 'none'; object-src 'none'",
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'X-XSS-Protection': '1; mode=block',
    'Referrer-Policy': 'no-referrer',
    'Strict-Transport-Security': 'max-age=31536000; includeSubDomains'
  });
  res.send(`
  <!DOCTYPE html>
  <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>AilyticsPro API Test</title>
      <style>
        body { font-family: Arial; margin: 20px; }
        h1 { color: navy; }
      </style>
    </head>
    <body>
      <h1>AilyticsPro API Test</h1>
      <p>Server is running correctly. The backend functionality is working as expected.</p>
      <p>API Status: Online</p>
    </body>
  </html>
  `);
});

// Ultra minimal version with no CSS/styling at all
app.get('/minimal', (req, res) => {
  res.set({
    'Content-Type': 'text/html',
    'Content-Security-Policy': "default-src 'none'",
    'X-Content-Type-Options': 'nosniff'
  });
  res.send(`
  <!DOCTYPE html>
  <html>
    <head>
      <title>API Status</title>
    </head>
    <body>
      <h1>API Status: Working</h1>
      <p>The server is running correctly. All server-side functionality is operational.</p>
      <ul>
        <li><a href="/api/external-websites">Test External Websites API</a></li>
        <li><a href="/api/insights">Test Insights API</a></li>
      </ul>
    </body>
  </html>
  `);
});

// Plain text version - absolutely minimal
app.get('/status', (req, res) => {
  res.set('Content-Type', 'text/plain');
  res.send(`
AilyticsPro API Status: ONLINE

Server is running
Database is connected
Sample data is initialized
API endpoints are operational

Test an endpoint: 
${req.protocol}://${req.get('host')}/api/external-websites
  `);
});

// Pure JSON response
app.get('/api/status', (req, res) => {
  res.set({
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*'
  });
  res.json({
    status: 'online',
    server: 'running',
    database: 'connected',
    api_endpoints: {
      external_websites: '/api/external-websites',
      insights: '/api/insights',
      recommendations: '/api/recommendations',
      ab_tests: '/api/abtests'
    },
    sample_data: 'initialized',
    timestamp: new Date().toISOString()
  });
});

// Serve static files from the public directory
app.use('/static', express.static('public'));

// Serve the trusted HTML files as entry points
app.get('/trusted', (req, res) => {
  res.sendFile('trusted.html', { root: 'public' });
});

// Serve the completely self-contained trusted application
app.get('/app', (req, res) => {
  res.sendFile('trusted-app.html', { root: 'public' });
});

// Serve static content pages
app.get('/privacy', (req, res) => {
  res.sendFile('privacy.html', { root: 'public' });
});

app.get('/terms', (req, res) => {
  res.sendFile('terms.html', { root: 'public' });
});

app.get('/security', (req, res) => {
  res.sendFile('security.html', { root: 'public' });
});

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

(async () => {
  try {
    // Initialize GA4 service for direct API access
    console.log("Initializing GA4 service for direct API access");
    await ga4Service.initialize();
    
    // Initialize sample data with error handling
    try {
      if (storage.initializeSampleData) {
        log("Initializing sample data...");
        await storage.initializeSampleData();
        log("Sample data initialized successfully");
      }
    } catch (dbError) {
      // This error is already handled by our storage proxy
      // that will automatically switch to memory storage
      log(`Database error handled, using memory storage`);
    }
  } catch (error) {
    log(`Error initializing: ${error instanceof Error ? error.message : String(error)}`);
  }
  
  const server = await registerRoutes(app);

  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    res.status(status).json({ message });
    throw err;
  });

  // importantly only setup vite in development and after
  // setting up all the other routes so the catch-all route
  // doesn't interfere with the other routes
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  // ALWAYS serve the app on port 5000
  // this serves both the API and the client.
  // It is the only port that is not firewalled.
  const port = 5000;
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true,
  }, () => {
    log(`serving on port ${port}`);
  });
})();
