import { Express, Request, Response } from 'express';
import { getRealTimeUserBehavior } from './services/user-behavior-service';

/**
 * Register routes for real-time user behavior data
 */
export const registerUserBehaviorRoutes = (app: Express) => {
  /**
   * GET /api/user-behavior/:domain
   * Returns real-time user behavior data for a specific domain
   */
  app.get('/api/user-behavior/:domain', async (req: Request, res: Response) => {
    try {
      const { domain } = req.params;
      
      // Get date range from query params (optional)
      const dateRange = req.query.dateRange as string || 'last7days';
      
      console.log(`Getting real-time user behavior for domain: ${domain}, date range: ${dateRange}`);
      
      // Get real-time user behavior data
      const data = await getRealTimeUserBehavior(domain);
      
      if (!data) {
        return res.status(404).json({ 
          error: 'No behavior data available for this domain',
          domain,
          dateRange
        });
      }
      
      res.json(data);
    } catch (error) {
      console.error('Error fetching user behavior data:', error);
      res.status(500).json({ 
        error: 'Failed to retrieve user behavior data',
        message: error.message 
      });
    }
  });
};