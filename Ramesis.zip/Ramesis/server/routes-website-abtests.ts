import { Express, Request, Response } from 'express';
import { storage } from './storage';

/**
 * Website-specific A/B testing configurations
 */
const websiteAbTests = {
  'google.com': [
    {
      id: 1,
      name: 'Search Results Page Layout',
      description: 'Testing different search results page layouts to optimize click-through rates',
      status: 'active',
      daysLeft: 8,
      variants: [
        { 
          id: 'A', 
          name: 'Standard layout with enhanced snippets', 
          conversionRate: 4.8, 
          description: 'Current layout with expanded rich snippets' 
        },
        { 
          id: 'B', 
          name: 'Intent-focused layout with visual elements', 
          conversionRate: 5.7, 
          description: 'New layout with more visual elements based on search intent' 
        }
      ],
      confidence: 92,
      startDate: '2025-05-15',
      endDate: '2025-06-01',
      metrics: {
        impressions: 2850000,
        clicks: 142500,
        avgTimeOnPage: '3.2m'
      }
    },
    {
      id: 2,
      name: 'Mobile Search Interface',
      description: 'Testing different mobile search interface designs to improve mobile engagement',
      status: 'active',
      daysLeft: 12,
      variants: [
        { 
          id: 'A', 
          name: 'Current swipe-based interface', 
          conversionRate: 3.2, 
          description: 'Standard swipe navigation between results' 
        },
        { 
          id: 'B', 
          name: 'Voice-prioritized interface', 
          conversionRate: 3.9, 
          description: 'Enhanced voice search with contextual suggestions' 
        }
      ],
      confidence: 81,
      startDate: '2025-05-18',
      endDate: '2025-06-05',
      metrics: {
        impressions: 1950000,
        clicks: 66300,
        avgTimeOnPage: '2.7m'
      }
    }
  ],
  'amazon.com': [
    {
      id: 3,
      name: 'Product Page Layout',
      description: 'Testing different product page layouts to increase add-to-cart conversions',
      status: 'active',
      daysLeft: 6,
      variants: [
        { 
          id: 'A', 
          name: 'Standard layout with reviews below', 
          conversionRate: 12.4, 
          description: 'Current layout with reviews below product details' 
        },
        { 
          id: 'B', 
          name: 'Social proof enhanced layout', 
          conversionRate: 14.2, 
          description: 'Layout with reviews and social proof more prominently displayed' 
        }
      ],
      confidence: 94,
      startDate: '2025-05-17',
      endDate: '2025-05-29',
      metrics: {
        impressions: 825000,
        clicks: 123750,
        avgTimeOnPage: '4.1m'
      }
    },
    {
      id: 4,
      name: 'Checkout Process Optimization',
      description: 'Testing streamlined checkout process vs. current multi-step checkout',
      status: 'active',
      daysLeft: 15,
      variants: [
        { 
          id: 'A', 
          name: 'Standard multi-step checkout', 
          conversionRate: 67.8, 
          description: 'Current checkout flow with separate pages' 
        },
        { 
          id: 'B', 
          name: 'Single-page checkout', 
          conversionRate: 72.1, 
          description: 'Streamlined checkout with all steps on one page' 
        }
      ],
      confidence: 88,
      startDate: '2025-05-20',
      endDate: '2025-06-10',
      metrics: {
        impressions: 340000,
        clicks: 231200,
        avgTimeOnPage: '2.9m'
      }
    }
  ],
  'facebook.com': [
    {
      id: 5,
      name: 'News Feed Algorithm',
      description: 'Testing different content prioritization algorithms in news feed',
      status: 'active',
      daysLeft: 9,
      variants: [
        { 
          id: 'A', 
          name: 'Current engagement-based algorithm', 
          conversionRate: 6.7, 
          description: 'Algorithm prioritizing content with high engagement' 
        },
        { 
          id: 'B', 
          name: 'Time-spent weighted algorithm', 
          conversionRate: 7.8, 
          description: 'Algorithm prioritizing content with longer viewing times' 
        }
      ],
      confidence: 85,
      startDate: '2025-05-14',
      endDate: '2025-06-02',
      metrics: {
        impressions: 1280000,
        clicks: 87040,
        avgTimeOnPage: '5.4m'
      }
    },
    {
      id: 6,
      name: 'Story Format Display',
      description: 'Testing different story format presentations for increased engagement',
      status: 'active',
      daysLeft: 11,
      variants: [
        { 
          id: 'A', 
          name: 'Standard circular previews', 
          conversionRate: 22.5, 
          description: 'Current circular preview icons at the top of feed' 
        },
        { 
          id: 'B', 
          name: 'Full-width story previews', 
          conversionRate: 26.8, 
          description: 'Expanded full-width story previews with peek content' 
        }
      ],
      confidence: 91,
      startDate: '2025-05-12',
      endDate: '2025-06-03',
      metrics: {
        impressions: 960000,
        clicks: 237600,
        avgTimeOnPage: '2.1m'
      }
    }
  ],
  'youtube.com': [
    {
      id: 7,
      name: 'Video Recommendation Algorithm',
      description: 'Testing different video recommendation systems for increased watch time',
      status: 'active',
      daysLeft: 7,
      variants: [
        { 
          id: 'A', 
          name: 'Current topic-based recommendations', 
          conversionRate: 14.3, 
          description: 'Recommendations based primarily on video topic and user history' 
        },
        { 
          id: 'B', 
          name: 'Viewer behavior clustering', 
          conversionRate: 16.7, 
          description: 'Recommendations based on viewer behavior clustering' 
        }
      ],
      confidence: 89,
      startDate: '2025-05-16',
      endDate: '2025-05-30',
      metrics: {
        impressions: 1750000,
        clicks: 262500,
        avgTimeOnPage: '15.7m'
      }
    },
    {
      id: 8,
      name: 'Autoplay Feature',
      description: 'Testing different autoplay behaviors for session length improvement',
      status: 'active',
      daysLeft: 14,
      variants: [
        { 
          id: 'A', 
          name: 'Standard 5-second autoplay countdown', 
          conversionRate: 83.5, 
          description: 'Current 5-second countdown before autoplay' 
        },
        { 
          id: 'B', 
          name: 'Interactive preview autoplay', 
          conversionRate: 87.2, 
          description: 'Interactive preview with content highlights during countdown' 
        }
      ],
      confidence: 77,
      startDate: '2025-05-19',
      endDate: '2025-06-09',
      metrics: {
        impressions: 890000,
        clicks: 757150,
        avgTimeOnPage: '12.3m'
      }
    }
  ],
  'twitter.com': [
    {
      id: 9,
      name: 'Timeline Algorithm',
      description: 'Testing chronological vs. algorithmic timelines for engagement',
      status: 'active',
      daysLeft: 10,
      variants: [
        { 
          id: 'A', 
          name: 'Current algorithmic timeline', 
          conversionRate: 5.2, 
          description: 'Algorithmically sorted tweets based on engagement' 
        },
        { 
          id: 'B', 
          name: 'Chronological timeline with highlights', 
          conversionRate: 4.9, 
          description: 'Chronologically sorted tweets with highlighted posts' 
        }
      ],
      confidence: 64,
      startDate: '2025-05-13',
      endDate: '2025-06-03',
      metrics: {
        impressions: 620000,
        clicks: 30380,
        avgTimeOnPage: '4.8m'
      }
    }
  ],
  'instagram.com': [
    {
      id: 10,
      name: 'Feed Layout Design',
      description: 'Testing different feed layouts for improved engagement metrics',
      status: 'active',
      daysLeft: 8,
      variants: [
        { 
          id: 'A', 
          name: 'Standard grid layout', 
          conversionRate: 9.3, 
          description: 'Current grid-based feed layout' 
        },
        { 
          id: 'B', 
          name: 'Content-adaptive layout', 
          conversionRate: 10.7, 
          description: 'Layout that adapts based on content type and engagement potential' 
        }
      ],
      confidence: 82,
      startDate: '2025-05-15',
      endDate: '2025-06-01',
      metrics: {
        impressions: 875000,
        clicks: 85750,
        avgTimeOnPage: '3.9m'
      }
    }
  ],
  'linkedin.com': [
    {
      id: 11,
      name: 'Professional Feed Algorithm',
      description: 'Testing different algorithms for professional content relevance',
      status: 'active',
      daysLeft: 12,
      variants: [
        { 
          id: 'A', 
          name: 'Network-based content prioritization', 
          conversionRate: 3.8, 
          description: 'Content prioritized from direct network connections' 
        },
        { 
          id: 'B', 
          name: 'Industry-focused content prioritization', 
          conversionRate: 4.5, 
          description: 'Content prioritized based on industry relevance' 
        }
      ],
      confidence: 79,
      startDate: '2025-05-11',
      endDate: '2025-06-04',
      metrics: {
        impressions: 420000,
        clicks: 17640,
        avgTimeOnPage: '2.7m'
      }
    }
  ],
  'netflix.com': [
    {
      id: 12,
      name: 'Content Discovery Interface',
      description: 'Testing different content discovery layouts for increased viewing time',
      status: 'active',
      daysLeft: 9,
      variants: [
        { 
          id: 'A', 
          name: 'Category-based recommendations', 
          conversionRate: 34.6, 
          description: 'Current category-based content discovery rows' 
        },
        { 
          id: 'B', 
          name: 'Mood-based recommendations', 
          conversionRate: 38.2, 
          description: 'Content discovery organized by viewer mood and time of day' 
        }
      ],
      confidence: 87,
      startDate: '2025-05-14',
      endDate: '2025-06-02',
      metrics: {
        impressions: 390000,
        clicks: 142740,
        avgTimeOnPage: '27.5m'
      }
    }
  ]
};

/**
 * Register routes for website-specific A/B tests
 */
export const registerWebsiteABTestRoutes = (app: Express) => {
  /**
   * GET /api/website-abtests
   * Returns all A/B tests across all websites
   */
  app.get('/api/website-abtests', async (_req: Request, res: Response) => {
    try {
      // Flatten all website A/B tests into a single array
      const allTests = Object.entries(websiteAbTests).reduce((acc, [domain, tests]) => {
        const testsWithDomain = tests.map(test => ({
          ...test,
          domain
        }));
        return [...acc, ...testsWithDomain];
      }, []);
      
      res.json(allTests);
    } catch (error) {
      console.error('Error fetching website A/B tests:', error);
      res.status(500).json({ error: 'Failed to fetch website A/B tests' });
    }
  });

  /**
   * GET /api/website-abtests/:domain
   * Returns all A/B tests for a specific website domain
   */
  app.get('/api/website-abtests/:domain', async (req: Request, res: Response) => {
    try {
      const { domain } = req.params;
      
      // Get the A/B tests for the specified domain
      const tests = websiteAbTests[domain] || [];
      
      if (tests.length === 0) {
        return res.status(404).json({ 
          error: 'No A/B tests found for this domain',
          domain 
        });
      }
      
      // Add domain to each test object
      const testsWithDomain = tests.map(test => ({
        ...test,
        domain
      }));
      
      res.json(testsWithDomain);
    } catch (error) {
      console.error('Error fetching website A/B tests:', error);
      res.status(500).json({ error: 'Failed to fetch website A/B tests' });
    }
  });

  /**
   * GET /api/website-abtests/:domain/:id
   * Returns a specific A/B test for a website domain
   */
  app.get('/api/website-abtests/:domain/:id', async (req: Request, res: Response) => {
    try {
      const { domain, id } = req.params;
      const testId = parseInt(id);
      
      if (isNaN(testId)) {
        return res.status(400).json({ error: 'Invalid test ID' });
      }
      
      const tests = websiteAbTests[domain] || [];
      const test = tests.find(t => t.id === testId);
      
      if (!test) {
        return res.status(404).json({ 
          error: 'A/B test not found',
          domain,
          id: testId
        });
      }
      
      res.json({
        ...test,
        domain
      });
    } catch (error) {
      console.error('Error fetching website A/B test:', error);
      res.status(500).json({ error: 'Failed to fetch website A/B test' });
    }
  });

  /**
   * GET /api/website-abtests-summary
   * Returns a summary count of A/B tests by website
   */
  app.get('/api/website-abtests-summary', async (_req: Request, res: Response) => {
    try {
      // Generate summary data from the A/B tests
      const summary = Object.entries(websiteAbTests).map(([domain, tests]) => ({
        domain,
        testCount: tests.length,
        activeTestCount: tests.filter(test => test.status === 'active').length,
        averageConfidence: Math.round(tests.reduce((sum, test) => sum + test.confidence, 0) / tests.length)
      }));
      
      // Always return a successful response with the array, even if it's empty
      res.json(summary);
    } catch (error) {
      console.error('Error fetching website A/B tests summary:', error);
      res.status(500).json({ error: 'Failed to fetch website A/B tests summary' });
    }
  });
};