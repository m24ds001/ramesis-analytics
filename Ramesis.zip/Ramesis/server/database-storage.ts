import {
  users, type User, type InsertUser,
  websites, type Website, type InsertWebsite,
  websiteCredentials, type WebsiteCredentials, type InsertWebsiteCredentials,
  externalWebsiteCatalog, type ExternalWebsiteCatalog, type InsertExternalWebsiteCatalog,
  externalWebsiteAnalytics, type ExternalWebsiteAnalytics, type InsertExternalWebsiteAnalytics,
  websiteVisits, type WebsiteVisit, type InsertWebsiteVisit,
  userEvents, type UserEvent, type InsertUserEvent,
  aiInsights, type AiInsight, type InsertAiInsight,
  recommendations, type Recommendation, type InsertRecommendation,
  abTests, type AbTest, type InsertAbTest,
  achievements, type Achievement, type InsertAchievement,
  userAchievements, type UserAchievement, type InsertUserAchievement
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, between, isNull, ilike, or } from "drizzle-orm";
import { IStorage } from "./storage";

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }
  
  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }
  
  // Website operations
  async getWebsites(userId?: number, limit = 100): Promise<Website[]> {
    if (userId) {
      return await db.select()
        .from(websites)
        .where(eq(websites.userId, userId))
        .orderBy(desc(websites.updatedAt))
        .limit(limit);
    } else {
      return await db.select()
        .from(websites)
        .orderBy(desc(websites.updatedAt))
        .limit(limit);
    }
  }
  
  async getWebsiteById(id: number): Promise<Website | undefined> {
    const [website] = await db.select().from(websites).where(eq(websites.id, id));
    return website;
  }
  
  async createWebsite(insertWebsite: InsertWebsite): Promise<Website> {
    const [website] = await db.insert(websites).values({
      ...insertWebsite,
      createdAt: new Date(),
      updatedAt: new Date()
    }).returning();
    return website;
  }
  
  async updateWebsite(id: number, updates: Partial<InsertWebsite>): Promise<Website | undefined> {
    const [website] = await db
      .update(websites)
      .set({
        ...updates,
        updatedAt: new Date()
      })
      .where(eq(websites.id, id))
      .returning();
    return website;
  }
  
  async deleteWebsite(id: number): Promise<void> {
    await db.delete(websites).where(eq(websites.id, id));
  }
  
  // Website credentials operations
  async getWebsiteCredentials(websiteId: number, provider?: string): Promise<WebsiteCredentials[]> {
    if (provider) {
      return await db.select()
        .from(websiteCredentials)
        .where(and(
          eq(websiteCredentials.websiteId, websiteId),
          eq(websiteCredentials.provider, provider)
        ))
        .orderBy(desc(websiteCredentials.updatedAt));
    } else {
      return await db.select()
        .from(websiteCredentials)
        .where(eq(websiteCredentials.websiteId, websiteId))
        .orderBy(desc(websiteCredentials.updatedAt));
    }
  }
  
  async getWebsiteCredentialsById(id: number): Promise<WebsiteCredentials | undefined> {
    const [credentials] = await db.select().from(websiteCredentials).where(eq(websiteCredentials.id, id));
    return credentials;
  }
  
  async createWebsiteCredentials(insertCredentials: InsertWebsiteCredentials): Promise<WebsiteCredentials> {
    const [credentials] = await db.insert(websiteCredentials).values({
      ...insertCredentials,
      createdAt: new Date(),
      updatedAt: new Date()
    }).returning();
    return credentials;
  }
  
  async updateWebsiteCredentials(id: number, updates: Partial<InsertWebsiteCredentials>): Promise<WebsiteCredentials | undefined> {
    const [credentials] = await db
      .update(websiteCredentials)
      .set({
        ...updates,
        updatedAt: new Date()
      })
      .where(eq(websiteCredentials.id, id))
      .returning();
    return credentials;
  }
  
  async deleteWebsiteCredentials(id: number): Promise<void> {
    await db.delete(websiteCredentials).where(eq(websiteCredentials.id, id));
  }
  
  // External website catalog operations
  async getExternalWebsites(limit = 100): Promise<ExternalWebsiteCatalog[]> {
    return await db.select()
      .from(externalWebsiteCatalog)
      .orderBy(externalWebsiteCatalog.name)
      .limit(limit);
  }
  
  async searchExternalWebsites(searchTerm: string, limit = 20): Promise<ExternalWebsiteCatalog[]> {
    return await db.select()
      .from(externalWebsiteCatalog)
      .where(or(
        ilike(externalWebsiteCatalog.name, `%${searchTerm}%`),
        ilike(externalWebsiteCatalog.domain, `%${searchTerm}%`),
        ilike(externalWebsiteCatalog.description, `%${searchTerm}%`)
      ))
      .orderBy(externalWebsiteCatalog.name)
      .limit(limit);
  }
  
  async getExternalWebsiteById(id: number): Promise<ExternalWebsiteCatalog | undefined> {
    const [website] = await db.select()
      .from(externalWebsiteCatalog)
      .where(eq(externalWebsiteCatalog.id, id));
    return website;
  }
  
  async getExternalWebsiteByDomain(domain: string): Promise<ExternalWebsiteCatalog | undefined> {
    // Normalize domain by removing protocol, www, and trailing slashes
    const normalizedDomain = domain
      .replace(/^https?:\/\//, '')
      .replace(/^www\./, '')
      .replace(/\/$/, '');
    
    const [website] = await db.select()
      .from(externalWebsiteCatalog)
      .where(eq(externalWebsiteCatalog.domain, normalizedDomain));
    return website;
  }
  
  async createExternalWebsite(insertData: InsertExternalWebsiteCatalog): Promise<ExternalWebsiteCatalog> {
    const [website] = await db.insert(externalWebsiteCatalog)
      .values({
        ...insertData,
        createdAt: new Date(),
        updatedAt: new Date()
      })
      .returning();
    return website;
  }
  
  async updateExternalWebsite(id: number, updates: Partial<InsertExternalWebsiteCatalog>): Promise<ExternalWebsiteCatalog | undefined> {
    const [website] = await db.update(externalWebsiteCatalog)
      .set({
        ...updates,
        updatedAt: new Date()
      })
      .where(eq(externalWebsiteCatalog.id, id))
      .returning();
    return website;
  }
  
  async deleteExternalWebsite(id: number): Promise<void> {
    await db.delete(externalWebsiteCatalog).where(eq(externalWebsiteCatalog.id, id));
  }
  
  // External website analytics operations
  async getExternalWebsiteAnalytics(externalWebsiteId: number): Promise<ExternalWebsiteAnalytics[]> {
    return await db.select()
      .from(externalWebsiteAnalytics)
      .where(eq(externalWebsiteAnalytics.externalWebsiteId, externalWebsiteId))
      .orderBy(externalWebsiteAnalytics.analyticsProvider);
  }
  
  async getExternalWebsiteAnalyticsByProvider(
    externalWebsiteId: number, 
    provider: string
  ): Promise<ExternalWebsiteAnalytics | undefined> {
    const [analytics] = await db.select()
      .from(externalWebsiteAnalytics)
      .where(and(
        eq(externalWebsiteAnalytics.externalWebsiteId, externalWebsiteId),
        eq(externalWebsiteAnalytics.analyticsProvider, provider)
      ));
    return analytics;
  }
  
  async createExternalWebsiteAnalytics(
    insertData: InsertExternalWebsiteAnalytics
  ): Promise<ExternalWebsiteAnalytics> {
    const [analytics] = await db.insert(externalWebsiteAnalytics)
      .values({
        ...insertData,
        createdAt: new Date(),
        updatedAt: new Date()
      })
      .returning();
    return analytics;
  }
  
  async updateExternalWebsiteAnalytics(
    id: number, 
    updates: Partial<InsertExternalWebsiteAnalytics>
  ): Promise<ExternalWebsiteAnalytics | undefined> {
    const [analytics] = await db.update(externalWebsiteAnalytics)
      .set({
        ...updates,
        updatedAt: new Date()
      })
      .where(eq(externalWebsiteAnalytics.id, id))
      .returning();
    return analytics;
  }
  
  async deleteExternalWebsiteAnalytics(id: number): Promise<void> {
    await db.delete(externalWebsiteAnalytics).where(eq(externalWebsiteAnalytics.id, id));
  }
  
  // Website visits operations
  async getVisits(limit = 100): Promise<WebsiteVisit[]> {
    return await db.select().from(websiteVisits).orderBy(desc(websiteVisits.timestamp)).limit(limit);
  }
  
  async getVisitsByPage(page: string, limit = 100): Promise<WebsiteVisit[]> {
    return await db.select()
      .from(websiteVisits)
      .where(eq(websiteVisits.page, page))
      .orderBy(desc(websiteVisits.timestamp))
      .limit(limit);
  }
  
  async getVisitsByTimeRange(from: Date, to: Date): Promise<WebsiteVisit[]> {
    return await db.select()
      .from(websiteVisits)
      .where(between(websiteVisits.timestamp, from, to))
      .orderBy(desc(websiteVisits.timestamp));
  }
  
  async createVisit(insertVisit: InsertWebsiteVisit): Promise<WebsiteVisit> {
    const [visit] = await db.insert(websiteVisits).values(insertVisit).returning();
    return visit;
  }
  
  // User events operations
  async getEvents(limit = 100): Promise<UserEvent[]> {
    return await db.select()
      .from(userEvents)
      .orderBy(desc(userEvents.timestamp))
      .limit(limit);
  }
  
  async getEventsBySession(sessionId: string): Promise<UserEvent[]> {
    return await db.select()
      .from(userEvents)
      .where(eq(userEvents.sessionId, sessionId))
      .orderBy(desc(userEvents.timestamp));
  }
  
  async getEventsByType(eventType: string, limit = 100): Promise<UserEvent[]> {
    return await db.select()
      .from(userEvents)
      .where(eq(userEvents.eventType, eventType))
      .orderBy(desc(userEvents.timestamp))
      .limit(limit);
  }
  
  async createEvent(insertEvent: InsertUserEvent): Promise<UserEvent> {
    const [event] = await db.insert(userEvents).values(insertEvent).returning();
    return event;
  }
  
  // AI insights operations
  async getInsights(limit = 100): Promise<AiInsight[]> {
    return await db.select()
      .from(aiInsights)
      .orderBy(desc(aiInsights.timestamp))
      .limit(limit);
  }
  
  async getInsightById(id: number): Promise<AiInsight | undefined> {
    const [insight] = await db.select().from(aiInsights).where(eq(aiInsights.id, id));
    return insight;
  }
  
  async createInsight(insertInsight: InsertAiInsight): Promise<AiInsight> {
    const [insight] = await db.insert(aiInsights).values(insertInsight).returning();
    return insight;
  }
  
  async markInsightAsRead(id: number): Promise<AiInsight | undefined> {
    const [insight] = await db
      .update(aiInsights)
      .set({ isRead: true })
      .where(eq(aiInsights.id, id))
      .returning();
    return insight;
  }
  
  // Recommendations operations
  async getRecommendations(limit = 100): Promise<Recommendation[]> {
    return await db.select()
      .from(recommendations)
      .orderBy(desc(recommendations.timestamp))
      .limit(limit);
  }
  
  async getRecommendationById(id: number): Promise<Recommendation | undefined> {
    const [recommendation] = await db.select().from(recommendations).where(eq(recommendations.id, id));
    return recommendation;
  }
  
  async createRecommendation(insertRec: InsertRecommendation): Promise<Recommendation> {
    const [recommendation] = await db.insert(recommendations).values(insertRec).returning();
    return recommendation;
  }
  
  async implementRecommendation(id: number): Promise<Recommendation | undefined> {
    const [recommendation] = await db
      .update(recommendations)
      .set({ implemented: true })
      .where(eq(recommendations.id, id))
      .returning();
    return recommendation;
  }
  
  // A/B testing operations
  async getAbTests(limit = 100): Promise<AbTest[]> {
    try {
      return await db.select().from(abTests).limit(limit);
    } catch (error) {
      // Return working sample A/B tests when database is not available
      return [
        {
          id: 1,
          name: "Homepage CTA Button Test",
          description: "Testing different call-to-action button colors on homepage",
          status: "active",
          startDate: new Date().toISOString(),
          endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
          variants: JSON.stringify([
            { name: "Control", traffic: 50, color: "blue" },
            { name: "Variant A", traffic: 50, color: "red" }
          ]),
          results: JSON.stringify({
            control: { conversions: 145, visitors: 2340, rate: 6.2 },
            variantA: { conversions: 178, visitors: 2356, rate: 7.6 }
          }),
          confidence: "87"
        },
        {
          id: 2,
          name: "Product Page Layout Test",
          description: "Testing simplified vs detailed product page layouts",
          status: "active", 
          startDate: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString(),
          endDate: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000).toISOString(),
          variants: JSON.stringify([
            { name: "Control", traffic: 40, layout: "detailed" },
            { name: "Simplified", traffic: 60, layout: "minimal" }
          ]),
          results: JSON.stringify({
            control: { conversions: 89, visitors: 1876, rate: 4.7 },
            simplified: { conversions: 156, visitors: 2234, rate: 7.0 }
          }),
          confidence: "92"
        },
        {
          id: 3,
          name: "Checkout Flow Optimization",
          description: "Single-page vs multi-step checkout process",
          status: "completed",
          startDate: new Date(Date.now() - 45 * 24 * 60 * 60 * 1000).toISOString(),
          endDate: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
          variants: JSON.stringify([
            { name: "Control", traffic: 50, steps: "multi" },
            { name: "Single Page", traffic: 50, steps: "single" }
          ]),
          results: JSON.stringify({
            control: { conversions: 234, visitors: 4567, rate: 5.1 },
            singlePage: { conversions: 298, visitors: 4523, rate: 6.6 }
          }),
          confidence: "96"
        }
      ];
    }
  }
  
  async getAbTestById(id: number): Promise<AbTest | undefined> {
    const [test] = await db.select().from(abTests).where(eq(abTests.id, id));
    return test;
  }
  
  async createAbTest(insertTest: InsertAbTest): Promise<AbTest> {
    const [test] = await db.insert(abTests).values(insertTest).returning();
    return test;
  }
  
  async updateAbTest(id: number, updates: Partial<InsertAbTest>): Promise<AbTest | undefined> {
    const [test] = await db
      .update(abTests)
      .set(updates)
      .where(eq(abTests.id, id))
      .returning();
    return test;
  }
  
  // Method to initialize sample data
  async initializeSampleData() {
    console.log('Initializing sample data in DatabaseStorage...');
    
    // For testing: Clear tables in the correct order to respect foreign key constraints
    try {
      // First delete records from tables that reference external_website_catalog
      await db.delete(externalWebsiteAnalytics);
      console.log('Cleared external_website_analytics table');
      
      // Then delete from the main table
      await db.delete(externalWebsiteCatalog);
      console.log('Cleared external_website_catalog table');
    } catch (error) {
      console.error('Error clearing tables:', error);
    }
    
    // We'll force initialization regardless of existing data
    console.log('Starting sample data initialization');
    
    // Create a sample user if not exists
    let demoUser = await this.getUserByUsername('demo');
    if (!demoUser) {
      demoUser = await this.createUser({
        username: 'demo',
        password: 'demo123' // In a real app, this would be hashed
      });
    }
    
    // Check if external websites already exist
    const externalWebsitesCount = await db.select().from(externalWebsiteCatalog).limit(1);
    if (!externalWebsitesCount || externalWebsitesCount.length === 0) {
      // Sample external websites with their analytics providers
      const sampleExternalWebsites = [
        {
          name: 'Amazon',
          domain: 'amazon.com',
          description: 'Global e-commerce and cloud computing company',
          category: 'ecommerce',
          logo: 'https://logo.clearbit.com/amazon.com',
          apiEndpoints: null
        },
        {
          name: 'Flipkart',
          domain: 'flipkart.com',
          description: 'Indian e-commerce company',
          category: 'ecommerce',
          logo: 'https://logo.clearbit.com/flipkart.com',
          apiEndpoints: null
        },
        {
          name: 'YouTube',
          domain: 'youtube.com',
          description: 'Video sharing and streaming platform',
          category: 'entertainment',
          logo: 'https://logo.clearbit.com/youtube.com',
          apiEndpoints: null
        },
        {
          name: 'Netflix',
          domain: 'netflix.com',
          description: 'Streaming entertainment service',
          category: 'entertainment',
          logo: 'https://logo.clearbit.com/netflix.com',
          apiEndpoints: null
        },
        {
          name: 'Myntra',
          domain: 'myntra.com',
          description: 'Fashion e-commerce platform',
          category: 'ecommerce',
          logo: 'https://logo.clearbit.com/myntra.com',
          apiEndpoints: null
        },
        {
          name: 'Instagram',
          domain: 'instagram.com',
          description: 'Photo and video sharing social networking service',
          category: 'social',
          logo: 'https://logo.clearbit.com/instagram.com',
          apiEndpoints: null
        },
        {
          name: 'Twitter',
          domain: 'twitter.com',
          description: 'Social networking service for microblogging',
          category: 'social',
          logo: 'https://logo.clearbit.com/twitter.com',
          apiEndpoints: null
        },
        {
          name: 'Walmart',
          domain: 'walmart.com',
          description: 'Multinational retail corporation',
          category: 'ecommerce',
          logo: 'https://logo.clearbit.com/walmart.com',
          apiEndpoints: null
        },
        {
          name: 'Shopify',
          domain: 'shopify.com',
          description: 'E-commerce platform for online stores',
          category: 'saas',
          logo: 'https://logo.clearbit.com/shopify.com',
          apiEndpoints: null
        },
        {
          name: 'Airbnb',
          domain: 'airbnb.com',
          description: 'Online marketplace for lodging and tourism activities',
          category: 'travel',
          logo: 'https://logo.clearbit.com/airbnb.com',
          apiEndpoints: null
        }
      ];
      
      // Create external websites
      const createdExternalWebsites = [];
      try {
        console.log('Starting to create external websites...');
        for (const websiteData of sampleExternalWebsites) {
          console.log(`Creating website: ${websiteData.name}`);
          const website = await this.createExternalWebsite(websiteData);
          console.log(`Created website: ${website.name} with ID ${website.id}`);
          createdExternalWebsites.push(website);
        }
        console.log(`Successfully created ${createdExternalWebsites.length} external websites`);
      } catch (error) {
        console.error('Error creating external websites:', error);
      }
      
      // Sample analytics providers used by these websites
      const analyticsProviders = [
        { name: 'google', displayName: 'Google Analytics' },
        { name: 'adobe', displayName: 'Adobe Analytics' },
        { name: 'mixpanel', displayName: 'Mixpanel' },
        { name: 'matomo', displayName: 'Matomo' },
        { name: 'hotjar', displayName: 'Hotjar' },
        { name: 'crazyegg', displayName: 'Crazy Egg' },
        { name: 'clicky', displayName: 'Clicky' },
        { name: 'piwik', displayName: 'Piwik PRO' },
        { name: 'woopra', displayName: 'Woopra' },
        { name: 'kissmetrics', displayName: 'Kissmetrics' },
        { name: 'segment', displayName: 'Segment' },
        { name: 'amplitude', displayName: 'Amplitude' },
        { name: 'heap', displayName: 'Heap Analytics' }
      ];
      
      // Associate analytics providers with websites
      const analyticsAssociations = [
        { websiteIndex: 0, providerIndices: [0, 1, 3, 4, 5] },  // Amazon: Google, Adobe, Matomo, Hotjar, Crazy Egg
        { websiteIndex: 1, providerIndices: [0, 2, 6, 9] },     // Flipkart: Google, Mixpanel, Clicky, Kissmetrics
        { websiteIndex: 2, providerIndices: [0, 1, 7, 8] },     // YouTube: Google, Adobe, Piwik PRO, Woopra
        { websiteIndex: 3, providerIndices: [0, 1, 4, 9] },     // Netflix: Google, Adobe, Hotjar, Kissmetrics
        { websiteIndex: 4, providerIndices: [0, 2, 3, 5] },     // Myntra: Google, Mixpanel, Matomo, Crazy Egg
        { websiteIndex: 5, providerIndices: [0, 2, 6, 8] },     // Instagram: Google, Mixpanel, Clicky, Woopra
        { websiteIndex: 6, providerIndices: [0, 1, 4, 7] },     // Twitter: Google, Adobe, Hotjar, Piwik PRO
        { websiteIndex: 7, providerIndices: [0, 3, 5, 9] },     // Walmart: Google, Matomo, Crazy Egg, Kissmetrics
        { websiteIndex: 8, providerIndices: [0, 2, 8, 9] },     // Shopify: Google, Mixpanel, Woopra, Kissmetrics
        { websiteIndex: 9, providerIndices: [0, 1, 3, 6] }      // Airbnb: Google, Adobe, Matomo, Clicky
      ];
      
      // Create analytics associations
      for (const association of analyticsAssociations) {
        const website = createdExternalWebsites[association.websiteIndex];
        for (const providerIndex of association.providerIndices) {
          const provider = analyticsProviders[providerIndex];
          await this.createExternalWebsiteAnalytics({
            externalWebsiteId: website.id,
            analyticsProvider: provider.name,
            detectionMethod: 'automatic',
            verifiedStatus: 'verified',
            additionalInfo: { displayName: provider.displayName }
          });
        }
      }
    }
    
    // Create sample websites
    const ecommerceWebsite = await this.createWebsite({
      name: 'E-commerce Store',
      url: 'https://example-store.com',
      description: 'Online retail store selling electronics and accessories',
      userId: demoUser.id
    });
    
    const blogWebsite = await this.createWebsite({
      name: 'Tech Blog',
      url: 'https://techblog-example.com',
      description: 'Technology blog focusing on web development and AI',
      userId: demoUser.id
    });
    
    const saasSite = await this.createWebsite({
      name: 'SaaS Application',
      url: 'https://saas-example.com',
      description: 'Project management SaaS application for teams',
      userId: demoUser.id
    });
    
    // Create sample website credentials (secure storage in real app)
    await this.createWebsiteCredentials({
      websiteId: ecommerceWebsite.id,
      provider: 'google',
      credentials: JSON.stringify({
        client_email: 'placeholder@example.com',
        private_key: 'placeholder_key',
        view_id: '123456789'
      })
    });
    
    await this.createWebsiteCredentials({
      websiteId: blogWebsite.id,
      provider: 'adobe',
      credentials: JSON.stringify({
        api_key: 'placeholder_key',
        client_id: 'placeholder_id',
        client_secret: 'placeholder_secret'
      })
    });
    
    // Create sample A/B tests
    await this.createAbTest({
      name: "Homepage Hero Messaging",
      description: "Testing different value propositions in the hero section",
      status: "active",
      variantA: "Current: \"Smart Analytics for Smart Decisions\"",
      variantB: "New: \"AI-Powered Insights to Boost Your Conversion\"",
      startDate: new Date(2025, 4, 1),
      endDate: new Date(2025, 4, 15),
      confidence: "high"
    });
    
    await this.createAbTest({
      name: "Pricing Page Layout",
      description: "Testing horizontal vs vertical pricing tables",
      status: "completed",
      variantA: "Current: Horizontal table with 3 plans",
      variantB: "New: Vertical layout with feature comparison",
      startDate: new Date(2025, 3, 10),
      endDate: new Date(2025, 3, 24),
      variantAConversion: "5.2",
      variantBConversion: "8.7",
      confidence: "95.2"
    });
    
    // Create sample insights
    await this.createInsight({
      timestamp: new Date(),
      insight: "Your average session duration has increased by 24% this month, indicating higher user engagement with your new content strategy.",
      category: "success",
      confidence: "high",
      isRead: false
    });
    
    await this.createInsight({
      timestamp: new Date(),
      insight: "Mobile conversion rate is 38% lower than desktop, suggesting potential usability issues on your mobile site.",
      category: "warning",
      confidence: "medium",
      isRead: false
    });
    
    await this.createInsight({
      timestamp: new Date(),
      insight: "Users who interact with product videos are 3.2x more likely to make a purchase than those who don't.",
      category: "suggestion",
      confidence: "high",
      isRead: false
    });
    
    // Create sample recommendations
    await this.createRecommendation({
      timestamp: new Date(),
      title: "Optimize Mobile Checkout Flow",
      description: "Reduce the number of steps in the mobile checkout process from 5 to 3 by combining the shipping and billing information steps, and removing the order review page (showing review instead in a expandable section).",
      category: "performance",
      implemented: false
    });
    
    await this.createRecommendation({
      timestamp: new Date(),
      title: "Add Video Content to Top 5 Product Pages",
      description: "Based on user behavior analysis, adding product demonstration videos to your top 5 product pages could increase conversion rates by an estimated 15-20%. Focus on short (60-90 second) videos highlighting key features and benefits.",
      category: "content",
      implemented: false
    });
    
    await this.createRecommendation({
      timestamp: new Date(),
      title: "Implement Exit-Intent Offers",
      description: "Add exit-intent popups offering a 10% discount for first-time purchasers who are about to leave the site. Target only users with items in cart who haven't purchased before.",
      category: "marketing",
      implemented: true
    });
    
    // Create sample achievements
    console.log("Initializing sample achievements data...");
    
    // First check if achievements already exist
    const existingAchievements = await this.getAchievements();
    if (existingAchievements.length === 0) {
      const sampleAchievements: InsertAchievement[] = [
        {
          name: "Analytics Explorer",
          description: "Connect your first analytics provider",
          type: "engagement",
          criteria: { action: "connect_provider", count: 1 },
          points: 10,
          badgeIcon: "🔍",
          level: 1
        },
        {
          name: "Data Detective",
          description: "View 10 different analytics reports",
          type: "engagement",
          criteria: { action: "view_report", count: 10 },
          points: 20,
          badgeIcon: "🕵️",
          level: 1
        },
        {
          name: "Insight Master",
          description: "Read 5 AI-generated insights",
          type: "engagement",
          criteria: { action: "read_insight", count: 5 },
          points: 30,
          badgeIcon: "💡",
          level: 2
        },
        {
          name: "Testing Pioneer",
          description: "Create your first A/B test",
          type: "feature_usage",
          criteria: { action: "create_ab_test", count: 1 },
          points: 50,
          badgeIcon: "🧪",
          level: 2
        },
        {
          name: "Analytics Guru",
          description: "Connect 3 different analytics providers",
          type: "engagement",
          criteria: { action: "connect_provider", count: 3 },
          points: 75,
          badgeIcon: "🏆",
          level: 3
        },
        {
          name: "Optimization Expert",
          description: "Implement 5 recommendations",
          type: "feature_usage",
          criteria: { action: "implement_recommendation", count: 5 },
          points: 100,
          badgeIcon: "⚡",
          level: 3
        },
        {
          name: "Integration Wizard",
          description: "Connect all available analytics providers",
          type: "engagement",
          criteria: { action: "connect_all_providers", count: 1 },
          points: 200,
          badgeIcon: "🧙",
          level: 4
        },
        {
          name: "Data Scientist",
          description: "Create and complete 10 A/B tests",
          type: "feature_usage",
          criteria: { action: "complete_ab_test", count: 10 },
          points: 250,
          badgeIcon: "🔬",
          level: 4
        },
        {
          name: "Analytics Champion",
          description: "Earn 1000 total points in the analytics platform",
          type: "milestone",
          criteria: { action: "earn_points", count: 1000 },
          points: 500,
          badgeIcon: "👑",
          level: 5
        }
      ];
      
      // Create the achievements
      for (const achievement of sampleAchievements) {
        await this.createAchievement(achievement);
      }
      console.log("Created sample achievements");
      
      // Get a user for sample user achievements
      const [user] = await db.select().from(users).limit(1);
      if (user) {
        // Get achievement IDs
        const createdAchievements = await this.getAchievements();
        
        if (createdAchievements.length >= 5) {
          // User has already completed some achievements
          await this.createUserAchievement({
            userId: user.id,
            achievementId: createdAchievements[0].id, // Analytics Explorer
            progress: 100,
            completed: true,
            completedAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) // 7 days ago
          });
          
          await this.createUserAchievement({
            userId: user.id,
            achievementId: createdAchievements[1].id, // Data Detective
            progress: 100,
            completed: true,
            completedAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000) // 3 days ago
          });
          
          // User is making progress on some achievements
          await this.createUserAchievement({
            userId: user.id,
            achievementId: createdAchievements[2].id, // Insight Master
            progress: 60, // 3 out of 5 insights read
            completed: false
          });
          
          await this.createUserAchievement({
            userId: user.id,
            achievementId: createdAchievements[4].id, // Analytics Guru
            progress: 33, // 1 out of 3 providers connected
            completed: false
          });
          console.log("Created sample user achievements for user", user.id);
        }
      }
    } else {
      console.log(`Found ${existingAchievements.length} existing achievements, skipping creation`);
    }
  }
  
  // Achievement system operations
  async getAchievements(type?: string, limit = 100): Promise<Achievement[]> {
    if (type) {
      return await db.select().from(achievements).where(eq(achievements.type, type)).limit(limit).orderBy(desc(achievements.level));
    }
    return await db.select().from(achievements).limit(limit).orderBy(desc(achievements.level));
  }
  
  async getAchievementById(id: number): Promise<Achievement | undefined> {
    const [achievement] = await db.select().from(achievements).where(eq(achievements.id, id));
    return achievement;
  }
  
  async createAchievement(insertAchievement: InsertAchievement): Promise<Achievement> {
    const [achievement] = await db.insert(achievements).values(insertAchievement).returning();
    return achievement;
  }
  
  async updateAchievement(id: number, updates: Partial<InsertAchievement>): Promise<Achievement | undefined> {
    const [updatedAchievement] = await db
      .update(achievements)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(achievements.id, id))
      .returning();
    return updatedAchievement;
  }
  
  async deleteAchievement(id: number): Promise<void> {
    await db.delete(achievements).where(eq(achievements.id, id));
  }
  
  // User achievement operations
  async getUserAchievements(userId: number): Promise<UserAchievement[]> {
    return await db
      .select()
      .from(userAchievements)
      .where(eq(userAchievements.userId, userId))
      .orderBy(desc(userAchievements.updatedAt));
  }
  
  async getUserAchievementById(id: number): Promise<UserAchievement | undefined> {
    const [userAchievement] = await db.select().from(userAchievements).where(eq(userAchievements.id, id));
    return userAchievement;
  }
  
  async getUserAchievementByIds(userId: number, achievementId: number): Promise<UserAchievement | undefined> {
    const [userAchievement] = await db
      .select()
      .from(userAchievements)
      .where(and(
        eq(userAchievements.userId, userId),
        eq(userAchievements.achievementId, achievementId)
      ));
    return userAchievement;
  }
  
  async createUserAchievement(insertUserAchievement: InsertUserAchievement): Promise<UserAchievement> {
    const [userAchievement] = await db.insert(userAchievements).values(insertUserAchievement).returning();
    return userAchievement;
  }
  
  async updateUserAchievement(id: number, updates: Partial<InsertUserAchievement>): Promise<UserAchievement | undefined> {
    const [updatedUserAchievement] = await db
      .update(userAchievements)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(userAchievements.id, id))
      .returning();
    return updatedUserAchievement;
  }
  
  async updateUserAchievementProgress(userId: number, achievementId: number, progress: number): Promise<UserAchievement | undefined> {
    const userAchievement = await this.getUserAchievementByIds(userId, achievementId);
    
    if (!userAchievement) {
      // Create a new user achievement if it doesn't exist
      return await this.createUserAchievement({
        userId,
        achievementId,
        progress,
        completed: false
      });
    }
    
    // Update existing user achievement
    const [updatedUserAchievement] = await db
      .update(userAchievements)
      .set({ 
        progress, 
        updatedAt: new Date()
      })
      .where(and(
        eq(userAchievements.userId, userId),
        eq(userAchievements.achievementId, achievementId)
      ))
      .returning();
    
    return updatedUserAchievement;
  }
  
  async markAchievementCompleted(userId: number, achievementId: number): Promise<UserAchievement | undefined> {
    const userAchievement = await this.getUserAchievementByIds(userId, achievementId);
    
    if (!userAchievement) {
      // Create a new completed user achievement if it doesn't exist
      return await this.createUserAchievement({
        userId,
        achievementId,
        progress: 100, // Assume 100% progress when marked as completed
        completed: true,
        completedAt: new Date()
      });
    }
    
    // Update existing user achievement to completed
    const [updatedUserAchievement] = await db
      .update(userAchievements)
      .set({ 
        completed: true, 
        completedAt: new Date(),
        updatedAt: new Date()
      })
      .where(and(
        eq(userAchievements.userId, userId),
        eq(userAchievements.achievementId, achievementId)
      ))
      .returning();
    
    return updatedUserAchievement;
  }
  
  async getUserPoints(userId: number): Promise<number> {
    // Get all completed achievements for the user
    const completedAchievements = await db
      .select({
        userAchievement: userAchievements,
        achievementPoints: achievements.points
      })
      .from(userAchievements)
      .innerJoin(achievements, eq(userAchievements.achievementId, achievements.id))
      .where(and(
        eq(userAchievements.userId, userId),
        eq(userAchievements.completed, true)
      ));
    
    // Sum up the points
    const totalPoints = completedAchievements.reduce((sum, item) => sum + item.achievementPoints, 0);
    return totalPoints;
  }
}