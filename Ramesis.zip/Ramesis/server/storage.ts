import { 
  users, type User, type InsertUser,
  websites, type Website, type InsertWebsite,
  websiteCredentials, type WebsiteCredentials, type InsertWebsiteCredentials,
  externalWebsiteCatalog, type ExternalWebsiteCatalog, type InsertExternalWebsiteCatalog,
  externalWebsiteAnalytics, type ExternalWebsiteAnalytics, type InsertExternalWebsiteAnalytics,
  websiteVisits, type WebsiteVisit, type InsertWebsiteVisit,
  userEvents, type UserEvent, type InsertUserEvent,
  aiInsights, type AiInsight, type InsertAiInsight,
  recommendations, type Recommendation, type InsertRecommendation,
  abTests, type AbTest, type InsertAbTest,
  achievements, type Achievement, type InsertAchievement,
  userAchievements, type UserAchievement, type InsertUserAchievement,
  transactions, type Transaction, type InsertTransaction,
  revenueGoals, type RevenueGoal, type InsertRevenueGoal
} from "@shared/schema";

// Storage interface for CRUD operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Website operations
  getWebsites(userId?: number, limit?: number): Promise<Website[]>;
  getWebsiteById(id: number): Promise<Website | undefined>;
  createWebsite(website: InsertWebsite): Promise<Website>;
  updateWebsite(id: number, updates: Partial<InsertWebsite>): Promise<Website | undefined>;
  deleteWebsite(id: number): Promise<void>;
  
  // Website credentials operations
  getWebsiteCredentials(websiteId: number, provider?: string): Promise<WebsiteCredentials[]>;
  getWebsiteCredentialsById(id: number): Promise<WebsiteCredentials | undefined>;
  createWebsiteCredentials(credentials: InsertWebsiteCredentials): Promise<WebsiteCredentials>;
  updateWebsiteCredentials(id: number, updates: Partial<InsertWebsiteCredentials>): Promise<WebsiteCredentials | undefined>;
  deleteWebsiteCredentials(id: number): Promise<void>;
  
  // Website visits operations
  getVisits(limit?: number): Promise<WebsiteVisit[]>;
  getVisitsByPage(page: string, limit?: number): Promise<WebsiteVisit[]>;
  getVisitsByTimeRange(from: Date, to: Date): Promise<WebsiteVisit[]>;
  createVisit(visit: InsertWebsiteVisit): Promise<WebsiteVisit>;
  
  // User events operations
  getEvents(limit?: number): Promise<UserEvent[]>;
  getEventsBySession(sessionId: string): Promise<UserEvent[]>;
  getEventsByType(eventType: string, limit?: number): Promise<UserEvent[]>;
  createEvent(event: InsertUserEvent): Promise<UserEvent>;
  
  // AI insights operations
  getInsights(limit?: number): Promise<AiInsight[]>;
  getInsightById(id: number): Promise<AiInsight | undefined>;
  createInsight(insight: InsertAiInsight): Promise<AiInsight>;
  markInsightAsRead(id: number): Promise<AiInsight | undefined>;
  
  // Recommendations operations
  getRecommendations(limit?: number): Promise<Recommendation[]>;
  getRecommendationById(id: number): Promise<Recommendation | undefined>;
  createRecommendation(recommendation: InsertRecommendation): Promise<Recommendation>;
  implementRecommendation(id: number): Promise<Recommendation | undefined>;
  
  // A/B testing operations
  getAbTests(limit?: number): Promise<AbTest[]>;
  getAbTestById(id: number): Promise<AbTest | undefined>;
  createAbTest(test: InsertAbTest): Promise<AbTest>;
  updateAbTest(id: number, test: Partial<InsertAbTest>): Promise<AbTest | undefined>;
  
  // External website catalog operations
  getExternalWebsites(limit?: number): Promise<ExternalWebsiteCatalog[]>;
  searchExternalWebsites(searchTerm: string, limit?: number): Promise<ExternalWebsiteCatalog[]>;
  getExternalWebsiteById(id: number): Promise<ExternalWebsiteCatalog | undefined>;
  getExternalWebsiteByDomain(domain: string): Promise<ExternalWebsiteCatalog | undefined>;
  createExternalWebsite(website: InsertExternalWebsiteCatalog): Promise<ExternalWebsiteCatalog>;
  updateExternalWebsite(id: number, updates: Partial<InsertExternalWebsiteCatalog>): Promise<ExternalWebsiteCatalog | undefined>;
  deleteExternalWebsite(id: number): Promise<void>;
  
  // External website analytics operations
  getExternalWebsiteAnalytics(externalWebsiteId: number): Promise<ExternalWebsiteAnalytics[]>;
  getExternalWebsiteAnalyticsByProvider(externalWebsiteId: number, provider: string): Promise<ExternalWebsiteAnalytics | undefined>;
  createExternalWebsiteAnalytics(analytics: InsertExternalWebsiteAnalytics): Promise<ExternalWebsiteAnalytics>;
  updateExternalWebsiteAnalytics(id: number, updates: Partial<InsertExternalWebsiteAnalytics>): Promise<ExternalWebsiteAnalytics | undefined>;
  deleteExternalWebsiteAnalytics(id: number): Promise<void>;
  
  // Achievement system operations
  getAchievements(type?: string, limit?: number): Promise<Achievement[]>;
  getAchievementById(id: number): Promise<Achievement | undefined>;
  createAchievement(achievement: InsertAchievement): Promise<Achievement>;
  updateAchievement(id: number, updates: Partial<InsertAchievement>): Promise<Achievement | undefined>;
  deleteAchievement(id: number): Promise<void>;
  
  // User achievement operations
  getUserAchievements(userId: number): Promise<UserAchievement[]>;
  getUserAchievementById(id: number): Promise<UserAchievement | undefined>;
  getUserAchievementByIds(userId: number, achievementId: number): Promise<UserAchievement | undefined>;
  createUserAchievement(userAchievement: InsertUserAchievement): Promise<UserAchievement>;
  updateUserAchievement(id: number, updates: Partial<InsertUserAchievement>): Promise<UserAchievement | undefined>;
  updateUserAchievementProgress(userId: number, achievementId: number, progress: number): Promise<UserAchievement | undefined>;
  markAchievementCompleted(userId: number, achievementId: number): Promise<UserAchievement | undefined>;
  getUserPoints(userId: number): Promise<number>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private websites: Map<number, Website>;
  private websiteCredentials: Map<number, WebsiteCredentials>;
  private visits: Map<number, WebsiteVisit>;
  private events: Map<number, UserEvent>;
  private insights: Map<number, AiInsight>;
  private recs: Map<number, Recommendation>;
  private tests: Map<number, AbTest>;
  private externalWebsites: Map<number, ExternalWebsiteCatalog>;
  private externalAnalytics: Map<number, ExternalWebsiteAnalytics>;
  private achievements: Map<number, Achievement>;
  private userAchievements: Map<number, UserAchievement>;
  
  private userId: number;
  private visitId: number;
  private eventId: number;
  private insightId: number;
  private recId: number;
  private testId: number;
  private externalWebsiteId: number;
  private externalAnalyticsId: number;
  private achievementId: number;
  private userAchievementId: number;

  constructor() {
    this.users = new Map();
    this.websites = new Map();
    this.websiteCredentials = new Map();
    this.visits = new Map();
    this.events = new Map();
    this.insights = new Map();
    this.recs = new Map();
    this.tests = new Map();
    this.externalWebsites = new Map();
    this.externalAnalytics = new Map();
    this.achievements = new Map();
    this.userAchievements = new Map();
    
    this.userId = 1;
    this.visitId = 1;
    this.eventId = 1;
    this.insightId = 1;
    this.recId = 1;
    this.testId = 1;
    this.externalWebsiteId = 1;
    this.externalAnalyticsId = 1;
    this.achievementId = 1;
    this.userAchievementId = 1;
    
    // Initialize with sample data asynchronously
    // We can't use await in the constructor, so we're just starting the initialization
    this.initializeSampleData().catch(err => {
      console.error("Error initializing sample data:", err);
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
    
  // Website operations
  async getWebsites(userId?: number, limit = 100): Promise<Website[]> {
    const websites = Array.from(this.websites.values());
    if (userId !== undefined) {
      return websites.filter(website => website.userId === userId).slice(0, limit);
    }
    return websites.slice(0, limit);
  }

  async getWebsiteById(id: number): Promise<Website | undefined> {
    return this.websites.get(id);
  }

  async createWebsite(website: InsertWebsite): Promise<Website> {
    const id = this.websites.size + 1;
    const newWebsite: Website = {
      ...website,
      id,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.websites.set(id, newWebsite);
    return newWebsite;
  }

  async updateWebsite(id: number, updates: Partial<InsertWebsite>): Promise<Website | undefined> {
    const website = this.websites.get(id);
    if (!website) return undefined;
    
    const updatedWebsite: Website = {
      ...website,
      ...updates,
      updatedAt: new Date()
    };
    this.websites.set(id, updatedWebsite);
    return updatedWebsite;
  }

  async deleteWebsite(id: number): Promise<void> {
    this.websites.delete(id);
  }
  
  // Website credentials operations
  async getWebsiteCredentials(websiteId: number, provider?: string): Promise<WebsiteCredentials[]> {
    const credentials = Array.from(this.websiteCredentials.values())
      .filter(cred => cred.websiteId === websiteId);
    
    if (provider) {
      return credentials.filter(cred => cred.provider === provider);
    }
    return credentials;
  }

  async getWebsiteCredentialsById(id: number): Promise<WebsiteCredentials | undefined> {
    return this.websiteCredentials.get(id);
  }

  async createWebsiteCredentials(credentials: InsertWebsiteCredentials): Promise<WebsiteCredentials> {
    const id = this.websiteCredentials.size + 1;
    const newCredentials: WebsiteCredentials = {
      ...credentials,
      id,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.websiteCredentials.set(id, newCredentials);
    return newCredentials;
  }

  async updateWebsiteCredentials(
    id: number, 
    updates: Partial<InsertWebsiteCredentials>
  ): Promise<WebsiteCredentials | undefined> {
    const credentials = this.websiteCredentials.get(id);
    if (!credentials) return undefined;
    
    const updatedCredentials: WebsiteCredentials = {
      ...credentials,
      ...updates,
      updatedAt: new Date()
    };
    this.websiteCredentials.set(id, updatedCredentials);
    return updatedCredentials;
  }

  async deleteWebsiteCredentials(id: number): Promise<void> {
    this.websiteCredentials.delete(id);
  }
  
  // Website visits operations
  async getVisits(limit = 100): Promise<WebsiteVisit[]> {
    return Array.from(this.visits.values())
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
      .slice(0, limit);
  }
  
  async getVisitsByPage(page: string, limit = 100): Promise<WebsiteVisit[]> {
    return Array.from(this.visits.values())
      .filter(visit => visit.page === page)
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
      .slice(0, limit);
  }
  
  async getVisitsByTimeRange(from: Date, to: Date): Promise<WebsiteVisit[]> {
    return Array.from(this.visits.values())
      .filter(visit => {
        const visitDate = new Date(visit.timestamp);
        return visitDate >= from && visitDate <= to;
      })
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }
  
  async createVisit(insertVisit: InsertWebsiteVisit): Promise<WebsiteVisit> {
    const id = this.visitId++;
    const visit: WebsiteVisit = { 
      ...insertVisit, 
      id,
      timestamp: insertVisit.timestamp || new Date(),
      duration: insertVisit.duration || null,
      referrer: insertVisit.referrer || null,
      country: insertVisit.country || null
    };
    this.visits.set(id, visit);
    return visit;
  }
  
  // User events operations
  async getEvents(limit = 100): Promise<UserEvent[]> {
    return Array.from(this.events.values())
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
      .slice(0, limit);
  }
  
  async getEventsBySession(sessionId: string): Promise<UserEvent[]> {
    return Array.from(this.events.values())
      .filter(event => event.sessionId === sessionId)
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }
  
  async getEventsByType(eventType: string, limit = 100): Promise<UserEvent[]> {
    return Array.from(this.events.values())
      .filter(event => event.eventType === eventType)
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
      .slice(0, limit);
  }
  
  async createEvent(insertEvent: InsertUserEvent): Promise<UserEvent> {
    const id = this.eventId++;
    const event: UserEvent = { 
      ...insertEvent, 
      id,
      timestamp: insertEvent.timestamp || new Date()
    };
    this.events.set(id, event);
    return event;
  }
  
  // AI insights operations
  async getInsights(limit = 100): Promise<AiInsight[]> {
    return Array.from(this.insights.values())
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
      .slice(0, limit);
  }
  
  async getInsightById(id: number): Promise<AiInsight | undefined> {
    return this.insights.get(id);
  }
  
  async createInsight(insertInsight: InsertAiInsight): Promise<AiInsight> {
    const id = this.insightId++;
    const insight: AiInsight = { 
      ...insertInsight, 
      id,
      timestamp: insertInsight.timestamp || new Date(),
      isRead: insertInsight.isRead === undefined ? false : insertInsight.isRead
    };
    this.insights.set(id, insight);
    return insight;
  }
  
  async markInsightAsRead(id: number): Promise<AiInsight | undefined> {
    const insight = this.insights.get(id);
    if (insight) {
      const updatedInsight = { ...insight, isRead: true };
      this.insights.set(id, updatedInsight);
      return updatedInsight;
    }
    return undefined;
  }
  
  // Recommendations operations
  async getRecommendations(limit = 100): Promise<Recommendation[]> {
    return Array.from(this.recs.values())
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
      .slice(0, limit);
  }
  
  async getRecommendationById(id: number): Promise<Recommendation | undefined> {
    return this.recs.get(id);
  }
  
  async createRecommendation(insertRec: InsertRecommendation): Promise<Recommendation> {
    const id = this.recId++;
    const rec: Recommendation = { 
      ...insertRec, 
      id,
      timestamp: insertRec.timestamp || new Date(),
      implemented: insertRec.implemented === undefined ? false : insertRec.implemented
    };
    this.recs.set(id, rec);
    return rec;
  }
  
  async implementRecommendation(id: number): Promise<Recommendation | undefined> {
    const rec = this.recs.get(id);
    if (rec) {
      const updatedRec = { ...rec, implemented: true };
      this.recs.set(id, updatedRec);
      return updatedRec;
    }
    return undefined;
  }
  
  // A/B testing operations with GrowthBook integration
  async getAbTests(limit = 100): Promise<AbTest[]> {
    let tests = Array.from(this.tests.values())
      .sort((a, b) => new Date(b.startDate).getTime() - new Date(a.startDate).getTime())
      .slice(0, limit);

    return tests;
  }
  
  async getAbTestById(id: number): Promise<AbTest | undefined> {
    return this.tests.get(id);
  }
  
  async createAbTest(insertTest: InsertAbTest): Promise<AbTest> {
    const id = this.testId++;
    const test: AbTest = { 
      ...insertTest, 
      id,
      name: insertTest.name,
      description: insertTest.description,
      variantA: insertTest.variantA,
      variantB: insertTest.variantB,
      status: insertTest.status || 'active',
      confidence: insertTest.confidence || '0',
      startDate: insertTest.startDate || new Date(),
      endDate: insertTest.endDate || null,
      variantAConversion: insertTest.variantAConversion || '0',
      variantBConversion: insertTest.variantBConversion || '0'
    };
    this.tests.set(id, test);
    return test;
  }
  
  async updateAbTest(id: number, updates: Partial<InsertAbTest>): Promise<AbTest | undefined> {
    const test = this.tests.get(id);
    if (test) {
      const updatedTest = { ...test, ...updates };
      this.tests.set(id, updatedTest);
      return updatedTest;
    }
    return undefined;
  }
  
  // External website catalog operations
  async getExternalWebsites(limit = 100): Promise<ExternalWebsiteCatalog[]> {
    return Array.from(this.externalWebsites.values())
      .sort((a, b) => a.name.localeCompare(b.name))
      .slice(0, limit);
  }
  
  async searchExternalWebsites(searchTerm: string, limit = 20): Promise<ExternalWebsiteCatalog[]> {
    const lowerCaseSearchTerm = searchTerm.toLowerCase();
    return Array.from(this.externalWebsites.values())
      .filter(website => 
        website.name.toLowerCase().includes(lowerCaseSearchTerm) || 
        website.domain.toLowerCase().includes(lowerCaseSearchTerm) ||
        (website.description && website.description.toLowerCase().includes(lowerCaseSearchTerm))
      )
      .sort((a, b) => a.name.localeCompare(b.name))
      .slice(0, limit);
  }
  
  async getExternalWebsiteById(id: number): Promise<ExternalWebsiteCatalog | undefined> {
    return this.externalWebsites.get(id);
  }
  
  async getExternalWebsiteByDomain(domain: string): Promise<ExternalWebsiteCatalog | undefined> {
    // Normalize domain by removing protocol, www, and trailing slashes
    const normalizedDomain = domain
      .replace(/^https?:\/\//, '')
      .replace(/^www\./, '')
      .replace(/\/$/, '');
    
    return Array.from(this.externalWebsites.values())
      .find(website => website.domain === normalizedDomain);
  }
  
  async createExternalWebsite(insertData: InsertExternalWebsiteCatalog): Promise<ExternalWebsiteCatalog> {
    const id = this.externalWebsiteId++;
    const website: ExternalWebsiteCatalog = {
      ...insertData,
      id,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.externalWebsites.set(id, website);
    return website;
  }
  
  async updateExternalWebsite(id: number, updates: Partial<InsertExternalWebsiteCatalog>): Promise<ExternalWebsiteCatalog | undefined> {
    const website = this.externalWebsites.get(id);
    if (website) {
      const updatedWebsite = { 
        ...website, 
        ...updates,
        updatedAt: new Date()
      };
      this.externalWebsites.set(id, updatedWebsite);
      return updatedWebsite;
    }
    return undefined;
  }
  
  async deleteExternalWebsite(id: number): Promise<void> {
    this.externalWebsites.delete(id);
  }
  
  // External website analytics operations
  async getExternalWebsiteAnalytics(externalWebsiteId: number): Promise<ExternalWebsiteAnalytics[]> {
    return Array.from(this.externalAnalytics.values())
      .filter(analytics => analytics.externalWebsiteId === externalWebsiteId)
      .sort((a, b) => a.analyticsProvider.localeCompare(b.analyticsProvider));
  }
  
  async getExternalWebsiteAnalyticsByProvider(
    externalWebsiteId: number, 
    provider: string
  ): Promise<ExternalWebsiteAnalytics | undefined> {
    return Array.from(this.externalAnalytics.values())
      .find(analytics => 
        analytics.externalWebsiteId === externalWebsiteId && 
        analytics.analyticsProvider === provider
      );
  }
  
  async createExternalWebsiteAnalytics(
    insertData: InsertExternalWebsiteAnalytics
  ): Promise<ExternalWebsiteAnalytics> {
    const id = this.externalAnalyticsId++;
    const analytics: ExternalWebsiteAnalytics = {
      ...insertData,
      id,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.externalAnalytics.set(id, analytics);
    return analytics;
  }
  
  async updateExternalWebsiteAnalytics(
    id: number, 
    updates: Partial<InsertExternalWebsiteAnalytics>
  ): Promise<ExternalWebsiteAnalytics | undefined> {
    const analytics = this.externalAnalytics.get(id);
    if (analytics) {
      const updatedAnalytics = { 
        ...analytics, 
        ...updates,
        updatedAt: new Date()
      };
      this.externalAnalytics.set(id, updatedAnalytics);
      return updatedAnalytics;
    }
    return undefined;
  }
  
  async deleteExternalWebsiteAnalytics(id: number): Promise<void> {
    this.externalAnalytics.delete(id);
  }
  
  // Achievement system operations
  async getAchievements(type?: string, limit = 100): Promise<Achievement[]> {
    const allAchievements = Array.from(this.achievements.values());
    if (type) {
      return allAchievements
        .filter(achievement => achievement.type === type)
        .sort((a, b) => b.level - a.level)
        .slice(0, limit);
    }
    return allAchievements
      .sort((a, b) => b.level - a.level)
      .slice(0, limit);
  }
  
  async getAchievementById(id: number): Promise<Achievement | undefined> {
    return this.achievements.get(id);
  }
  
  async createAchievement(insertAchievement: InsertAchievement): Promise<Achievement> {
    const id = this.achievementId++;
    const achievement: Achievement = {
      ...insertAchievement,
      id,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.achievements.set(id, achievement);
    return achievement;
  }
  
  async updateAchievement(id: number, updates: Partial<InsertAchievement>): Promise<Achievement | undefined> {
    const achievement = this.achievements.get(id);
    if (!achievement) return undefined;
    
    const updatedAchievement: Achievement = {
      ...achievement,
      ...updates,
      updatedAt: new Date()
    };
    this.achievements.set(id, updatedAchievement);
    return updatedAchievement;
  }
  
  async deleteAchievement(id: number): Promise<void> {
    this.achievements.delete(id);
  }
  
  // User achievement operations
  async getUserAchievements(userId: number): Promise<UserAchievement[]> {
    return Array.from(this.userAchievements.values())
      .filter(ua => ua.userId === userId)
      .sort((a, b) => {
        if (a.updatedAt && b.updatedAt) {
          return b.updatedAt.getTime() - a.updatedAt.getTime();
        }
        return 0;
      });
  }
  
  async getUserAchievementById(id: number): Promise<UserAchievement | undefined> {
    return this.userAchievements.get(id);
  }
  
  async getUserAchievementByIds(userId: number, achievementId: number): Promise<UserAchievement | undefined> {
    return Array.from(this.userAchievements.values())
      .find(ua => ua.userId === userId && ua.achievementId === achievementId);
  }
  
  async createUserAchievement(insertUserAchievement: InsertUserAchievement): Promise<UserAchievement> {
    const id = this.userAchievementId++;
    const userAchievement: UserAchievement = {
      ...insertUserAchievement,
      id,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.userAchievements.set(id, userAchievement);
    return userAchievement;
  }
  
  async updateUserAchievement(id: number, updates: Partial<InsertUserAchievement>): Promise<UserAchievement | undefined> {
    const userAchievement = this.userAchievements.get(id);
    if (!userAchievement) return undefined;
    
    const updatedUserAchievement: UserAchievement = {
      ...userAchievement,
      ...updates,
      updatedAt: new Date()
    };
    this.userAchievements.set(id, updatedUserAchievement);
    return updatedUserAchievement;
  }
  
  async updateUserAchievementProgress(userId: number, achievementId: number, progress: number): Promise<UserAchievement | undefined> {
    const userAchievement = await this.getUserAchievementByIds(userId, achievementId);
    
    if (!userAchievement) {
      // Create a new user achievement if it doesn't exist
      return this.createUserAchievement({
        userId,
        achievementId,
        progress,
        completed: false
      });
    }
    
    // Update existing user achievement
    const updatedUserAchievement: UserAchievement = {
      ...userAchievement,
      progress,
      updatedAt: new Date()
    };
    this.userAchievements.set(userAchievement.id, updatedUserAchievement);
    return updatedUserAchievement;
  }
  
  async markAchievementCompleted(userId: number, achievementId: number): Promise<UserAchievement | undefined> {
    const userAchievement = await this.getUserAchievementByIds(userId, achievementId);
    
    if (!userAchievement) {
      // Create a new completed user achievement if it doesn't exist
      return this.createUserAchievement({
        userId,
        achievementId,
        progress: 100, // Assume 100% progress when marked as completed
        completed: true,
        completedAt: new Date()
      });
    }
    
    // Update existing user achievement to completed
    const updatedUserAchievement: UserAchievement = {
      ...userAchievement,
      completed: true,
      completedAt: new Date(),
      updatedAt: new Date()
    };
    this.userAchievements.set(userAchievement.id, updatedUserAchievement);
    return updatedUserAchievement;
  }
  
  async getUserPoints(userId: number): Promise<number> {
    // Get all completed achievements for the user
    const userAchievements = Array.from(this.userAchievements.values())
      .filter(ua => ua.userId === userId && ua.completed);
    
    // Get the points for each achievement and sum them
    let totalPoints = 0;
    for (const ua of userAchievements) {
      const achievement = this.achievements.get(ua.achievementId);
      if (achievement) {
        totalPoints += achievement.points;
      }
    }
    
    return totalPoints;
  }
  
  // Initialize sample data for demonstration
  private async initializeSampleData() {
    // Prevent duplicate initialization
    if (this.externalWebsites.size > 0) {
      return; // Already initialized
    }
    // Sample insights
    const sampleInsights: InsertAiInsight[] = [
      {
        timestamp: new Date(),
        insight: "Mobile conversion rate increased by 12% after your recent checkout optimization. Users are completing purchases 30% faster.",
        category: "success",
        confidence: "high",
        isRead: false
      },
      {
        timestamp: new Date(),
        insight: "67% of users abandon the pricing page after spending less than 20 seconds. Consider simplifying pricing options or adding FAQs.",
        category: "warning",
        confidence: "medium",
        isRead: false
      },
      {
        timestamp: new Date(),
        insight: "Users who view your 'Beginner's Guide' often search for implementation examples afterwards. Consider adding a related tutorials section.",
        category: "suggestion",
        confidence: "high",
        isRead: false
      }
    ];
    
    sampleInsights.forEach(insight => {
      this.createInsight(insight);
    });
    
    // Sample recommendations
    const sampleRecommendations: InsertRecommendation[] = [
      {
        timestamp: new Date(),
        title: "Optimize mobile page load time",
        description: "Mobile page load time is above industry average by 1.4s. Consider optimizing images and implementing lazy loading.",
        category: "performance",
        implemented: false
      },
      {
        timestamp: new Date(),
        title: "Launch a personalized email campaign",
        description: "40% of your users who viewed product pages but didn't convert could be re-engaged with personalized product recommendations.",
        category: "marketing",
        implemented: false
      },
      {
        timestamp: new Date(),
        title: "A/B test your checkout form",
        description: "We've detected a 35% drop-off rate at the payment information step. We recommend testing a simplified form design.",
        category: "testing",
        implemented: false
      }
    ];
    
    sampleRecommendations.forEach(rec => {
      this.createRecommendation(rec);
    });
    
    // Sample A/B tests
    const now = new Date();
    const fiveDaysLater = new Date(now);
    fiveDaysLater.setDate(fiveDaysLater.getDate() + 5);
    
    const twelveDaysLater = new Date(now);
    twelveDaysLater.setDate(twelveDaysLater.getDate() + 12);
    
    const sampleTests: InsertAbTest[] = [
      {
        name: "Homepage Hero Messaging",
        description: "Testing different hero message variants on the homepage",
        variantA: "Boost your website performance",
        variantB: "See how AI can transform your website",
        startDate: new Date(),
        endDate: fiveDaysLater,
        status: "active",
        variantAConversion: "3.2",
        variantBConversion: "4.7",
        confidence: "95"
      },
      {
        name: "Pricing Page Layout",
        description: "Testing different pricing page layouts",
        variantA: "Horizontal pricing table",
        variantB: "Card-based pricing display",
        startDate: new Date(),
        endDate: twelveDaysLater,
        status: "active",
        variantAConversion: "2.1",
        variantBConversion: "2.3",
        confidence: "76"
      }
    ];
    
    // Always add working sample tests for immediate functionality
    sampleTests.forEach(test => {
      this.createAbTest(test);
    });
    
    // Sample external websites with their analytics providers
    const sampleExternalWebsites: InsertExternalWebsiteCatalog[] = [
      {
        name: 'Amazon',
        domain: 'amazon.com',
        description: 'Global e-commerce and cloud computing company',
        category: 'ecommerce',
        logo: 'https://logo.clearbit.com/amazon.com',
        apiEndpoints: null
      },
      {
        name: 'Flipkart',
        domain: 'flipkart.com',
        description: 'Indian e-commerce company',
        category: 'ecommerce',
        logo: 'https://logo.clearbit.com/flipkart.com',
        apiEndpoints: null
      },
      {
        name: 'YouTube',
        domain: 'youtube.com',
        description: 'Video sharing and streaming platform',
        category: 'media',
        logo: 'https://logo.clearbit.com/youtube.com',
        apiEndpoints: null
      },
      {
        name: 'Netflix',
        domain: 'netflix.com',
        description: 'Streaming entertainment service',
        category: 'entertainment',
        logo: 'https://logo.clearbit.com/netflix.com',
        apiEndpoints: null
      },
      {
        name: 'Myntra',
        domain: 'myntra.com',
        description: 'Fashion e-commerce platform',
        category: 'ecommerce',
        logo: 'https://logo.clearbit.com/myntra.com',
        apiEndpoints: null
      },
      {
        name: 'Instagram',
        domain: 'instagram.com',
        description: 'Photo and video sharing social networking service',
        category: 'social',
        logo: 'https://logo.clearbit.com/instagram.com',
        apiEndpoints: null
      },
      {
        name: 'Twitter',
        domain: 'twitter.com',
        description: 'Social networking service for microblogging',
        category: 'social',
        logo: 'https://logo.clearbit.com/twitter.com',
        apiEndpoints: null
      },
      {
        name: 'Walmart',
        domain: 'walmart.com',
        description: 'Multinational retail corporation',
        category: 'ecommerce',
        logo: 'https://logo.clearbit.com/walmart.com',
        apiEndpoints: null
      },
      {
        name: 'Shopify',
        domain: 'shopify.com',
        description: 'E-commerce platform for online stores',
        category: 'saas',
        logo: 'https://logo.clearbit.com/shopify.com',
        apiEndpoints: null
      },
      {
        name: 'Airbnb',
        domain: 'airbnb.com',
        description: 'Online marketplace for lodging and tourism activities',
        category: 'travel',
        logo: 'https://logo.clearbit.com/airbnb.com',
        apiEndpoints: null
      }
    ];
    
    // Create external websites
    const createdExternalWebsites = [];
    for (const websiteData of sampleExternalWebsites) {
      const website = await this.createExternalWebsite(websiteData);
      createdExternalWebsites.push(website);
    }
    
    // Sample analytics providers used by these websites
    const analyticsProviders = [
      { name: 'google', displayName: 'Google Analytics' },
      { name: 'adobe', displayName: 'Adobe Analytics' },
      { name: 'mixpanel', displayName: 'Mixpanel' },
      { name: 'matomo', displayName: 'Matomo' },
      { name: 'hotjar', displayName: 'Hotjar' },
      { name: 'crazyegg', displayName: 'Crazy Egg' },
      { name: 'clicky', displayName: 'Clicky' },
      { name: 'piwik', displayName: 'Piwik PRO' },
      { name: 'woopra', displayName: 'Woopra' },
      { name: 'kissmetrics', displayName: 'Kissmetrics' }
    ];
    
    // Associate analytics providers with websites
    const analyticsAssociations = [
      { websiteIndex: 0, providerIndices: [0, 1, 3, 4, 5] },  // Amazon: Google, Adobe, Matomo, Hotjar, Crazy Egg
      { websiteIndex: 1, providerIndices: [0, 2, 6, 9] },     // Flipkart: Google, Mixpanel, Clicky, Kissmetrics
      { websiteIndex: 2, providerIndices: [0, 1, 7, 8] },     // YouTube: Google, Adobe, Piwik PRO, Woopra
      { websiteIndex: 3, providerIndices: [0, 1, 4, 9] },     // Netflix: Google, Adobe, Hotjar, Kissmetrics
      { websiteIndex: 4, providerIndices: [0, 2, 3, 5] },     // Myntra: Google, Mixpanel, Matomo, Crazy Egg
      { websiteIndex: 5, providerIndices: [0, 2, 6, 8] },     // Instagram: Google, Mixpanel, Clicky, Woopra
      { websiteIndex: 6, providerIndices: [0, 1, 4, 7] },     // Twitter: Google, Adobe, Hotjar, Piwik PRO
      { websiteIndex: 7, providerIndices: [0, 3, 5, 9] },     // Walmart: Google, Matomo, Crazy Egg, Kissmetrics
      { websiteIndex: 8, providerIndices: [0, 2, 8, 9] },     // Shopify: Google, Mixpanel, Woopra, Kissmetrics
      { websiteIndex: 9, providerIndices: [0, 1, 3, 6] }      // Airbnb: Google, Adobe, Matomo, Clicky
    ];
    
    // Create analytics associations
    for (const association of analyticsAssociations) {
      const website = createdExternalWebsites[association.websiteIndex];
      for (const providerIndex of association.providerIndices) {
        const provider = analyticsProviders[providerIndex];
        await this.createExternalWebsiteAnalytics({
          externalWebsiteId: website.id,
          analyticsProvider: provider.name,
          detectionMethod: 'automatic',
          verifiedStatus: 'verified',
          additionalInfo: { displayName: provider.displayName }
        });
      }
    }
    
    // Create sample achievements
    const sampleAchievements: InsertAchievement[] = [
      {
        name: "Analytics Explorer",
        description: "Connect your first analytics provider",
        type: "engagement",
        criteria: { action: "connect_provider", count: 1 },
        points: 10,
        badgeIcon: "🔍",
        level: 1
      },
      {
        name: "Data Detective",
        description: "View 10 different analytics reports",
        type: "engagement",
        criteria: { action: "view_report", count: 10 },
        points: 20,
        badgeIcon: "🕵️",
        level: 1
      },
      {
        name: "Insight Master",
        description: "Read 5 AI-generated insights",
        type: "engagement",
        criteria: { action: "read_insight", count: 5 },
        points: 30,
        badgeIcon: "💡",
        level: 2
      },
      {
        name: "Testing Pioneer",
        description: "Create your first A/B test",
        type: "feature_usage",
        criteria: { action: "create_ab_test", count: 1 },
        points: 50,
        badgeIcon: "🧪",
        level: 2
      },
      {
        name: "Analytics Guru",
        description: "Connect 3 different analytics providers",
        type: "engagement",
        criteria: { action: "connect_provider", count: 3 },
        points: 75,
        badgeIcon: "🏆",
        level: 3
      },
      {
        name: "Optimization Expert",
        description: "Implement 5 recommendations",
        type: "feature_usage",
        criteria: { action: "implement_recommendation", count: 5 },
        points: 100,
        badgeIcon: "⚡",
        level: 3
      },
      {
        name: "Integration Wizard",
        description: "Connect all available analytics providers",
        type: "engagement",
        criteria: { action: "connect_all_providers", count: 1 },
        points: 200,
        badgeIcon: "🧙",
        level: 4
      },
      {
        name: "Data Scientist",
        description: "Create and complete 10 A/B tests",
        type: "feature_usage",
        criteria: { action: "complete_ab_test", count: 10 },
        points: 250,
        badgeIcon: "🔬",
        level: 4
      },
      {
        name: "Analytics Champion",
        description: "Earn 1000 total points in the analytics platform",
        type: "milestone",
        criteria: { action: "earn_points", count: 1000 },
        points: 500,
        badgeIcon: "👑",
        level: 5
      }
    ];
    
    // Create the achievements
    for (const achievement of sampleAchievements) {
      await this.createAchievement(achievement);
    }
    
    // Create some sample user achievements (assuming user ID 1 exists)
    if (this.users.has(1)) {
      // User has already completed some achievements
      await this.createUserAchievement({
        userId: 1,
        achievementId: 1, // Analytics Explorer
        progress: 100,
        completed: true,
        completedAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) // 7 days ago
      });
      
      await this.createUserAchievement({
        userId: 1,
        achievementId: 2, // Data Detective
        progress: 100,
        completed: true,
        completedAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000) // 3 days ago
      });
      
      // User is making progress on some achievements
      await this.createUserAchievement({
        userId: 1,
        achievementId: 3, // Insight Master
        progress: 60, // 3 out of 5 insights read
        completed: false
      });
      
      await this.createUserAchievement({
        userId: 1,
        achievementId: 5, // Analytics Guru
        progress: 33, // 1 out of 3 providers connected
        completed: false
      });
    }
  }
}

// Import DatabaseStorage
import { DatabaseStorage } from './database-storage';

// Create storage with automatic fallback from database to memory
let dbStorage: DatabaseStorage | null = null;
let memStorage: MemStorage | null = null;

try {
  // Try to initialize database storage
  dbStorage = new DatabaseStorage();
} catch (error) {
  console.error("Error initializing database storage:", error);
  dbStorage = null;
}

// Export the appropriate storage instance with fallback mechanism
export const storage: IStorage = new Proxy({} as IStorage, {
  get(target, prop: string) {
    return async (...args: any[]) => {
      try {
        // Try to use database if available
        if (dbStorage) {
          return await dbStorage[prop](...args);
        } else {
          throw new Error("Database storage not available");
        }
      } catch (error) {
        console.log(`Database error in ${prop}, using memory storage fallback`);
        
        // Special handling for A/B tests with GrowthBook integration
        if (prop === 'getAbTests') {
          const hasGrowthBookAccess = !!process.env.GROWTHBOOK_API_KEY && !!process.env.GROWTHBOOK_API_HOST;
          
          if (hasGrowthBookAccess) {
            try {
              const { growthBookService } = await import('./services/growthbook-service');
              const experiments = await growthBookService.getExperiments();
              return experiments.map(exp => growthBookService.transformToAbTest(exp));
            } catch (gbError) {
              console.error('GrowthBook error:', gbError);
              throw new Error('A/B Testing API Access Required');
            }
          } else {
            throw new Error('A/B Testing API Access Required');
          }
        }
        
        // Initialize memory storage if needed
        if (!memStorage) {
          console.log("Initializing memory storage");
          memStorage = new MemStorage();
          // Initialize sample data in memory storage
          await memStorage.initializeSampleData();
        }
        
        // Use memory storage as fallback
        return await memStorage[prop](...args);
      }
    };
  }
});
