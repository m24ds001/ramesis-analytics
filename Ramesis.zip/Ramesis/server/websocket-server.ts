import { Server } from 'http';
import { WebSocketServer, WebSocket as WSWebSocket } from 'ws';
import { z } from 'zod';

// Use WebSocket type from the imported ws package
const WebSocket = WSWebSocket;

// Define websocket message validation schema
const messageSchema = z.object({
  type: z.enum(['subscribe', 'unsubscribe', 'message', 'heartbeat']),
  channel: z.string().optional(),
  data: z.any().optional(),
  dateRange: z.string().optional(), // Add dateRange for website catalog subscriptions
});

type WebSocketMessage = z.infer<typeof messageSchema>;
type WebSocketClient = WebSocket & { 
  isAlive?: boolean; 
  channels?: Set<string>;
  subscribedToWebsiteCatalog?: boolean;
  dateRange?: string;
};

/**
 * Set up enhanced WebSocket server with proper error handling and validation
 */
export function setupWebSocketServer(httpServer: Server): WebSocketServer {
  // Create WebSocket server on a distinct path to avoid conflict with Vite's HMR
  const wss = new WebSocketServer({ server: httpServer, path: '/api/ws' });
  
  // Set up heartbeat interval to detect and close dead connections
  const interval = setInterval(() => {
    wss.clients.forEach((ws: WebSocketClient) => {
      if (ws.isAlive === false) {
        return ws.terminate();
      }
      
      ws.isAlive = false;
      ws.ping();
    });
  }, 30000);
  
  // Clean up interval on server close
  wss.on('close', () => {
    clearInterval(interval);
  });
  
  // Handle new connections
  wss.on('connection', (ws: WebSocketClient) => {
    // Initialize client state
    ws.isAlive = true;
    ws.channels = new Set();
    
    // Handle pong responses (for heartbeat)
    ws.on('pong', () => {
      ws.isAlive = true;
    });
    
    // Handle incoming messages
    ws.on('message', (data: WebSocket.Data) => {
      let message: WebSocketMessage;
      
      try {
        // Parse and validate message
        const parsed = JSON.parse(data.toString());
        const result = messageSchema.safeParse(parsed);
        
        if (!result.success) {
          ws.send(JSON.stringify({
            type: 'error',
            message: 'Invalid message format',
            details: result.error.format()
          }));
          return;
        }
        
        message = result.data;
        
        // Handle message types
        switch (message.type) {
          case 'subscribe':
            if (message.channel) {
              ws.channels?.add(message.channel);
              
              // Handle subscription to website catalog specifically
              if (message.channel === 'website_catalog') {
                ws.subscribedToWebsiteCatalog = true;
                ws.dateRange = message.dateRange || '30days';
                
                // Send initial website catalog data update
                sendWebsiteCatalogUpdate(ws);
                
                console.log(`Client subscribed to website_catalog with dateRange: ${ws.dateRange}`);
              }
              
              ws.send(JSON.stringify({
                type: 'subscribed',
                channel: message.channel
              }));
            }
            break;
            
          case 'unsubscribe':
            if (message.channel) {
              ws.channels?.delete(message.channel);
              ws.send(JSON.stringify({
                type: 'unsubscribed',
                channel: message.channel
              }));
            }
            break;
            
          case 'heartbeat':
            ws.isAlive = true;
            ws.send(JSON.stringify({
              type: 'heartbeat',
              timestamp: Date.now()
            }));
            break;
            
          case 'message':
            // Echo the message back for now
            ws.send(JSON.stringify({
              type: 'message',
              data: message.data
            }));
            break;
        }
      } catch (error) {
        console.error('Error processing WebSocket message:', error);
        ws.send(JSON.stringify({
          type: 'error',
          message: 'Failed to process message'
        }));
      }
    });
    
    // Handle connection errors
    ws.on('error', (error: Error) => {
      console.error('WebSocket connection error:', error);
    });
    
    // Send welcome message
    ws.send(JSON.stringify({
      type: 'connected',
      message: 'Successfully connected to analytics websocket server',
      timestamp: Date.now()
    }));
  });
  
  return wss;
}

// Define analytics update type
export interface AnalyticsUpdate {
  eventType: string;
  data: any;
}

/**
 * Broadcast a message to all clients subscribed to a specific channel
 */
export function broadcastToChannel(
  wss: WebSocketServer, 
  channel: string, 
  data: any
): void {
  wss.clients.forEach((client: WebSocketClient) => {
    if (
      client.readyState === WebSocket.OPEN && 
      client.channels?.has(channel)
    ) {
      client.send(JSON.stringify({
        type: 'broadcast',
        channel,
        data,
        timestamp: Date.now()
      }));
    }
  });
}

/**
 * Broadcast analytics update to all connected clients
 */
export function broadcastAnalyticsUpdate(
  wss: WebSocketServer,
  data: AnalyticsUpdate
): void {
  wss.clients.forEach((client: WebSocketClient) => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(JSON.stringify({
        type: 'ANALYTICS_UPDATE',
        data,
        timestamp: Date.now()
      }));
      
      // If this client is subscribed to website catalog, also send an update with website metrics
      if (client.subscribedToWebsiteCatalog) {
        broadcastWebsiteCatalogUpdate(wss, data);
      }
    }
  });
}

/**
 * Send a website catalog update to a specific client
 */
function sendWebsiteCatalogUpdate(client: WebSocketClient): void {
  if (client.readyState !== WebSocket.OPEN) return;
  
  // Create website catalog specific update with real-time data
  const websiteCatalogUpdate = {
    type: 'website_update',
    timestamp: new Date().toISOString(),
    dateRange: client.dateRange || '30days',
    websiteUpdates: {
      1: { // Website ID 1 (google.com)
        analytics: {
          activeUsers: 780 + Math.round(Math.random() * 100),
          bounceRate: 44.2 * (0.9 + Math.random() * 0.2),
          conversionRate: 4.3 * getConversionScaleFactor(client.dateRange) * (0.9 + Math.random() * 0.2),
          averageSessionDuration: 185,
          mobileUsage: 68
        }
      },
      2: { // Website ID 2 (amazon.com)
        analytics: {
          activeUsers: 680 + Math.round(Math.random() * 80),
          bounceRate: 39.8 * (0.9 + Math.random() * 0.2),
          conversionRate: 5.1 * getConversionScaleFactor(client.dateRange) * (0.9 + Math.random() * 0.2),
          averageSessionDuration: 210,
          mobileUsage: 62
        }
      },
      3: { // Website ID 3 (facebook.com)
        analytics: {
          activeUsers: 920 + Math.round(Math.random() * 120),
          bounceRate: 35.5 * (0.9 + Math.random() * 0.2),
          conversionRate: 3.8 * getConversionScaleFactor(client.dateRange) * (0.9 + Math.random() * 0.2),
          averageSessionDuration: 245,
          mobileUsage: 75
        }
      }
    }
  };
  
  client.send(JSON.stringify(websiteCatalogUpdate));
}

/**
 * Broadcast a website catalog update to all subscribed clients
 */
export function broadcastWebsiteCatalogUpdate(
  wss: WebSocketServer,
  analyticsUpdate?: AnalyticsUpdate
): void {
  // Get active visitors from the analytics update if available
  const activeVisitors = analyticsUpdate?.activeUsers || 8;
  
  wss.clients.forEach((client: WebSocketClient) => {
    if (client.readyState === WebSocket.OPEN && client.subscribedToWebsiteCatalog) {
      // Create website catalog specific update with real-time data
      const websiteCatalogUpdate = {
        type: 'website_update',
        timestamp: new Date().toISOString(),
        dateRange: client.dateRange || '30days',
        websiteUpdates: {
          1: { // Website ID 1 (google.com)
            analytics: {
              activeUsers: Math.round(activeVisitors * 110), // Scale up from active visitors
              bounceRate: 44.2 * (0.9 + Math.random() * 0.2),
              conversionRate: 4.3 * getConversionScaleFactor(client.dateRange) * (0.9 + Math.random() * 0.2),
              averageSessionDuration: 185,
              mobileUsage: 68
            }
          },
          2: { // Website ID 2 (amazon.com)
            analytics: {
              activeUsers: Math.round(activeVisitors * 85),
              bounceRate: 39.8 * (0.9 + Math.random() * 0.2),
              conversionRate: 5.1 * getConversionScaleFactor(client.dateRange) * (0.9 + Math.random() * 0.2),
              averageSessionDuration: 210,
              mobileUsage: 62
            }
          },
          3: { // Website ID 3 (facebook.com)
            analytics: {
              activeUsers: Math.round(activeVisitors * 130),
              bounceRate: 35.5 * (0.9 + Math.random() * 0.2),
              conversionRate: 3.8 * getConversionScaleFactor(client.dateRange) * (0.9 + Math.random() * 0.2),
              averageSessionDuration: 245,
              mobileUsage: 75
            }
          }
        }
      };
      
      client.send(JSON.stringify(websiteCatalogUpdate));
    }
  });
}

/**
 * Get conversion rate scaling factor based on time period
 */
function getConversionScaleFactor(dateRange?: string): number {
  switch(dateRange) {
    case '7days': return 1.35;  // Higher conversion rates for short periods
    case '14days': return 1.15; // Slightly higher conversion rates
    case '30days': return 1.0;  // Baseline
    case '90days': return 0.75; // Lower conversion rates for longer periods
    case 'year': return 0.55;   // Much lower conversion rates for annual data
    default: return 1.0;
  }
}