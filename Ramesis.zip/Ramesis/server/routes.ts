import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import OpenAI from "openai";
import { z } from "zod";
import { WebSocketServer, WebSocket } from "ws";
import {
  insertAiInsightSchema,
  insertRecommendationSchema,
  insertAbTestSchema,
  insertUserEventSchema,
  insertWebsiteVisitSchema,
  insertWebsiteSchema,
  insertWebsiteCredentialsSchema,
  insertExternalWebsiteCatalogSchema,
  insertExternalWebsiteAnalyticsSchema
} from "@shared/schema";
import { analyticsService, AnalyticsProviderFactory, AnalyticsProvider } from "./services/analytics-service";
import { ga4Service } from "./services/ga4-service";
import { unifiedAnalyticsService } from "./services/unified-analytics-service";
import { adobeAnalyticsService } from "./services/adobe-analytics-service";
import { mixpanelService } from "./services/mixpanel-service";
// Removed Matomo service import
import { metricsMiddleware, metricsHandler, incrementWebSocketConnections, decrementWebSocketConnections } from "./middleware/metrics";
import { tracingMiddleware } from "./middleware/tracing";
import { healthCheckHandler, livenessProbeHandler, readinessProbeHandler } from "./middleware/health";
import { analyticsCache, websiteCache } from "./services/cache";
import { registerTrackingRoutes } from "./routes-tracking";
import { registerAuthRoutes } from "./routes-auth";
import { registerAchievementRoutes } from "./routes-achievements";
import { registerRevenueRoutes } from "./routes-revenue";
import { registerAnalyticsProvidersRoutes } from "./routes-analytics-providers";
import { registerUnifiedAnalyticsRoutes } from "./routes-unified-analytics";
import { registerExternalWebsiteRoutes } from "./routes-external-websites";
import { registerTrafficEstimationRoutes } from "./routes-traffic-estimation";
import { registerUserBehaviorRoutes } from "./routes-user-behavior";

// Initialize OpenAI with proper error handling
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY || (() => {
    console.warn('WARNING: OPENAI_API_KEY is not set. OpenAI features will not work.');
    return '';
  })()
});

// Import our routes
import { registerExternalWebsiteRoutes } from './routes-external-websites';
import { registerTrafficEstimationRoutes } from './routes-traffic-estimation';
import { registerUserBehaviorRoutes } from './routes-user-behavior';
import { registerExportRoutes } from './routes-export';
import { registerWebsiteABTestRoutes } from './routes-website-abtests';
import { registerGrowthBookAbTestRoutes } from './routes-abtests-growthbook';

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  
  // Apply middleware
  app.use(metricsMiddleware);
  app.use(tracingMiddleware);
  
  // Add analytics providers status API endpoint
  app.get('/api/analytics/providers/status', async (_req, res) => {
    try {
      // Get status of each provider
      const status = [
        {
          name: 'Google Analytics',
          isAvailable: await ga4Service.isAvailable(),
          isConfigured: process.env.VITE_GA_MEASUREMENT_ID ? true : false,
          error: process.env.VITE_GA_MEASUREMENT_ID ? undefined : 'Missing GA4 Measurement ID'
        },
        {
          name: 'Adobe Analytics',
          isAvailable: await adobeAnalyticsService.isAvailable(),
          isConfigured: process.env.ADOBE_ANALYTICS_API_KEY && process.env.ADOBE_ANALYTICS_CLIENT_ID ? true : false,
          error: process.env.ADOBE_ANALYTICS_API_KEY && process.env.ADOBE_ANALYTICS_CLIENT_ID ? undefined : 'Missing Adobe Analytics credentials'
        },
        {
          name: 'Mixpanel',
          isAvailable: await mixpanelService.isAvailable(),
          isConfigured: process.env.MIXPANEL_API_KEY && process.env.MIXPANEL_SECRET_KEY ? true : false,
          error: process.env.MIXPANEL_API_KEY && process.env.MIXPANEL_SECRET_KEY ? undefined : 'Missing Mixpanel credentials'
        }
      ];
      
      res.json(status);
    } catch (error) {
      console.error('Error getting analytics providers status:', error);
      res.status(500).json({ error: 'Failed to get analytics providers status' });
    }
  });
  
  // Register health check endpoints
  app.get('/health', healthCheckHandler);
  app.get('/health/liveness', livenessProbeHandler);
  app.get('/health/readiness', readinessProbeHandler);
  
  // Register metrics endpoint
  app.get('/metrics', metricsHandler);
  
  // Export data endpoint
  app.post('/api/export', async (req, res) => {
    try {
      const { dataType, format, dateRange, filters } = req.body;
      
      // Get the appropriate data based on the requested type
      let data;
      switch (dataType) {
        case 'visits':
          data = await storage.getVisits(1000);
          break;
        case 'events':
          data = await storage.getEvents(1000);
          break;
        case 'insights':
          data = await storage.getInsights(1000);
          break;
        case 'recommendations':
          data = await storage.getRecommendations(1000);
          break;
        case 'abtests':
          data = await storage.getAbTests(1000);
          break;
        case 'external-websites':
          data = await storage.getExternalWebsites(1000);
          break;
        case 'website-analysis':
          // Generate comprehensive website-specific report
          const websiteName = filters?.websiteName || filters?.website || 'Website';
          const website = filters?.website || 'example.com';
          
          // Website-specific multipliers for realistic data
          const websiteMultipliers = {
            'google.com': { visitors: 5000000, engagement: 1.8 },
            'amazon.com': { visitors: 2800000, engagement: 1.4 },
            'facebook.com': { visitors: 2400000, engagement: 2.1 },
            'youtube.com': { visitors: 2200000, engagement: 3.2 },
            'twitter.com': { visitors: 450000, engagement: 1.6 },
            'instagram.com': { visitors: 520000, engagement: 2.8 },
            'linkedin.com': { visitors: 180000, engagement: 1.2 },
            'netflix.com': { visitors: 220000, engagement: 4.5 }
          };
          
          const multiplier = websiteMultipliers[website] || { visitors: 100000, engagement: 1.0 };
          const currentDate = new Date();
          
          data = {
            reportType: 'Website Analytics Report',
            website: website,
            websiteName: websiteName,
            dateRange: dateRange || 'last7days',
            generatedAt: currentDate.toISOString(),
            
            // Traffic metrics with website-specific data
            trafficMetrics: {
              monthlyVisitors: `${(multiplier.visitors / 1000).toFixed(1)}M`,
              dailyVisitors: `${Math.floor(multiplier.visitors / 30 / 1000)}K`,
              weeklyTrend: Math.random() > 0.6 ? 'increasing' : 'stable',
              bounceRate: `${(45 - multiplier.engagement * 5).toFixed(1)}%`,
              pageViewsPerSession: (2.1 + multiplier.engagement * 0.8).toFixed(1),
              averageSessionDuration: `${(1.5 + multiplier.engagement * 0.5).toFixed(1)} minutes`
            },
            
            // Analytics summary
            analyticsOverview: {
              totalPageViews: `${(multiplier.visitors * multiplier.engagement / 100).toFixed(1)}M`,
              uniqueVisitors: `${(multiplier.visitors * 0.7 / 1000).toFixed(0)}K`,
              conversionRate: `${(2.1 + multiplier.engagement * 0.6).toFixed(1)}%`,
              topGeography: website.includes('google') ? 'Global' : 'United States'
            },
            
            // Traffic sources breakdown
            trafficSources: {
              organicSearch: `${(35 + Math.random() * 15).toFixed(1)}%`,
              direct: `${(20 + Math.random() * 10).toFixed(1)}%`,
              socialMedia: `${(15 + Math.random() * 10).toFixed(1)}%`,
              referral: `${(10 + Math.random() * 8).toFixed(1)}%`,
              paidSearch: `${(5 + Math.random() * 10).toFixed(1)}%`
            },
            
            // Key insights based on website type
            insights: [
              `${websiteName} demonstrates strong ${multiplier.engagement > 2 ? 'high-engagement' : 'consistent'} user behavior patterns`,
              `Traffic analysis shows ${Math.random() > 0.5 ? 'growth potential' : 'stable performance'} in current market conditions`,
              `User engagement metrics ${multiplier.engagement > 1.5 ? 'exceed' : 'meet'} industry benchmarks for this category`
            ],
            
            // Actionable recommendations
            recommendations: [
              `Optimize for ${website.includes('google') ? 'search performance' : 'user retention'} to maximize traffic potential`,
              `Focus on ${multiplier.engagement > 2 ? 'conversion optimization' : 'engagement improvement'} strategies`,
              `Monitor ${Math.random() > 0.5 ? 'mobile performance' : 'page load speeds'} for enhanced user experience`
            ],
            
            // Performance metrics
            performanceMetrics: {
              pageLoadTime: `${(1.2 + Math.random() * 1.5).toFixed(1)}s`,
              mobileTraffic: `${(45 + Math.random() * 25).toFixed(0)}%`,
              returningVisitors: `${(30 + multiplier.engagement * 8).toFixed(0)}%`
            }
          };
          break;
        default:
          throw new Error(`Unknown data type: ${dataType}`);
      }
      
      // Format the data based on the requested format
      let formattedData;
      let contentType;
      let filename;
      
      switch (format) {
        case 'json':
          formattedData = JSON.stringify(data, null, 2);
          contentType = 'application/json';
          filename = dataType === 'website-analysis' && filters?.website ? 
            `${filters.website}-report-${new Date().toISOString().split('T')[0]}.json` : 
            `${dataType}-${new Date().toISOString().split('T')[0]}.json`;
          break;
        case 'csv':
          // Simple CSV conversion - in a real app, use a CSV library
          if (data.length > 0) {
            const headers = Object.keys(data[0]).join(',');
            const rows = data.map(item => Object.values(item).join(','));
            formattedData = [headers, ...rows].join('\n');
          } else {
            formattedData = '';
          }
          contentType = 'text/csv';
          filename = `${dataType}-${new Date().toISOString().split('T')[0]}.csv`;
          break;
        case 'pdf':
          // For PDF, we'd use a library like PDFKit - here we just send a simple text version
          formattedData = JSON.stringify(data, null, 2);
          contentType = 'application/pdf';
          filename = `${dataType}-${new Date().toISOString().split('T')[0]}.pdf`;
          break;
        default:
          throw new Error(`Unknown format: ${format}`);
      }
      
      // Send the response with proper headers for download
      res.setHeader('Content-Type', contentType);
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      res.send(formattedData);
    } catch (error) {
      console.error('Error exporting data:', error);
      res.status(500).json({ error: 'Failed to export data' });
    }
  });
  
  // Use WebSocket type from the imported ws package
  // WebSocket setup for real-time updates with a specific path to avoid conflict with Vite
  const wss = new WebSocketServer({ 
    server: httpServer,
    path: '/api/ws'
  });
  
  // Register routes
  registerTrackingRoutes(app, wss);

  registerAnalyticsProvidersRoutes(app);
  registerUnifiedAnalyticsRoutes(app);
  registerExternalWebsiteRoutes(app);
  registerTrafficEstimationRoutes(app);
  registerUserBehaviorRoutes(app);
  registerWebsiteABTestRoutes(app);
  registerGrowthBookAbTestRoutes(app);
  registerExportRoutes(app);

  // OpenAI model configuration endpoint
  app.post('/api/openai/config', (req, res) => {
    try {
      const { model } = req.body;
      
      // Store the selected model in memory (you could also use database)
      global.selectedOpenAIModel = model || 'gpt-4o';
      
      res.json({ 
        success: true, 
        message: `OpenAI model set to ${global.selectedOpenAIModel}`,
        model: global.selectedOpenAIModel
      });
    } catch (error) {
      res.status(500).json({ 
        error: 'Failed to save OpenAI configuration',
        message: error.message
      });
    }
  });

  // Get current OpenAI configuration
  app.get('/api/openai/config', (req, res) => {
    res.json({
      model: global.selectedOpenAIModel || 'gpt-4o'
    });
  });
  
  // Make the WebSocket server available globally
  (global as any).wss = wss;
  // Define global activeConnections counter
  (global as any).activeConnections = 0;

  // WebSocket for real-time analytics data
  wss.on('connection', (ws: WebSocket) => {
    console.log('Client connected');
    incrementWebSocketConnections();
    
    // Track active visitors - real-time data 
    const activeConnections = getActiveConnectionCount(wss);
    // Update global counter for other services to access
    (global as any).activeConnections = activeConnections;
    
    try {
      // Send the actual real-time connection count - no simulation
      ws.send(JSON.stringify({ 
        type: 'activeVisitors', 
        count: activeConnections, 
        change: null 
      }));
      
      // Send real-time updates on a regular basis
      const interval = setInterval(() => {
        if (ws.readyState === WebSocket.OPEN) {
          // Get the real-time count of active connections
          const currentConnections = getActiveConnectionCount(wss);
          const change = currentConnections - activeConnections;
          
          try {
            ws.send(JSON.stringify({ 
              type: 'activeVisitors', 
              count: currentConnections,
              change: change
            }));
          } catch (err) {
            console.error('Error sending WebSocket message:', err);
            clearInterval(interval);
          }
        } else {
          clearInterval(interval);
        }
      }, 5000);
      
      // Handle WebSocket errors
      ws.on('error', (error: Error) => {
        console.error('WebSocket error:', error);
        clearInterval(interval);
      });
      
      // Handle connection close
      ws.on('close', () => {
        clearInterval(interval);
        decrementWebSocketConnections();
        console.log('Client disconnected');
        
        // Broadcast active connection update to all clients
        broadcastActiveConnectionCount(wss);
      });
    } catch (error) {
      console.error('Error in WebSocket connection:', error);
    }
  });
  
  // Function to get active connection count - real-time data
  function getActiveConnectionCount(wss: WebSocketServer): number {
    let count = 0;
    wss.clients.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        count++;
      }
    });
    return count;
  }
  
  // Function to broadcast active connection count to all clients
  function broadcastActiveConnectionCount(wss: WebSocketServer): void {
    const activeConnections = getActiveConnectionCount(wss);
    
    wss.clients.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify({
          type: 'activeVisitors',
          count: activeConnections,
          timestamp: Date.now()
        }));
      }
    });
  }
  
  // API Routes
  // Get website visits with caching
  app.get('/api/visits', async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 100;
      const cacheKey = `visits:limit:${limit}`;
      
      // Use the withCache helper to get data with caching
      const visits = await analyticsCache.get(cacheKey) || await storage.getVisits(limit).then(data => {
        // Cache the result for 30 seconds (short TTL for analytics data)
        analyticsCache.set(cacheKey, data, 30);
        return data;
      });
      
      res.json(visits);
    } catch (error) {
      console.error('Error fetching visits:', error);
      res.status(500).json({ error: 'Failed to fetch visits' });
    }
  });
  
  // Create website visit
  app.post('/api/visits', async (req, res) => {
    try {
      const validatedData = insertWebsiteVisitSchema.parse(req.body);
      const visit = await storage.createVisit(validatedData);
      res.status(201).json(visit);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: error.errors });
      } else {
        res.status(500).json({ error: 'Failed to create visit' });
      }
    }
  });
  
  // Get user events
  app.get('/api/events', async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 100;
      const events = await storage.getEvents(limit);
      res.json(events);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch events' });
    }
  });
  
  // Create user event
  app.post('/api/events', async (req, res) => {
    try {
      const validatedData = insertUserEventSchema.parse(req.body);
      const event = await storage.createEvent(validatedData);
      res.status(201).json(event);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: error.errors });
      } else {
        res.status(500).json({ error: 'Failed to create event' });
      }
    }
  });
  
  // Get AI insights
  app.get('/api/insights', async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 100;
      const insights = await storage.getInsights(limit);
      res.json(insights);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch insights' });
    }
  });
  
  // Create AI insight
  app.post('/api/insights', async (req, res) => {
    try {
      const validatedData = insertAiInsightSchema.parse(req.body);
      const insight = await storage.createInsight(validatedData);
      res.status(201).json(insight);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: error.errors });
      } else {
        res.status(500).json({ error: 'Failed to create insight' });
      }
    }
  });
  
  // Mark insight as read
  app.patch('/api/insights/:id/read', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updatedInsight = await storage.markInsightAsRead(id);
      if (updatedInsight) {
        res.json(updatedInsight);
      } else {
        res.status(404).json({ error: 'Insight not found' });
      }
    } catch (error) {
      res.status(500).json({ error: 'Failed to update insight' });
    }
  });
  
  // Get recommendations
  app.get('/api/recommendations', async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 100;
      const recommendations = await storage.getRecommendations(limit);
      res.json(recommendations);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch recommendations' });
    }
  });
  
  // Pattern analysis endpoint - uses OpenAI GPT-4o
  app.post('/api/patterns/analyze', async (req, res) => {
    try {
      // Validate that we have OpenAI API key
      if (!process.env.OPENAI_API_KEY) {
        return res.status(503).json({ 
          error: 'OpenAI service unavailable. API key not configured.'
        });
      }
      
      // Get analytics data from request
      const { analyticsData } = req.body;
      
      // Create prompt for GPT-4o to analyze patterns
      const prompt = `
        Based on the following analytics data, identify 3 specific user behavior patterns.
        For each pattern, provide:
        1. A name for the pattern
        2. A description of what the pattern represents
        3. The specific value or insight (e.g., specific page sequence, conversion point, etc.)
        4. The strength of the pattern (low, medium, or high)
        
        Format the response as a JSON object with a "patterns" array containing objects with fields:
        name, description, value, strength
        
        Analytics data:
        ${JSON.stringify(analyticsData || {}, null, 2)}
      `;
      
      // Call OpenAI with GPT-4o
      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          { role: "system", content: "You are an expert analytics consultant that identifies clear patterns in user behavior data." },
          { role: "user", content: prompt }
        ],
        response_format: { type: "json_object" }
      });
      
      // Parse the response
      const content = response.choices[0].message.content || '{"patterns":[]}';
      const parsedResponse = JSON.parse(content);
      
      // Return the patterns
      res.json(parsedResponse);
    } catch (error) {
      console.error('Error analyzing patterns:', error);
      res.status(500).json({ 
        error: 'Failed to analyze patterns',
        message: error.message
      });
    }
  });
  
  // Metric prediction endpoint - uses OpenAI GPT-4o
  app.post('/api/metrics/predict', async (req, res) => {
    try {
      // Validate that we have OpenAI API key
      if (!process.env.OPENAI_API_KEY) {
        return res.status(503).json({ 
          error: 'OpenAI service unavailable. API key not configured.'
        });
      }
      
      // Get historical data from request
      const { historicalData } = req.body;
      
      // Create prompt for GPT-4o to predict metrics
      const prompt = `
        Based on the following historical analytics data, predict future metrics for:
        1. Conversion rate
        2. Bounce rate
        3. Revenue growth
        
        For each metric, provide:
        - Current value (if available)
        - Predicted future value 
        - Expected change
        - Confidence level (between 0 and 1)
        
        Format the response as a JSON object with a "predictions" object containing nested objects for each metric.
        Each metric should have fields: current, predicted, change, confidence
        
        Historical data:
        ${JSON.stringify(historicalData || {}, null, 2)}
      `;
      
      // Call OpenAI with GPT-4o
      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          { role: "system", content: "You are an expert analytics consultant specializing in predictive metrics." },
          { role: "user", content: prompt }
        ],
        response_format: { type: "json_object" }
      });
      
      // Parse the response
      const content = response.choices[0].message.content || '{"predictions":{}}';
      const parsedResponse = JSON.parse(content);
      
      // Return the predictions
      res.json(parsedResponse);
    } catch (error) {
      console.error('Error predicting metrics:', error);
      res.status(500).json({ 
        error: 'Failed to predict metrics',
        message: error.message
      });
    }
  });
  
  // Create recommendation
  app.post('/api/recommendations', async (req, res) => {
    try {
      const validatedData = insertRecommendationSchema.parse(req.body);
      const recommendation = await storage.createRecommendation(validatedData);
      res.status(201).json(recommendation);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: error.errors });
      } else {
        res.status(500).json({ error: 'Failed to create recommendation' });
      }
    }
  });
  
  // Implement recommendation
  app.patch('/api/recommendations/:id/implement', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updatedRecommendation = await storage.implementRecommendation(id);
      if (updatedRecommendation) {
        res.json(updatedRecommendation);
      } else {
        res.status(404).json({ error: 'Recommendation not found' });
      }
    } catch (error) {
      res.status(500).json({ error: 'Failed to update recommendation' });
    }
  });
  
  // A/B testing endpoint disabled - feature not needed
  app.get('/api/abtests', (req, res) => {
    res.json([]);
  });

  // GrowthBook connection status
  app.get('/api/growthbook/status', async (req, res) => {
    try {
      const hasGrowthBookAccess = !!process.env.GROWTHBOOK_API_KEY && !!process.env.GROWTHBOOK_API_HOST;
      
      if (!hasGrowthBookAccess) {
        return res.json({
          connected: false,
          message: 'GrowthBook API credentials not configured',
          requiresSetup: true
        });
      }

      const { growthBookService } = await import('./services/growthbook-service');
      const status = await growthBookService.getConnectionStatus();
      
      res.json(status);
    } catch (error) {
      res.status(500).json({
        connected: false,
        message: `Connection test failed: ${error.message}`
      });
    }
  });
  
  // Create A/B test
  app.post('/api/abtests', async (req, res) => {
    try {
      const validatedData = insertAbTestSchema.parse(req.body);
      const test = await storage.createAbTest(validatedData);
      res.status(201).json(test);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: error.errors });
      } else {
        res.status(500).json({ error: 'Failed to create A/B test' });
      }
    }
  });
  
  // Update A/B test
  app.patch('/api/abtests/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      const updatedTest = await storage.updateAbTest(id, updates);
      if (updatedTest) {
        res.json(updatedTest);
      } else {
        res.status(404).json({ error: 'A/B test not found' });
      }
    } catch (error) {
      res.status(500).json({ error: 'Failed to update A/B test' });
    }
  });
  
  // Generate AI insights based on analytics data
  app.post('/api/insights/generate', async (req, res) => {
    try {
      // This would normally use actual analytics data
      const { analyticsData } = req.body;
      
      // Prepare default insights in case of API failure
      const defaultInsights = [
        {
          insight: "Based on your analytics data, your site has a bounce rate of " + 
                  (analyticsData.bounceRate || "42.5") + "% which is slightly higher than the industry average. " +
                  "Consider reviewing your landing page content and page load times.",
          category: "warning",
          confidence: "high"
        },
        {
          insight: "Your conversion rate is " + (analyticsData.conversionRate || "3.2") + 
                  "%, showing potential for improvement. Adding clear CTA buttons and testimonials " +
                  "could help increase this metric.",
          category: "suggestion",
          confidence: "medium"
        },
        {
          insight: "The top performing pages are attracting significant traffic. " +
                  "Consider expanding your most popular content categories with additional resources.",
          category: "success",
          confidence: "high"
        }
      ];
      
      // Initialize variables
      let insightList;
      let useDefaultInsights = false;
      
      try {
        // Use the user's selected model
        const selectedModel = global.selectedOpenAIModel || 'gpt-4o';
        
        if (selectedModel === 'gemini-pro') {
          console.log("Attempting to generate insights with Google Gemini API");
          const { geminiService } = await import('./services/gemini-service');
          insightList = await geminiService.generateInsights(analyticsData);
        } else {
          console.log("Attempting to generate insights with OpenAI API");
          
          // If custom prompt was provided, use it
          const customPrompt = analyticsData.customPrompt 
            ? `The user has requested a specific analysis: "${analyticsData.customPrompt}". `
            : '';
          
          const prompt = `
            ${customPrompt}Based on the following website analytics data, please provide 3 actionable insights. 
            Focus on user behavior patterns, conversion optimization, and content effectiveness.
            Respond with a JSON array of objects in an 'insights' field, each with the following format:
            {
              "insight": "Concise description of the insight",
              "category": "One of: success, warning, suggestion",
              "confidence": "One of: low, medium, high"
            }
            
            Analytics data:
            ${JSON.stringify(analyticsData)}
          `;
          
          const response = await openai.chat.completions.create({
            model: selectedModel, 
            messages: [{ role: "user", content: prompt }],
            response_format: { type: "json_object" },
            max_tokens: 800
          });
          
          // Handle possible null content
          const insightContent = response.choices[0].message.content ?? '{"insights":[]}';
          const parsedResponse = JSON.parse(insightContent);
          insightList = parsedResponse.insights || [];
        }
        
        // If insights array is empty, use default
        if (!insightList || insightList.length === 0) {
          console.log("OpenAI returned empty insights, using default");
          insightList = defaultInsights;
          useDefaultInsights = true;
        }
      } catch (error) {
        console.error('Error calling OpenAI API:', error);
        // Use default insights on API error
        insightList = defaultInsights;
        useDefaultInsights = true;
        
        if (error.status === 429) {
          console.warn('OpenAI API rate limit exceeded');
        }
      }
      
      // Store the generated or default insights
      const storedInsights = [];
      const timestamp = new Date();
      
      for (const insight of insightList) {
        const newInsight = await storage.createInsight({
          timestamp: timestamp,
          insight: insight.insight,
          category: insight.category || "suggestion",
          confidence: insight.confidence || "medium",
          isRead: false
        });
        storedInsights.push(newInsight);
      }
      
      // If we used default insights, inform the client
      if (useDefaultInsights) {
        return res.status(201).json({
          insights: storedInsights,
          message: "Used locally generated insights due to API limitations."
        });
      }
      
      res.status(201).json({
        insights: storedInsights
      });
      
    } catch (error) {
      console.error('Error generating insights:', error);
      res.status(500).json({ 
        error: 'Failed to generate AI insights',
        message: "An unexpected error occurred while processing your request."
      });
    }
  });
  
  // Google Analytics Data API proxy endpoint - Real-time data for external websites
  app.post('/api/ga4-data', async (req, res) => {
    try {
      const { websiteId, websiteName, measurementId, metrics, dimensions, dateRange } = req.body;
      
      if (!measurementId) {
        return res.status(400).json({
          error: 'Missing required parameter: measurementId'
        });
      }
      
      // Get real-time data from both WebSocket connections and GA4 service
      try {
        // Get active connections from the WebSocket server for local visitors
        let localActiveUsers = 0;
        
        // Get the active WebSocket connections from the global server instance
        if (global.wss) {
          global.wss.clients.forEach(client => {
            if (client.readyState === WebSocket.OPEN) {
              localActiveUsers++;
            }
          });
        }
        
        // Track the data request in Google Analytics if available
        if (typeof measurementId === 'string' && measurementId.startsWith('G-')) {
          console.log(`Recording real-time analytics event for measurement ID: ${measurementId}`);
        }
        
        // Variables to store the analytics data
        let analyticsData = {
          activeUsers: 0,
          pageViews: 0,
          bounceRate: 0,
          conversionRate: 0, 
          averageSessionDuration: 0
        };
        
        // If we have a specific website name, get real-time data for that website
        if (websiteName) {
          console.log(`Getting real-time data for website: ${websiteName}`);
          
          // Initialize GA4 service if not already initialized
          if (!ga4Service.initialized) {
            await ga4Service.initialize();
          }
          
          // Get real-time data from GA4 for the website
          analyticsData = await ga4Service.getRealTimeData(websiteName);
          
          console.log(`Real-time data for ${websiteName}: active users = ${analyticsData.activeUsers}`);
        } else {
          // For local site with no website name, use WebSocket connections as active users
          analyticsData.activeUsers = localActiveUsers;
        }
        
        // For metrics change calculations, we would normally use historical data
        // from a database. Since we don't have that, we'll return zero for changes
        const previousBounceRate = 0;
        const previousConversionRate = 0;
        const previousSessionDuration = 0;
        
        // Return the real-time analytics data
        res.json({
          // Active users based on the website (real GA4 data) or local connections
          activeUsers: analyticsData.activeUsers,
          
          // These values come from Google Analytics Data API
          bounceRate: analyticsData.bounceRate,
          bounceRateChange: calculatePercentageChange(previousBounceRate, analyticsData.bounceRate),
          conversionRate: analyticsData.conversionRate,
          conversionRateChange: calculatePercentageChange(previousConversionRate, analyticsData.conversionRate),
          averageSessionDuration: analyticsData.averageSessionDuration,
          sessionDurationChange: calculatePercentageChange(previousSessionDuration, analyticsData.averageSessionDuration)
        });
      } catch (gaError) {
        console.error('Error processing real-time analytics data:', gaError);
        return res.status(502).json({
          error: 'Failed to process real-time analytics data',
          message: gaError.message
        });
      }
    } catch (error) {
      console.error('Error in real-time analytics endpoint:', error);
      res.status(500).json({
        error: 'Internal server error processing real-time analytics request',
        message: error.message
      });
    }
  });
  
  // Helper function to calculate percentage change
  function calculatePercentageChange(oldValue: number, newValue: number): number {
    // Ensure we don't do division by zero or return NaN
    if (oldValue === 0 || isNaN(oldValue) || isNaN(newValue)) return 0;
    // Calculate and round to 2 decimal places
    return Math.round(((newValue - oldValue) / oldValue) * 10000) / 100;
  }
  
  // Pattern analysis endpoint using OpenAI GPT-4o
  app.post('/api/patterns/analyze', async (req, res) => {
    try {
      // Validate that we have a valid API key
      if (!process.env.OPENAI_API_KEY) {
        return res.status(503).json({ 
          error: 'OpenAI service unavailable. API key not configured.'
        });
      }

      const { analyticsData } = req.body;
      
      if (!analyticsData) {
        return res.status(400).json({
          error: 'Missing required parameter: analyticsData'
        });
      }

      // Create a better prompt for pattern analysis
      const prompt = `
        Analyze the following analytics data to identify meaningful patterns in user behavior. 
        Focus on finding correlations, trends, and anomalies that would be valuable for business decisions.
        
        For each pattern you identify:
        1. Provide a concise description
        2. Explain why this pattern is significant 
        3. Assign a confidence level (high, medium, low)
        
        Format your response as a JSON object with a "patterns" array containing objects with the fields:
        description, significance, confidence
        
        Analytics data:
        ${JSON.stringify(analyticsData, null, 2)}
      `;
      
      // Use GPT-4o for better analysis
      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          { 
            role: "system", 
            content: "You are an expert data analyst who identifies meaningful patterns in analytics data. Only identify patterns that are clearly supported by the data."
          },
          { role: "user", content: prompt }
        ],
        response_format: { type: "json_object" },
        temperature: 0.5
      });
      
      // Parse the response content
      const patternContent = response.choices[0].message.content ?? '{"patterns":[]}';
      const patternResults = JSON.parse(patternContent);
      
      // Return patterns to the client - send empty array if null
      res.json({
        patterns: patternResults.patterns || [],
        timestamp: new Date().toISOString()
      });
      
    } catch (error) {
      console.error('Error analyzing patterns with OpenAI:', error);
      res.status(500).json({ 
        error: 'Pattern analysis failed',
        message: error.message,
        patterns: [] // Return empty array on error
      });
    }
  });
  
  // Predictive metrics endpoint using OpenAI GPT-4o
  app.post('/api/metrics/predict', async (req, res) => {
    try {
      // Validate that we have a valid API key
      if (!process.env.OPENAI_API_KEY) {
        return res.status(503).json({ 
          error: 'OpenAI service unavailable. API key not configured.'
        });
      }

      const { historicalData } = req.body;
      
      if (!historicalData) {
        return res.status(400).json({
          error: 'Missing required parameter: historicalData'
        });
      }

      // Create a better prompt for metric prediction
      const prompt = `
        Based on the following historical analytics data, predict likely values for the next time period.
        Analyze trends, seasonality, and growth patterns to make evidence-based predictions.
        
        For each metric in the data:
        1. Predict its future value
        2. Provide a confidence score (0-100%)
        3. Include brief reasoning for the prediction
        
        Format your response as a JSON object with a "predictions" object containing key-value pairs
        where each key is a metric name and each value is an object with:
        value (the predicted value), confidence (0-100), reasoning (brief explanation)
        
        Historical data:
        ${JSON.stringify(historicalData, null, 2)}
      `;
      
      // Use GPT-4o for better predictions
      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          { 
            role: "system", 
            content: "You are an expert data scientist who makes evidence-based predictions from historical analytics data. Only provide predictions that are reasonable based on the data trends."
          },
          { role: "user", content: prompt }
        ],
        response_format: { type: "json_object" },
        temperature: 0.3
      });
      
      // Parse the response content
      const predictionContent = response.choices[0].message.content ?? '{"predictions":{}}';
      const predictionResults = JSON.parse(predictionContent);
      
      // Return predictions to the client with timestamp
      res.json({
        predictions: predictionResults.predictions || {},
        timestamp: new Date().toISOString()
      });
      
    } catch (error) {
      console.error('Error predicting metrics with OpenAI:', error);
      res.status(500).json({ 
        error: 'Metric prediction failed',
        message: error.message,
        predictions: {} // Return empty object on error
      });
    }
  });
  
  // Generic OpenAI proxy endpoint to prevent client-side API key exposure
  app.post('/api/openai-proxy', async (req, res) => {
    try {
      // Validate that we have a valid API key
      if (!process.env.OPENAI_API_KEY) {
        return res.status(503).json({ 
          error: 'OpenAI service unavailable. API key not configured.'
        });
      }

      // Get request parameters from client
      const { endpoint, params } = req.body;
      
      // Validate the requested endpoint for security
      const allowedEndpoints = ['chat.completions', 'completions', 'embeddings'];
      if (!allowedEndpoints.includes(endpoint)) {
        return res.status(400).json({ 
          error: 'Invalid OpenAI endpoint requested'
        });
      }

      // Execute the OpenAI request server-side
      let response;
      if (endpoint === 'chat.completions') {
        response = await openai.chat.completions.create(params);
      } else if (endpoint === 'completions') {
        response = await openai.completions.create(params);
      } else if (endpoint === 'embeddings') {
        response = await openai.embeddings.create(params);
      }

      // Return the response to the client
      res.json(response);
    } catch (error) {
      console.error('Error in OpenAI proxy:', error);
      res.status(500).json({ 
        error: 'OpenAI request failed',
        message: error.message
      });
    }
  });

  // Generate recommendations based on analytics and insights
  app.post('/api/recommendations/generate', async (req, res) => {
    try {
      // This would normally use actual analytics data and insights
      const { analyticsData, insights } = req.body;
      
      const prompt = `
        Based on the following website analytics data and existing insights, 
        please provide 3 specific, actionable recommendations to improve website performance.
        
        Focus on concrete actions the website owner can take to improve metrics.
        Respond with a JSON array of objects, each with the following format:
        {
          "title": "Short, action-focused title",
          "description": "Detailed explanation with specific implementation suggestions",
          "category": "One of: performance, marketing, content, testing, design"
        }
        
        Analytics data:
        ${JSON.stringify(analyticsData)}
        
        Existing insights:
        ${JSON.stringify(insights)}
      `;
      
      // Use the user's selected model
      const selectedModel = global.selectedOpenAIModel || 'gpt-4o';
      const response = await openai.chat.completions.create({
        model: selectedModel,
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" }
      });
      
      // Handle possible null content
      const content = response.choices[0].message.content ?? '{"recommendations":[]}';
      const recommendations = JSON.parse(content);
      
      // Store the generated recommendations
      const storedRecommendations = [];
      for (const rec of recommendations.recommendations) {
        const newRec = await storage.createRecommendation({
          timestamp: new Date(),
          title: rec.title,
          description: rec.description,
          category: rec.category,
          implemented: false
        });
        storedRecommendations.push(newRec);
      }
      
      res.json({ recommendations: storedRecommendations });
    } catch (error) {
      console.error('Error generating recommendations:', error);
      res.status(500).json({ error: 'Failed to generate recommendations' });
    }
  });

  // ======= Websites Management Routes =======
  
  // Get all websites or by user ID with caching
  app.get('/api/websites', async (req, res) => {
    try {
      const userId = req.query.userId ? parseInt(req.query.userId as string) : undefined;
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 100;
      
      // Create a cache key based on query parameters
      const cacheKey = userId ? `websites:user:${userId}:limit:${limit}` : `websites:all:limit:${limit}`;
      
      // Use caching for websites (longer TTL than analytics data)
      const websites = await websiteCache.get(cacheKey) || await storage.getWebsites(userId, limit).then(data => {
        // Cache website data for 5 minutes
        websiteCache.set(cacheKey, data, 300);
        return data;
      });
      
      res.json(websites);
    } catch (error) {
      console.error('Error fetching websites:', error);
      res.status(500).json({ error: 'Failed to fetch websites' });
    }
  });
  
  // Get website by ID with caching
  app.get('/api/websites/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const cacheKey = `website:${id}`;
      
      // Use the cache for individual website data
      const website = await websiteCache.get(cacheKey) || await storage.getWebsiteById(id).then(data => {
        // Only cache if website exists
        if (data) {
          // Cache individual website data for 10 minutes
          websiteCache.set(cacheKey, data, 600);
        }
        return data;
      });
      
      if (website) {
        res.json(website);
      } else {
        res.status(404).json({ error: 'Website not found' });
      }
    } catch (error) {
      console.error(`Error fetching website ID ${req.params.id}:`, error);
      res.status(500).json({ error: 'Failed to fetch website' });
    }
  });
  
  // Create website and invalidate cache
  app.post('/api/websites', async (req, res) => {
    try {
      const validatedData = insertWebsiteSchema.parse(req.body);
      const website = await storage.createWebsite(validatedData);
      
      // Invalidate website list caches
      await websiteCache.clear();
      
      res.status(201).json(website);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: error.errors });
      } else {
        console.error('Error creating website:', error);
        res.status(500).json({ error: 'Failed to create website' });
      }
    }
  });
  
  // Update website and invalidate relevant caches
  app.patch('/api/websites/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      const updatedWebsite = await storage.updateWebsite(id, updates);
      
      if (updatedWebsite) {
        // Invalidate specific website cache
        await websiteCache.delete(`website:${id}`);
        // Invalidate all website list caches too
        await websiteCache.clear();
        
        res.json(updatedWebsite);
      } else {
        res.status(404).json({ error: 'Website not found' });
      }
    } catch (error) {
      console.error(`Error updating website ID ${req.params.id}:`, error);
      res.status(500).json({ error: 'Failed to update website' });
    }
  });
  
  // Delete website and invalidate caches
  app.delete('/api/websites/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const result = await storage.deleteWebsite(id);
      
      // Invalidate specific website cache
      await websiteCache.delete(`website:${id}`);
      // Invalidate all website list caches too
      await websiteCache.clear();
      
      res.json({ success: true });
    } catch (error) {
      console.error(`Error deleting website ID ${req.params.id}:`, error);
      res.status(500).json({ error: 'Failed to delete website' });
    }
  });
  
  // ======= Website Credentials Routes =======
  
  // Get credentials for a website
  app.get('/api/websites/:websiteId/credentials', async (req, res) => {
    try {
      const websiteId = parseInt(req.params.websiteId);
      const provider = req.query.provider as string | undefined;
      const credentials = await storage.getWebsiteCredentials(websiteId, provider);
      res.json(credentials);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch credentials' });
    }
  });
  
  // Create credentials for a website
  app.post('/api/websites/:websiteId/credentials', async (req, res) => {
    try {
      const websiteId = parseInt(req.params.websiteId);
      const data = { ...req.body, websiteId };
      const validatedData = insertWebsiteCredentialsSchema.parse(data);
      const credentials = await storage.createWebsiteCredentials(validatedData);
      res.status(201).json(credentials);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: error.errors });
      } else {
        res.status(500).json({ error: 'Failed to create credentials' });
      }
    }
  });
  
  // Update credentials
  app.patch('/api/credentials/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      const updatedCredentials = await storage.updateWebsiteCredentials(id, updates);
      if (updatedCredentials) {
        res.json(updatedCredentials);
      } else {
        res.status(404).json({ error: 'Credentials not found' });
      }
    } catch (error) {
      res.status(500).json({ error: 'Failed to update credentials' });
    }
  });
  
  // Delete credentials
  app.delete('/api/credentials/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteWebsiteCredentials(id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to delete credentials' });
    }
  });
  
  // ======= External Websites Catalog Routes =======
  
  // Get all external websites
  app.get('/api/external-websites', async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 100;
      const websites = await storage.getExternalWebsites(limit);
      res.json(websites);
    } catch (error) {
      console.error('Error getting external websites:', error);
      res.status(500).json({ error: 'Failed to get external websites' });
    }
  });
  



  
  // Get external website by domain
  app.get('/api/external-websites/domain/:domain', async (req, res) => {
    try {
      const website = await storage.getExternalWebsiteByDomain(req.params.domain);
      if (!website) {
        return res.status(404).json({ error: 'External website not found' });
      }
      res.json(website);
    } catch (error) {
      console.error('Error getting external website by domain:', error);
      res.status(500).json({ error: 'Failed to get external website by domain' });
    }
  });
  
  // Create external website
  app.post('/api/external-websites', async (req, res) => {
    try {
      const validatedData = insertExternalWebsiteCatalogSchema.parse(req.body);
      const website = await storage.createExternalWebsite(validatedData);
      res.status(201).json(website);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: error.errors });
      } else {
        console.error('Error creating external website:', error);
        res.status(500).json({ error: 'Failed to create external website' });
      }
    }
  });

  // Update external website
  app.patch('/api/external-websites/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      const website = await storage.updateExternalWebsite(id, updates);
      if (!website) {
        return res.status(404).json({ error: 'External website not found' });
      }
      res.json(website);
    } catch (error) {
      console.error('Error updating external website:', error);
      res.status(500).json({ error: 'Failed to update external website' });
    }
  });
  
  // Delete external website
  app.delete('/api/external-websites/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteExternalWebsite(id);
      res.status(204).end();
    } catch (error) {
      console.error('Error deleting external website:', error);
      res.status(500).json({ error: 'Failed to delete external website' });
    }
  });
  
  // ======= External Website Analytics Routes =======
  
  // Get analytics providers for an external website
  app.get('/api/external-websites/:id/analytics', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const analytics = await storage.getExternalWebsiteAnalytics(id);
      res.json(analytics);
    } catch (error) {
      console.error('Error getting external website analytics:', error);
      res.status(500).json({ error: 'Failed to get external website analytics' });
    }
  });
  
  // Get specific analytics provider for a website
  app.get('/api/external-websites/:id/analytics/:provider', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const provider = req.params.provider;
      const analytics = await storage.getExternalWebsiteAnalyticsByProvider(id, provider);
      if (!analytics) {
        return res.status(404).json({ error: 'Analytics provider not found for this website' });
      }
      res.json(analytics);
    } catch (error) {
      console.error('Error getting external website analytics by provider:', error);
      res.status(500).json({ error: 'Failed to get external website analytics by provider' });
    }
  });
  
  // Get analytics data for external website
  app.post('/api/external-websites/:id/analytics/:metricType', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const metricType = req.params.metricType;
      const { provider, startDate, endDate } = req.body;
      
      // For presentation purposes, we'll return demonstration data
      console.log(`Providing analytics data for external website ${id}, provider ${provider}, metric ${metricType}`);
      
      let data = [];
      switch (metricType) {
        case 'pageviews':
          data = [
            { name: '/home', value: 15250 },
            { name: '/shop', value: 9720 },
            { name: '/blog', value: 6280 },
            { name: '/about', value: 4640 },
            { name: '/contact', value: 3980 },
          ];
          break;
        
        case 'visitors':
          data = [
            { name: '05/07', newUsers: 550, returningUsers: 480 },
            { name: '05/08', newUsers: 570, returningUsers: 510 },
            { name: '05/09', newUsers: 620, returningUsers: 550 },
            { name: '05/10', newUsers: 680, returningUsers: 610 },
            { name: '05/11', newUsers: 720, returningUsers: 640 },
            { name: '05/12', newUsers: 680, returningUsers: 620 },
            { name: '05/13', newUsers: 750, returningUsers: 670 },
          ];
          break;
        
        case 'traffic':
          data = [
            { name: 'Organic Search', value: 7280 },
            { name: 'Direct', value: 5750 },
            { name: 'Social Media', value: 4420 },
            { name: 'Referral', value: 3860 },
            { name: 'Email', value: 2520 },
          ];
          break;
          
        case 'devices':
          data = [
            { name: 'Mobile', value: 8840 },
            { name: 'Desktop', value: 7320 },
            { name: 'Tablet', value: 2680 },
            { name: 'Others', value: 780 },
          ];
          break;
          
        case 'conversion':
          // Apply different conversion rates based on time period
          let conversionScaleFactor = 1.0;
          
          // We apply different scaling factors for different time periods
          switch(dateRange) {
            case '7days':
              conversionScaleFactor = 1.35; // Higher conversion rates for shorter periods
              break;
            case '14days':
              conversionScaleFactor = 1.15; // Slightly higher conversion rates
              break;
            case '30days':
              conversionScaleFactor = 1.0; // Baseline
              break;
            case '90days':
              conversionScaleFactor = 0.75; // Lower conversion rates for longer periods
              break;
            case 'year':
              conversionScaleFactor = 0.55; // Much lower conversion rates for annual data
              break;
            default:
              conversionScaleFactor = 1.0;
          }
          
          // Apply the scale factor to the conversion values
          data = [
            { name: 'Newsletter Signup', value: parseFloat((6.8 * conversionScaleFactor).toFixed(1)) },
            { name: 'Account Creation', value: parseFloat((5.2 * conversionScaleFactor).toFixed(1)) },
            { name: 'Purchase Completion', value: parseFloat((4.1 * conversionScaleFactor).toFixed(1)) },
            { name: 'Add to Cart', value: parseFloat((11.5 * conversionScaleFactor).toFixed(1)) }
          ];
          break;
      }
      
      res.json(data);
    } catch (error) {
      console.error('Error getting external website analytics data:', error);
      res.status(500).json({ error: 'Failed to get external website analytics data' });
    }
  });
  
  // Add analytics provider to a website
  app.post('/api/external-websites/:id/analytics', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const data = { ...req.body, externalWebsiteId: id };
      const validatedData = insertExternalWebsiteAnalyticsSchema.parse(data);
      const analytics = await storage.createExternalWebsiteAnalytics(validatedData);
      res.status(201).json(analytics);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: error.errors });
      } else {
        console.error('Error creating external website analytics:', error);
        res.status(500).json({ error: 'Failed to create external website analytics' });
      }
    }
  });
  
  // ======= External Analytics API Routes =======
  
  // Add an analytics provider for a website
  app.post('/api/websites/:websiteId/analytics/providers', async (req, res) => {
    try {
      const websiteId = parseInt(req.params.websiteId);
      const { provider, credentials } = req.body;
      
      // Validate provider type
      if (!['google', 'adobe'].includes(provider)) {
        return res.status(400).json({ error: 'Unsupported analytics provider' });
      }
      
      // Store credentials for the provider
      await storage.createWebsiteCredentials({
        websiteId,
        provider,
        credentials: JSON.stringify(credentials)
      });
      
      // Create and register provider
      const analyticsProvider = AnalyticsProviderFactory.createProvider(
        provider as 'google' | 'adobe',
        credentials
      );
      
      // Register the provider with a unique name for this website
      const providerName = `${provider}-${websiteId}`;
      analyticsService.registerProvider(providerName, analyticsProvider);
      
      res.status(201).json({ success: true, providerName });
    } catch (error) {
      console.error('Error adding analytics provider:', error);
      res.status(500).json({ error: 'Failed to add analytics provider' });
    }
  });
  
  // Get analytics data from a provider
  app.post('/api/websites/:websiteId/analytics/:metric', async (req, res) => {
    try {
      const websiteId = parseInt(req.params.websiteId);
      const metric = req.params.metric;
      const { provider = 'google', startDate, endDate } = req.body;
      
      // Get the saved credentials
      const credentials = await storage.getWebsiteCredentials(
        websiteId, 
        provider as string
      );
      
      // Use demo credentials if no credentials are found
      let credentialsData = {};
      
      if (credentials && credentials.length > 0) {
        // Parse real credentials
        credentialsData = JSON.parse(credentials[0].credentials);
      } else {
        console.log(`No credentials found for website ${websiteId} and provider ${provider}, using demo data`);
        // Use demo credentials based on provider
        if (provider === 'google') {
          credentialsData = {
            view_id: '12345',
            client_email: 'demo@example.com',
            private_key: 'demo_key'
          };
        } else if (provider === 'adobe') {
          credentialsData = {
            api_key: 'demo_adobe_key',
            client_id: 'demo_client_id',
            client_secret: 'demo_client_secret'
          };
        } else if (provider === 'matomo') {
          credentialsData = {
            site_id: '1',
            auth_token: 'demo_matomo_token',
            api_url: 'https://matomo.example.com/matomo.php'
          };
        } else if (provider === 'hotjar') {
          credentialsData = {
            site_id: '12345',
            auth_token: 'demo_hotjar_token'
          };
        } else if (provider === 'crazyegg') {
          credentialsData = {
            api_key: 'demo_crazyegg_key',
            account_id: 'demo_account_id'
          };
        } else if (provider === 'mixpanel') {
          credentialsData = {
            project_token: 'demo_mixpanel_token',
            api_secret: 'demo_mixpanel_secret'
          };
        } else if (provider === 'segment') {
          credentialsData = {
            write_key: 'demo_segment_write_key'
          };
        } else if (provider === 'amplitude') {
          credentialsData = {
            api_key: 'demo_amplitude_key'
          };
        } else if (provider === 'clicky' || provider === 'piwik' || provider === 'woopra' || 
                  provider === 'kissmetrics' || provider === 'heap') {
          // Generic demo credentials for other providers
          credentialsData = {
            api_key: `demo_${provider}_key`,
            site_id: '12345'
          };
        }
      }
      
      // Create provider if not registered yet
      const providerName = `${provider}-${websiteId}`;
      let analyticsProvider;
      
      try {
        analyticsProvider = analyticsService.getProvider(providerName);
      } catch (error) {
        // Provider not registered yet, create it
        analyticsProvider = AnalyticsProviderFactory.createProvider(
          provider as 'google' | 'adobe' | 'mixpanel' | 'segment' | 'matomo' | 'amplitude' | 'hotjar' | 'crazyegg' | 'clicky' | 'piwik' | 'woopra' | 'kissmetrics' | 'heap',
          credentialsData
        );
        analyticsService.registerProvider(providerName, analyticsProvider);
      }
      
      // Map metric to appropriate method
      let method: keyof AnalyticsProvider;
      switch (metric) {
        case 'pageviews':
          method = 'getPageViews';
          break;
        case 'visitors':
          method = 'getVisitorMetrics';
          break;
        case 'traffic':
          method = 'getTrafficSources';
          break;
        case 'conversion':
          method = 'getConversionRate';
          break;
        case 'devices':
          method = 'getDeviceMetrics';
          break;
        default:
          return res.status(400).json({ error: 'Unsupported metric' });
      }
      
      // Config for the analytics request
      const config = {
        viewId: (credentialsData as any)?.view_id || '12345',
        startDate: startDate as string || '30daysAgo',
        endDate: endDate as string || 'today'
      };
      
      // Get the analytics data
      const data = await analyticsService.getAnalyticsData(
        providerName, 
        method as keyof AnalyticsProvider, 
        config
      );
      res.json(data);
      
    } catch (error) {
      console.error('Error fetching analytics data:', error);
      res.status(500).json({ error: 'Failed to fetch analytics data' });
    }
  });

  return httpServer;
}
