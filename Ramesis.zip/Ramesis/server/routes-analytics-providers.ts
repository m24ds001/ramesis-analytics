import { Request, Response, Express } from 'express';
import { ga4Service } from './services/ga4-service';
import { adobeAnalyticsService } from './services/adobe-analytics-service'; 
import { mixpanelService } from './services/mixpanel-service';

/**
 * Register routes for analytics providers
 */
export const registerAnalyticsProvidersRoutes = (app: Express) => {
  /**
   * GET /api/analytics/providers/status
   * Returns the status of all analytics providers
   */
  app.get('/api/analytics/providers/status', async (_req: Request, res: Response) => {
    try {
      // Get status of each provider
      const status = [
        {
          name: 'Google Analytics',
          isAvailable: await ga4Service.isAvailable(),
          isConfigured: process.env.VITE_GA_MEASUREMENT_ID ? true : false,
          error: process.env.VITE_GA_MEASUREMENT_ID ? undefined : 'Missing GA4 Measurement ID'
        },
        {
          name: 'Adobe Analytics',
          isAvailable: await adobeAnalyticsService.isAvailable(),
          isConfigured: process.env.ADOBE_ANALYTICS_API_KEY && process.env.ADOBE_ANALYTICS_CLIENT_ID ? true : false,
          error: process.env.ADOBE_ANALYTICS_API_KEY && process.env.ADOBE_ANALYTICS_CLIENT_ID ? undefined : 'Missing Adobe Analytics credentials'
        },
        {
          name: 'Mixpanel',
          isAvailable: await mixpanelService.isAvailable(),
          isConfigured: process.env.MIXPANEL_API_KEY && process.env.MIXPANEL_SECRET_KEY ? true : false,
          error: process.env.MIXPANEL_API_KEY && process.env.MIXPANEL_SECRET_KEY ? undefined : 'Missing Mixpanel credentials'
        }
      ];
      
      res.json(status);
    } catch (error) {
      console.error('Error getting analytics providers status:', error);
      res.status(500).json({ error: 'Failed to get analytics providers status' });
    }
  });
};