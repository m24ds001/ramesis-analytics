import { Express, Request, Response, NextFunction } from 'express';
import { z } from 'zod';
import { storage } from './storage';
import { authenticate, authErrorHandler } from './middleware/auth';
import { authRateLimiter } from './middleware/rate-limiter';
import { User } from '@shared/schema';

// Define validation schema for login
const loginSchema = z.object({
  username: z.string().min(3),
  password: z.string().min(6),
});

/**
 * Register authentication-related routes
 */
export const registerAuthRoutes = (app: Express) => {
  // Apply authentication error handler
  app.use(authErrorHandler);

  // Login endpoint with rate limiting
  app.post('/api/auth/login', authRateLimiter, async (req: Request, res: Response) => {
    try {
      // Validate request body
      const result = loginSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ 
          error: 'Invalid login data',
          details: result.error.format()
        });
      }
      
      const { username, password } = result.data;
      
      // Find user by username
      const user = await storage.getUserByUsername(username);
      if (!user) {
        return res.status(401).json({ error: 'Invalid username or password' });
      }
      
      // In a real app, we would verify the password hash here
      // For development, we're just comparing passwords directly
      if (password !== 'password') { // Replace with actual password verification
        return res.status(401).json({ error: 'Invalid username or password' });
      }
      
      // Set user in session
      req.session.user = {
        id: user.id,
        username: user.username,
      };
      
      // Return user data (excluding sensitive info)
      const { id, username: userName, email, role } = user;
      res.json({ id, username: userName, email, role });
    } catch (error) {
      console.error('Login error:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  });

  // Protected route example
  app.get('/api/auth/me', authenticate, (req: Request, res: Response) => {
    // User is guaranteed to exist due to authenticate middleware
    const user = req.session.user as Partial<User>;
    res.json(user);
  });

  // Logout endpoint
  app.post('/api/auth/logout', (req: Request, res: Response) => {
    req.session.destroy(err => {
      if (err) {
        console.error('Error destroying session:', err);
        return res.status(500).json({ error: 'Logout failed' });
      }
      res.json({ success: true });
    });
  });
};