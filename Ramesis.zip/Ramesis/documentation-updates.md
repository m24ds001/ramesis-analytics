# Analytics Platform Documentation Updates

## WebSocket Implementation Details

The analytics platform uses WebSockets for real-time data transmission with the following architecture:

### Key Components:
1. **WebSocket Server**: Runs on a dedicated path (/api/ws) to avoid conflicts with development tools
2. **Client Tracking Library**: Connects to WebSocket server for real-time data transmission
3. **Channel-based Subscriptions**: Clients can subscribe to specific data channels
4. **Heartbeat Mechanism**: Maintains connection health and detects disconnected clients

### Security Features:
- Message validation with Zod schemas
- Error handling for malformed data
- Client authentication (via session cookie)
- Rate limiting for connection attempts

### Connection Flow:
```
Client                                Server
  |                                     |
  |------ WebSocket Connection -------->|
  |                                     |
  |<------ Connection Accepted ---------|
  |                                     |
  |------- Channel Subscription ------->|
  |                                     |
  |<------ Subscription Confirmed ------|
  |                                     |
  |<------- Real-time Updates ----------|
  |                                     |
  |----------- Heartbeat ------------->|
  |                                     |
  |<---------- Heartbeat ACK -----------|
```

## Credential Encryption Flow Diagram

The platform securely manages API credentials using symmetric encryption:

### Storage Process:
```
  ┌─────────────────────┐     ┌─────────────────────┐     ┌─────────────────────┐
  │                     │     │                     │     │                     │
  │  API Credentials    │────▶│  Encryption         │────▶│  Database Storage   │
  │  (Google, Adobe)    │     │  (AES-256)          │     │  (Encrypted String) │
  │                     │     │                     │     │                     │
  └─────────────────────┘     └─────────────────────┘     └─────────────────────┘
                                       │
                                       │
                                       ▼
                              ┌─────────────────────┐
                              │                     │
                              │  Environment        │
                              │  Variable Key       │
                              │                     │
                              └─────────────────────┘
```

### Retrieval Process:
```
  ┌─────────────────────┐     ┌─────────────────────┐     ┌─────────────────────┐
  │                     │     │                     │     │                     │
  │  Database Retrieval │────▶│  Decryption         │────▶│  API Request with   │
  │  (Encrypted String) │     │  (AES-256)          │     │  Decrypted Creds    │
  │                     │     │                     │     │                     │
  └─────────────────────┘     └─────────────────────┘     └─────────────────────┘
                                       ▲
                                       │
                                       │
                              ┌─────────────────────┐
                              │                     │
                              │  Environment        │
                              │  Variable Key       │
                              │                     │
                              └─────────────────────┘
```

## Security Enhancements

The following security improvements have been made to the platform:

1. **Input Validation**: All user inputs are validated using Zod schemas
2. **Data Sanitization**: DOMPurify is used to sanitize data to prevent XSS attacks
3. **Secure Cookies**: Session cookies use SameSite=Strict and Secure flags
4. **API Key Protection**: OpenAI API key is never exposed to the client
5. **Rate Limiting**: Prevents abuse of authentication and API endpoints
6. **Enhanced Error Handling**: Detailed error messages are logged but not exposed to clients
7. **Database Constraints**: Foreign key constraints with cascading delete options

## Accessibility Improvements

The following accessibility enhancements have been implemented:

1. **ARIA Attributes**: Added to icons and interactive elements
2. **Role Definitions**: Clear role definitions for custom components
3. **Focus Management**: Improved keyboard navigation
4. **Color Contrast**: Enhanced visual indicators for data sources
5. **Error States**: Clear error messaging with remediation instructions
6. **Provider Identification**: Consistent visual cues for data sources