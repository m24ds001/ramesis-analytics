# Analytics Platform Reliability Features

This document outlines the reliability features implemented in the analytics platform to ensure robustness, performance, and scalability.

## Monitoring & Observability

### Metrics (Prometheus)
- HTTP request duration metrics with method, path, and status code labels
- Active WebSocket connections gauge
- Database connection pool metrics (total and idle connections)
- Available at `/metrics` endpoint in Prometheus format
- Compatible with Grafana dashboards

### Distributed Tracing (OpenTelemetry)
- Request spans with HTTP method, URL, and status code
- Database operation spans
- Cache operation spans
- Error recording with proper status codes
- Trace context propagation across services

### Health Checks
- Main health check endpoint at `/health`
- Component-specific health endpoints:
  - `/health/liveness` - Used for container orchestration liveness probes
  - `/health/readiness` - Used for container orchestration readiness probes
- Status categories: healthy, degraded, unhealthy
- Component status monitoring for database, API, and OpenAI

## Performance Optimization

### Caching (Redis)
- Analytics data caching (30s TTL)
- Website data caching (5-10m TTL)
- User data caching (30m TTL)
- Automatic fallback to in-memory cache if Redis unavailable
- Cache invalidation on data modification

### Database Optimization
- Strategic indexes for common query patterns:
  - Session-based indexes for user events
  - Timestamp-based indexes for time-series queries
  - Category-based indexes for filtering
  - Domain-based indexes for external websites
- GIN indexes for JSON fields
- Database statistics updated for query planner

## Resilience Testing

### Load Testing
- HTTP endpoint load testing with autocannon
- Configurable connections, duration, and target
- Success rate validation
- Performance metrics reporting

### Chaos Testing
- Database outage simulation
- Automatic recovery verification
- API error handling verification

### Contract Testing
- API schema validation against OpenAPI spec
- Response structure verification
- Status code validation

## Fault Tolerance

### Error Handling
- Consistent error response format
- Detailed logging for debugging
- Graceful degradation
- Circuit breaking for external services

### Database Migration
- Transactional schema updates
- Migration history tracking
- Rollback support

## Usage Instructions

### Running Health Checks
```bash
curl http://localhost:5000/health
```

### Applying Database Migrations
```bash
npx tsx apply-migrations.js
```

### Running Load Tests
```bash
# Basic test
npx tsx tests/load/load-test.js

# Custom test
CONNECTIONS=50 DURATION=30 URL=http://localhost:5000/api/events npx tsx tests/load/load-test.js
```

### Environment Variables
- `REDIS_URL` - Redis connection string (optional, falls back to in-memory cache)
- `DATABASE_URL` - PostgreSQL connection string
- `OPENAI_API_KEY` - OpenAI API key for insights generation