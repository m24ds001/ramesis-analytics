const fs = require('fs');
const path = require('path');
const archiver = require('archiver');

// Create a file to stream archive data to
const output = fs.createWriteStream('analytics-platform-project.zip');
const archive = archiver('zip', {
  zlib: { level: 9 } // Maximum compression
});

// Listen for all archive data to be written
output.on('close', function() {
  console.log(`Project successfully zipped! Total size: ${archive.pointer()} bytes`);
  console.log('File created: analytics-platform-project.zip');
  console.log('You can download this file from your Replit files panel');
});

// Good practice to catch warnings
archive.on('warning', function(err) {
  if (err.code === 'ENOENT') {
    console.warn('Warning:', err);
  } else {
    throw err;
  }
});

// Handle errors
archive.on('error', function(err) {
  throw err;
});

// Pipe archive data to the output file
archive.pipe(output);

// List of directories/files to include
const includeDirs = [
  'client',
  'server',
  'shared'
];

// List of specific files to include from root
const includeFiles = [
  'package.json',
  'tsconfig.json',
  'vite.config.ts',
  'drizzle.config.ts',
  'tailwind.config.ts',
  'postcss.config.js',
  'components.json'
];

// List of directories/files to exclude
const excludeDirs = [
  'node_modules',
  '.git',
  '.cache'
];

// Add directories recursively
includeDirs.forEach(dir => {
  archive.directory(dir, dir, (data) => {
    const filePath = data.name;
    // Check if this file/directory should be excluded
    for (const excludeDir of excludeDirs) {
      if (filePath.includes(excludeDir)) {
        return false; // Skip this file
      }
    }
    return data;
  });
});

// Add individual files from root
includeFiles.forEach(file => {
  if (fs.existsSync(file)) {
    archive.file(file, { name: file });
  }
});

// Add README.md with project information
const readmeContent = `# Advanced Analytics Platform

## Project Overview
An advanced AI-powered website analytics platform that enables multi-source data integration, real-time tracking, and intelligent insights generation through a flexible, extensible analytics provider ecosystem.

## Key Features
- Multi-provider analytics integration (Google, Adobe, Mixpanel, Segment, etc.)
- Real-time user behavior tracking and monitoring
- AI-powered insights using OpenAI's GPT-4o model
- Predictive analytics capabilities
- Custom tracking script for authentic data collection
- Dynamic credentials management for API connections
- External website catalog integration
- Visual data source attribution system

## Technology Stack
- React (TypeScript) frontend
- Node.js and Express backend
- PostgreSQL with Drizzle ORM
- TanStack Query for state management
- Tailwind CSS with Shadcn/UI components
- OpenAI API integration
- WebSockets for real-time communication

## Getting Started
1. Install dependencies: \`npm install\`
2. Start the development server: \`npm run dev\`
3. Open your browser at: \`http://localhost:5000\`

## Environment Variables
The following environment variables are required:
- \`DATABASE_URL\`: PostgreSQL connection string
- \`OPENAI_API_KEY\`: OpenAI API key for AI insights

## Project Structure
- \`/client\`: Frontend React application
- \`/server\`: Backend Express server
- \`/shared\`: Shared types and utilities

## License
This project is for demonstration purposes only.

`;

// Add README file
archive.append(readmeContent, { name: 'README.md' });

// Finalize the archive
archive.finalize();